# 赤い点のついた傘　町の記録

続編のみ　｜　英日対訳読本

傘の持ち主を探していた町に、川の展示室をもう一度開く話が持ち上がる。赤い印は、誰がどんな場面で何のためにつけたのか。写真、舟、町の記録を手に取った人たちが、それぞれの言葉で語る。

四つの連作、計195話。英文28,804語。英文は一文ずつ和訳と対にし、太字の語は巻末の用例索引からたどれる。

以前の版と照合しやすいように、話番号は第50〜244話の通し番号を引き継いでいる。文の前の数字は「話．文」。話末の問いで場面を思い出し、確認には各篇の末尾を使う。

| 収録内容 | 読み始める場所 |
|---|---|
| 第1篇　川の部屋をもう一度 | [第50〜89話](#exp-part-1) |
| 第2篇　水位を記した人たち | [第90〜138話](#exp-part-2) |
| 第3篇　箱に残る声 | [第139〜198話](#exp-part-3) |
| 第4篇　町が開く展覧会 | [第199〜244話](#exp-part-4) |
| 用例索引 | [名詞](#lex-noun) ／ [動詞](#lex-verb) ／ [形容詞](#lex-adjective) |

---

<a id="exp-part-1"></a>

## 第1篇　川の部屋をもう一度

一月、父と私は赤い印のある傘を貸すことにした。川の部屋を再現するには、展示物がもとの暮らしの中で何に使われていたかを、ひとつずつ確かめなくてはならない。

[50　開ける順番](#ex-story-050) ／ [51　二つの岸のあいだ](#ex-story-051) ／ [52　水位の跡](#ex-story-052) ／ [53　地下に残った仕事](#ex-story-053)

[54　鉱員の服](#ex-story-054) ／ [55　箱に残った音](#ex-story-055) ／ [56　地図を逆にした舟乗り](#ex-story-056) ／ [57　青い封筒を開く](#ex-story-057)

[58　棚に出さない一枚](#ex-story-058) ／ [59　避難所の台所](#ex-story-059) ／ [60　庭で眠る種](#ex-story-060) ／ [61　女王の最後の夜](#ex-story-061)

[62　衣装部屋の女王](#ex-story-062) ／ [63　王国が失ったもの](#ex-story-063) ／ [64　巡回法廷の木箱](#ex-story-064) ／ [65　看板の裏の数字](#ex-story-065)

[66　駅の裏口の行列](#ex-story-066) ／ [67　白いバッジを外した人](#ex-story-067) ／ [68　走る人と数える人](#ex-story-068) ／ [69　カメラのとらえた三秒](#ex-story-069)

[70　雨の峡谷の声](#ex-story-070) ／ [71　絵から外れたもの](#ex-story-071) ／ [72　録音にまじった笑い声](#ex-story-072) ／ [73　本の背から画面へ](#ex-story-073)

[74　誰が見ているか](#ex-story-074) ／ [75　焼け残った鐘](#ex-story-075) ／ [76　静かな部屋に描かれた獣](#ex-story-076) ／ [77　土の中のパイオニア](#ex-story-077)

[78　水が運んだ粉](#ex-story-078) ／ [79　看護学校への手紙](#ex-story-079) ／ [80　校門の小さな地図](#ex-story-080) ／ [81　橋を支えた石](#ex-story-081)

[82　広場を巡る二つの考え](#ex-story-082) ／ [83　小包の赤いひも](#ex-story-083) ／ [84　浅い眠りの窓辺](#ex-story-084) ／ [85　本物の月はどちらか](#ex-story-085)

[86　暮らしを取り戻した人](#ex-story-086) ／ [87　ごみの箱を開ける](#ex-story-087) ／ [88　二枚の札で違うことを言う](#ex-story-088) ／ [89　赤い点を探しに](#ex-story-089)

<a id="ex-story-050"></a>

### 50　開ける順番

<a id="x050-01"></a>

**50.01**　The **invitation** came on a **grey** **Wednesday** in **January**.

> 招待状が届いたのは、一月の空が灰色に曇った水曜日だった。

<a id="x050-02"></a>

**50.02**　My **acceptance** went back the same **day**.

> 私はその日のうちに参加すると返事をした。

<a id="x050-03"></a>

**50.03**　The town wanted to **reconstruct** the lost river room for its **exhibition**.

> 町は展示のために、失われた川の部屋を再現しようとしていた。

<a id="x050-04"></a>

**50.04**　My father and I could **lend** them the umbrella with the red **mark**.

> 父と私は、赤い印のついたあの傘を貸すことができた。

<a id="x050-05"></a>

**50.05**　But what did an umbrella have to **do** with the **history** of our **village**?

> けれど、傘と私たちの村の歴史に何の関係があるのだろう。

<a id="x050-06"></a>

**50.06**　The **key** was in a **little** **tin** under a **wooden** **ladder**.

> 鍵は木のはしごの下の、小さな缶に入っていた。

<a id="x050-07"></a>

**50.07**　A length of **thread** **bound** it to a **note**.

> 一本の糸で、鍵と書き置きが結んであった。

<a id="x050-08"></a>

**50.08**　“**Open** the **window** before you **move** the **clock**.”

> 「時計を動かす前に窓を開けること。」

<a id="x050-09"></a>

**50.09**　There was a **knock** behind us.

> 後ろで戸をたたく音がした。

<a id="x050-10"></a>

**50.10**　A **young** woman held a **curved** **handle** in one hand.

> 若い女性が片手に曲がった取っ手を持っていた。

<a id="x050-11"></a>

**50.11**　“Does this **belong** to the clock?” she asked.

> 「これはその時計の部品ですか」と彼女は尋ねた。

<a id="x050-12"></a>

**50.12**　It was the missing handle from the window.

> それは窓からなくなっていた取っ手だった。

**読みの問い**　時計を動かす前に窓を開けられたのはなぜか。

<a id="ex-story-051"></a>

### 51　二つの岸のあいだ

<a id="x051-01"></a>

**51.01**　From the **window** we saw the **opposite** **bank** and the **bare** **tree** where the **boat** once stopped.

> 窓からは対岸と、かつて舟が着いた場所に立つ葉のない木が見えた。

<a id="x051-02"></a>

**51.02**　The woman had been the last child to **cross** there before the **flood**.

> 洪水の前、あそこで最後に川を渡った子どもが彼女だった。

<a id="x051-03"></a>

**51.03**　She remembered the **rope** going **tight** under her **thumb**.

> 親指の下で綱がぴんと張った感触を、彼女は覚えていた。

<a id="x051-04"></a>

**51.04**　She could still **feel** the pull in her wrist.

> 今でも手首を引かれる感じがするという。

<a id="x051-05"></a>

**51.05**　Her **grandparent** had drawn the **route** on a **sheet** with a **soft** **stick**.

> 彼女の祖父母の一人が、柔らかい棒を使って、一枚の紙にその経路を描いていた。

<a id="x051-06"></a>

**51.06**　It showed the **distance** from the **island** to the **beach** in **miles**.

> 島から浜までの距離がマイルで記されていた。

<a id="x051-07"></a>

**51.07**　We spread it across a **round** table and **traced** the thin line.

> 私たちは丸いテーブルに紙を広げ、細い線をたどった。

<a id="x051-08"></a>

**51.08**　The **boundary** had **changed** after a **severe** **winter**.

> 厳しい冬を経て境界は変わっていた。

<a id="x051-09"></a>

**51.09**　“What did that do to the people on the island?”

> 「それで島の人たちはどうなったの？」

<a id="x051-10"></a>

**51.10**　“They kept their **land** but lost the **way** to the **shop**.”

> 「土地はそのままでも、店に行く道がなくなったの。」

**読みの問い**　地図の線が変わったことで、島の人の生活はどう変わったか。

<a id="ex-story-052"></a>

### 52　水位の跡

<a id="x052-01"></a>

**52.01**　A **horizontal** line ran across the **basement** wall at the height of my **neck**.

> 地下室の壁には、私の首の高さに横線が走っていた。

<a id="x052-02"></a>

**52.02**　The **guide** said the water had reached a record **high** in **April**.

> 案内人によると、四月には水位が過去最高に達したという。

<a id="x052-03"></a>

**52.03**　He **placed** his **finger** against the line and drew it along a crack.

> 彼はその線に指を当て、裂け目に沿って指を動かした。

<a id="x052-04"></a>

**52.04**　The workers had hidden the **damage** under a **layer** of **white** paint.

> 職人たちは傷んだ部分を白い塗料で塗り隠していた。

<a id="x052-05"></a>

**52.05**　We could **remove** the paint or **retain** it as a **record** of the repair.

> 私たちは塗料を取り除くことも、補修の記録として残すこともできた。

<a id="x052-06"></a>

**52.06**　Our first vote produced a **tie**.

> 最初の投票では同数だった。

<a id="x052-07"></a>

**52.07**　The **former** **miner** said, “Shine a light along the wall.”

> 元鉱員が「壁に沿って明かりを当ててごらん」と言った。

<a id="x052-08"></a>

**52.08**　Every **subtle** **shade** appeared in the **still** air.

> 静かな空気の中で、かすかな陰影が一つ残らず浮かび上がった。

<a id="x052-09"></a>

**52.09**　The absence of paint on one small patch was enough.

> 塗料のない小さな部分がひとつあれば、それで十分だった。

<a id="x052-10"></a>

**52.10**　We left the rest for a future generation to **discover**.

> 残りは将来の世代が自分で見つけられるように残した。

**読みの問い**　壁全体の塗料を取り除かなかったのはなぜか。

<a id="ex-story-053"></a>

### 53　地下に残った仕事

<a id="x053-01"></a>

**53.01**　The **inspector** came with an engineer to **estimate** the **expense** of making the **entire** room **safe**.

> 部屋全体を安全にする費用を見積もるため、検査官が技師とやって来た。

<a id="x053-02"></a>

**53.02**　A **leak** above the **machinery** had let water into the **only** working **motor**.

> 機械の上から水が漏れ、唯一動いていたモーターに入り込んでいた。

<a id="x053-03"></a>

**53.03**　The **operator** had pulled a **switch** to **shut** down the **power**.

> 運転係はスイッチを引いて電源を落としていた。

<a id="x053-04"></a>

**53.04**　A **flash** from the **broken** **circuit** had left a black ring on the wall.

> 壊れた回路から火花が散り、壁に黒い輪が残っていた。

<a id="x053-05"></a>

**53.05**　The **battery** was **dead** and the **magnetic** door would never **hold** again.

> 電池は完全に切れ、磁石式の扉はもう閉まった状態を保てなかった。

<a id="x053-06"></a>

**53.06**　Our **budget** would **allow** us to **repair** one **item** this **year**.

> 今年の予算で直せるのは一つだった。

<a id="x053-07"></a>

**53.07**　A **local** **entrepreneur** offered to establish a **fund** for **maintenance** and charge no **fee**.

> 地元の起業家が、手数料を取らずに維持管理のための基金を設けると申し出た。

<a id="x053-08"></a>

**53.08**　His **condition** was an **exclusive** **contract** to **market** a **model** of the clock.

> 彼が出した条件は、時計の模型を独占的に販売する契約だった。

<a id="x053-09"></a>

**53.09**　The **clerk** read the **agreement** twice and **highlighted** a **restrictive** line.

> 事務員は契約書を二度読み、制限の厳しい一行に印をつけた。

<a id="x053-10"></a>

**53.10**　Even a **photograph** of the original clock would **require** a **licence**.

> もとの時計を写真に撮るだけでも許可が必要になる。

<a id="x053-11"></a>

**53.11**　We sent the **draft** back with one **amendment** and waited for a reply.

> 私たちは修正を一つ加えて草案を送り返し、返事を待った。

**読みの問い**　時計の写真を自由に撮れるようにするには何を変える必要があったか。

<a id="ex-story-054"></a>

### 54　鉱員の服

<a id="x054-01"></a>

**54.01**　The miner came back with his **clothes** in a sack.

> 元鉱員が仕事着を袋に詰めて再び来た。

<a id="x054-02"></a>

**54.02**　A **thick** **fabric** protected his **leg** below the knee.

> 厚い生地が膝から下を守っていた。

<a id="x054-03"></a>

**54.03**　His **cap** still held a **trace** of red **dirt**.

> 帽子にはまだ赤土が少しついていた。

<a id="x054-04"></a>

**54.04**　There was a **badge** inside his coat and a **button** missing from the **left** pocket.

> 上着の内側には記章があり、左のポケットのボタンが一つ取れていた。

<a id="x054-05"></a>

**54.05**　The **thread** had **snapped** when a **hook** caught the **material**.

> 鉤が生地に引っ掛かったとき、糸がぷつんと切れたのだ。

<a id="x054-06"></a>

**54.06**　He **brushed** the dust away with a small **brush** and looked at the label.

> 彼は小さなブラシでほこりを払い、札に目をやった。

<a id="x054-07"></a>

**54.07**　“Please correct the **name** before anyone sees it.”

> 「誰かが見る前に、名前を直してください。」

<a id="x054-08"></a>

**54.08**　The **correction** concerned his **companion**, who had **died** in the same **pit**.

> 訂正が必要なのは、同じ坑内で亡くなった仕事仲間の名前だった。

<a id="x054-09"></a>

**54.09**　His **widow** had given him the coat to wear at the **memorial**.

> 仲間の妻は、追悼式に着ていけるように彼に上着を渡したのだった。

<a id="x054-10"></a>

**54.10**　The **ownership** had **passed** to him, but the memory stayed with them both.

> 上着は彼のものになっても、思い出は二人のもとに残っていた。

**読みの問い**　鉱員が札の訂正を求めたのはなぜか。

<a id="ex-story-055"></a>

### 55　箱に残った音

<a id="x055-01"></a>

**55.01**　A **musician** wanted to **capture** the sound of the clock for a **solo** **concert**.

> ある音楽家が独奏会のために時計の音を録りたいと言った。

<a id="x055-02"></a>

**55.02**　She brought a **drum**, a bass and a tiny **receiver**.

> 彼女が持ってきたのは太鼓とベース、それに小さな受信機だった。

<a id="x055-03"></a>

**55.03**　The low **bass** made the floor shake.

> その低音で床が震えた。

<a id="x055-04"></a>

**55.04**　We had to **sit** in **silent** rows through a **long** **interval**.

> 長い間、私たちは何列かに並んで静かに座っていなければならなかった。

<a id="x055-05"></a>

**55.05**　At last a single **note** rose above the noise of the **old** **electronics**.

> やがて古い電子機器の雑音の中から、ひとつの音が際立って聞こえてきた。

<a id="x055-06"></a>

**55.06**　She **echoed** the **tune** on her bass and **varied** the **speed** with each **repeat**.

> 彼女はベースでその旋律をまねし、繰り返すたびに速さを変えた。

<a id="x055-07"></a>

**55.07**　The **audience** heard a **trio** where there was **only** one player.

> 演奏者は一人なのに、聴衆には三重奏が聞こえた。

<a id="x055-08"></a>

**55.08**　A boy with a punk **T-shirt** started singing in **harmony** with the low notes.

> パンクのＴシャツを着た少年が、低い音に合わせてハーモニーをつけて歌い始めた。

<a id="x055-09"></a>

**55.09**　He had learnt the song from a **CD** his **mother** played while **cooking**.

> お母さんが料理中にかけていたＣＤで、その歌を覚えたという。

<a id="x055-10"></a>

**55.10**　The **recording** caught his **breath**, then a **sudden** **knock** from the **corridor**.

> 録音には彼の息づかいと、それに続いて廊下から突然聞こえたノックが入っていた。

<a id="x055-11"></a>

**55.11**　“Leave that in,” said the musician with a **grin**.

> 音楽家はにっと笑って「そこも残して」と言った。

**読みの問い**　録音に残した予定外の音は何か。

<a id="ex-story-056"></a>

### 56　地図を逆にした舟乗り

<a id="x056-01"></a>

**56.01**　The **crew** from the **port** came to **guide** us through a map of the **ocean**.

> 港の乗組員たちが、大洋の地図の読み方を教えに来てくれた。

<a id="x056-02"></a>

**56.02**　In the **east** a **naval** **fleet** once carried **cargo** along the **border**.

> 東では、かつて海軍の船団が国境に沿って積み荷を運んでいた。

<a id="x056-03"></a>

**56.03**　One **barrel** contained **salt** and another held **sugar** for the **island**.

> ひと樽には塩が、もうひと樽には島に届ける砂糖が入っていた。

<a id="x056-04"></a>

**56.04**　On each return **cruise** the ships carried **fish** and **local** farm **produce**.

> 戻る航海のたびに、船は魚と地元の農産物を運んだ。

<a id="x056-05"></a>

**56.05**　I tried to **picture** a **giant** **sail** above the deck.

> 私は甲板の上に張った巨大な帆を思い描こうとした。

<a id="x056-06"></a>

**56.06**　The **chief** turned the map through half a circle to **illustrate** a **marine** danger.

> 船長は海の危険を説明するため、地図を半回転させた。

<a id="x056-07"></a>

**56.07**　“People **mistake** the **shade** of blue for a measure of depth.”

> 「青の濃さを深さの目安と取り違える人がいる。」

<a id="x056-08"></a>

**56.08**　“We used colour to indicate the direction of the flow.”

> 「私たちは流れの向きを示すのに色を使ったのです。」

<a id="x056-09"></a>

**56.09**　His **finger** followed the **south** coast and stopped at a patch of **sand**.

> 彼の指が南岸をたどり、砂地のところで止まった。

<a id="x056-10"></a>

**56.10**　“Here we could **sail** in, but we had to **drag** the boat out.”

> 「ここへは舟で入れたが、出すときは引きずらなければならなかった。」

**読みの問い**　青の濃さはこの地図では何を表していたか。

<a id="ex-story-057"></a>

### 57　青い封筒を開く

<a id="x057-01"></a>

**57.01**　The **nurse** from the **district** hospital brought a **file** and a plain blue envelope.

> 地区病院の看護師がファイルと青い無地の封筒を持ってきた。

<a id="x057-02"></a>

**57.02**　Inside was a **journal** kept by the first **physician** to **treat** the **epidemic**.

> 封筒の中には、その流行病を最初に治療した医師の日誌が入っていた。

<a id="x057-03"></a>

**57.03**　The **beginning** described the **mild** **symptoms** of an **infection** in the **lung**.

> 最初に、肺の感染症が引き起こす軽い症状のことが書かれていた。

<a id="x057-04"></a>

**57.04**　A **dry** throat could **last** two weeks, and breathing could become **painful** in the days that **followed**.

> 喉が乾いた状態が二週間続くことがあり、その後の数日間に、呼吸のたびに痛むようになることもあった。

<a id="x057-05"></a>

**57.05**　A **surgeon** devised an **apparatus** to help the patient **breathe** and **endure** the **pain**.

> ある外科医が患者の呼吸を助け、痛みに耐えられるようにする器具を考案した。

<a id="x057-06"></a>

**57.06**　The only **available** **pill** offered relief but no **cure**.

> そのとき手に入る唯一の錠剤は苦痛を和らげるだけで、病気そのものを治せなかった。

<a id="x057-07"></a>

**57.07**　Every **measurement** of temperature and **pulse** went into a separate **document**.

> 体温と脈拍の測定値はすべて、別の書類に記録された。

<a id="x057-08"></a>

**57.08**　A mark in the **blood** column was an **indication** of a **probable** **kidney** problem.

> 血液の欄の印は、腎臓に問題が起きている可能性が高いことを示していた。

<a id="x057-09"></a>

**57.09**　The **medical** staff had to **interpret** each **test** with **discretion**.

> 医療スタッフは、一つ一つの検査結果を慎重に読み取る必要があった。

<a id="x057-10"></a>

**57.10**　The latter pages asked whether changes in **diet** could improve **well-being** after a **severe** illness.

> 日誌の後半では、重い病気をした後、食事を変えると体調が良くなるかを問いかけていた。

<a id="x057-11"></a>

**57.11**　“Early **detection** helps,” said the nurse, “but a record of two people cannot establish **causation**.”

> 「早期発見は役に立ちます。でも二人分の記録だけで因果関係は示せません」と看護師は言った。

**読みの問い**　医師の記録からは何を断定できないか。

<a id="ex-story-058"></a>

### 58　棚に出さない一枚

<a id="x058-01"></a>

**58.01**　A **mother** had given her daughter an **oral** account of a difficult **pregnancy** and **birth**.

> ある母親が、つらかった妊娠と出産について娘に口頭で話していた。

<a id="x058-02"></a>

**58.02**　She had discussed **abortion** with her doctor and asked for **counselling** about **abuse** at home.

> 彼女は医師に中絶について相談し、家庭内の虐待についてカウンセリングを求めていた。

<a id="x058-03"></a>

**58.03**　The daughter gave us a **tape** on **permanent** loan, then expressed **doubt** about public **disclosure**.

> 娘はテープを期限を設けず貸してくれたが、公開することには疑問を口にした。

<a id="x058-04"></a>

**58.04**　The **therapist** said we had an **obligation** to respect her **dignity**.

> セラピストは、本人の尊厳を守る義務が私たちにはあると言った。

<a id="x058-05"></a>

**58.05**　A **healthy** **society** must **allow** people to **remain** **silent** about **mental** and **physical** **injury**.

> 健全な社会には、心や体の傷について口を閉ざす自由がなければならない。

<a id="x058-06"></a>

**58.06**　The **psychologist** also asked us to consider the **vulnerability** of a **young** **listener**.

> 心理士からは、若い聞き手の傷つきやすさも考慮してほしいと言われた。

<a id="x058-07"></a>

**58.07**　Our **decision-making** took a whole afternoon because the **panel** could not **agree**.

> 委員の意見が一致せず、決めるのに午後いっぱいかかった。

<a id="x058-08"></a>

**58.08**　The daughter finally withdrew her offer with a **calm** **expression**.

> 娘は最後には穏やかな表情で申し出を取り下げた。

<a id="x058-09"></a>

**58.09**　All we put on **display** was the umbrella under which the two had once walked together.

> 私たちが展示したのは、かつて母と娘が二人で差して歩いた傘だけだった。

**読みの問い**　娘のテープを展示しなかったのはなぜか。

<a id="ex-story-059"></a>

### 59　避難所の台所

<a id="x059-01"></a>

**59.01**　The **municipal** **hall** had been a **refuge** during the **emergency**.

> 市のホールは災害の間、避難所になっていた。

<a id="x059-02"></a>

**59.02**　Its **oven** could **produce** a hundred rolls before first light.

> そこのオーブンなら夜明けまでにロールパンを百個焼けた。

<a id="x059-03"></a>

**59.03**　One **dairy** farmer gave a **litre** of **milk** for each **house** that lost its supply.

> ある酪農家は、牛乳が届かなくなった各家庭に一リットルずつ届けた。

<a id="x059-04"></a>

**59.04**　The **menu** offered a hot **dish** of **onion** and **herbs**, then an **apple** or an **orange**.

> 献立はタマネギと香草の温かい料理、そのあとにリンゴかオレンジだった。

<a id="x059-05"></a>

**59.05**　A **boy** asked for **ice cream** and the cook **spared** him a **bit** of **chocolate**.

> 男の子がアイスクリームをねだると、料理係はチョコを少し分けてくれた。

<a id="x059-06"></a>

**59.06**　She **melted** the rest into a **rich** **blend** of milk and sugar.

> 残りのチョコは、ミルクと砂糖を混ぜた濃厚な液に溶かした。

<a id="x059-07"></a>

**59.07**　I could almost **taste** it as I unfolded her **shopping** list.

> 彼女の買い物リストを広げていると、その味までしてくるようだった。

<a id="x059-08"></a>

**59.08**　At the bottom two lines read, “**Reserve** one **sweet** for each child.”

> 下の二行には「子ども一人につき、お菓子を一つ取っておくこと」と書いてあった。

<a id="x059-09"></a>

**59.09**　“Please **wipe** the **glass** and leave a **clean** **towel** on the **rail**.”

> 「ガラスを拭き、タオル掛けに清潔なタオルを掛けておいてください。」

<a id="x059-10"></a>

**59.10**　I had expected a story of heroes and found a **habit** of looking after people.

> 英雄の物語を予想していた私は、人の世話を普段から続けてきた暮らしに出会った。

**読みの問い**　買い物リストを広げた語り手は何を想像したか。

<a id="ex-story-060"></a>

### 60　庭で眠る種

<a id="x060-01"></a>

**60.01**　The **garden** behind the **cottage** was **wild** when a **lonely** **widow** took it over.

> 夫を亡くし、寂しさを抱えた女性が管理を引き継いだころ、その小さな家の裏庭は荒れ放題だった。

<a id="x060-02"></a>

**60.02**　She had no **agricultural** **training** but knew how to **cultivate** a **crop** on half an **acre**.

> 農業の訓練は受けていなかったが、半エーカーの土地で作物を育てる方法は知っていた。

<a id="x060-03"></a>

**60.03**　She would **water** the **grass** at night and **harvest** the seed before **autumn**.

> 夜になると草に水をやり、秋を迎える前に種を取った。

<a id="x060-04"></a>

**60.04**　Some native **species** **grew** well under the **bush** at the **east** end.

> 在来種のいくつかは、東端の低木の下でよく育った。

<a id="x060-05"></a>

**60.05**　Inside the **greenhouse** she kept a **worm** in a glass container and a **poisonous** **chemical** in a **shut** cupboard.

> 温室ではガラスの容器にミミズを入れ、毒性のある薬品は戸を閉めた戸棚にしまっていた。

<a id="x060-06"></a>

**60.06**　A **rat** could **consume** the seed in a single night.

> ネズミ一匹でも、一晩で種を食べてしまう可能性があった。

<a id="x060-07"></a>

**60.07**　A **snake** was its natural **predator** and could control its numbers.

> ヘビはその天敵で、ネズミの数を抑えられた。

<a id="x060-08"></a>

**60.08**　On our winter visit, one **flower** remained **frozen** beneath a **thick** sheet of ice.

> 冬に訪ねたとき、一輪の花が厚い氷の下で凍ったまま残っていた。

<a id="x060-09"></a>

**60.09**　It was the **only** one we could identify from the **old** **illustration** in her **journal**.

> 彼女の日誌にある古い挿絵から種類を特定できたのは、その花だけだった。

<a id="x060-10"></a>

**60.10**　We **attached** her drawing to a **stake** and waited for the first green leaf.

> 私たちはその絵を杭に留め、最初の緑の葉を待った。

**読みの問い**　ネズミの数を自然に抑えられるものは何か。

<a id="ex-story-061"></a>

### 61　女王の最後の夜

<a id="x061-01"></a>

**61.01**　A **renowned** **writer** agreed to **compose** a play for our **upcoming** **festival**.

> 名の知れた作家が、来たる祭りのために劇を書くことを引き受けた。

<a id="x061-02"></a>

**61.02**　Her **ambitious** **novel** had won a **prestigious** award for its picture of a **queen**.

> 彼女の意欲作である小説は、女王の描写で名誉ある賞を受けていた。

<a id="x061-03"></a>

**61.03**　She wanted to **adapt** the book for a **local** **cast** and **centre** the story on the **final** night of the **reign**.

> 小説を地元の役者向けに脚色し、女王の治世が終わる一夜に焦点を当てたいという。

<a id="x061-04"></a>

**61.04**　The **beloved** queen must **face** a **coup** by a **corrupt** **general** who **possesses** the only **gun**.

> 慕われていた女王は、唯一の銃を持つ腐敗した将軍が起こすクーデターに直面する。

<a id="x061-05"></a>

**61.05**　A **soldier** must choose between an order to **imprison** her and a promise to **uphold** the **constitution**.

> 兵士は、女王を投獄せよとの命令と、憲法を守るという誓いの間で選択を迫られる。

<a id="x061-06"></a>

**61.06**　The first **scene** was a **brief** **encounter** with a **spy** inside the **chamber**.

> 最初の場面は、部屋の中で女王がスパイとつかの間顔を合わせるところだった。

<a id="x061-07"></a>

**61.07**　The **armed** spy could **betray** the queen or **guide** her through a secret passage to safety.

> 武装したスパイには、女王を裏切ることも、抜け道で安全な場所へ案内することもできた。

<a id="x061-08"></a>

**61.08**　A **teenage** **amateur** was **cast** as the spy for her **debut**.

> 初舞台を踏む十代のアマチュアがスパイ役に選ばれた。

<a id="x061-09"></a>

**61.09**　She made a **decisive** **gesture** and **bowed** before the queen without taking her **gaze** off the gun.

> 彼女はきっぱりとしたしぐさで女王に一礼したが、銃からは目を離さなかった。

<a id="x061-10"></a>

**61.10**　The **ending** was a surprise even to the **author**, who had never seen the **fragile** queen as the **real** **contender** for **power**.

> 最後の場面には作家自身も驚いた。あの頼りなく見える女王が実際に権力を争う人物だとは、それまで考えていなかったからだ。

**読みの問い**　史劇の冒頭でスパイにはどんな選択があったか。

<a id="ex-story-062"></a>

### 62　衣装部屋の女王

<a id="x062-01"></a>

**62.01**　The **dress** was too **elegant** for a woman about to **flee** her **homeland**.

> 祖国から逃れようとする女性にしては、そのドレスはあまりに優雅だった。

<a id="x062-02"></a>

**62.02**　A **blonde** actor took off the **fashionable** **skirt** and asked to **dress** in a **simple** shirt.

> 金髪の俳優は流行のスカートを脱ぎ、簡素なシャツに着替えたいと言った。

<a id="x062-03"></a>

**62.03**　“I **like** the **fancy** **jewellery**, but the **diamond** will **distract** the **audience**.”

> 「豪華な宝石は好きだけれど、そのダイヤがあると観客の注意がそれます。」

<a id="x062-04"></a>

**62.04**　The designer had used **pure** **glass** to **manufacture** an **attractive** copy at **minimum** **expense**.

> 衣装担当者は費用を最小限に抑え、純粋なガラスで見栄えのする模造品を作っていた。

<a id="x062-05"></a>

**62.05**　To **spoil** the shine, the spy pressed a **thumb** against the **precious** stone.

> スパイ役は石の輝きを曇らせようと、貴重に見える石に親指を押しつけた。

<a id="x062-06"></a>

**62.06**　She tied her hair with a **strand** from a **rope** and **ironed** the shirt until it was smooth.

> 彼女は縄をほぐした一本で髪を結び、シャツのしわがなくなるまでアイロンをかけた。

<a id="x062-07"></a>

**62.07**　When she **stepped** into the **spotlight**, her plain clothes cast a **dramatic** **shape** on the wall.

> スポットライトに足を踏み入れると、質素な衣装が壁に印象的な影を落とした。

<a id="x062-08"></a>

**62.08**　The **delighted** writer **grinned** at the director, who merely **nodded**.

> 喜んだ作家が監督の方を見てにっと笑うと、監督はただうなずいた。

<a id="x062-09"></a>

**62.09**　“Now we **know** who the queen is without the glory of a crown.”

> 「これで王冠の華やかさがなくても、誰が女王か分かる。」

**読みの問い**　脚本家と監督が満足したのはどんな衣装か。

<a id="ex-story-063"></a>

### 63　王国が失ったもの

<a id="x063-01"></a>

**63.01**　The **teacher** wanted to **introduce** the play to a **secondary** class studying **empire** and **slavery**.

> 教師は、帝国と奴隷制を学ぶ中等学校のクラスに、この劇を紹介しようとした。

<a id="x063-02"></a>

**63.02**　The **textbook** described a **dominant** **regime**, a **wealthy** **colony** and a **distant** **territory**.

> 教科書には、支配的な政権と裕福な植民地、それに遠く離れた領土が出てきた。

<a id="x063-03"></a>

**63.03**　A **crude** **cartoon** showed a **naked** **native** carrying a bag of **trading** goods.

> 粗雑な風刺画には、交易品の袋を運ぶ裸の現地人が描かれていた。

<a id="x063-04"></a>

**63.04**　Its **racist** message had been **propaganda** for a **vicious** campaign of **removal**.

> その人種差別的なメッセージは、住民を追放する残忍な運動のための宣伝だった。

<a id="x063-05"></a>

**63.05**　We asked an **indigenous** historian to **contrast** that picture with the **actual** **landscape**.

> 私たちは先住民の歴史家に、その絵と現地の実際の風景を比べ、違いを示してほしいと頼んだ。

<a id="x063-06"></a>

**63.06**　Five million people had lived there before the first foreign **settlement**.

> 外国人が最初の集落を築く前から、そこには五百万人の人が暮らしていた。

<a id="x063-07"></a>

**63.07**　A **veteran** described a **massacre** in which a **desperate** **mob** attacked an **isolated** village.

> 退役軍人は、追い詰められた暴徒が人里離れた村を襲ったときの虐殺を語った。

<a id="x063-08"></a>

**63.08**　“The word **genocide** has a specific **meaning** in **international** **law**,” the historian said.

> 「ジェノサイドという言葉は、国際法では特定の意味を持ちます」と歴史家は言った。

<a id="x063-09"></a>

**63.09**　“**Investigate** what happened, **acknowledge** the **deaths**, and resist attempts to **simplify** the past.”

> 「起きたことを調べ、人々が命を落とした事実を認めてください。過去を単純に片づけようとする試みに抵抗してください。」

<a id="x063-10"></a>

**63.10**　The class **revised** the **commentary** and asked him to **attend** the **final**.

> クラスのみんなは解説を書き直し、彼に決勝を見に来てほしいと頼んだ。

**読みの問い**　歴史家は絵と何を比べたか。

<a id="ex-story-064"></a>

### 64　巡回法廷の木箱

<a id="x064-01"></a>

**64.01**　The **court** once occupied the same **site** as the **former** railway **terminal**.

> 巡回法廷は、昔の鉄道の終点と同じ敷地に置かれた時期があった。

<a id="x064-02"></a>

**64.02**　A **warrant** gave the **police** permission to search a **warehouse** after a **robbery**.

> 強盗の後、警察は令状によって倉庫を捜索する許可を得た。

<a id="x064-03"></a>

**64.03**　The **accused** was a young **immigrant** with no **income** and no **permanent** **address**.

> 被告人は、収入も定まった住所もない若い移民だった。

<a id="x064-04"></a>

**64.04**　An **officer** claimed to recognize the **suspect** from a red mark on his **cheek**.

> ある警官は、頬の赤い跡を見て容疑者だと分かったと主張した。

<a id="x064-05"></a>

**64.05**　An **attorney** asked a **reporter** to **testify** about the **arrest** and the **illegal** raid.

> 弁護士は逮捕と違法な手入れについて記者に証言を求めた。

<a id="x064-06"></a>

**64.06**　The **injured** **defender** had seen no **theft** and could not **confirm** the **allegation**.

> 負傷していた守備選手は盗むところを見ておらず、その申し立てを裏づけられなかった。

<a id="x064-07"></a>

**64.07**　The **hearing** concerned **jurisdiction** as well as the conduct of the **criminal** **investigation**.

> 審理では、犯罪捜査の進め方と同時に管轄権も問題になった。

<a id="x064-08"></a>

**64.08**　The judge **deemed** the evidence **inadequate** to **warrant** **imprisonment**.

> 裁判官は、その証拠では投獄を正当化できないと判断した。

<a id="x064-09"></a>

**64.09**　The **verdict** caused **considerable** **controversy** and a **petition** for an independent **review**.

> 評決は大きな論争を呼び、独立した再調査を求める請願が出た。

<a id="x064-10"></a>

**64.10**　The man received **compensation** after a **tribunal** criticized the **enforcement** of the **old** **ruling**.

> 審判所が以前の裁定の執行を批判した後、その男性には補償金が支払われた。

**読みの問い**　裁判官は警察が示した証拠をどう評価したか。

<a id="ex-story-065"></a>

### 65　看板の裏の数字

<a id="x065-01"></a>

**65.01**　The **accountant** showed us the **earnings** of the old **retail** **chain** before its **industrial** **expansion**.

> 会計士は、事業を大規模化する前の小売チェーンの利益を見せてくれた。

<a id="x065-02"></a>

**65.02**　The **net** **income** of each **store** had started to **fall** despite a **steady** **turnover**.

> 各店の売上高は安定していたのに、純利益は落ち始めていた。

<a id="x065-03"></a>

**65.03**　A **commodity** could **cost** a **penny** in **bulk** and a **dollar** across the **street**.

> ある品はまとめ買いなら一ペニーなのに、通りの向こうでは一ドルした。

<a id="x065-04"></a>

**65.04**　An **analyst** had tried to **account** for that **contrast** in a **quantitative** **study**.

> ある分析者が定量的な調査でその対照を説明しようとした。

<a id="x065-05"></a>

**65.05**　The **equation** used a **favourable** **exchange** rate as its **default**.

> 計算式は、有利な為替レートを初期値として使っていた。

<a id="x065-06"></a>

**65.06**　But an increase in **tax** and a **huge** **advertising** bill had **absorbed** the **proceeds**.

> だが増税と巨額の広告費で、売上金は消えてしまっていた。

<a id="x065-07"></a>

**65.07**　The **founder** had paid an **agency** to **create** a **colourful** **logo** for the **brand**.

> 創業者は代理店に代金を払い、そのブランド用の色鮮やかなロゴを作らせていた。

<a id="x065-08"></a>

**65.08**　A **prominent** **ad** **depicted** a **bride** counting her **change** outside a **cafe**.

> ひときわ目立つ広告には、カフェの外で釣り銭を数える花嫁が描かれていた。

<a id="x065-09"></a>

**65.09**　The **slogan** **implied** that shopping here would **double** your **fortune**.

> ここで買えば財産が倍になる、と宣伝文句はほのめかしていた。

<a id="x065-10"></a>

**65.10**　“This is a classic **example** of a **misleading** **claim**,” said the accountant.

> 「これは誤解を招く主張の典型例です」と会計士は言った。

<a id="x065-11"></a>

**65.11**　He **favoured** a **moderate** profit and a fair **payment** to the staff.

> 彼はほどほどの利益と従業員への公正な支払いをよしとしていた。

**読みの問い**　売上高が安定していたのに利益が減った二つの理由は何か。

<a id="ex-story-066"></a>

### 66　駅の裏口の行列

<a id="x066-01"></a>

**66.01**　A **union** **spokesman** explained the **strike** to a **group** on our first public **tour**.

> 最初の一般向けツアーでは、組合の広報担当者が参加者にストライキのことを説明した。

<a id="x066-02"></a>

**66.02**　The **national** **government** had announced the **privatization** of the railway and the **imminent** closure of the station.

> 政府は鉄道の民営化と、駅を近く閉鎖することを発表していた。

<a id="x066-03"></a>

**66.03**　A **civil** servant had signed the order under intense pressure from the **minister**.

> 大臣からの強い圧力を受けて、ある公務員が命令書に署名していた。

<a id="x066-04"></a>

**66.04**　The **parliamentary** **deputy** had asked **parliament** to **declare** a temporary **ban** on the **transfer**.

> 議員は移管を一時禁止すると宣言するよう議会に求めた。

<a id="x066-05"></a>

**66.05**　Outside the **assembly**, a **protester** tried to **persuade** people to **join** an **electoral** **coalition**.

> 議会の外では、抗議者が選挙連合に参加するよう人々を説得しようとしていた。

<a id="x066-06"></a>

**66.06**　An **activist** from a **rival** **faction** used a different **tactic** to **protest** against the sale.

> 対立する派閥の活動家は、別の作戦で売却に抗議した。

<a id="x066-07"></a>

**66.07**　He asked each **member** to **queue** outside the **platform** from which the last train would **go**.

> 最後の列車が出ていくホームの外に並んでほしい、と各会員に呼びかけた。

<a id="x066-08"></a>

**66.08**　He would **telephone** the **president** of the company and **insist** on a **definite** answer.

> 自分は会社の社長に電話し、はっきりした返答を求めるつもりだった。

<a id="x066-09"></a>

**66.09**　The **confrontation** failed to **erupt** because a **diplomatic** **ally** invited both leaders inside.

> 外交手腕のある協力者が両方の指導者を中に招いたため、衝突は起こらなかった。

<a id="x066-10"></a>

**66.10**　The **diplomat** helped them **formulate** an **interim** **position** that the **legislature** could **adopt**.

> 外交官は、議会が採択できる暫定的な方針を両者がまとめるのを手伝った。

**読みの問い**　広報担当者が説明した抗議行動では、参加者はどこに並んだか。

<a id="ex-story-067"></a>

### 67　白いバッジを外した人

<a id="x067-01"></a>

**67.01**　An **angry** **foreigner** had written to the newspaper about **harassment** during the campaign.

> 選挙運動中の嫌がらせについて、憤った外国人が新聞に投書していた。

<a id="x067-02"></a>

**67.02**　He had been a **lifelong** **inhabitant** of our town but had only recently gained **citizenship**.

> ずっとこの町で暮らしていたものの、市民権を得たのはつい最近だった。

<a id="x067-03"></a>

**67.03**　The **anonymous** **article** had called him an **idiot** for his **belief** in **peaceful** **politics**.

> 匿名の記事は、平和的な政治を信じる彼をばか呼ばわりしていた。

<a id="x067-04"></a>

**67.04**　A **liberal** from the other party **denounced** this **expression** of **hatred** and asked for **constructive** criticism.

> 他党の自由主義者もその憎悪の表現を非難し、建設的な批判を求めた。

<a id="x067-05"></a>

**67.05**　“The right to **disagree** is a **virtue**,” she said, “and public **anger** can **fuel** useful **change**.”

> 「意見を異にする権利は大切です。世の中の怒りが、有益な変化の原動力になることもあります」と彼女は言った。

<a id="x067-06"></a>

**67.06**　“Yet that cannot **justify** a **rude** attack on a person.”

> 「それでも、人に対する無礼な攻撃は正当化できません。」

<a id="x067-07"></a>

**67.07**　The mainstream press sent an **interviewer** to **probe** the **background** of the **controversy**.

> 主要な報道機関は、論争の背景を探るため聞き手を派遣した。

<a id="x067-08"></a>

**67.08**　He asked whom the people held **accountable** and what **effective** form a **complaint** might **take**.

> 誰に責任があると考えるか、またどんな方法で苦情を伝えると効果があるかを尋ねた。

<a id="x067-09"></a>

**67.09**　The letter gained a **large** **following** when the first **headline** appeared on **Monday**.

> 月曜に最初の見出しが載ると、その投書には多くの支持者が集まった。

<a id="x067-10"></a>

**67.10**　I asked to **publish** the two letters side by side, with an **explanatory** **reference** above them.

> 私は説明用の参照先を上に添え、二通の手紙を並べて掲載する許可を求めた。

**読みの問い**　他党から投書の主を擁護した人は、何を大切だとしたか。

<a id="ex-story-068"></a>

### 68　走る人と数える人

<a id="x068-01"></a>

**68.01**　An **outdoor** **marathon** would raise our **profile** and **generate** money for the **charity**.

> 屋外でマラソン大会を開けば、私たちの活動を知ってもらえて、慈善団体の資金も集まるはずだった。

<a id="x068-02"></a>

**68.02**　The **coordinator** asked a **professional** athlete to design a **training** **cycle** for a mixed **field**.

> 運営担当者はプロの選手に、実力がまちまちな参加者に合う練習サイクルの設計を頼んだ。

<a id="x068-03"></a>

**68.03**　A **fit** **graduate** with a **passion** for **running** offered to **train** those new to the sport.

> 体力があり、走るのが大好きな卒業生が、初心者を指導すると申し出た。

<a id="x068-04"></a>

**68.04**　A **relaxing** **walk** would **serve** as an alternative to a full **workout** after each hard stretch.

> きつい区間の後には、リラックスして歩くことが、ひととおりの本格的な運動を行う代わりになるはずだった。

<a id="x068-05"></a>

**68.05**　If you **hurt** your **ankle** or a **muscle** felt **tight**, you had to **stop** and **notify** a doctor.

> 足首を傷めたり、筋肉が張ったりしたら、立ち止まって医師に知らせる決まりだった。

<a id="x068-06"></a>

**68.06**　The **stadium** had one **stand** for every hundred **spectators** and a **pool** to **cool** the runners.

> 競技場には観客百人につき一つの観覧席の区画と、走者が体を冷やせるプールがあった。

<a id="x068-07"></a>

**68.07**　A **spectator** could **cheer** from the **home** end or **applaud** as each runner **approached** the finish.

> 観客は地元の応援席から声をかけても、走者がゴールに近づくのを拍手で迎えてもよかった。

<a id="x068-08"></a>

**68.08**　The **medal** went to a **talented** **female** runner who had started in the middle of the pack.

> メダルは、集団の真ん中から出発した才能ある女性走者の手に渡った。

<a id="x068-09"></a>

**68.09**　She refused to lift the **trophy** until a **teenage** volunteer at the **sporting** event had joined her.

> このスポーツ大会の十代のボランティアが隣に来るまで、彼女はトロフィーを掲げようとしなかった。

<a id="x068-10"></a>

**68.10**　“He brought my shoe back,” she said, “and he **deserves** half the **praise** for this **feat**.”

> 「この子が靴を届けてくれたんです。この快挙への称賛は、半分この子が受けて当然です。」

**読みの問い**　優勝者が表彰台で待っていたのは誰か。

<a id="ex-story-069"></a>

### 69　カメラのとらえた三秒

<a id="x069-01"></a>

**69.01**　A **broadcaster** sent three seconds of **footage** from a **notorious** **crash** in **July**.

> 放送局から、七月に起きた悪名高い衝突事故の映像が三秒分届いた。

<a id="x069-02"></a>

**69.02**　A **lorry** was carrying a **load** of **steel** through a **residential** **area** in **terrible** **weather**.

> ひどい天候の中で、トラックが鋼材を積んで住宅地を通っていた。

<a id="x069-03"></a>

**69.03**　The maximum legal **weight** was one **tonne**, and the **vehicle** carried a little over a **ton**.

> 法定の最大積載量は一メートルトンで、車両は一英トンを少し超える量を載せていた。

<a id="x069-04"></a>

**69.04**　The **following** **shot** showed the driver trying to avoid a **bicycle**.

> 次の映像には、自転車を避けようとする運転手が映っていた。

<a id="x069-05"></a>

**69.05**　The back wheels lost their grip and the metal began to **swing** into the **left** lane.

> 後輪が滑り、鉄材が左車線へ振れ始めた。

<a id="x069-06"></a>

**69.06**　A **firefighter** **shouted** to **alert** a **pair** of children who had stopped to **stare**.

> 消防士が声を張り上げ、立ち止まってじっと見ていた二人の子どもに危険を知らせた。

<a id="x069-07"></a>

**69.07**　The camera turned away before the truck **smashed** into the **bin**.

> トラックがごみ箱に突っ込む前に、カメラはほかを向いた。

<a id="x069-08"></a>

**69.08**　“The **coverage** ends there,” the reporter said, “so the **fault** may lie elsewhere.”

> 「報道映像はそこで終わりですから、責任は別のところにあるかもしれません」と記者は言った。

<a id="x069-09"></a>

**69.09**　“The **insurance** company paid, but that alone does not **constitute** an admission of **blame**.”

> 「保険会社は支払いましたが、それだけで責任を認めたことにはなりません。」

<a id="x069-10"></a>

**69.10**　One child had to **lie** down on the grass until the shaking stopped.

> 一人の子は震えが止まるまで草の上に横になっていなければならなかった。

<a id="x069-11"></a>

**69.11**　I watched the **video** again and noticed an **odd** **twist** in the rope: it had already come loose.

> もう一度映像を見ると、綱のねじれ方がおかしかった。すでに緩んでいたのだ。

**読みの問い**　記者が映像だけで責任を決められなかったのはなぜか。

<a id="ex-story-070"></a>

### 70　雨の峡谷の声

<a id="x070-01"></a>

**70.01**　An **airline** had kept a **booking** for a **traveller** who never made her return flight.

> 航空会社には、帰りの便に乗れなかった旅客の予約が残されていた。

<a id="x070-02"></a>

**70.02**　Her **fare** covered **transportation** to a **resort** **situated** in the **surrounding** **valley**.

> 彼女の運賃には、周辺の谷に位置する保養地までの移動も含まれていた。

<a id="x070-03"></a>

**70.03**　She had put aside her **camping** **kit**, taken a **ski** and set off along a narrow **trail**.

> 彼女はキャンプ道具を脇に置き、スキー板を一本持って細い小道へ出発した。

<a id="x070-04"></a>

**70.04**　A **massive** bank of snow began to **slide**, **threatening** to **bury** all the houses below.

> 大量の雪が滑り始め、下にある家々をのみ込みそうになった。

<a id="x070-05"></a>

**70.05**　The **danger** had escaped a **careful** **evaluation** because the slope fell outside its **scope**.

> その斜面が調査対象の範囲外だったため、綿密な評価でも危険が見過ごされていた。

<a id="x070-06"></a>

**70.06**　Her phone signal was weak, but she could **transmit** her **location** and describe the **magnitude** of the fall.

> 携帯の電波は弱かったが、居場所と雪崩の規模を伝えることはできた。

<a id="x070-07"></a>

**70.07**　The first rescue group had to **climb** a **vertical** face and **stretch** a rope from the **summit**.

> 最初の救助隊は垂直な岩壁を登り、頂上から綱を張る必要があった。

<a id="x070-08"></a>

**70.08**　They could lower the children in turns but had to **displace** a **huge** rock to **free** their **parent**.

> 子どもたちは一人ずつ下ろせたが、親を救い出すには巨大な岩を動かす必要があった。

<a id="x070-09"></a>

**70.09**　Her **determination** helped the family **survive**, and the company **returned** her **fare**.

> 彼女が諦めなかったおかげで一家は助かり、会社は彼女の運賃を払い戻した。

<a id="x070-10"></a>

**70.10**　Her **true** **reward** was a **visit** from all three, who brought the umbrella back in spring.

> 彼女にとって本当の報いは、春に三人そろって傘を返しに来てくれたことだった。

**読みの問い**　評価で危険を見落としたのはなぜか。

<a id="ex-story-071"></a>

### 71　絵から外れたもの

<a id="x071-01"></a>

**71.01**　A **patron** asked the **gallery** to **commission** a **picture** of the **historic** hall before its **restoration**.

> ある後援者が画廊に、修復前の歴史あるホールの絵を発注してほしいと頼んだ。

<a id="x071-02"></a>

**71.02**　The **commission** could **mean** a **full-time** job for a talented but **unemployed** painter.

> この依頼が、才能はあるが失業中の画家にとって常勤の仕事になるかもしれなかった。

<a id="x071-03"></a>

**71.03**　His **preliminary** **design** placed the **gorgeous** windows in the **middle** of the **composition**.

> 彼の下絵では、美しい窓が構図の中央に置かれていた。

<a id="x071-04"></a>

**71.04**　The **visual** **contrast** between blue light and red **decoration** was **spectacular**.

> 青い光と赤い装飾が織りなす色の対比は見事だった。

<a id="x071-05"></a>

**71.05**　The artist had **modified** the **scale** to **emphasize** the height of each window by one **inch**.

> 画家は縮尺に手を加え、窓を一インチずつ高く描いて強調していた。

<a id="x071-06"></a>

**71.06**　The **creator** wanted a **symbolic** **reproduction** rather than a **boring** copy.

> 画家が描きたかったのは、退屈な写し絵よりも象徴性のある再現画だった。

<a id="x071-07"></a>

**71.07**　But one **important** **aspect** of the original painting was **invisible** from the usual **position**.

> だが原画の大切な特徴が一つ、普通に立っている位置からは見えなかった。

<a id="x071-08"></a>

**71.08**　A **shaped** piece of glass behind the frame could **project** a second image of the umbrella.

> 額の裏に成形したガラス片があり、傘の像をもう一つ映し出せるようになっていた。

<a id="x071-09"></a>

**71.09**　The **catalogue** would **title** the work “The Other Room” and **specify** the **placement** of the lamp.

> 図録には「もう一つの部屋」と題して作品を載せ、明かりを置く位置を明記することになった。

<a id="x071-10"></a>

**71.10**　We asked about **copyright** before making an **extract** from his **publication**.

> 彼の出版物を部分的に引用する前に、私たちは著作権について尋ねた。

**読みの問い**　なぜランプを置く位置を図録に記すのか。

<a id="ex-story-072"></a>

### 72　録音にまじった笑い声

<a id="x072-01"></a>

**72.01**　The **young** preferred an **informal** **gig** to a formal evening of **poetry** and **singing**.

> 若者たちは、詩と歌の改まった夕べより気軽なライブを好んだ。

<a id="x072-02"></a>

**72.02**　Their **enthusiasm** **surprised** a **provincial** poet whose **humorous** **work** had gone out of **fashion**.

> 彼らの熱気に驚いたのは、ユーモアのある作品が時代遅れになっていた地方の詩人だった。

<a id="x072-03"></a>

**72.03**　His **funny** **character** was a young woman, a **punk** with close friends among the **pop** stars.

> 彼の愉快な登場人物は、ポップスターたちに親しい友人がいる、パンク系の若い女性だった。

<a id="x072-04"></a>

**72.04**　She offered the listener an **enjoyable** **ride** through the **bizarre** **marketplace** of her dreams.

> 彼女は聞き手を、夢に現れる風変わりな市場を巡る楽しい旅に連れていった。

<a id="x072-05"></a>

**72.05**　One **comic** **metaphor** turned the crowd into a **beast** with a **massive** **ego**.

> おかしな比喩の一つで、群衆はとてつもなく自尊心の強い獣になった。

<a id="x072-06"></a>

**72.06**　Her **wit** and **talent** held the **screen** during a **rare** **solo** at the end of the **movie**.

> 彼女の機知と才能が光り、映画の最後にある珍しいソロの間、画面から目を離せなかった。

<a id="x072-07"></a>

**72.07**　The **singing** **flowed** into speech, then she **whispered** one last **goodbye** to the crowd.

> 歌は語りへと流れ込み、彼女は最後にもう一度、観衆に別れをささやいた。

<a id="x072-08"></a>

**72.08**　A **grateful** **relative** told us the poet had gone out with that young singer in his **teens**.

> 親戚の一人が感謝の気持ちを込めて、詩人が十代のころその若い歌手と付き合っていたことを教えてくれた。

<a id="x072-09"></a>

**72.09**　The **affection** in the old recording gave our **series** a **feeling** of **real** **friendship**.

> 古い録音ににじむ愛情で、私たちの連作にも本物の友情が感じられるようになった。

<a id="x072-10"></a>

**72.10**　She warned us against a **romance** with a **false** ending: the two had remained friends for a **lifetime**.

> 彼女は、勝手な結末の恋物語にしないでと言った。二人は一生、友達のままだった。

**読みの問い**　古い歌にこもった愛情を親戚はどう説明したか。

<a id="ex-story-073"></a>

### 73　本の背から画面へ

<a id="x073-01"></a>

**73.01**　The **spine** of the **rare** book was too weak to **survive** another **shower** of rain.

> その珍しい本は背がもろく、もう一度にわか雨に降られたら持ちそうになかった。

<a id="x073-02"></a>

**73.02**　We had to **copy** each page and **restore** the **original** before we could **expose** it to light.

> 光に当てる前に、各ページを複写し、原本を修復しなければならなかった。

<a id="x073-03"></a>

**73.03**　A **university** **donor** sent a **laptop**, a **desktop** computer and a **used** **mouse** through the **post**.

> 大学の寄付者がノートパソコン、デスクトップパソコン、中古のマウスを郵便で送ってくれた。

<a id="x073-04"></a>

**73.04**　A **programming** **consultant** described a **flexible** **database** that could **link** each copy to its **source**.

> プログラム開発の相談役が、各複写を出典に結びつけられる柔軟なデータベースについて説明した。

<a id="x073-05"></a>

**73.05**　We would **code** every entry in a **common** **format** and **embed** a **translation** below the title.

> 項目はすべて共通形式でコード化し、題の下に翻訳を組み込むことになった。

<a id="x073-06"></a>

**73.06**　Our **code** had to **enable** a reader to **access** the entire **collection** with one **search**.

> ひとつ検索するだけで収蔵品すべてを調べられるようにすることが、コードの役目だった。

<a id="x073-07"></a>

**73.07**　“**Plug** the camera in and **load** the **latest** file,” she said, “then **adjust** the **lens**.”

> 「カメラをつないで最新版のファイルを読み込み、レンズを調整して」と彼女は言った。

<a id="x073-08"></a>

**73.08**　The **output** filled the **screen**, but the **above** figures detailed the input alone.

> 結果が画面いっぱいに出たが、上記の数値が表していたのは入力情報だけだった。

<a id="x073-09"></a>

**73.09**　We **logged** the **failure** and **sent** an **email** asking for **external** **support**.

> 私たちは不具合を記録し、外部の支援を求めるメールを送った。

<a id="x073-10"></a>

**73.10**　The **recipient** found our message among the **spam** and sent a **fix** with the subject “More **info**”.

> 受け取った人は迷惑メールの中で見つけ、件名を「追加情報」として修正方法を送った。

**読みの問い**　画面いっぱいに結果が出ても、何がまだ分からなかったか。

<a id="ex-story-074"></a>

### 74　誰が見ているか

<a id="x074-01"></a>

**74.01**　The **interference** started each time we **powered** the camera and the outside camera at the same time.

> 屋内と屋外のカメラに同時に電源を入れるたびに干渉が起きた。

<a id="x074-02"></a>

**74.02**　A **security** camera outside would **rotate**, then **send** its pictures at the same **frequency** as ours.

> 外の防犯カメラが回転し、同じ周波数で画像を送信していた。

<a id="x074-03"></a>

**74.03**　One guest asked if our **inside** camera was a form of **surveillance**.

> 見学者の一人が、屋内カメラは監視の一種なのかと尋ねた。

<a id="x074-04"></a>

**74.04**　We **outlined** its **purpose** and showed how a **selective** mask could **conceal** every face.

> 私たちは目的を説明し、選択した部分を覆う機能で、一人ひとりの顔を隠せるところを見せた。

<a id="x074-05"></a>

**74.05**　A **regulatory** officer wanted **adequate** evidence of **compliance** before a second **deployment**.

> 監督官は二度目の設置の前に、規則を守っているという十分な証拠を求めた。

<a id="x074-06"></a>

**74.06**　“The rule is **applicable** to **informal** visits too,” he said, “so **vague** signs are **insufficient**.”

> 「気軽な見学にもこの規則は適用されますから、曖昧な表示では不十分です」と彼は言った。

<a id="x074-07"></a>

**74.07**　His **cautious** **manner** did not **diminish** our **confidence** in the **innovation**.

> 慎重な言い方を聞いても、この新しい工夫への私たちの信頼は揺らがなかった。

<a id="x074-08"></a>

**74.08**　We changed one frequency, tested the **modification** and **reported** our findings for **scrutiny**.

> 片方の周波数を変更し、改修の効果を調べ、精査してもらうため結果を報告した。

<a id="x074-09"></a>

**74.09**　The cameras could now **run** without a **breakdown** or any serious **limitation** on their **use**.

> これでカメラは故障せず、使用上の大きな制限もなく動くようになった。

**読みの問い**　二台のカメラが互いに干渉したのはなぜか。

<a id="ex-story-075"></a>

### 75　焼け残った鐘

<a id="x075-01"></a>

**75.01**　During the war a **strategic** bridge had been a **prime** target for aircraft flying missions above the town.

> 戦時中、戦略上重要な橋は町の上空で任務に当たる航空機の主要な標的だった。

<a id="x075-02"></a>

**75.02**　One pilot refused to **bomb** the **church** or **destroy** the **religious** **statue** by the door.

> 一人の操縦士は教会を爆撃することも、戸口の宗教像を壊すことも拒んだ。

<a id="x075-03"></a>

**75.03**　A **guerrilla** group hoped to **raid** the **store** and **arm** its members with the captured **arms**.

> ゲリラの一団は倉庫を襲撃し、奪った武器で仲間を武装させようとしていた。

<a id="x075-04"></a>

**75.04**　They planned to **kidnap** a **priest** and **threaten** to **wound** the **hostage** unless the soldiers left.

> 彼らの計画は司祭をさらい、兵士が去らなければ人質を傷つけると脅すものだった。

<a id="x075-05"></a>

**75.05**　The priest **pleaded** with their leader for the **sake** of the **vulnerable** people inside.

> 司祭は中にいる弱い立場の人たちのために、一団の指導者に懇願した。

<a id="x075-06"></a>

**75.06**　An **explosion** tore a hole in the wall, but the device in the tower failed to **explode**.

> 爆発で壁に穴が開いたが、塔に仕掛けられた装置は爆発しなかった。

<a id="x075-07"></a>

**75.07**　The **ring** of the bell was the first sign that the **combat** had ended.

> 鐘の響きが、戦闘の終わりを告げる最初のしるしになった。

<a id="x075-08"></a>

**75.08**　In the **post-war** **era**, a **pastor** stood by the **remains** to **preach** about mercy and **humanity**.

> 戦後、牧師は廃墟のそばに立ち、慈悲と思いやりについて説いた。

<a id="x075-09"></a>

**75.09**　His words **conveyed** the **horror** of that **period** without promising **glory** in **heaven**.

> その言葉は、天国での栄光を約束することなく、あの時代の恐ろしさを伝えた。

<a id="x075-10"></a>

**75.10**　The **monument** was built as a lasting reminder that **evil** can **exist** even where people **love** their **god**.

> この記念碑は、人々が神を愛する場所にも悪は存在しうることを、いつまでも思い起こせるよう建てられた。

**読みの問い**　鐘が鳴ったとき、中にいた人々には何が分かったか。

<a id="ex-story-076"></a>

### 76　静かな部屋に描かれた獣

<a id="x076-01"></a>

**76.01**　A **philosopher** asked us to **wander** through the old **temple** with him before the **ritual** began.

> 儀式が始まる前に、古い寺を一緒に歩いて回ろうと哲学者に誘われた。

<a id="x076-02"></a>

**76.02**　The **atmosphere** inside was **pleasant**, and the **smell** of wet wood helped me **relax**.

> 中は心地よい空気に満たされ、ぬれた木の香りが私の気持ちをほぐした。

<a id="x076-03"></a>

**76.03**　He would **preside** over a **meditation** on **morality**, **conscience** and the **moral** **consequences** of power.

> 彼は道徳、良心、そして力を持つことの道徳的な帰結について考える瞑想の会を取り仕切る予定だった。

<a id="x076-04"></a>

**76.04**　A painted **demon** seemed to leap from the walls of **hell** with the **fur** of a **lion** and the hands of a **monkey**.

> 地獄を描いた壁から、ライオンの毛並みと猿の手を持つ鬼が飛び出してくるように見えた。

<a id="x076-05"></a>

**76.05**　The **devil** in a classic tale had the **opposite** **personality**: he spoke in a low voice and offered **pleasure**.

> 古典の物語に登場する悪魔は正反対の性格だった。静かに語りかけ、快楽を差し出した。

<a id="x076-06"></a>

**76.06**　“Does the monster **cause** fear, or does fear **influence** what you **perceive**?” he asked.

> 「怪物のせいで怖くなるのか、それとも恐れがものの見え方を左右するのか」と彼は尋ねた。

<a id="x076-07"></a>

**76.07**　The **proposition** offered an **intellectual** **framework** for the discussion, but it did not **compel** us to **agree**.

> その命題は話し合いを支える知的な枠組みを与えたが、同意を強いるものではなかった。

<a id="x076-08"></a>

**76.08**　A visiting **intellectual** called the question **thought-provoking** and the **reasoning** **compelling**.

> 訪ねてきた知識人は、考えさせられる問いで、その推論には説得力があると言った。

<a id="x076-09"></a>

**76.09**　A child **dropped** his toy and gave a much more direct answer: “It looks **scary**.”

> 子どもはおもちゃを落とし、ずっと率直に「怖そう」と答えた。

<a id="x076-10"></a>

**76.10**　We **stayed** for a **while** after the others left, until my **anxiety** gave way to **calm**.

> ほかの人が去ったあとも、私の不安が落ち着きに変わるまで、私たちはしばらくそこにいた。

**読みの問い**　絵を見た子どもは、哲学者の問いにどのように答えたか。

<a id="ex-story-077"></a>

### 77　土の中のパイオニア

<a id="x077-01"></a>

**77.01**　The **laboratory** agreed to **host** an **outing** for children with an interest in **evolutionary** biology.

> 研究室は、進化生物学に興味を持つ子どもたちの見学会を引き受けた。

<a id="x077-02"></a>

**77.02**　One **pioneer** had studied how birds **mate** in a **cold** **climate** and why some families **migrate**.

> 先駆者の一人は、寒冷な気候で鳥がどう交尾するか、また一部の鳥の仲間が渡りをするのはなぜかを研究した。

<a id="x077-03"></a>

**77.03**　Every **female** bird had a **characteristic** call, yet two calls sometimes sounded exactly **alike**.

> 雌鳥にはそれぞれ特徴的な鳴き声があるが、二羽の声がまったく同じに聞こえることもあった。

<a id="x077-04"></a>

**77.04**　A **cell** under the glass showed a **genetic** difference hidden from our ordinary senses.

> ガラスの下の細胞を見ると、普段の感覚では捉えられない遺伝的な違いが分かった。

<a id="x077-05"></a>

**77.05**　The guide **classified** the birds by their **hunting** **range** rather than their colour.

> 案内人は色の代わりに、獲物を探し回る範囲を基準として鳥を分類した。

<a id="x077-06"></a>

**77.06**　We watched one **dive** to **fish** and another **chase** a mouse across a level field.

> 一羽は魚を捕ろうと飛び込み、もう一羽は平らな野を横切ってネズミを追った。

<a id="x077-07"></a>

**77.07**　The second bird could **deliver** a **lethal** blow, but the mouse could **leap** into a hole.

> 二羽目の一撃は命を奪いかねなかったが、ネズミは穴へ跳び込めた。

<a id="x077-08"></a>

**77.08**　Their **chase** helped us **understand** how a species can **evolve** to **occupy** a **niche**.

> その追いかけ合いを見て、ある種が進化し、生態系の中で特有の位置を占めるようになるしくみが分かってきた。

<a id="x077-09"></a>

**77.09**　A **sensory** display let us **experience** the **sensation** of **flying** over our own town.

> 感覚を刺激する展示で、自分の町の上を飛ぶ感覚を体験することもできた。

<a id="x077-10"></a>

**77.10**　The **similarity** to a **gaming** system was no surprise: the scientist had **derived** the idea from a game.

> ゲーム機と似ているのは当然で、科学者はゲームからその着想を得ていた。

**読みの問い**　鳥の分類に用いたのはどのような行動の違いだったか。

<a id="ex-story-078"></a>

### 78　水が運んだ粉

<a id="x078-01"></a>

**78.01**　We then saw a **probe** used to **collect** water after a **tsunami** and **analyse** the **residue**.

> 次に、津波のあとに水を採取して残留物を分析するための探査装置を見た。

<a id="x078-02"></a>

**78.02**　A **chemical** **substance** had entered the harbour from an **unknown** **source** during the disaster.

> 災害の際、出所の分からない化学物質が港に流入した。

<a id="x078-03"></a>

**78.03**　The **cumulative** **concentration** could **increase** each time a ship **discharged** its **waste**.

> 船が廃棄物を排出するたびに、その物質は蓄積し、濃度が上がるおそれがあった。

<a id="x078-04"></a>

**78.04**　The **normal** **requirement** was to **randomize** the order of the samples before testing them for **radiation**.

> 放射線を測る前に試料の順番を無作為に入れ替えるのが、通常の要件だった。

<a id="x078-05"></a>

**78.05**　A **variance** in results could **reflect** a **real** difference or a simple error in **execution**.

> 結果のばらつきは、実際の違いを反映していることも、単純な作業ミスによることもありえた。

<a id="x078-06"></a>

**78.06**　The guide drew a **framework** to **summarize** the **rationale** for a **proportional** response.

> 案内人は図を描いて、被害の大きさに見合った対応を取る理由をまとめた。

<a id="x078-07"></a>

**78.07**　A **major** spill could **disrupt** work, **intensify** local fears and **elevate** the **tension** at the port.

> 大きな流出事故は仕事を中断させ、地元の不安を強め、港の緊張を高めるかもしれない。

<a id="x078-08"></a>

**78.08**　The chief **obstacle** was **uncertainty** about how the waste would **deteriorate** or react with **excess** **carbon**.

> 主な障害は、廃棄物がどのように劣化するか、あるいは過剰な炭素とどう反応するかが不確かなことだった。

<a id="x078-09"></a>

**78.09**　The material could **yield** energy if we learnt to **handle** it with **special** care.

> 特別に注意して扱う方法が分かれば、その物質からエネルギーを得られる可能性があった。

<a id="x078-10"></a>

**78.10**　It was a **thought-provoking** **instance** of **engineering** changing our **reliance** on **limited** resources.

> これは、限られた資源に頼るあり方を技術が変えていく、考えさせられる一例だった。

**読みの問い**　試料を調べる順番はどのように決めたか。

<a id="ex-story-079"></a>

### 79　看護学校への手紙

<a id="x079-01"></a>

**79.01**　A **nursing** student had written from the **university** to ask about a **scholarship** for her **education**.

> 大学の看護学生から、勉学のための奨学金について問い合わせる手紙が来ていた。

<a id="x079-02"></a>

**79.02**　Her **curriculum** included an **intensive** course on **cancer** **prevention** and an **assignment** about **AIDS**.

> 彼女の学習課程には、がん予防の集中講座とエイズに関する課題があった。

<a id="x079-03"></a>

**79.03**　The **topic** that interested her most was the effect of **tobacco** and **alcohol** on the **stomach**.

> 特に関心を持っていたのは、たばことアルコールが胃に及ぼす影響だった。

<a id="x079-04"></a>

**79.04**　She hoped to **gain** a **qualification** and **graduate** with a **degree** before seeking her first paid **shift**.

> 資格を取得し、学位を得て卒業してから、初めての有給の勤務に就くのが目標だった。

<a id="x079-05"></a>

**79.05**　The **induction** would **prepare** each student to **assist** a **dentist** and work under **supervision**.

> 導入研修では、各学生が歯科医を補助し、監督のもとで働く準備をする。

<a id="x079-06"></a>

**79.06**　Patients with **obesity** might **suffer** severe pain or feel **uncomfortable** during treatment.

> 肥満の患者は、治療中に激しい痛みを覚えたり、不快感を抱いたりする可能性があった。

<a id="x079-07"></a>

**79.07**　The student learnt to **screen** films for them, **seat** each person carefully and **calm** an **unhappy** child.

> 彼女は患者のために映画を上映し、一人ずつ注意して席に案内し、つらそうな子どもを落ち着かせる方法を学んだ。

<a id="x079-08"></a>

**79.08**　If a cut began to **bleed**, a nurse would **instruct** the patient not to **swallow** the blood.

> 口の中の傷から血が出てきたら、血を飲み込まないよう、看護師が患者に指示した。

<a id="x079-09"></a>

**79.09**　The **depressed** student had lost **contact** with a close **peer** during her previous hospital **placement**.

> 気落ちしていたその学生は、前回の病院実習の間に、親しい仲間と連絡が途絶えてしまっていた。

<a id="x079-10"></a>

**79.10**　The homes of the two students were **close** enough for them to meet on foot.

> 二人の学生の家は、歩いて会いに行けるほど近くにあった。

<a id="x079-11"></a>

**79.11**　The **news** of her **success** in the exam prompted us to **congratulate** them both and help them **forge** a new **bond**.

> 合格の知らせをきっかけに、私たちは二人にお祝いを伝え、新たなきずなを結ぶ手助けをした。

**読みの問い**　導入研修では、どんな働き方に備えたか。

<a id="ex-story-080"></a>

### 80　校門の小さな地図

<a id="x080-01"></a>

**80.01**　A **questionnaire** asked every visitor about their **likes** and dislikes before the **selection** of a **pathway**.

> 見学コースを選ぶ前の質問票で、来館者一人ひとりが好きなことと嫌いなことを尋ねられた。

<a id="x080-02"></a>

**80.02**　The **core** **principle** was to offer a **diverse** **set** of choices at an **affordable** price.

> 大切にした原則は、手の届く料金で多様な選択肢を用意することだった。

<a id="x080-03"></a>

**80.03**　**Admission** was free on **Saturday** with an **advance** **reservation** or a family **pass**.

> 土曜は、事前予約か家族用パスがあれば入場無料だった。

<a id="x080-04"></a>

**80.04**　An **advance** of ten **per cent** would **entitle** a group to **spend** a night in the **old** guest **suite**.

> 一割を前払いすると、団体は古い来客用のスイートルームで一泊できた。

<a id="x080-05"></a>

**80.05**　An **alternative** **package** included a smaller **bedroom** and a **friendly** guide for the **following** **outing**.

> 別のプランには、小さめの寝室と、その後の見学に同行する親しみやすい案内人が含まれていた。

<a id="x080-06"></a>

**80.06**　A teacher on **vacation** had to **order** a **pair** of boots because visitors could **encounter** mud on the **trail**.

> 見学者が小道でぬかるみに出合うことがあるため、休暇中の教師はブーツを一足注文しなければならなかった。

<a id="x080-07"></a>

**80.07**　We **scheduled** the next **visit** around the local **custom** of taking a cold drink at noon.

> 昼に冷たい飲み物を飲む地元の習慣に合わせ、次の訪問の日程を組んだ。

<a id="x080-08"></a>

**80.08**　A **ball** and a **toy** train would **occupy** the children while their parents **exchanged** stories.

> 親たちが互いの話を聞き合う間、子どもたちはボールとおもちゃの列車で遊べた。

<a id="x080-09"></a>

**80.09**　My father helped **assemble** the train and told one child to keep a firm **hold** on the **rail**.

> 父は列車を組み立てるのを手伝い、一人の子にレールをしっかり押さえておいてと頼んだ。

<a id="x080-10"></a>

**80.10**　The **delight** on his face was a **better** guide than any formal **criterion** for judging the **merit** of the visit.

> その子の顔に現れた喜びを見れば、見学の良さは、どんな正式な評価基準よりもよく分かった。

**読みの問い**　土曜日に無料で入場する方法は何通り示されたか。

<a id="ex-story-081"></a>

### 81　橋を支えた石

<a id="x081-01"></a>

**81.01**　A **century** ago the council had to **devise** a way to **stabilize** the bridge without closing it.

> 一世紀前、市の議会は橋を閉鎖せずに安定させる方法を考え出さなければならなかった。

<a id="x081-02"></a>

**81.02**　Its **structure** rested on stones taken from a **pit** just outside the **urban** boundary.

> 橋の構造を支えていたのは、市街地の境界の少し外にある採石場から運んだ石だった。

<a id="x081-03"></a>

**81.03**　A **structural** survey found a **complex** pattern of damage on the **inside** of the west wall.

> 構造調査で、西壁の内側に複雑な損傷の跡が見つかった。

<a id="x081-04"></a>

**81.04**　The **planning** office asked its coastal **counterpart** to **conduct** a test and judge the **efficacy** of a new treatment.

> 計画担当部署は、沿岸部で同じ役割を担う部署に、試験を行って新しい処置の効き目を判定してほしいと依頼した。

<a id="x081-05"></a>

**81.05**　A problem with **consistency** had made a sample **crack** on the **even** surface of the bench.

> 材料の固さに問題があったため、平らな作業台の上で試料にひびが入った。

<a id="x081-06"></a>

**81.06**　An expert in bridge **management** offered his **expertise** to **solve** that particular problem.

> 橋の管理の専門家が、その特定の問題を解決するために専門知識を提供した。

<a id="x081-07"></a>

**81.07**　He could **anticipate** movement and **narrow** the gap without adding weight to the **top** step.

> 彼は動きを予測し、最上段に重みをかけずに隙間を狭めることができた。

<a id="x081-08"></a>

**81.08**　The bridge could carry a **maximum** of fifty people after the treatment, compared with a previous **low** of four.

> 補修後の橋は最大五十人を支えられた。以前の最低値は四人だった。

<a id="x081-09"></a>

**81.09**　Our **assumption** about the **making** of the bridge changed as the team **shed** new light on its **conversion**.

> 改造の様子にチームが新しい光を当ててくれたおかげで、橋がどのようにできたかについての私たちの前提も変わった。

<a id="x081-10"></a>

**81.10**　We would **owe** the **overall** **accomplishment** to a man whose name had fallen into **neglect**.

> この成果を全体として支えたのは、いつしか名前を忘れ去られていた一人の人だった。

**読みの問い**　石の損傷に対し、専門家は橋に何を加えずに隙間を狭めたか。

<a id="ex-story-082"></a>

### 82　広場を巡る二つの考え

<a id="x082-01"></a>

**82.01**　An **economic** **projection** showed the new market would **average** ten visitors a day in winter.

> 経済予測では、新しい市場には冬、一日平均十人が訪れる見込みだった。

<a id="x082-02"></a>

**82.02**　That **estimation** made the **organization** question the **potential** for **prosperity** in our small **economy**.

> その見積もりを見て、運営団体は、この小さな地域経済が繁栄できるのか疑問を抱いた。

<a id="x082-03"></a>

**82.03**　The **leadership** had a **hierarchical** view of **productivity**, but the local businesses had a **contrary** view.

> 幹部は生産性を上から下への序列で考えたが、商人は正反対の見方をしていた。

<a id="x082-04"></a>

**82.04**　One shop owner **contended** that a community market could **unite** people and **exemplify** a different **kind** of **capitalism**.

> ある商人は、地域の市場なら人々を結び付け、別の種類の資本主義を体現できると主張した。

<a id="x082-05"></a>

**82.05**　She tried to **articulate** her **intention** and explain its **implication** for a **developed** country.

> 彼女は自分の意図を言葉にし、それが先進国にとってどんな意味を持つかを説明しようとした。

<a id="x082-06"></a>

**82.06**　“The **conceptual** problem,” she said, “is how to **conceptualize** **success** when **fame** is no longer the **benchmark**.”

> 「考え方の問題なのです。名声がもはや物差しでないなら、成功をどんなものとして捉えるか」と彼女は言った。

<a id="x082-07"></a>

**82.07**　She would **advocate** local **recruitment** and **recruit** people from the **parade** to **support** the market.

> 彼女は地元での人材募集を提唱し、パレードの参加者から市場を支えてくれる人を募るつもりだった。

<a id="x082-08"></a>

**82.08**　The council chose to **back** her **worthy** **undertaking** with a small **sponsorship** payment.

> 議会は意義あるその仕事を、少額の協賛金で支えることにした。

<a id="x082-09"></a>

**82.09**　A **passionate** **submission** described the market as an **essential** meeting place and an **ideal** for the next generation.

> 熱のこもった意見書には、市場は欠かせない出会いの場で、次の世代にとっての理想だとあった。

<a id="x082-10"></a>

**82.10**　We added a **quote** from a customer to **convey** the **subjective** **sentiment** behind the numbers.

> 数字の裏にある個人的な気持ちを伝えるために、私たちは客の言葉を引用して加えた。

**読みの問い**　商人たちは、市場の成功を判断するうえで何を大切にしていたか。

<a id="ex-story-083"></a>

### 83　小包の赤いひも

<a id="x083-01"></a>

**83.01**　The **organizational** **division** that usually **headed** our public events was busy with a **racing** **contest**.

> 普段は一般向け行事を取り仕切る部署が、その日はレース大会で手いっぱいだった。

<a id="x083-02"></a>

**83.02**　We had to **package** the old books, **tie** each box and **ship** everything to the hall ourselves.

> 私たち自身で古い本を包み、箱にひもをかけ、ホールに発送しなければならなかった。

<a id="x083-03"></a>

**83.03**　“**Put** the **expensive** **volume** on top,” said my father, “and **fill** the space below it.”

> 「高価な一冊は上に置いて、その下の隙間を埋めて」と父は言った。

<a id="x083-04"></a>

**83.04**　A **secret** pocket in the cover held a **present** that a **husband** had given his wife.

> 表紙のひそかなポケットには、夫が妻にくれた贈り物があった。

<a id="x083-05"></a>

**83.05**　It was a ticket to **ride** the very first railway train, almost a **miracle** in its day.

> 鉄道が開通したときの一番列車に乗る切符で、当時ならほとんど奇跡のような体験だった。

<a id="x083-06"></a>

**83.06**　She had been **born** the week the train first came and had been **asleep** in the arms of her father.

> 初めてその列車が来た週に生まれた彼女は、父親の腕に抱かれて眠っていたのだ。

<a id="x083-07"></a>

**83.07**　My father **said** the ticket alone must **be** worth a great deal, but I **wondered** about the date.

> 父は切符だけでも相当な値打ちだろうと言ったが、私は日付が気になった。

<a id="x083-08"></a>

**83.08**　A second **clue** helped me **realize** she had received a **used** ticket as a reminder of the day.

> 二つ目の手掛かりで、彼女があの日の記念に使用済みの切符をもらったのだと分かった。

<a id="x083-09"></a>

**83.09**　I had been **convinced** the **latter** of the two dates was her birthday, but I could **find** no proof.

> 私は二つの日付のうち二つ目が誕生日だと確信していたが、証拠は見つからなかった。

<a id="x083-10"></a>

**83.10**　The **realization** made me **regard** the ticket as a **lovely** **thing**, even if its market value was **limited**.

> そのことに気づくと、市場価値は限られていても、切符がすてきな品に思えてきた。

**読みの問い**　妻が夫にもらった後でこの切符を使うことができなかったのはなぜか。

<a id="ex-story-084"></a>

### 84　浅い眠りの窓辺

<a id="x084-01"></a>

**84.01**　A **mature** visitor showed us a **glorious** photograph of the hill taken just after a **cold** kept him indoors.

> 年配の見学者が、風邪で外出できなかった時期の直後に撮った、見事な丘の写真を見せてくれた。

<a id="x084-02"></a>

**84.02**　“I was hardly **well**, so you can imagine my **frustration** when I had to **cycle** up that hill.”

> 「まだ元気と言える状態ではなくてね。その丘を自転車で登らなければならなかったとき、どんなにいら立ったか分かるでしょう。」

<a id="x084-03"></a>

**84.03**　His first **attempt** to photograph the **slow** cattle ended in **disappointment**.

> ゆっくり歩く牛を撮ろうとした一度目の試みは、期待外れに終わった。

<a id="x084-04"></a>

**84.04**　His hands would **shake**, the wind would **blow** and a loose lens would **twist** inside its case.

> 手は震えるし、風は吹くし、ケースの中で緩んだレンズが回ってしまう。

<a id="x084-05"></a>

**84.05**　A **nice** couple came to **comfort** him when he **stumbled** over a stone and began to **complain**.

> 石につまずき、思わず不平をこぼしたとき、親切な二人連れが慰めに来てくれた。

<a id="x084-06"></a>

**84.06**　Their paths were already **connected**: one of them had made this camera and could **substitute** a **better** lens.

> すでに縁のある相手だった。二人のうち一人はこのカメラを作った人で、もっと良いレンズに取り替えることができた。

<a id="x084-07"></a>

**84.07**　A **tremendous** sense of **joy** filled him at the **sight** of the hill coming into focus.

> 丘にピントが合った光景を見たとき、彼はたいへんな喜びに満たされた。

<a id="x084-08"></a>

**84.08**　In **appreciation** he wrote a **will** promising that the camera would **stay** in town.

> 感謝のしるしに、そのカメラが町に残るよう遺言状を書いた。

<a id="x084-09"></a>

**84.09**　He was **happy** to **indulge** our **wonder** for a minute and let us **enjoy** the view.

> 彼は喜んで、私たちがしばらく驚きに浸り、その景色を楽しむ時間をくれた。

<a id="x084-10"></a>

**84.10**　The **superb** picture contained a **hint** of red, just enough to **heighten** our **awareness** of the umbrella.

> その見事な写真には、傘に意識を向けさせるのにちょうどよいほどの、ほんの少しの赤が写っていた。

**読みの問い**　写真のピントが合うようになったのはなぜか。

<a id="ex-story-085"></a>

### 85　本物の月はどちらか

<a id="x085-01"></a>

**85.01**　My father had one special **mission** left: to **make** a **rocket** of paper for the **young** visitors.

> 父には紙のロケットを若い来館者のために作るという、とっておきの任務が一つ残っていた。

<a id="x085-02"></a>

**85.02**　The last **instruction** was to **weave** a narrow band of paper round the tube and **slap** the base with a flat hand.

> 最後の指示は、細い紙の帯を筒の周りに編み込み、広げた手で底をたたくことだった。

<a id="x085-03"></a>

**85.03**　If the top did not **pop**, he had to **toss** the paper ball a little higher and start again.

> ふたがぽんと外れなければ、紙の玉をもう少し高く放って、もう一度始める。

<a id="x085-04"></a>

**85.04**　The paper moon would **spring** from the tube and land on a blue **sphere**.

> 紙の月が筒から跳び出して、青い球体に着地する仕掛けだった。

<a id="x085-05"></a>

**85.05**　It might **seem** **absurd** for two moons to **exist** in the same sky, but that was the **essence** of the game.

> 同じ空に月が二つあるなんてばかげているように思えるかもしれないが、そこがこの遊びの肝だった。

<a id="x085-06"></a>

**85.06**　A girl laughed and called the device a **crazy** **classic** from the days before computer games.

> 女の子が笑って、コンピューターゲームがなかった時代の奇想天外な名作だと言った。

<a id="x085-07"></a>

**85.07**　I had expected her to be **disappointed**, but the **opposite** happened: she wanted to **lead** the next group.

> 私は彼女ががっかりすると思っていたが、その逆に、彼女は次のグループを案内したがった。

<a id="x085-08"></a>

**85.08**　She wrote the **particulars** on a card and felt **confident** enough to **structure** the game herself.

> 詳しい遊び方をカードに書き、自分で進行を組み立てられるほど自信をつけた。

<a id="x085-09"></a>

**85.09**　Her **nomination** for a prize for children was a **fabulous** **plus**, but seeing her work was our **ultimate** **reward**.

> 子ども向けの賞への推薦もうれしいおまけだったが、一番の喜びは彼女が働く姿を見られたことだった。

<a id="x085-10"></a>

**85.10**　She turned to **date** her drawing, and the **standing** visitors smiled when they saw the **recent** date.

> 彼女が振り向いて絵に日付を書き入れると、立っていた人たちは新しい日付を見てほほえんだ。

**読みの問い**　紙の月はどのように動く仕掛けだったか。

<a id="ex-story-086"></a>

### 86　暮らしを取り戻した人

<a id="x086-01"></a>

**86.01**　We reserved a small space for a man who had once been in a **cult** and struggled to **initiate** a **normal** life afterwards.

> かつてカルト集団にいて、抜けたあと普段の暮らしを始めるのに苦労した男性のため、小さな場所を確保した。

<a id="x086-02"></a>

**86.02**　He had been taught to **beg** for food and take an order as an absolute **duty**.

> 食べ物を乞い、命令を絶対の義務として受け取るよう教わっていた。

<a id="x086-03"></a>

**86.03**　A failure to **oblige** its leader could **lead** to a **worse** form of treatment.

> 指導者の意に従わなければ、もっとひどい扱いを受けるおそれがあった。

<a id="x086-04"></a>

**86.04**　The group tried to **punish** him when he **defied** its rules and would **bar** the door when he tried to leave.

> 彼が規則に逆らうと集団は罰を与えようとし、出ていこうとすれば戸口をふさいだ。

<a id="x086-05"></a>

**86.05**　A **gay** friend finally helped him escape, taking a risk and asking nothing in return.

> ついに同性愛者の友人が、危険を承知で、見返りを求めずに脱出を手伝った。

<a id="x086-06"></a>

**86.06**　“My **reaction** was to **vow** never to **violate** the **trust** of another person,” he told me.

> 「その経験を受けて、もう誰の信頼も裏切るまいと誓ったのです」と彼は語った。

<a id="x086-07"></a>

**86.07**　He wanted the listener to **understand** his **regret** and the **shock** of discovering how far he had gone.

> 自分の後悔と、そこまで深く関わってしまっていたと分かったときの衝撃とを、聞き手に知ってほしかった。

<a id="x086-08"></a>

**86.08**　The writer had called him an **offender**, and that description still **troubled** him.

> 書き手は彼を加害者と呼んでおり、その表現が今も彼を悩ませていた。

<a id="x086-09"></a>

**86.09**　“It was **necessary** to face my **responsibility**,” he said, “but that one word can **conceal** the **worst** of what happened to us.”

> 「自分の責任と向き合う必要はありました。でも一語で片づけると、私たちに起きた一番むごい部分が隠れてしまうのです。」

<a id="x086-10"></a>

**86.10**　He brushed away a **tear** and asked to **receive** a copy of the recording for his friend.

> 彼は涙をぬぐって、友人に渡すため録音の複製を一部もらいたいと言った。

**読みの問い**　男性は録音を誰に届けたいと思ったか。

<a id="ex-story-087"></a>

### 87　ごみの箱を開ける

<a id="x087-01"></a>

**87.01**　Our final obstacle was the **state** of the box marked “**Rubbish**”.

> 最後の障害は「ごみ」と書かれた箱の状態だった。

<a id="x087-02"></a>

**87.02**　Someone planned to **dump** it, but the rule to **conserve** old paper might **oblige** us to keep it.

> 捨てるつもりの人がいたが、古い紙を保存する決まりに従えば取っておく必要があるかもしれなかった。

<a id="x087-03"></a>

**87.03**　An argument would **ensue** unless one clear message could **circulate** before closing time.

> 閉館までに一つの明確な指示が行き渡らなければ、言い争いになるだろう。

<a id="x087-04"></a>

**87.04**　Our **driving** instructor, who knew the **bureaucracy** better than anyone, found the **legitimate** owner.

> 役所の仕組みに誰より通じていた運転の指導員が、正当な持ち主を突き止めた。

<a id="x087-05"></a>

**87.05**　She said visitors paid a **premium** for the **varied** stamps among the papers and felt **lucky** to find the box.

> 書類に混じるさまざまな切手には見学者が通常より高い値段を払うのだと話し、箱が見つかって運がよかったと感じていた。

<a id="x087-06"></a>

**87.06**　We had to **resolve** the dispute and **utilize** the **best** of our resources before the storm arrived.

> 嵐が来る前に争いを解決し、手元にある一番よい資材を活用しなければならなかった。

<a id="x087-07"></a>

**87.07**　We could **overlook** a simple error, but ignoring the public interest would be **inconsistent** with our promise.

> 単純な間違いなら大目に見られるが、公共の利益を無視すれば私たちの約束と矛盾する。

<a id="x087-08"></a>

**87.08**　A **just** decision would **prevail** if we kept that promise as our first **priority**.

> その約束を最優先にすれば、公正な判断に落ち着くはずだった。

<a id="x087-09"></a>

**87.09**　We **termed** the box a temporary loan, paid the owner a fair fee and promised to return the stamps.

> 私たちは箱を一時借用品として扱い、持ち主に相応の料金を払い、切手は返すと約束した。

<a id="x087-10"></a>

**87.10**　The **encouraging** **revelation** was that one stamp showed the hall as it had stood before the storm.

> 希望が持てたのは、切手の一枚に嵐の前のホールの姿が写っていたことだった。

**読みの問い**　見つかった切手はどう扱うことになったか。

<a id="ex-story-088"></a>

### 88　二枚の札で違うことを言う

<a id="x088-01"></a>

**88.01**　The guide put two cards beside the clock.

> 案内人は時計の横に二枚の札を置いた。

<a id="x088-02"></a>

**88.02**　The first said, “The clock stopped at six.”

> 一枚目には「時計は六時に止まった」とあった。

<a id="x088-03"></a>

**88.03**　The second said, “A child stopped the clock at six.”

> 二枚目には「子どもが六時に時計を止めた」とあった。

<a id="x088-04"></a>

**88.04**　“I saw the clock stop,” said my father.

> 「時計が止まるのは見ました」と父は言った。

<a id="x088-05"></a>

**88.05**　“Did you see the child stop it?” asked the guide.

> 「その子が止めるのを見ましたか」と案内人が聞いた。

<a id="x088-06"></a>

**88.06**　My father shook his head and gave back the second card.

> 父は首を振り、二枚目の札を返した。

<a id="x088-07"></a>

**88.07**　I turned the first card over.

> 私は一枚目を裏返した。

<a id="x088-08"></a>

**88.08**　On the back someone had written, “And what about the little hand?”

> 裏には「ところで、あの小さな『手』は？」と書いてあった。

<a id="x088-09"></a>

**88.09**　Did they mean the hand on the clock or the hand that had stopped it?

> 時計の針のことだろうか、それとも時計を止めた手のことだろうか。

**読みの問い**　六時に時計の針が止まるのを見ただけで、どちらの札を残せるか。

<a id="ex-story-089"></a>

### 89　赤い点を探しに

<a id="x089-01"></a>

**89.01**　A **shocked** silence **reigned** when the doors finally opened and all the lights went out.

> いよいよ扉が開いたときに明かりが全部消え、驚きのあまり辺りは静まり返った。

<a id="x089-02"></a>

**89.02**　My first thought was that this was the most **embarrassing** opening our town had ever seen.

> 最初に思ったのは、町の歴史で一番きまりの悪い開幕になった、ということだった。

<a id="x089-03"></a>

**89.03**　An **awkward** laugh passed through the line, followed by a new **sort** of sound.

> 列の中でぎこちない笑いが起き、次に違う種類の音がした。

<a id="x089-04"></a>

**89.04**　A child was trying to **pronounce** a sign in the dark, asking what the **so-called** red dot actually meant.

> 子どもが暗闇で看板の文字を声に出して読もうとし、いわゆる『赤い点』が実際には何を意味するのかを尋ねていた。

<a id="x089-05"></a>

**89.05**　“I feel **dumb**,” he said, “because I cannot see the dot at all.”

> 「点が全然見えないから、僕がばかなのかな」と言った。

<a id="x089-06"></a>

**89.06**　“Even in **ideal** light it takes a little **nerve** to **risk** a guess,” my father told him.

> 「理想的な明るさでも、思い切って推測するには少し勇気がいるよ」と父は伝えた。

<a id="x089-07"></a>

**89.07**　“We can **rate** the light, but only you can decide the **significance** of the mark.”

> 「明るさを評価することはできるけれど、その印がどんな意味を持つか決めるのは君だ。」

<a id="x089-08"></a>

**89.08**　Our **norm** was to **say** nothing until we were **sure**; our town showed **unprecedented** **tolerance** for guesses that day.

> 普段の私たちには確信するまで黙っているという習慣があったが、この日の町はこれまでにないほど推測に寛容だった。

<a id="x089-09"></a>

**89.09**　Some people were **disappointed** when the lights came back: for a little while, the umbrella had belonged to everyone.

> 明かりが戻ったとき、がっかりした人もいた。しばらくの間、あの傘はみんなのものだったからだ。

**読みの問い**　照明が消えたおかげで、見学者の間にどんな変化があったか。

### 第1篇　読みの確認

**[50　開ける順番](#ex-story-050)**　女性が、なくなっていた窓の取っ手を持ってきたから。

**[51　二つの岸のあいだ](#ex-story-051)**　土地は持ち続けたが、店まで行く道がなくなった。

**[52　水位の跡](#ex-story-052)**　小さな一部分の陰影から傷みが分かり、ほかの部分には補修の記録を残せたから。

**[53　地下に残った仕事](#ex-story-053)**　模型の販売以外にも許可を求めていた契約条項。

**[54　鉱員の服](#ex-story-054)**　上着を最初に着ていた亡き仲間の名前を残したかったから。

**[55　箱に残った音](#ex-story-055)**　少年の息づかいと、廊下で戸をたたく音。

**[56　地図を逆にした舟乗り](#ex-story-056)**　水がどちらへ流れるかを示していた。

**[57　青い封筒を開く](#ex-story-057)**　記録にある一方の出来事がもう一方を引き起こしたとは断定できない。

**[58　棚に出さない一枚](#ex-story-058)**　公開に迷っていた娘が最後に提供を取り下げたから。

**[59　避難所の台所](#ex-story-059)**　料理係がミルクと砂糖にチョコレートを溶かしたものの味。

**[60　庭で眠る種](#ex-story-060)**　ネズミを獲物とするヘビ。

**[61　女王の最後の夜](#ex-story-061)**　女王を裏切るか、安全な場所まで逃がすか。

**[62　衣装部屋の女王](#ex-story-062)**　宝石や華やかなドレスに頼らず、女王役の存在が伝わる簡素な衣装。

**[63　王国が失ったもの](#ex-story-063)**　人々が暮らしていたその土地の実際の風景。

**[64　巡回法廷の木箱](#ex-story-064)**　投獄する根拠としては不十分だと判断した。

**[65　看板の裏の数字](#ex-story-065)**　増税と、巨額の広告費。

**[66　駅の裏口の行列](#ex-story-066)**　最後の列車が出るホームの外。

**[67　白いバッジを外した人](#ex-story-067)**　意見を異にする権利。

**[68　走る人と数える人](#ex-story-068)**　落ちた靴を届けてくれた十代のボランティア。

**[69　カメラのとらえた三秒](#ex-story-069)**　衝突前にカメラがほかを向き、事故の全体が映っていなかったから。

**[70　雨の峡谷の声](#ex-story-070)**　雪が滑り落ちた斜面が調査の範囲外だったから。

**[71　絵から外れたもの](#ex-story-071)**　額の裏のガラスを通して、もう一つの傘の像を映せるようにするため。

**[72　録音にまじった笑い声](#ex-story-072)**　若いころは交際し、その後も一生続いた二人の友情と結びつけた。

**[73　本の背から画面へ](#ex-story-073)**　表示された数値は入力に関するものだけで、出力については分からなかった。

**[74　誰が見ているか](#ex-story-074)**　外の防犯カメラが同じ周波数で画像を送信していたから。

**[75　焼け残った鐘](#ex-story-075)**　戦闘が終わったこと。

**[76　静かな部屋に描かれた獣](#ex-story-076)**　難しい理屈を使わず、怖そうに見えると率直に答えた。

**[77　土の中のパイオニア](#ex-story-077)**　餌を探して狩りをする範囲の違い。

**[78　水が運んだ粉](#ex-story-078)**　無作為に入れ替えて決めた。

**[79　看護学校への手紙](#ex-story-079)**　監督を受けながら歯科医の仕事を補助する働き方。

**[80　校門の小さな地図](#ex-story-080)**　事前に予約するか家族用パスを使うかの二通り。

**[81　橋を支えた石](#ex-story-081)**　最上段にかかる重み。

**[82　広場を巡る二つの考え](#ex-story-082)**　地域の人が出会い、互いに結びつける場所であること。

**[83　小包の赤いひも](#ex-story-083)**　開通の日を思い出すための、使用済みの切符だったから。

**[84　浅い眠りの窓辺](#ex-story-084)**　偶然出会ったカメラの作り手が、よいレンズと交換してくれたから。

**[85　本物の月はどちらか](#ex-story-085)**　筒から跳び出して青い球の上に落ちる仕掛けだった。

**[86　暮らしを取り戻した人](#ex-story-086)**　かつて危険を冒して集団からの脱出を手伝ってくれた友人。

**[87　ごみの箱を開ける](#ex-story-087)**　料金を払って一時的に借り、後で持ち主に返すことになった。

**[88　二枚の札で違うことを言う](#ex-story-088)**　一枚目。二枚目を残すには、止まった時刻に加え、止めた人が子どもだと言える根拠が要る。

**[89　赤い点を探しに](#ex-story-089)**　印の意味について、確信する前でも自由に推測を口にできた。

---

<a id="exp-part-2"></a>

## 第2篇　水位を記した人たち

夜明け、水路の流れが逆になった。同じ川辺の町でも、家族、技師、待合室で知らせを聞いた人では、その日に見えたものが違う。

[90　水位の印](#ex-story-090) ／ [91　六本の傘が向かう家](#ex-story-091) ／ [92　道を選ぶ白い線](#ex-story-092) ／ [93　ゆっくり育つリンゴ](#ex-story-093)

[94　開く傘、閉じた手](#ex-story-094) ／ [95　畑におとずれた春](#ex-story-095) ／ [96　待合室の灯](#ex-story-096) ／ [97　薬を飲む人の話](#ex-story-097)

[98　幕は港の絵](#ex-story-098) ／ [99　歌を返す壁](#ex-story-099) ／ [100　スポーツ館の置き忘れ](#ex-story-100) ／ [101　勝者の賞金](#ex-story-101)

[102　新聞に載せる一枚](#ex-story-102) ／ [103　集会の二つの票](#ex-story-103) ／ [104　裁判所の時計](#ex-story-104) ／ [105　名前を書かない扉](#ex-story-105)

[106　閉じた扉から来た手紙](#ex-story-106) ／ [107　手紙に残った戦争](#ex-story-107) ／ [108　井戸に映った空](#ex-story-108) ／ [109　炭鉱で消えた白い手](#ex-story-109)

[110　病院の予算会議](#ex-story-110) ／ [111　二枚の切符と一枚の領収書](#ex-story-111) ／ [112　画面の中の忘れ物](#ex-story-112) ／ [113　画面が教えない数字](#ex-story-113)

[114　見えない棚にも重さがある](#ex-story-114) ／ [115　台所の記憶](#ex-story-115) ／ [116　池から来た手紙](#ex-story-116) ／ [117　砂漠を運ぶ箱](#ex-story-117)

[118　空港で消えた点](#ex-story-118) ／ [119　隣の国の傘](#ex-story-119) ／ [120　選挙をする教室](#ex-story-120) ／ [121　三人の客が同じ部屋を見た](#ex-story-121)

[122　葬列の最後の楽譜](#ex-story-122) ／ [123　額の外に出る物語](#ex-story-123) ／ [124　手作りの番組](#ex-story-124) ／ [125　一枚の写真、二つの肩書](#ex-story-125)

[126　消えた名の競売](#ex-story-126) ／ [127　暮らしの値段、町の値段](#ex-story-127) ／ [128　手の届く宇宙](#ex-story-128) ／ [129　同じ顔をした双子の絵](#ex-story-129)

[130　放送の恐ろしい役名](#ex-story-130) ／ [131　許可証の裏の文字](#ex-story-131) ／ [132　水をこぼさない工夫](#ex-story-132) ／ [133　二人の決心](#ex-story-133)

[134　半分だけ光る月](#ex-story-134) ／ [135　反対の声の居場所](#ex-story-135) ／ [136　赤い点は商標か](#ex-story-136) ／ [137　いくらと言ったのは誰か](#ex-story-137)

[138　最終列車の前に](#ex-story-138)

<a id="ex-story-090"></a>

### 90　水位の印

<a id="x090-01"></a>

**90.01**　The first **warning** came at **dawn**.

> 最初の警報は夜明けに届いた。

<a id="x090-02"></a>

**90.02**　A **wet** **wind** blew across the **bay** and shook the **shiny** **metal** **pole** outside our **home**.

> 湿った風が湾を吹き渡り、家の外の光沢のある金属の柱を揺らした。

<a id="x090-03"></a>

**90.03**　My **sister** saw a brown **wave** **rise** over the **canal** wall.

> 妹は茶色の波が運河の壁を越えてくるのを見た。

<a id="x090-04"></a>

**90.04**　The wooden **bench** began to **swim** away like a small **vessel** without a sail.

> 木のベンチが帆のない小舟のように泳ぎ出した。

<a id="x090-05"></a>

**90.05**　“The **tide** is high,” our **father** said.

> 「潮が高い」と父が言った。

<a id="x090-06"></a>

**90.06**　“But that **current** is going the wrong way.”

> 「でも、あの流れは向きが逆だ」

<a id="x090-07"></a>

**90.07**　He **marked** the water **level** on the **brick** wall with a **pencil**.

> 父は鉛筆でれんがの壁に水位の印をつけた。

<a id="x090-08"></a>

**90.08**　A second mark soon lay a **handful** of inches above the first.

> 次の印は、まもなく最初の印より数インチ上についた。

<a id="x090-09"></a>

**90.09**　The **engineer** at the **dam** **called** to **explain** the sudden **surge**.

> ダムの技師が電話をかけてきて、急な増水のわけを話した。

<a id="x090-10"></a>

**90.10**　A **branch** had fallen across an **automatic** gate and **blocked** the **flow**.

> 枝が自動ゲートに引っかかり、水の流れを止めていた。

<a id="x090-11"></a>

**90.11**　Then the **branch** had broken, and the gate had opened all at once.

> やがて枝が折れ、ゲートが一気に開いたのだ。

<a id="x090-12"></a>

**90.12**　When we returned to the **yard**, a black **umbrella** lay against the **fence**.

> 庭に戻ると、柵に黒い傘が寄りかかっていた。

<a id="x090-13"></a>

**90.13**　On its handle was a little red **dot**.

> 持ち手には小さな赤い点があった。

**読みの問い**　妹は水のどこを見て、父は何に気づいたか。

<a id="ex-story-091"></a>

### 91　六本の傘が向かう家

<a id="x091-01"></a>

**91.01**　We carried the umbrella to the lost property **office** in the station.

> 私たちは傘を駅の遺失物窓口に届けた。

<a id="x091-02"></a>

**91.02**　A **kind** **woman** behind the **counter** opened a deep **cupboard**.

> カウンターの向こうの親切な女性が奥行きのある戸棚を開けた。

<a id="x091-03"></a>

**91.03**　She counted six black umbrellas and gave each one a paper **label**.

> 彼女は黒い傘を六本数え、一本ずつ紙の札をつけた。

<a id="x091-04"></a>

**91.04**　“Can you **name** the **owner** of the one with the red spot?” she asked.

> 「赤い印の傘の持ち主が誰か分かる？」と彼女は聞いた。

<a id="x091-05"></a>

**91.05**　My sister shook her head and pointed to its **rubber** tip.

> 妹は首を横に振り、そのゴムの先端を指した。

<a id="x091-06"></a>

**91.06**　There was **green** paint on the **bottom** and a narrow cut in the **leather**.

> 底には緑の塗料がつき、革には細い切れ目があった。

<a id="x091-07"></a>

**91.07**　She showed us the **spot** where the other five had been found.

> 女性は、ほかの五本が見つかった場所を教えてくれた。

<a id="x091-08"></a>

**91.08**　The woman opened her **desk** and **handed** us a **map**.

> 女性は机の引き出しを開け、私たちに地図を手渡した。

<a id="x091-09"></a>

**91.09**　“Here is my **proposal**,” she said.

> 「こうしてみたらどうかな」と彼女は言った。

<a id="x091-10"></a>

**91.10**　“Visit each **place** where someone has asked for an umbrella.”

> 「傘の問い合わせがあった場所を一か所ずつ回ってみて」

<a id="x091-11"></a>

**91.11**　“Write down the **tale** they tell, even if this umbrella belongs to another **person**.”

> 「この傘が別の人のものでも、みんなが話してくれたことを書き留めて」

<a id="x091-12"></a>

**91.12**　“Could we **exhibit** the stories here?” I asked.

> 「ここでその話を展示してもいい？」と私は聞いた。

<a id="x091-13"></a>

**91.13**　She gave a quick nod and a **generous** **supply** of **paper**.

> 彼女はすぐにうなずき、たっぷり紙をくれた。

<a id="x091-14"></a>

**91.14**　A whole exhibition about lost property was a **first** for our town.

> 町では、展覧会を丸ごと遺失物の話にするのはこれが初めてだった。

<a id="x091-15"></a>

**91.15**　The search had **become** an exhibition before it had even begun.

> 捜索は、始まる前から展覧会になっていた。

**読みの問い**　どんなときにも話を書き留めるよう頼まれたか。

<a id="ex-story-092"></a>

### 92　道を選ぶ白い線

<a id="x092-01"></a>

**92.01**　The first address was a **remote** farm above the **hill**.

> 最初に向かうのは丘の上の遠い農場だった。

<a id="x092-02"></a>

**92.02**　The **road** split at a **shallow** **stream**.

> 浅い小川のところで道が分かれていた。

<a id="x092-03"></a>

**92.03**　The left **path** ran through a **rough** **stretch** of **wet** **ground**.

> 左の小道は、でこぼこして濡れた地面の一帯を通っていた。

<a id="x092-04"></a>

**92.04**　The **other** one followed a row of trees to a **solid** bridge.

> もう一方は並木に沿って頑丈な橋まで続いていた。

<a id="x092-05"></a>

**92.05**　A grey **dog** **raced** past us and **jumped** into the water.

> 灰色の犬が私たちを追い越して走り、水に飛び込んだ。

<a id="x092-06"></a>

**92.06**　My sister **noticed** a white mark on a flat **rock**.

> 妹は平らな石に白い印を見つけた。

<a id="x092-07"></a>

**92.07**　“Does that **denote** the normal **depth**?”

> 「これは普段の深さを表すの？」

<a id="x092-08"></a>

**92.08**　A **resident** farmer **replied** that it showed the **usual** crossing.

> そこに住む農家の人が、いつも渡る場所の印だと答えた。

<a id="x092-09"></a>

**92.09**　His **cattle** could still walk across, but his **sheep** could not.

> 牛はまだ歩いて渡れたが、羊には無理だった。

<a id="x092-10"></a>

**92.10**　“Take the bridge and **lean** on the rail if the wind is **strong**.”

> 「橋を渡りなさい。風が強ければ手すりに体を預けて」

<a id="x092-11"></a>

**92.11**　We crossed in safety and carried on towards his house.

> 無事に渡って、その人の家に向かった。

<a id="x092-12"></a>

**92.12**　The dog **emerged** behind us with a **yellow** **boot** between its teeth.

> 後ろから犬が現れた。黄色いブーツをくわえていた。

**読みの問い**　牛と羊で道が違うのは、白い印の意味が変わったからか。

<a id="ex-story-093"></a>

### 93　ゆっくり育つリンゴ

<a id="x093-01"></a>

**93.01**　The farmer invited us in for **lunch**.

> 農家の人は私たちを家に招き、昼食を出してくれた。

<a id="x093-02"></a>

**93.02**　His **aunt** laid a white **cloth** on the table and set out three **plates**.

> その農家の人のおばがテーブルに白い布を敷いて、皿を三枚並べた。

<a id="x093-03"></a>

**93.03**　She had **cooked** **chicken** with **rice**, **pepper** and half a **carrot**.

> 彼女が用意したのは、鶏肉と米、こしょう、ニンジン半分を使った料理だった。

<a id="x093-04"></a>

**93.04**　A day outside had given me a real **appetite**.

> 一日外にいたおかげで、私はすっかりおなかがすいていた。

<a id="x093-05"></a>

**93.05**　A **single** **ingredient** gave the **meal** its **unusual** **taste**.

> その料理に珍しい風味を添えていたのは、一つの食材だった。

<a id="x093-06"></a>

**93.06**　My sister **guessed** apple **juice** and the old woman smiled.

> 妹がリンゴ果汁でしょうと言うと、おばさんは笑った。

<a id="x093-07"></a>

**93.07**　“People **expect** **fruit** to be **sweet**,” she said.

> 「果物なら甘いと思うでしょ」と彼女は言った。

<a id="x093-08"></a>

**93.08**　“My apples are **bitter** until they have been inside for a **month**.”

> 「うちのリンゴは家の中でひと月置くまで苦いんだよ」

<a id="x093-09"></a>

**93.09**　Their trees **flourish** in poor **soil**, and their **roots** go very deep.

> その木々はやせた土でもよく育ち、根をとても深く伸ばす。

<a id="x093-10"></a>

**93.10**　The local **supermarket** had **offered** to buy the whole crop.

> 近くのスーパーが収穫を丸ごと買い取ると申し出ていた。

<a id="x093-11"></a>

**93.11**　But the shop wanted a **rapid** return on its money.

> けれど店は、投じた金からすぐに利益を得たかった。

<a id="x093-12"></a>

**93.12**　It could not wait for the **natural** change that made the apples **delicious**.

> リンゴがおいしくなる自然な変化を待ってはいられなかった。

<a id="x093-13"></a>

**93.13**　“Farming is a **patient** business,” said my sister.

> 「農業には辛抱がいるね」と妹は言った。

<a id="x093-14"></a>

**93.14**　“The customer may be in a hurry, but dinner has its **own** time.”

> 「お客は急いでも、食べ物には自分の時間があるんだ」

**読みの問い**　スーパーとおばさんが待てる時間には、何の違いがあったか。

<a id="ex-story-094"></a>

### 94　開く傘、閉じた手

<a id="x094-01"></a>

**94.01**　After **dinner** the farmer took us to his **garage**.

> 食事の後、農家の人は私たちをガレージへ案内した。

<a id="x094-02"></a>

**94.02**　A **mechanical** **device** on his work table held a flat **blade**.

> 作業台には平らな刃を備えた機械装置が置かれていた。

<a id="x094-03"></a>

**94.03**　He had **installed** a small **lamp** above it for better **lighting**.

> よく見えるよう、すぐ上に小さなランプを取り付けていた。

<a id="x094-04"></a>

**94.04**　A newspaper **cutting** showed the farmer at the same table forty years ago.

> 新聞の切り抜きには、四十年前に同じ作業台に向かっていた農家の人が写っていた。

<a id="x094-05"></a>

**94.05**　He **shrugged** and slipped a **stiff** finger under the handle of the umbrella.

> 彼は肩をすくめ、こわばった指を傘の持ち手にかけた。

<a id="x094-06"></a>

**94.06**　“The **grasp** is the problem,” he said.

> 「握るのが難しいんだ」と言った。

<a id="x094-07"></a>

**94.07**　“My **wrist** does not **turn** the way it did in my youth.”

> 「手首が若いころのようには回らん」

<a id="x094-08"></a>

**94.08**　His **invention** let him open his old umbrella with the **slight** pressure of one **foot**.

> 彼の発明のおかげで、片足で少し押せば古い傘が開いた。

<a id="x094-09"></a>

**94.09**　He took a red rubber band and **wound** it round the new handle.

> 彼は赤い輪ゴムを取って、新しい持ち手に巻いた。

<a id="x094-10"></a>

**94.10**　“Try that for **comfort** before you **decide** whose it is.”

> 「誰のものか決める前に、それで持ちやすくなるか試して」

<a id="x094-11"></a>

**94.11**　A piece of **craft** could be a **gift** even when nobody took it away.

> 工夫を凝らした手仕事は、誰も現物を持ち帰らなくても贈り物になり得た。

<a id="x094-12"></a>

**94.12**　I borrowed a **rubber** to remove a pencil line that crossed the handle.

> 持ち手の上を横切ってしまった鉛筆の線を消すため、私は消しゴムを借りた。

<a id="x094-13"></a>

**94.13**　We drew the **mechanism** and left it on his table.

> 私たちは仕組みをスケッチし、装置は彼の机に置いてきた。

**読みの問い**　農家から持ち帰ったものは何だったか。

<a id="ex-story-095"></a>

### 95　畑におとずれた春

<a id="x095-01"></a>

**95.01**　The farmer found a black umbrella in the shed and opened it for us.

> 農家の人は物置で黒い傘を見つけて開いてくれた。

<a id="x095-02"></a>

**95.02**　A tiny **bird** had made a nest in a **box** on the top shelf.

> 小さな鳥が、一番上の棚の箱に巣を作っていた。

<a id="x095-03"></a>

**95.03**　The umbrella kept the box in the shade during the **hot** **summer**.

> その傘は、暑い夏の間、箱を日陰にしてやっていた。

<a id="x095-04"></a>

**95.04**　In **spring** the **eggs** needed a **regular** **temperature**.

> 春には卵を一定の温度に保つ必要があった。

<a id="x095-05"></a>

**95.05**　The farmer had measured the temperature beside the box and made a **daily** note.

> 農家の人は箱の横で温度を測り、毎日記録していた。

<a id="x095-06"></a>

**95.06**　An **expert** from a **wildlife** **association** wanted to **view** his records.

> 野生生物の団体の専門家が、その記録を見たがっていた。

<a id="x095-07"></a>

**95.07**　She had **advised** him to keep a **similar** box outside as a **control**.

> 比較のため、同じような箱を外に置くよう彼女は助言していた。

<a id="x095-08"></a>

**95.08**　A cool nest alone could not prove that the umbrella had saved the birds.

> 巣が涼しかっただけでは、傘が鳥を救ったとは証明できない。

<a id="x095-09"></a>

**95.09**　“Will the extra box **harm** them?” he asked.

> 「箱をもう一つ置くと、鳥に害はないか」と彼が聞いた。

<a id="x095-10"></a>

**95.10**　She asked him to leave the nest alone and **test** the **idea** after the birds left.

> 彼女は巣に手を触れず、鳥が巣立った後にその考えを試すよう頼んだ。

<a id="x095-11"></a>

**95.11**　We left with a **photo** of the umbrella and the promise of a small **report**.

> 私たちはその傘の写真を持ち帰り、短い報告を書いてもらう約束をした。

**読みの問い**　比較用の箱を用意する理由は何か。

<a id="ex-story-096"></a>

### 96　待合室の灯

<a id="x096-01"></a>

**96.01**　Our **return** from the farm took longer than the journey out.

> 農場からの帰路には、行きよりも時間がかかった。

<a id="x096-02"></a>

**96.02**　On our way back an **ambulance** passed us on the bridge.

> 帰り道、救急車が橋の上で私たちを追い越した。

<a id="x096-03"></a>

**96.03**　An **elderly** **man** had suffered a **stroke** at the **bus** stop.

> バス停で高齢の男性が脳卒中を起こしたのだった。

<a id="x096-04"></a>

**96.04**　His right **arm** felt **weak**, and his **speech** sounded **strange**.

> 右腕に力が入らず、話し方もいつもと違っていた。

<a id="x096-05"></a>

**96.05**　The **driver** stopped when a **teenager** called for **help**.

> 十代の子の助けを求める声を聞き、運転手は車を止めた。

<a id="x096-06"></a>

**96.06**　At the hospital a **junior** doctor checked his **eyes** and listened to his heart.

> 病院では若手の医師が男性の目を調べ、心音を聴いた。

<a id="x096-07"></a>

**96.07**　In a picture on the wall, each **organ** had a different colour.

> 壁の図では、臓器が一つずつ違う色で示されていた。

<a id="x096-08"></a>

**96.08**　She asked for his **consent** before a further **examination**.

> さらに診察を進める前に、医師は本人の同意を求めた。

<a id="x096-09"></a>

**96.09**　One **drug** lay ready for use, but the doctor did not reach for it.

> すぐに使える薬が一つ用意されていたが、医師はそれに手を伸ばさなかった。

<a id="x096-10"></a>

**96.10**　“The choice will **depend** on the pictures,” she told his wife.

> 「どうするかは画像を見て決めます」と医師は妻に伝えた。

<a id="x096-11"></a>

**96.11**　His wife was **scared** of an **injection** because he was already taking **medicine**.

> 夫がすでに薬を飲んでいたので、妻は注射を心配していた。

<a id="x096-12"></a>

**96.12**　The doctor sat beside her and explained the difference in a calm **voice**.

> 医師は隣に腰を下ろし、穏やかな声で違いを説明した。

<a id="x096-13"></a>

**96.13**　In that moment the waiting room seemed a less lonely **world**.

> そのとき、待合室が少しだけ孤独でない世界に感じられた。

**読みの問い**　用意してあった薬をすぐに使わなかったのはなぜか。

<a id="ex-story-097"></a>

### 97　薬を飲む人の話

<a id="x097-01"></a>

**97.01**　A **clinical** **researcher** was interviewing people in the next **ward**.

> 隣の病棟では、臨床研究者が人々に話を聞いていた。

<a id="x097-02"></a>

**97.02**　She invited my sister to **participate** in a small drawing **project**.

> 研究者は小さな絵の企画に参加しないかと妹を誘った。

<a id="x097-03"></a>

**97.03**　The **objective** was to see how people described **hurt** without a **word**.

> 言葉を使わずに痛みをどう伝えるかを知るのが目的だった。

<a id="x097-04"></a>

**97.04**　Each **individual** chose a shape and a colour on a card.

> 一人ひとりがカードの上で形と色を選んだ。

<a id="x097-05"></a>

**97.05**　A girl with a **headache** drew a **dark** **circle**.

> 頭の痛い女の子は暗い色の丸を描いた。

<a id="x097-06"></a>

**97.06**　A boy with pain in his **throat** drew a thin **flame**.

> 喉の痛い男の子は細い炎を描いた。

<a id="x097-07"></a>

**97.07**　The **researcher** did not **grade** a drawing or **compare** one child with another.

> 研究者は絵に点をつけず、子ども同士を比べることもしなかった。

<a id="x097-08"></a>

**97.08**　“The **interpretation** belongs to the **interviewee**,” she said.

> 「絵の意味を決めるのは、聞かれる側です」と彼女は言った。

<a id="x097-09"></a>

**97.09**　“A red circle might represent heat or fear, or just a **particular** sweet.”

> 「赤い丸は熱や怖さかもしれないし、ある決まったお菓子かもしれません」

<a id="x097-10"></a>

**97.10**　She asked each child for a **title** and kept it with the drawing.

> 研究者はそれぞれの子に題名を聞き、絵と一緒に残した。

<a id="x097-11"></a>

**97.11**　“I will have to **interview** the farmer about our red dot,” said my sister.

> 「うちの赤い点のことも、あの農家の人にちゃんと話を聞かなくちゃ」と妹は言った。

**読みの問い**　研究者は、絵だけを見て痛みの意味を決めたか。

<a id="ex-story-098"></a>

### 98　幕は港の絵

<a id="x098-01"></a>

**98.01**　Our next **appointment** was at the **theatre**, beside the harbour **entrance**.

> 次の約束は港の入口のそばにある劇場だった。

<a id="x098-02"></a>

**98.02**　An **actress** was painting a **broad** **canvas** for the **backdrop** of a new **musical**.

> 女優が新作ミュージカルの背景幕にする幅広い布に絵を描いていた。

<a id="x098-03"></a>

**98.03**　An **ancient** ship filled the middle of the **painting**.

> 絵の中央を古代の船が占めていた。

<a id="x098-04"></a>

**98.04**　A **pirate** in a purple **costume** stood on the **left**, raising a **pointed** **knife**.

> 左では紫色の衣装の海賊が、とがったナイフを掲げていた。

<a id="x098-05"></a>

**98.05**　“I **play** the captain and **star** in the last scene,” she said.

> 「船長役で、最後の場面では主役なの」と女優は言った。

<a id="x098-06"></a>

**98.06**　She pulled on a **shirt**, **fastened** her belt and **hid** her hair under a hat.

> 彼女はシャツを着て、ベルトを締め、帽子の下に髪を隠した。

<a id="x098-07"></a>

**98.07**　Our umbrella was the **perfect** object for a comic fight.

> 私たちの傘は、こっけいな戦いを演じるのにぴったりの小道具だった。

<a id="x098-08"></a>

**98.08**　She **pretended** to **stab** a **fierce** **bear** and hit the drum with the wrong end.

> どう猛なクマを刺すふりをして、反対の端で太鼓をたたいてしまった。

<a id="x098-09"></a>

**98.09**　The **bear** **yelled**, dropped his head and showed his real **nose**.

> クマはわっと叫び、かぶり物を落として本物の鼻をのぞかせた。

<a id="x098-10"></a>

**98.10**　It was the **famous** **singer** from the new **album** my sister had bought.

> 妹が買った新しいアルバムの有名な歌手だった。

<a id="x098-11"></a>

**98.11**　The **singer** found the accident **hilarious** and asked to keep it in the **script**.

> 歌手はこの失敗をとても面白がり、台本に残してほしいと言った。

<a id="x098-12"></a>

**98.12**　“Let the **joke** **arise** from the action,” he told the writer.

> 「動きからおかしさが生まれるようにしよう」と彼は作家に言った。

**読みの問い**　本番の台本に偶然の出来事を残そうとしたのは誰か。

<a id="ex-story-099"></a>

### 99　歌を返す壁

<a id="x099-01"></a>

**99.01**　The **composer** was listening from a **hidden** seat in the front row.

> 作曲家は前列の目立たない席で聞いていた。

<a id="x099-02"></a>

**99.02**　A **folk** **melody** came from a **guitar** and a single **horn**.

> ギターと一本のホルンが民謡の旋律を奏でた。

<a id="x099-03"></a>

**99.03**　The **classical** musician had to **convert** the **song** into something the organ could **sustain**.

> クラシックの奏者は、その歌をオルガンで音を保てる形に直す必要があった。

<a id="x099-04"></a>

**99.04**　A bell gave the children their **cue** for a **round** of **dancing**.

> 鐘が鳴ると、それが子どもたちがひと踊りする合図だった。

<a id="x099-05"></a>

**99.05**　They **missed** it because a **loud** **noise** came back from the wall.

> 壁から大きな音が返ってきて、子どもたちは合図を聞き逃した。

<a id="x099-06"></a>

**99.06**　“Please **position** the **frame** at an angle,” the composer said.

> 「枠を斜めに置いてくれますか」と作曲家が言った。

<a id="x099-07"></a>

**99.07**　The new **alignment** made the sound **travel** to the side.

> 新しい向きにすると、音は横へ進んだ。

<a id="x099-08"></a>

**99.08**　One **colleague** thought the change **marginal**; another thought it **immense**.

> ある同僚は変化はわずかだと思い、別の人は非常に大きいと感じた。

<a id="x099-09"></a>

**99.09**　We **walked** from seat to seat and wrote the **result** beside each **number**.

> 私たちは席を一つずつ回り、それぞれの番号の横に結果を書いた。

<a id="x099-10"></a>

**99.10**　A **blind** visitor could **detect** the echo long before we did.

> 目の見えない観客は、私たちよりずっと早く反響に気づいた。

<a id="x099-11"></a>

**99.11**　The **honour** of giving the final signal went to her.

> 最後の合図を出すという名誉ある役目は、彼女に任された。

<a id="x099-12"></a>

**99.12**　For one **performance** she would be the most **influential** **ear** in town.

> 一回の公演にかぎっては、彼女の耳が町でいちばん影響力を持つことになる。

**読みの問い**　席を移って聞いたのは、二人の意見が正反対だったからか。

<a id="ex-story-100"></a>

### 100　スポーツ館の置き忘れ

<a id="x100-01"></a>

**100.01**　The **gym** was the next **venue** on our **list**.

> 訪問リストの次の会場は体育館だった。

<a id="x100-02"></a>

**100.02**　A coach was helping a **kid** **bounce** a **basketball** against a wall.

> コーチが、子どもにバスケットボールを壁に当てて弾ませる方法を教えていた。

<a id="x100-03"></a>

**100.03**　At the **indoor** **tennis** court a **trainer** asked us to **watch** a tennis player take a swing.

> 屋内テニスコートでは、トレーナーに選手のスイングを見るよう頼まれた。

<a id="x100-04"></a>

**100.04**　She tried to **hit** the ball with a **smooth** **spin**.

> 選手はボールに滑らかな回転をかけて打とうとした。

<a id="x100-05"></a>

**100.05**　The **baseball** **club** had left a **plastic** bat beside her bag.

> 野球部が彼女のかばんの横にプラスチックのバットを置き忘れていた。

<a id="x100-06"></a>

**100.06**　A **hockey** player **knocked** on the door looking for a lost glove.

> ホッケーの選手がドアをノックした。なくした手袋を探していた。

<a id="x100-07"></a>

**100.07**　Then a **soccer** **referee** came to **retrieve** his watch.

> 続いてサッカーの審判が時計を取りに来た。

<a id="x100-08"></a>

**100.08**　His **busy** **weekend** had begun with a **junior** **league** **game** at **noon**.

> 審判の忙しい週末は、正午のジュニアリーグの試合から始まっていた。

<a id="x100-09"></a>

**100.09**　A **runner** had missed her **start** and asked for a second **try**.

> 走者がスタートを逃し、もう一度やらせてほしいと言っていた。

<a id="x100-10"></a>

**100.10**　“The **rule** is the same for every **athlete**,” he told us.

> 「規則はどの競技者にも同じだ」と審判は私たちに言った。

<a id="x100-11"></a>

**100.11**　“But some rules have to **cover** an **exceptional** case.”

> 「でも、例外的な事態を考えに入れた規則も必要だ」

<a id="x100-12"></a>

**100.12**　A boy had fallen on the track, and she had stopped to help him.

> 男の子が走路で転び、その走者は助けようと立ち止まったのだった。

<a id="x100-13"></a>

**100.13**　Her **chance** to **achieve** her **goal** had gone in a single **second**.

> 目標を達成するチャンスは一秒で消えていた。

<a id="x100-14"></a>

**100.14**　We put her race number in our **exhibit** beside the written **decision** of the referee.

> 私たちは走者のゼッケンを、審判の判断を書いた紙と並べて展示に加えた。

**読みの問い**　走者が遅れた理由を知って、二度目の機会の意味はどう変わるか。

<a id="ex-story-101"></a>

### 101　勝者の賞金

<a id="x101-01"></a>

**101.01**　The annual sports **tournament** had a new **sponsor**.

> 毎年恒例のスポーツ大会に新しいスポンサーがついた。

<a id="x101-02"></a>

**101.02**　A large **corporation** wanted to **finance** a silver cup for the **winner**.

> ある大企業が優勝者の銀杯の費用を出したがっていた。

<a id="x101-03"></a>

**101.03**　It would **award** the same prize to the two members of a winning team.

> チーム優勝なら二人の選手に同じ賞を授けるという。

<a id="x101-04"></a>

**101.04**　A keen **competitor** welcomed the **incentive**, but her **mate** took a different **stance**.

> 熱心な出場者は励みになると喜んだが、相棒の考えは違った。

<a id="x101-05"></a>

**101.05**　“Why **target** only the **best**?” she asked the **representative**.

> 「なぜいちばんの選手だけが対象なんですか」と彼女は企業の担当者に聞いた。

<a id="x101-06"></a>

**101.06**　“Some of us **strive** just to **regain** our **fitness** after a long illness.”

> 「長い病気の後、体力を取り戻そうと頑張っている人もいます」

<a id="x101-07"></a>

**101.07**　The **public** had paid an **entrance** **charge** and wanted a **say** in the **award**.

> 観客は入場料を払っており、賞の決め方にも発言権を求めていた。

<a id="x101-08"></a>

**101.08**　One fan had already **bet** his **pay** for a week on the **likely** winner.

> あるファンはすでに、一週間分の給料を優勝しそうな選手に賭けていた。

<a id="x101-09"></a>

**101.09**　The **committee** refused to **ban** the cup or to **endorse** the betting.

> 委員会はカップを廃止することも、賭けを支持することも拒んだ。

<a id="x101-10"></a>

**101.10**　Instead it asked the sponsor to **fund** a **monthly** **session** for **disabled** players.

> その代わりに、障害のある選手のための月一回の練習会の資金を求めた。

<a id="x101-11"></a>

**101.11**　The players could **enrol** for free and choose who would **coach** them.

> 選手は無料で申し込み、誰に指導してもらうか選べた。

<a id="x101-12"></a>

**101.12**　My sister called that the **victory** worth writing about.

> 妹は、それこそ書き残す価値のある勝利だと言った。

**読みの問い**　相棒が求めたのは賞をなくすことだったか。

<a id="ex-story-102"></a>

### 102　新聞に載せる一枚

<a id="x102-01"></a>

**102.01**　Our **photo** of the borrowed cup appeared in the local newspaper.

> 借りたカップの写真が地元紙に載った。

<a id="x102-02"></a>

**102.02**　The **editor** wanted it for the **cover** of a special issue.

> 編集者は特集号の表紙に使いたかった。

<a id="x102-03"></a>

**102.03**　A **columnist** wrote a short **comment** about our search, and a **correspondent** sent in a different **viewpoint**.

> コラムニストが捜索について短い感想を書き、通信員は違う見方を寄せた。

<a id="x102-04"></a>

**102.04**　The **columnist** wanted a **cheerful** **portrait** of town life.

> コラムニストは明るい町の姿を描きたかった。

<a id="x102-05"></a>

**102.05**　The other writer wanted to **challenge** the comfortable **notion** of a town without **conflict**.

> もう一人は、対立のない町という心地よい見方を問い直したかった。

<a id="x102-06"></a>

**102.06**　A reader had already published an **accusation** of **dishonest** **marketing** on her **blog**.

> 読者のブログにはすでに、不正な宣伝だという非難が載っていた。

<a id="x102-07"></a>

**102.07**　An **advertisement** used our picture to **sell** a copy of the cup.

> 広告が私たちの写真を使って、カップの複製品を売っていたのだ。

<a id="x102-08"></a>

**102.08**　Its **commercial** value lay in the **impression** that the team had approved it.

> その広告の商業価値は、チームが承認したような印象にあった。

<a id="x102-09"></a>

**102.09**　The editor **requested** the original **text** and the **receipt** for the picture.

> 編集者は元の文面と写真代の領収書を求めた。

<a id="x102-10"></a>

**102.10**　A signed receipt would have proved payment, but not consent.

> 署名入りの領収書があれば支払いは証明できたが、同意までは証明できなかった。

<a id="x102-11"></a>

**102.11**　The team had had no **conversation** with the **dealer** at all.

> チームは販売業者と一度も話をしていなかった。

<a id="x102-12"></a>

**102.12**　The editor replaced the picture with a **sketch** and **printed** the correction on the same **page**.

> 編集者は写真をスケッチに差し替え、同じページに訂正を載せた。

**読みの問い**　写真が有料だったとしても、何がまだ確かめられないか。

<a id="ex-story-103"></a>

### 103　集会の二つの票

<a id="x103-01"></a>

**103.01**　The **county** council asked for our **evidence** at a **public** **gathering**.

> 州議会は公開集会で私たちに証拠を示してほしいと頼んだ。

<a id="x103-02"></a>

**103.02**　The **councillor** for our **constituency** put a **ballot** box on the table.

> 地元選挙区の議員がテーブルに投票箱を置いた。

<a id="x103-03"></a>

**103.03**　A **conservative** **politician** hoped to **prohibit** all advertising inside the sports hall.

> 保守派の政治家は体育館内の広告を全面禁止したがっていた。

<a id="x103-04"></a>

**103.04**　A **liberal** **representative** was **opposed** to a complete ban.

> リベラル派の代表は全面禁止に反対だった。

<a id="x103-05"></a>

**103.05**　They could agree on one **crucial** **clause** in the proposed **legislation**.

> 二人は法案の中の重要な一条では一致できた。

<a id="x103-06"></a>

**103.06**　“A picture of a child must not **appear** in an advertisement without **parental** consent.”

> 「保護者の同意がなければ、子どもの写真を広告に掲載してはならない」

<a id="x103-07"></a>

**103.07**　A **civic** group asked for a **formal** **definition** of consent.

> 市民団体が、同意の正式な定義を求めた。

<a id="x103-08"></a>

**103.08**　Was silence an **implicit** agreement, or did a **signature** have to accompany the request?

> 沈黙は暗黙の合意なのか、それとも依頼に署名が伴わなければならないのか。

<a id="x103-09"></a>

**103.09**　Our **delegation** asked the **citizens** to **vote** on that **question** first.

> 私たちの代表団は、市民にまずその問いに投票してもらった。

<a id="x103-10"></a>

**103.10**　The **turnout** was small, but the majority wanted a **specific** written **answer**.

> 投票者は少なかったが、過半数は具体的な書面での回答を求めた。

<a id="x103-11"></a>

**103.11**　The **decision** on the wider **reform** would follow the next day.

> より広い改革についての判断は、翌日に行われることになっていた。

**読みの問い**　最初の投票で広告の全面禁止が決まったか。

<a id="ex-story-104"></a>

### 104　裁判所の時計

<a id="x104-01"></a>

**104.01**　A **lawyer** asked us to attend the **proceedings** in a different case.

> 弁護士が、別の事件の審理を傍聴しないかと誘った。

<a id="x104-02"></a>

**104.02**　A **thief** had stolen a **ring** from a glass case in a downtown hotel.

> 泥棒が中心街のホテルのガラスケースから指輪を盗んだのだった。

<a id="x104-03"></a>

**104.03**　The **guard** had seen a tall figure in an **unusual** **outfit**.

> 警備員は、変わった服装をした背の高い人影を見ていた。

<a id="x104-04"></a>

**104.04**　A witness claimed to have seen the same man **shop** for a wedding **suit**.

> 証人は、同じ男性が結婚式用のスーツを買おうと探しているところを見たと主張した。

<a id="x104-05"></a>

**104.05**　On the price label, the final **figure** was too small to read.

> 値札の末尾の数字は小さすぎて読めなかった。

<a id="x104-06"></a>

**104.06**　The **magistrate** asked the witness to **state** the precise **hour**.

> 判事は正確な時刻を述べるよう証人に求めた。

<a id="x104-07"></a>

**104.07**　An honest **approximation** would have done less **harm** than a false claim to **precision**.

> 見当だと正直に言った方が、誤って正確だと言い切るより害は少なかっただろう。

<a id="x104-08"></a>

**104.08**　The defence showed that the clock had stopped a **quarter** of an **hour** before the theft.

> 弁護側は、時計が盗難の十五分前に止まっていたことを示した。

<a id="x104-09"></a>

**104.09**　The witness had every **reason** to **believe** the time and no **credible** way to **check** it.

> 証人にはその時刻を信じる十分な理由があったが、それを確認する信頼できる方法はなかった。

<a id="x104-10"></a>

**104.10**　The court chose to **dismiss** that **detail** and **seek** other **proof**.

> 裁判所はその細部を採用せず、別の証拠を探すことにした。

<a id="x104-11"></a>

**104.11**　My sister wrote, “A stopped clock can **confuse** a careful witness.”

> 妹は「止まった時計は、慎重な証人をも迷わせる」と書いた。

**読みの問い**　証人の誠実さと、証言の正確さは、この話でどのように分かれるか。

<a id="ex-story-105"></a>

### 105　名前を書かない扉

<a id="x105-01"></a>

**105.01**　The **archive** for the exhibition was in an **upstairs** room of the local **library**.

> 展覧会の資料庫は地元図書館の上階の一室にあった。

<a id="x105-02"></a>

**105.02**　The **administrator** had made the lower **entrance** **accessible** to every **resident**.

> 管理者は、下の階の入口をどの住民でも利用できるようにしていた。

<a id="x105-03"></a>

**105.03**　A **private** interview room offered **shelter** to anyone who wanted to give an account in confidence.

> 人に知られず体験を語りたい人には、個室の聞き取り部屋が安心できる場所になった。

<a id="x105-04"></a>

**105.04**　A **survivor** of **rape** had offered a statement for the exhibition.

> 強姦の被害に遭った人が、展覧会に証言を寄せていた。

<a id="x105-05"></a>

**105.05**　It said that a man she had known for years had **raped** her.

> 長年知っていた男性に強姦されたと、その証言にはあった。

<a id="x105-06"></a>

**105.06**　She had felt **shame** and **fear**, although the **offence** was his.

> 罪を犯したのは彼だったのに、彼女は恥と恐怖を感じていた。

<a id="x105-07"></a>

**105.07**　She agreed to **donate** her account on one **firm** condition.

> 証言を提供するにあたって、彼女は譲れない条件を一つ示した。

<a id="x105-08"></a>

**105.08**　No name, date or **landmark** could identify the writer; her **privacy** came first.

> 名前や日付、土地の目印から書き手が特定されてはならない。彼女のプライバシーが最優先だった。

<a id="x105-09"></a>

**105.09**　A **specialist** offered **guidance** on how to **preserve** the **integrity** of the account.

> 証言の内容を忠実に保つ方法を、専門家が助言した。

<a id="x105-10"></a>

**105.10**　We **read** her words back and asked whether she would **consent** to the final **copy**.

> 文面を彼女に読み上げ、最終稿に同意してもらえるか尋ねた。

<a id="x105-11"></a>

**105.11**　A **verbal** promise was not enough for this **sensitive** **matter**.

> この繊細な問題には口約束だけでは足りなかった。

<a id="x105-12"></a>

**105.12**　She kept the right to **request** the removal of her statement at any time.

> 彼女にはいつでも証言の撤去を求める権利があった。

**読みの問い**　名前だけ消せばよいとしなかったのはなぜか。

<a id="ex-story-106"></a>

### 106　閉じた扉から来た手紙

<a id="x106-01"></a>

**106.01**　A second account had come from an **inmate** who was serving a sentence for **serious** **assault**.

> 二通目の手記は、重大な暴行で服役中の人から届いた。

<a id="x106-02"></a>

**106.02**　He had **assaulted** a **drunk** visitor outside a **casino**.

> 彼はカジノの外で酔った客に暴行したことがあった。

<a id="x106-03"></a>

**106.03**　The first **sentence** of his letter was just three words long.

> 手紙の最初の文は、わずか三語だった。

<a id="x106-04"></a>

**106.04**　His **confession** did not offer his anger as an **excuse**.

> その告白は、自分の怒りを言い訳にしていなかった。

<a id="x106-05"></a>

**106.05**　“I wanted to **punch** him because he had shouted an **insult**,” he wrote.

> 「侮辱の言葉を浴びせられ、殴りたいと思った」と書いていた。

<a id="x106-06"></a>

**106.06**　“The **intent** was mine; the **punishment** was mine too.”

> 「そうするつもりだったのは私だし、罰を受けたのも私だ」

<a id="x106-07"></a>

**106.07**　In **custody** he had learned to **carve** a bird from one **chunk** of wood.

> 拘禁されていた間、彼は一つの木片から鳥を彫ることを学んだ。

<a id="x106-08"></a>

**106.08**　His **mentor** had advised him to **concentrate** on the cut his hand was making now.

> 指導者は、今その手で削っている一か所に集中するよう助言した。

<a id="x106-09"></a>

**106.09**　“Can **rehabilitation** happen while the **underlying** disorder remains?” he asked.

> 「根本にある障害が続いていても、立ち直ることはできるのか」と彼は尋ねた。

<a id="x106-10"></a>

**106.10**　He did not **desire** an easy **answer** or a declaration that he was **evil**.

> 彼は簡単な答えも、自分は邪悪だという宣告も望んでいなかった。

<a id="x106-11"></a>

**106.11**　The papers on the desk were in such **disorder** that we almost lost the last page of his letter.

> 机の書類はとても散らかっていて、手紙の最後のページをなくしかけた。

<a id="x106-12"></a>

**106.12**　The board agreed to show the bird with the words of the writer.

> 委員会は、書き手自身の言葉と一緒に鳥を展示することに同意した。

<a id="x106-13"></a>

**106.13**　To **jail** someone, the woman at the library said, does not make his voice the property of an **institution**.

> 人を投獄しても、その声が施設の所有物になるわけではない、と図書館の女性は言った。

**読みの問い**　鳥をただの「立ち直りの証拠」として展示しなかったのはなぜか。

<a id="ex-story-107"></a>

### 107　手紙に残った戦争

<a id="x107-01"></a>

**107.01**　An old truck carried a box of letters down from the **mountain**.

> 古いトラックが、手紙の詰まった箱を山から運んできた。

<a id="x107-02"></a>

**107.02**　The writer had joined a **militia** as a young **recruit**, before a foreign **troop** entered his valley.

> 書き手は若い新兵のころ、外国部隊が谷に入る前に民兵組織に加わっていた。

<a id="x107-03"></a>

**107.03**　He remembered the first **aircraft** alarm, then the **continuous** **bombing** of the **capital**.

> 最初の空襲警報、次いで首都への途切れない爆撃を覚えていた。

<a id="x107-04"></a>

**107.04**　A **missile** had struck the station; the **blast** had broken every window in the street.

> ミサイルが駅に命中し、爆風で通りの窓はすべて割れた。

<a id="x107-05"></a>

**107.05**　The soldiers had orders to **blast** a hole through a wall and **fire** at any moving **weapon**.

> 兵士には、爆破して壁に穴を開け、動く武器なら何にでも発砲せよという命令があった。

<a id="x107-06"></a>

**107.06**　In a night **raid** a **nervous** guard saw a **firearm** where there was only a water pipe.

> 夜の襲撃で、緊張した見張りはただの水道管を銃と見誤った。

<a id="x107-07"></a>

**107.07**　The **shooting** that followed had a **fatal** **result**.

> 続く銃撃で人が亡くなった。

<a id="x107-08"></a>

**107.08**　“What was the **motive** for the **attack**?” his young daughter had asked.

> 「何のための攻撃だったの」と幼い娘は尋ねていた。

<a id="x107-09"></a>

**107.09**　He could **recall** the sound of the **trigger** but no **sound** **justification** for pulling it.

> 引き金の音は思い出せても、引くべき確かな理由は思い出せなかった。

<a id="x107-10"></a>

**107.10**　A **historian** warned that it was wrong to **condemn** an entire **tribe** as **aggressive**.

> 歴史家は、部族全体を攻撃的だと断じるのは誤りだと注意した。

<a id="x107-11"></a>

**107.11**　One **brave** soldier had chosen to **desert** his unit rather than **torture** a prisoner.

> ある勇気ある兵は、捕虜を拷問するくらいならと部隊を脱走した。

<a id="x107-12"></a>

**107.12**　For the **defence** of the village, the soldiers built a wall beside the road.

> 村を守るため、兵士たちは道のそばに壁を築いた。

<a id="x107-13"></a>

**107.13**　The letters did not settle the **disagreement** about the war.

> 手紙がその戦争をめぐる意見の対立を解いたわけではなかった。

<a id="x107-14"></a>

**107.14**　They did **disturb** the easy division between friend and **alien** enemy.

> それでも、味方と異邦の敵という単純な線引きは揺らいだ。

**読みの問い**　書き手が覚えていることと、説明できないことを一つずつ拾う。

<a id="ex-story-108"></a>

### 108　井戸に映った空

<a id="x108-01"></a>

**108.01**　Behind the library a wooden **wheel** hung above an old **well**.

> 図書館の裏の古井戸には木製の滑車が掛かっていた。

<a id="x108-02"></a>

**108.02**　A **peasant** family once used it to **supply** water to a **poor** **neighbourhood**.

> 昔、ある農家の一家がそれで貧しい地区に水を供給していた。

<a id="x108-03"></a>

**108.03**　Here a local **landmark** connected the modern **suburb** with its distant **past**.

> この土地の目印が今の郊外と遠い過去をつないでいた。

<a id="x108-04"></a>

**108.04**　A **scholar** had found a deed that called the well the property of a **lord**.

> 学者が見つけた権利証書には、井戸は領主の所有とあった。

<a id="x108-05"></a>

**108.05**　A **later** **charter** allowed every family to draw a **reasonable** **allowance** each day.

> 後の特許状は、どの家族にも一日ごとに妥当な割当量をくみ上げることを認めていた。

<a id="x108-06"></a>

**108.06**　The people of the town still remembered this good **deed**.

> 町の人たちは今も、この善い行いを覚えていた。

<a id="x108-07"></a>

**108.07**　A stone beside the well showed a **slave** with a rope across his **breast**.

> 井戸端の石には、胸に縄を渡した奴隷の姿が表されていた。

<a id="x108-08"></a>

**108.08**　Our guide could not **establish** the **origin** of the stone or date its **insertion** in the wall.

> 案内人には、その石の由来も、いつ壁に組み込まれたのかも確かめられなかった。

<a id="x108-09"></a>

**108.09**　A **holy** image on the other side seemed to show a **saint** or an **angel**.

> 反対の面の聖なる像は、聖人か天使を表しているようだった。

<a id="x108-10"></a>

**108.10**　A visiting **bishop** thought the mark above its head was a **crown**.

> 訪れた司教は、頭の上の印は冠だと思った。

<a id="x108-11"></a>

**108.11**　A **monk** from a nearby temple said it could also **resemble** the rising sun.

> 近くの寺の僧は、昇る太陽に見えなくもないと言った。

<a id="x108-12"></a>

**108.12**　One guide invited people of every belief to **pray** there or simply to **rest** on the stone seat.

> ある案内人は、どんな信仰の人でも、そこで祈っても石の腰掛けでただ休んでもよいと言った。

<a id="x108-13"></a>

**108.13**　A **mosque** across the square now shared the well yard as a place of **worship**.

> 今は広場を挟んだモスクも、井戸の庭を礼拝の場にしていた。

<a id="x108-14"></a>

**108.14**　“We do not all **worship** in the same way,” said our **host**.

> 「みんなが同じやり方で礼拝するわけではない」と案内役は言った。

<a id="x108-15"></a>

**108.15**　“But we all need water.”

> 「でも、水はみんなにいる」

**読みの問い**　石が壁に組み込まれた時期が分かれば、像の意味まで確定するだろうか。

<a id="ex-story-109"></a>

### 109　炭鉱で消えた白い手

<a id="x109-01"></a>

**109.01**　From the **top** of the hill we could see the roof of the library.

> 丘の頂上からは図書館の屋根が見えた。

<a id="x109-02"></a>

**109.02**　Beneath the hill lay a **mine** where men had once dug **coal**.

> 丘の地下には、かつて人々が石炭を掘り出した鉱山があった。

<a id="x109-03"></a>

**109.03**　The decline of **mining** had left the industrial **sector** without its largest **asset**.

> 鉱業の衰退で、この工業部門は最大の資産を失った。

<a id="x109-04"></a>

**109.04**　In a **covered** room the guide showed us a **machine** that could **extract** a **full** **truck** of coal in a morning.

> 屋根のある部屋で、案内人は午前中に石炭をトラック一台分採掘できる機械を見せてくれた。

<a id="x109-05"></a>

**109.05**　An old pair of boots and a **neat** **pile** of black gloves lay on the floor.

> 使い古されたブーツと、きちんと積んだ黒い手袋が床にあった。

<a id="x109-06"></a>

**109.06**　One glove made for a child had remained white under a thick layer of **dust** and **ash**.

> 厚いほこりと灰の下で、子ども用の手袋が一枚、白いまま残っていた。

<a id="x109-07"></a>

**109.07**　Fine **powder** had entered the miners' lungs and damaged their **skin**.

> 細かい粉が鉱員の肺に入り、肌も傷つけていた。

<a id="x109-08"></a>

**109.08**　Their **exposure** to it had caused a **disease** that often appeared years **later**.

> それを浴びたことが、何年も後に発症することも多い病気の原因になった。

<a id="x109-09"></a>

**109.09**　A **practitioner** had measured the **prevalence** of the disease in every **age** group.

> 医師は各年齢層で、その病気にかかっている人の割合を調べていた。

<a id="x109-10"></a>

**109.10**　The **statistical** **analysis** was an important **addition** to the workers' personal accounts.

> 統計分析は労働者の個々の証言を補う重要な資料だった。

<a id="x109-11"></a>

**109.11**　An unusual spot on a picture showed an **abnormality**, but one spot was not an entire diagnosis.

> 画像の珍しい影は異常を示したが、その一つの影で診断が決まるわけではなかった。

<a id="x109-12"></a>

**109.12**　He was **used** to working in the dark.

> 彼は暗いところで作業するのに慣れていた。

<a id="x109-13"></a>

**109.13**　The guide had been a miner himself; he let us touch the white glove.

> 案内人もかつて鉱員で、その白い手袋に触れさせてくれた。

<a id="x109-14"></a>

**109.14**　“It belonged to my little sister,” he said.

> 「妹のだったんだ」と彼は言った。

<a id="x109-15"></a>

**109.15**　“She gave it to me for luck before my first shift.”

> 「最初の勤務の前に、お守りにって渡してくれた」

**読みの問い**　ここで統計分析は何を補っているか。

<a id="ex-story-110"></a>

### 110　病院の予算会議

<a id="x110-01"></a>

**110.01**　The workers' letters **prompted** a debate about **healthcare** **spending**.

> 労働者の手紙をきっかけに、医療支出について議論が起こった。

<a id="x110-02"></a>

**110.02**　An **economist** offered an **estimate** of the cost of free health checks.

> 経済学者は、無料の健康診断にかかる費用の見積もりを示した。

<a id="x110-03"></a>

**110.03**　The **expenditure** would **amount** to about a **euro** per worker per week.

> 支出は、労働者一人につき週一ユーロほどになるという。

<a id="x110-04"></a>

**110.04**　The **benefit** was harder to **compute**, because future illness could only be a **probability**.

> 将来の発病は確率でしか示せないので、得られる利益はもっと計算しづらかった。

<a id="x110-05"></a>

**110.05**　The chair asked for a **comparative** study of two **possible** plans.

> 議長は、候補となる二つの計画を比較する調査を求めた。

<a id="x110-06"></a>

**110.06**　Under the first, a **mobile** clinic would **tour** the **remote** villages.

> 第一案なら、移動診療所が遠くの村々を巡る。

<a id="x110-07"></a>

**110.07**　Under the second, the **county** would **pay** for **transport** to the hospital **centre**.

> 第二案なら、州が医療センターまでの交通費を負担する。

<a id="x110-08"></a>

**110.08**　The chief **determinant** was the **ratio** of patients to available nurses.

> 決め手となる大きな要素は、患者の数と勤務可能な看護師の数との比だった。

<a id="x110-09"></a>

**110.09**　The **initial** figures did not **encompass** pregnant women or an **infant** who needed special care.

> 当初の数字には、妊婦や、特別なケアを必要とする乳児一人が含まれていなかった。

<a id="x110-10"></a>

**110.10**　A **worried** mother asked the council to **allocate** an **additional** nurse to the clinic.

> 心配した母親が議会に、診療所へ看護師をもう一人配置するよう求めた。

<a id="x110-11"></a>

**110.11**　A government **subsidy** would be **conditional** on proof of the **effectiveness** of the service.

> 行政の補助金が出る条件は、このサービスの有効性を証明することだった。

<a id="x110-12"></a>

**110.12**　The council agreed to **implement** a **short-term** trial and **review** it in **June**.

> 議会は短期試行を実施し、六月に見直すことに同意した。

**読みの問い**　一人につき週一ユーロという数字だけで、二案を選べるか。

<a id="ex-story-111"></a>

### 111　二枚の切符と一枚の領収書

<a id="x111-01"></a>

**111.01**　At the station an **investor** waited to discuss a proposed railway **merger**.

> 駅では、鉄道会社の合併案について話し合おうと、投資家が待っていた。

<a id="x111-02"></a>

**111.02**　The **bank** had offered **credit**, but the smaller company already had a substantial **debt**.

> 銀行は融資を申し出ていたが、小さい方の会社にはすでに多額の負債があった。

<a id="x111-03"></a>

**111.03**　A new **bill** for **electricity** and **heating** would put it under further **strain**.

> 電気代と暖房費の新しい請求書で、会社の負担はさらに増す見込みだった。

<a id="x111-04"></a>

**111.04**　A **generous** public **donation** had covered part of the **burden**, but could not **sustain** an entire **network**.

> 市民の気前のよい寄付で負担の一部はまかなえたが、路線網全体は支えられなかった。

<a id="x111-05"></a>

**111.05**　An **independent** report put the expected **gain** below the cost of the **acquisition**.

> 独立した立場の報告書は、予想される利益は買収費を下回るとした。

<a id="x111-06"></a>

**111.06**　“Will you **invest** if ticket **sales** **decrease**?” a passenger asked.

> 「切符の売り上げが減っても投資しますか」と客がたずねた。

<a id="x111-07"></a>

**111.07**　The investor would **negotiate** a lower price, he said, but first he wanted to **obtain** the accounts.

> 投資家は価格を下げる交渉をするが、まずは帳簿を入手したいと答えた。

<a id="x111-08"></a>

**111.08**　His **forecast** had been **optimistic** about summer **travel** and negative about winter demand.

> この人の見通しは、夏の旅行需要については楽観的で、冬については否定的だった。

<a id="x111-09"></a>

**111.09**　He had **failed** to **forecast** the **disruption** caused by the flood.

> 洪水によって生じた運行の混乱は予測できていなかった。

<a id="x111-10"></a>

**111.10**　A passenger held up two tickets for one **journey** and asked for his money back.

> 乗客が一回の旅のための切符を二枚掲げ、返金を求めた。

<a id="x111-11"></a>

**111.11**　“Before you **bill** us again, decide how many trips we actually made.”

> 「また請求する前に、私たちが実際に何回乗ったのか決めてください」

**読みの問い**　客が切符二枚分の代金を払ったことは、二回列車に乗った証拠になるか。

<a id="ex-story-112"></a>

### 112　画面の中の忘れ物

<a id="x112-01"></a>

**112.01**　A young **IT** teacher offered an **innovative** **link** between the exhibition and the town.

> 若い情報技術の先生が、展覧会と町を結びつける新しい手段を提案した。

<a id="x112-02"></a>

**112.02**　Her **app** would let people **search** for a lost object on a **smartphone** or a **computer**.

> 彼女のアプリなら、スマートフォンでもパソコンでも忘れ物を探せるという。

<a id="x112-03"></a>

**112.03**　The **digital** **directory** had an **index** arranged by the first letter of each word and a **handy** colour **filter**.

> デジタルの一覧にはアルファベット順の索引と、色で絞り込める便利な機能があった。

<a id="x112-04"></a>

**112.04**　To **activate** it, you had to **click** one **electronic** switch on the **interface**.

> 起動するには画面にある電子スイッチを一つクリックする必要があった。

<a id="x112-05"></a>

**112.05**　“The first **activation** is slow,” she said, “because the **processor** has to **compile** the **data**.”

> 「最初の起動は遅いんです。処理装置がデータをまとめる必要があるから」と先生は説明した。

<a id="x112-06"></a>

**112.06**　A blue light would **flash** when the **online** **connection** was **secure**.

> ネットの接続が安全になると青いランプが点滅する。

<a id="x112-07"></a>

**112.07**　You could **insert** a new item or **tag** a picture for **future** **inspection**.

> 新しい品物を登録したり、後で確認するため写真にタグを付けたりできた。

<a id="x112-08"></a>

**112.08**　You could also **group** the records by **usage** and choose a simpler **mode**.

> 使い道ごとに記録をまとめ、もっと簡単なモードを選ぶこともできた。

<a id="x112-09"></a>

**112.09**　The system did not **discard** your notes if your **browser** stopped working.

> ブラウザが止まっても、システムがメモを捨ててしまうことはなかった。

<a id="x112-10"></a>

**112.10**　Our **initial** **installation** had one **flaw**; two umbrellas with the same label could **overlap** on the screen.

> 初めて設置した版には欠点が一つあった。同じ札の傘が二本あると画面で重なるのだ。

<a id="x112-11"></a>

**112.11**　We suggested an upgrade, and the teacher agreed to **upgrade** the search **function**.

> 私たちは改良を提案し、先生は検索機能を更新すると約束した。

<a id="x112-12"></a>

**112.12**　I held the printed labels together with a **clip**.

> 私は印刷した札をクリップで一まとめにした。

<a id="x112-13"></a>

**112.13**　Each clip now showed one umbrella and the name given to it by a visitor.

> 各動画には傘が一本と、訪問者がその傘に付けた名が表示されるようになった。

**読みの問い**　同じ色・同じ札の傘が二本あると、初期の表示にはどんな問題が出たか。

<a id="ex-story-113"></a>

### 113　画面が教えない数字

<a id="x113-01"></a>

**113.01**　The **faculty** where she worked had arranged a **scientific** survey of the new service.

> 先生の学部では、新しいサービスを科学的に調べる調査を準備していた。

<a id="x113-02"></a>

**113.02**　A **professor** asked us to **survey** visitors on three **successive** days.

> 教授から、三日連続で来場者を調べるよう頼まれた。

<a id="x113-03"></a>

**113.03**　Each participant could **submit** one **qualitative** **response** and one **grade** in figures.

> 参加者は、質的な回答を一つと、数字による評価を一つ提出できた。

<a id="x113-04"></a>

**113.04**　The **parameter** for success was a **significant** rise in **voluntary** **participation**.

> 成功を測る指標は、自分から参加する人がはっきり増えることだった。

<a id="x113-05"></a>

**113.05**　The **primary** **variable** was the waiting time, but the **population** changed from day to day.

> 主な変数は待ち時間だったが、調査対象の集団は日によって違った。

<a id="x113-06"></a>

**113.06**　On the **middle** day a bus brought an entire **class** of children to the hall.

> 真ん中の日にはバスが学校の一クラス丸ごとを会場に連れてきた。

<a id="x113-07"></a>

**113.07**　That unexpected **occurrence** could **distort** the **distribution** of ages.

> その予期せぬ出来事で、年齢分布が偏る可能性があった。

<a id="x113-08"></a>

**113.08**　Was the extra interest in pictures **causal** evidence of a **technological** improvement?

> 写真への関心が増したことは、技術の改善が原因だという証拠になるのだろうか。

<a id="x113-09"></a>

**113.09**　We had to **separate** a **theoretical** **possibility** from what the **statistic** actually showed.

> 理論上の可能性と、統計値が実際に示したことを分けなければならなかった。

<a id="x113-10"></a>

**113.10**　The professor asked us not to **generalize** from a small sample or **ignore** its obvious **bias**.

> 教授は、小規模な標本から一般化せず、その明らかな偏りを無視しないよう頼んだ。

<a id="x113-11"></a>

**113.11**　“The **validity** of a conclusion can never **exceed** that of its starting **premise**.”

> 「結論の妥当性が、出発点となる前提の妥当性を超えることはありません」

<a id="x113-12"></a>

**113.12**　We recorded the limits beside the figures to **protect** their **reliability**.

> 数字の信頼性を守るため、その限界を数字の横に記した。

**読みの問い**　数が増えたのに、サービスのおかげだとは言えなかったのはなぜか。

<a id="ex-story-114"></a>

### 114　見えない棚にも重さがある

<a id="x114-01"></a>

**114.01**　A man who built stages took us through the empty **building** before the public opening.

> 一般公開前に、舞台を作る職人が空の建物を案内してくれた。

<a id="x114-02"></a>

**114.02**　The **construction** team had used **concrete** for the **foundation** and **aluminium** for the shelves.

> 工事班は基礎にコンクリートを、棚にアルミを使った。

<a id="x114-03"></a>

**114.03**　Each shelf could **span** a **length** of two **metres** without extra support.

> それぞれの棚は、追加の支えなしで二メートルにわたって架け渡せた。

<a id="x114-04"></a>

**114.04**　The **architectural** **vision** was to keep every support nearly invisible.

> 設計上の構想は、支えをどれもほとんど見えなくすることだった。

<a id="x114-05"></a>

**114.05**　A **transparent** cover would **enhance** that **illusion**, not the **stability** of the shelf.

> 透明なカバーはその錯覚を強めるが、棚の安定性を高めるわけではない。

<a id="x114-06"></a>

**114.06**　The **aesthetic** **benefit** had to be weighed against the **risk** of a **fall**.

> 見た目の利点は、落下の危険と比べて考える必要があった。

<a id="x114-07"></a>

**114.07**　A **thorough** **check** revealed a **visible** crack where a **nail** had gone in at the wrong angle.

> 入念に点検すると、くぎを誤った角度で打ったところに目に見えるひびがあった。

<a id="x114-08"></a>

**114.08**　The man decided to **lay** the shelf flat and **mount** the large **exhibit** lower down.

> 職人は棚を平らに寝かせ、大きな展示物を低い位置に据えることにした。

<a id="x114-09"></a>

**114.09**　We had to **fold** the empty boxes, **tidy** the stairs and **lock** the side **exit** after the **repair**.

> 修理の後、私たちは空箱をたたみ、階段を片付け、脇の出口に鍵をかけなければならなかった。

<a id="x114-10"></a>

**114.10**　A little water still lay on the bottom **stair**.

> 階段の一番下の段には、まだ少し水が残っていた。

<a id="x114-11"></a>

**114.11**　One curious child tried to **crawl** beneath the stand and almost **tripped** over a **cable**.

> 好奇心旺盛な子が台の下をはい進もうとして、ケーブルにつまずきかけた。

<a id="x114-12"></a>

**114.12**　The man fixed the cable under a **coloured** strip and put a **safety** sign on the floor.

> 職人は色のついた帯の下にケーブルを固定し、床に安全標識を置いた。

<a id="x114-13"></a>

**114.13**　“The **practical** use of a room begins where the drawing ends,” he said.

> 「部屋を実際に使うのは、図面が終わったところからだよ」と彼は言った。

**読みの問い**　カバーが透明になると変わるのは棚の何か。

<a id="ex-story-115"></a>

### 115　台所の記憶

<a id="x115-01"></a>

**115.01**　A **chef** arrived from the **restaurant** carrying an old **cooker** on a small truck.

> レストランから料理人が、小型トラックに古いこんろを載せてやって来た。

<a id="x115-02"></a>

**115.02**　She wanted to follow a **recipe** that her **grandmother** had written in **February**.

> 祖母が二月に書いたレシピを再現したいという。

<a id="x115-03"></a>

**115.03**　“**Heat** a little **oil** in a **pan** and **fry** one **potato**,” the note began.

> 「フライパンで少量の油を熱し、ジャガイモを一個揚げること」とメモは始まった。

<a id="x115-04"></a>

**115.04**　“**Slice** the **fresh** **vegetable** thin; **pour** off the oil when each **chip** is gold.”

> 「新鮮な野菜は薄く切り、一枚一枚がきつね色になったら、油を注ぎ出すこと」

<a id="x115-05"></a>

**115.05**　My sister offered to **boil** the water for **tea** and **stir** the **soup**.

> 妹はお茶のお湯を沸かし、スープをかき混ぜる役を買って出た。

<a id="x115-06"></a>

**115.06**　The **steam** made a white cloud over the **mixture** of milk and **butter**.

> 牛乳とバターを合わせたものの上に、湯気が白い雲のように立った。

<a id="x115-07"></a>

**115.07**　We had to **whip** the cream, **stuff** the bread with **jam** and **roll** the bread into a small **roll**.

> クリームを泡立て、パンにジャムを詰め、パンを小さく巻く必要もあった。

<a id="x115-08"></a>

**115.08**　A **dozen** visitors could now **eat** together, and the **remainder** could take food away.

> これで十二人の来場者が一緒に食べられ、残りの人は持ち帰れた。

<a id="x115-09"></a>

**115.09**　A **waiter** brought a **cocktail** for each **adult** who did not **prefer** **beer**.

> ビールを好んでは選ばない大人一人ひとりに、給仕がカクテルを一杯ずつ運んだ。

<a id="x115-10"></a>

**115.10**　The drinks for the children had no **ice** because the **plug** on the ice machine had come loose.

> 製氷機のプラグが抜けかけていたため、子どもの飲み物に氷はなかった。

<a id="x115-11"></a>

**115.11**　The chef hung the clean **washing** outside before she took a seat.

> 料理人は腰を下ろす前に、洗い終わった洗濯物を外に干した。

<a id="x115-12"></a>

**115.12**　Some children liked their drinks warm; the **chef** made no rule about **preference**.

> 温かい飲み物が好きな子もいた。料理人は好みに決まりを設けなかった。

<a id="x115-13"></a>

**115.13**　Beside the recipe we printed a short note about **nutrition** and a long one about **love**.

> レシピのそばには、栄養についての短いメモと、愛情についての長いメモを載せた。

**読みの問い**　レシピに従うことと、食べる人の好みを尊重することは、どう両立したか。

<a id="ex-story-116"></a>

### 116　池から来た手紙

<a id="x116-01"></a>

**116.01**　Beside the **pond**, a **scientist** was feeding a **fly** to a hungry fish.

> 池のそばで、科学者が腹をすかせた魚にハエをやっていた。

<a id="x116-02"></a>

**116.02**　“An **abundance** of fish is good news for a bird, but it can mean a **shortage** of insects,” she said.

> 「魚が豊富なのは鳥には朗報でも、虫が不足しているということにもなります」と彼女は言った。

<a id="x116-03"></a>

**116.03**　Her work on life in the bay had shown a **widespread** change in the **environment**.

> 湾で暮らす生物を調べた結果、環境に広範な変化が起きていると分かった。

<a id="x116-04"></a>

**116.04**　During the spring **migration** the birds had begun to **linger** on the bank for longer.

> 春の渡りの途中、鳥は以前より長く岸にとどまるようになっていた。

<a id="x116-05"></a>

**116.05**　An **array** of tiny cameras could **chart** their **movement** across the **geographical** **divide**.

> 小型カメラを並べて、地形上の境を越える鳥の動きを地図に記録できた。

<a id="x116-06"></a>

**116.06**　Their **energy** needs and the **density** of insects did not always **match**.

> 鳥が必要とするエネルギーと、虫の密度はいつも釣り合うわけではなかった。

<a id="x116-07"></a>

**116.07**　The **yield** of fish from a river is **variable**, she said, and it is easy to mistake an **occasional** **decline** for a permanent one.

> 川の漁獲量にはばらつきがあるので、ときどき起きる減少を永続的な減少と取り違えやすいという。

<a id="x116-08"></a>

**116.08**　A little **toy** boat belonging to a child lay on the bank with a **mysterious** green mark on its side.

> 岸には子どものおもちゃの舟があり、側面に謎の緑の染みがついていた。

<a id="x116-09"></a>

**116.09**　“Do the **bacteria** in the water **poison** the fish?” the child asked.

> 「水の中の細菌で魚が中毒になるの？」と子どもが聞いた。

<a id="x116-10"></a>

**116.10**　“Some can produce **toxic** substances, but the green colour is not enough to tell us that.”

> 「有毒なものを作る種類もいるけれど、緑色だというだけでは分からないよ」

<a id="x116-11"></a>

**116.11**　A **seal** was resting on the bank where the river entered the bay.

> 川が湾に流れ込むところでは、アザラシが岸で休んでいた。

<a id="x116-12"></a>

**116.12**　The **scientist** took a sample with a **proper** seal and recorded the time of collection.

> 科学者は試料を採り、きちんと封をして採取時刻を記録した。

<a id="x116-13"></a>

**116.13**　We agreed to wait for the result before calling the pond dangerous.

> 池が危険だと言うのは結果を待ってからにしようと私たちは決めた。

**読みの問い**　緑色の染みから、まだ分からないことは何か。

<a id="ex-story-117"></a>

### 117　砂漠を運ぶ箱

<a id="x117-01"></a>

**117.01**　The next delivery came from a **geographical** society that had sent a team into the **desert**.

> 次の荷物は、砂漠に調査班を送った地理学会から届いた。

<a id="x117-02"></a>

**117.02**　Their **exploration** had followed the edge of a **cliff** into a narrow **cave**.

> 探検隊は崖の縁に沿って進み、狭い洞窟に入った。

<a id="x117-03"></a>

**117.03**　The bare stone **terrain** caused **extreme** heat by day and cold at night.

> 岩がむき出しの地形のため、昼は猛烈に暑くなり、夜は冷え込んだ。

<a id="x117-04"></a>

**117.04**　They had to **pack** enough food to **feed** the team and leave **space** for samples.

> 班の全員を養うだけの食料を詰め、試料のスペースも空けておく必要があった。

<a id="x117-05"></a>

**117.05**　A guide in a loose white **uniform** helped them **cope** with the heat.

> ゆったりした白い制服の案内人が、暑さに対処するのを手伝ってくれた。

<a id="x117-06"></a>

**117.06**　An old drawing in the cave showed the sun, a fish and a round **planet**.

> 洞窟の古い絵には太陽、魚、丸い惑星が描かれていた。

<a id="x117-07"></a>

**117.07**　A keen student saw the **universe** in that drawing; her teacher urged a more **humble** **outlook**.

> 夢中になった学生にはその絵に宇宙が見えたが、先生はもっと謙虚に見るように勧めた。

<a id="x117-08"></a>

**117.08**　“Why not a **globe** for the world, a circle for the sun, or a stone for a **game**?”

> 「世界を表す球かもしれないし、太陽を表す円やゲームに使う石かもしれないね」

<a id="x117-09"></a>

**117.09**　The **scientific** **discipline** here was to **resist** calling one **thought** a **discovery**.

> ここでの科学的な心得は、一つの思いつきを発見と呼びたくなる気持ちに抵抗することだった。

<a id="x117-10"></a>

**117.10**　In the exhibition we set a blank card beside each **beautiful** photograph.

> 展覧会では、美しい写真のそばに一枚ずつ何も書いていない札を置いた。

<a id="x117-11"></a>

**117.11**　Visitors could **draft** their own explanations before reading the **expert** account.

> 来場者は専門家の説明を読む前に、自分の考えを下書きできた。

**読みの問い**　なぜ地理学会の写真の横の札に、最初から意味を書かなかったのか。

<a id="ex-story-118"></a>

### 118　空港で消えた点

<a id="x118-01"></a>

**118.01**　The police **helicopter** was the only **active** aircraft in that **zone**.

> その区域で動いていた航空機は警察のヘリコプターだけだった。

<a id="x118-02"></a>

**118.02**　It had permission to **circle** above the bay while a passenger **jet** waited to **land**.

> 旅客機が着陸を待つ間、そのヘリには湾の上空を旋回する許可が出ていた。

<a id="x118-03"></a>

**118.03**　The **radar** screen showed a **surprising** change in the **sequence** of lights.

> レーダー画面に並ぶ光の順序が意外な変わり方をした。

<a id="x118-04"></a>

**118.04**　A dot seemed to **vanish** and then to **come** back on a different **course**.

> 一つの点が消えたように見え、別の進路でまた現れた。

<a id="x118-05"></a>

**118.05**　A nervous **call** from the airport warned of a possible **collision**.

> 空港から切迫した連絡があり、衝突の可能性が伝えられた。

<a id="x118-06"></a>

**118.06**　The pilot could **signal** the crew, **slow** the **flight** and **warn** the ground **patrol**.

> 操縦士は乗員に合図し、飛行速度を落とし、地上の巡回班に警告することができた。

<a id="x118-07"></a>

**118.07**　But he could not see the actual distance between the two machines from his seat.

> ただし、自分の席から二機の実際の距離を見ることはできなかった。

<a id="x118-08"></a>

**118.08**　The operator checked the **timing** and tracked the trail of each aircraft.

> 管制員は時刻を確認して、一機ずつ通った跡をたどった。

<a id="x118-09"></a>

**118.09**　A single minute error on a secondary screen had shown the same machine twice.

> 補助画面のごく小さな誤差で、同じ機体が二度表示されていた。

<a id="x118-10"></a>

**118.10**　A **minute** later the jet landed without trouble and the **operation** could **resume**.

> 一分後に旅客機は無事着陸し、通常の業務を再開できた。

<a id="x118-11"></a>

**118.11**　The children asked us to **use** a moving **animation** to explain the apparent disaster.

> 見かけ上の大惨事を説明するのに、動くアニメーションを使ってほしいと子どもたちが頼んだ。

<a id="x118-12"></a>

**118.12**　Even a **tired** visitor could follow two dots on a **tidy** black screen.

> 疲れた来場者でも、すっきりした黒い画面に浮かぶ二つの点なら追うことができた。

**読みの問い**　空中で二機が同じ場所にいたことは、レーダー画面で証明されたか。

<a id="ex-story-119"></a>

### 119　隣の国の傘

<a id="x119-01"></a>

**119.01**　The railway had agreed to **export** a small travelling exhibition after the **launch** in our town.

> この町での開幕後、鉄道会社が小さな巡回展を国外へ運ぶことに同意した。

<a id="x119-02"></a>

**119.02**　Two countries that **border** the bay had signed a **cultural** **treaty**.

> 湾に接する二つの国が文化協定に署名していた。

<a id="x119-03"></a>

**119.03**　A **senator** and a presidential aide had helped to **draft** the proposal during the last **campaign**.

> 上院議員と大統領補佐官が、前回の選挙運動中に提案作成を手伝っていた。

<a id="x119-04"></a>

**119.04**　Their **congressional** office hoped to **unify** the ticket **system** on both sides.

> 議会の事務局は両側の切符制度を統一することを望んでいた。

<a id="x119-05"></a>

**119.05**　But a **constitutional** rule prevented one national office from taking over another.

> ただし憲法上の規定により、一国の機関がもう一国の機関を引き継ぐことはできなかった。

<a id="x119-06"></a>

**119.06**　A foreign **national** who lived on the border could help us translate both tickets.

> 国境で暮らす外国籍の人が、両国の切符の翻訳に協力できた。

<a id="x119-07"></a>

**119.07**　The legislative group had to **consult** both sides before the final **implementation**.

> 立法を担当する団体は、最終的な実施に移る前に双方の意見を聞く必要があった。

<a id="x119-08"></a>

**119.08**　An **integrated** schedule did not require either side to **sacrifice** its **autonomy**.

> 時刻表を一体化するために、どちらかが自治権を犠牲にする必要はなかった。

<a id="x119-09"></a>

**119.09**　“Do not **centralize** what the stations already do well,” said our local **leader**.

> 「各駅がうまくやっていることを中央に集めるのはやめよう」と地元の指導者は言った。

<a id="x119-10"></a>

**119.10**　A **cooperative** agreement could **accomplish** more than an order from the top of a **hierarchy**.

> 上からの命令よりも、協力の合意の方が多くのことを成し遂げられる場合がある。

<a id="x119-11"></a>

**119.11**　Both boards voted to **authorize** the **transition**, but neither could **dictate** the price of tickets abroad.

> 双方の理事会は移行を認める投票をしたが、相手国の運賃まで一方的に決めることはできなかった。

<a id="x119-12"></a>

**119.12**　The agreement was a compromise in railway **governance**, not a political **revolution**.

> この合意は鉄道運営についての妥協で、政治革命ではなかった。

**読みの問い**　一体化した時刻表を使うことは、両国の運賃決定権にどう影響するか。

<a id="ex-story-120"></a>

### 120　選挙をする教室

<a id="x120-01"></a>

**120.01**　A teacher turned the final **chapter** of her **book** into an **educational** **programme** about **democracy**.

> 先生が本の最終章を、民主主義を学ぶ授業に作り替えた。

<a id="x120-02"></a>

**120.02**　The **principal** invited the pupils to **elect** a **class** representative for a short **term**.

> 校長は短い任期の学級代表を生徒たちの投票で選ぶよう提案した。

<a id="x120-03"></a>

**120.03**　One candidate asked to **abolish** **compulsory** **registration** for clubs after school.

> ある候補は放課後のクラブの登録義務を廃止するよう求めた。

<a id="x120-04"></a>

**120.04**　Another wanted **universal** access to music **tuition** and a room for each party to meet.

> もう一人は誰でも音楽の指導を受けられるようにし、各党が集まれる部屋を設けたいと言った。

<a id="x120-05"></a>

**120.05**　The music teacher offered to hold a small **party** after the vote.

> 音楽の先生は投票の後、小さなパーティーを開こうと申し出た。

<a id="x120-06"></a>

**120.06**　The **enthusiastic** pupils **formed** three groups and chose **coloured** cards for **voting**.

> 乗り気の生徒たちは三つの集団に分かれ、投票用に色の違うカードを選んだ。

<a id="x120-07"></a>

**120.07**　One group stood on the grass and held a peaceful **rally**.

> 一つのグループは芝生の広場で平和的な集会を開いた。

<a id="x120-08"></a>

**120.08**　They tried to **rally** their **fellow** pupils behind a **plea** for **equality**.

> 平等を求める訴えのもとに、仲間の生徒たちを集めようとした。

<a id="x120-09"></a>

**120.09**　Their **mainstream** rival seemed more **relaxed**, but a **determined** **outsider** soon gained **momentum**.

> 主流派の対抗候補はもっと落ち着いて見えたが、主流派に属さない決意の固い候補が、すぐに勢いを増していた。

<a id="x120-10"></a>

**120.10**　Our teacher **stressed** that **inclusion** mattered more than control of the **presidency**.

> 先生は、代表の座を握ることより、誰もが参加できることが大切だと強調した。

<a id="x120-11"></a>

**120.11**　Nobody was allowed to **deprive** a pupil of a vote or **provoke** **hate** against a rival.

> 生徒の投票権を奪うことも、対抗候補に対する憎しみをあおることも許されなかった。

<a id="x120-12"></a>

**120.12**　A fair count was a **fundamental** **necessity**, and a second count offered **additional** **accountability**.

> 公正な集計は基本的に必要なことで、数え直せば結果についてさらに説明責任を果たせた。

<a id="x120-13"></a>

**120.13**　The winning pupil promised to **meet** the other groups before changing any rule.

> 当選した生徒は、規則を変える前にほかのグループとも会うと約束した。

**読みの問い**　勝てばすぐにすべての規則を変えられる、という終わり方だったか。

<a id="ex-story-121"></a>

### 121　三人の客が同じ部屋を見た

<a id="x121-01"></a>

**121.01**　A **downtown** hotel offered **accommodation** to the team travelling with our umbrellas.

> 中心街のホテルが傘の巡回展に同行するチームに宿を提供した。

<a id="x121-02"></a>

**121.02**　A twin room cost a little more than a small single room with a private **bathroom**.

> ベッド二台の部屋は、専用の浴室が付いた小さな一人部屋より少し高かった。

<a id="x121-03"></a>

**121.03**　An **adult** guest had booked the **empty** room at a **bargain** price.

> 一人の成人客が空き部屋を格安で予約していた。

<a id="x121-04"></a>

**121.04**　His **buddy** asked to **rent** a **car** and wanted to know the rules for **parking**.

> 彼の友人は車を借りたいと言い、駐車規則を知りたがった。

<a id="x121-05"></a>

**121.05**　An **ill** guest wanted a warm **bed** and **decent** washing facilities.

> 具合の悪い客は暖かいベッドと、体を洗えるきちんとした設備を求めていた。

<a id="x121-06"></a>

**121.06**　A **pregnant** guest asked whether the nearest **toilet** was on the ground floor.

> 妊娠中の客は、いちばん近いトイレが一階かどうかを尋ねた。

<a id="x121-07"></a>

**121.07**　The **tap** was broken and the shower leaked into the sink.

> 蛇口は壊れ、シャワーから洗面台へ水が漏れていた。

<a id="x121-08"></a>

**121.08**　The **embarrassed** manager offered to **cancel** the **bill** for the first night.

> ばつの悪そうな支配人は初日の宿泊料金を取り消すと申し出た。

<a id="x121-09"></a>

**121.09**　He would **assign** a **ready** room to the two guests who needed it most.

> 一番必要としている二人に、用意の整った部屋を割り当てるつもりだった。

<a id="x121-10"></a>

**121.10**　The third guest agreed to **settle** for a room above the garage without extra pay.

> 三人目の客は、追加料金なしで、ガレージの上の部屋で手を打つことに同意した。

<a id="x121-11"></a>

**121.11**　“My **pet** **cat** will not **object**,” he said.

> 「うちの飼い猫は文句を言いませんよ」と彼は言った。

<a id="x121-12"></a>

**121.12**　“The **presence** of a warm engine is all she wants.”

> 「暖かいエンジンがあればそれで十分なんです」

**読みの問い**　同じ宿が三人の客に同じ価値を持たなかったのはなぜか。

<a id="ex-story-122"></a>

### 122　葬列の最後の楽譜

<a id="x122-01"></a>

**122.01**　On our last morning a **funeral** passed the library and turned towards the church.

> 最後の朝、葬列が図書館の前を通って教会の方へ曲がった。

<a id="x122-02"></a>

**122.02**　The passing of a **long-time** teacher had brought **intense** **grief** to this small **community**.

> 長年勤めた教師の死が、この小さな地域に深い悲しみをもたらしていた。

<a id="x122-03"></a>

**122.03**　An old **friend** walked behind the family with a pink **sweater** across his **arm**.

> 古くからの友人がピンクのセーターを腕に掛け、遺族の後ろを歩いた。

<a id="x122-04"></a>

**122.04**　A shy **lad** held her guitar on his **lap**, too upset to **cry**.

> 内気な少年が彼女のギターを膝に乗せ、動揺のあまり泣くこともできずにいた。

<a id="x122-05"></a>

**122.05**　Her **funeral** **wish** had been that her students should play something **memorable** rather than something **sad**.

> 葬儀では悲しい曲より、心に残る曲を生徒たちに演奏してほしいと彼女は願っていた。

<a id="x122-06"></a>

**122.06**　With a **sigh**, the boy made the first **forward** movement of his hand.

> 少年はため息をつき、最初の音を出そうと手を前へ動かした。

<a id="x122-07"></a>

**122.07**　It was the tune she had played at the **wedding** of his mother.

> それは、彼の母親の結婚式で先生が弾いた曲だった。

<a id="x122-08"></a>

**122.08**　Nobody offered him a **kiss** or words of **sympathy** until he had finished.

> 弾き終えるまで、誰も少年にキスをしたり、お悔やみの言葉をかけたりしなかった。

<a id="x122-09"></a>

**122.09**　His finger caught in a little **tear** in the pink sweater.

> 指がピンクのセーターの小さな裂け目に引っかかった。

<a id="x122-10"></a>

**122.10**　A tear slipped down his cheek and caught the light like a little drop of **silver**.

> 一筋の涙が頬を伝い、銀のしずくのように光を受けた。

<a id="x122-11"></a>

**122.11**　He smiled and said the quiet had given him **freedom** to finish her last **request**.

> 少年はほほ笑み、静かにしていてくれたから先生の最後の頼みをやり通せたと言った。

<a id="x122-12"></a>

**122.12**　The **passing** of time changed the sound of the tune without changing a single note.

> 時がたつと、一音も変わっていないのに曲は違って聞こえた。

<a id="x122-13"></a>

**122.13**　My sister wrote about that **kind** of **compassion** on the back of a music card.

> 妹は、そういう思いやりについて楽譜カードの裏に書いた。

**読みの問い**　この場で人々が黙っていたことを、少年はどう受け取ったか。

<a id="ex-story-123"></a>

### 123　額の外に出る物語

<a id="x123-01"></a>

**123.01**　A **poet** at the reading room offered a literary **critique** of our collection.

> 読書室の詩人が、私たちの作品集に文学的な批評を寄せた。

<a id="x123-02"></a>

**123.02**　She wrote **fiction**, but her latest **memoir** contained an **outstanding** account of her own **career**.

> 彼女は小説家でもあったが、最新の回想録には、自身の作家人生を描いた秀逸な文章があった。

<a id="x123-03"></a>

**123.03**　Each **essay** gave an ordinary object a different **setting**.

> 随筆ごとに、ありふれた品が別の場面に置かれていた。

<a id="x123-04"></a>

**123.04**　A worn umbrella could **evoke** the **fantasy** of a bird or the **reality** of a broken promise.

> 使い古した傘からは、鳥をめぐる空想も、破られた約束という現実も呼び起こせた。

<a id="x123-05"></a>

**123.05**　“It is tempting to frame every **tragedy** as a lesson,” she said.

> 「どんな悲劇も教訓の形にしたくなるものです」と彼女は言った。

<a id="x123-06"></a>

**123.06**　“But **literature** can hold **suffering** without finding a tidy **moral**.”

> 「でも文学なら、きれいな教訓を出さなくても、苦しみをそのまま抱えていられます」

<a id="x123-07"></a>

**123.07**　She asked whether my sister would **dare** to write a **complete** **dialogue** without using the word umbrella.

> 彼女は妹に、「傘」という言葉を使わずに一編の対話を書き切る勇気があるかと聞いた。

<a id="x123-08"></a>

**123.08**　The **challenge** called for **imagination** and a **good** **understanding** of the spoken language.

> その課題には想像力と、話し言葉の確かな理解が必要だった。

<a id="x123-09"></a>

**123.09**　A **dictionary** could give a **phrase** in another language, but it could not **translate** the **feel** of an **accent** in speech.

> 辞書なら他言語での言い回しは教えられても、話し手の訛りの感じまでは訳せない。

<a id="x123-10"></a>

**123.10**　Words can be **art** without a frame or a wall to hang them on.

> 額縁も飾る壁もなくても、言葉は芸術になれる。

<a id="x123-11"></a>

**123.11**　She offered to **frame** our page and hang it beside the umbrellas.

> 詩人は、私たちの文章を額に入れて、傘のそばに飾ってくれると言った。

<a id="x123-12"></a>

**123.12**　The poet asked us to **preserve** that difference in a **quotation** rather than correct it.

> 詩人は、その違いを直すより、引用の中に残してほしいと頼んだ。

<a id="x123-13"></a>

**123.13**　Our exhibition now included the art of leaving an **interesting** silence on the page.

> 私たちの展覧会には、紙の上に意味深い沈黙を残す術も加わった。

**読みの問い**　詩人が残したかったのは、辞書に載っている語義だけか。

<a id="ex-story-124"></a>

### 124　手作りの番組

<a id="x124-01"></a>

**124.01**　In a small **studio** a student prepared a **broadcast** about the lost umbrellas.

> 小さなスタジオで、学生が忘れ物の傘についての放送を準備した。

<a id="x124-02"></a>

**124.02**　“**Tonight** is our chance to **broadcast** it live,” he said.

> 「今夜なら生放送できます」と彼は言った。

<a id="x124-03"></a>

**124.03**　“**Tomorrow** would be better for a short **segment** of the play.”

> 「劇の一部を短く流すなら、明日の方がよさそうです」

<a id="x124-04"></a>

**124.04**　A **celebrity** offered to **entertain** the audience with an **engaging** story from her first **show**.

> ある有名人が、自分が初めて出演した舞台の面白い逸話で聴衆を楽しませようと申し出た。

<a id="x124-05"></a>

**124.05**　An old lady objected to the **emphasis** on **entertainment** and **mass** appeal.

> ある年配の女性は、娯楽性と大衆受けへの偏りに異を唱えた。

<a id="x124-06"></a>

**124.06**　“People came to remember their neighbours, not to **witness** a **spectacle**,” she said.

> 「みんな近所の人を思い出しに来たんです。見世物を見るためじゃありません」と言った。

<a id="x124-07"></a>

**124.07**　The student agreed to **cut** the **commercial** and **incorporate** her words in the **transcript**.

> 学生は広告を削り、その女性の言葉を放送記録に加えることに同意した。

<a id="x124-08"></a>

**124.08**　He let her **comment** on the **production** and **recommend** the next speaker.

> 番組の作り方について意見を述べ、次に話す人を推薦するのも彼女に任せた。

<a id="x124-09"></a>

**124.09**　Her first **pick** was a **humble** teacher who made an **impressive** umbrella from a **pack** of paper.

> 彼女の最初の選択は、ひと包みの紙から見事な傘を作った控えめな先生だった。

<a id="x124-10"></a>

**124.10**　“Do not **light** a match near the paper,” the teacher said.

> 「紙のそばでマッチに火をつけてはいけません」と先生は言った。

<a id="x124-11"></a>

**124.11**　The sound of paper beginning to **tear** was better than any **fake** sound of a storm.

> 紙が破れかける音は、どんな作り物の嵐の音よりも効果的だった。

<a id="x124-12"></a>

**124.12**　The teacher could **fold** it, open it and light it from inside.

> 先生はそれを折り畳み、開き、中から照らしてみせた。

<a id="x124-13"></a>

**124.13**　On the screen the little lamp began to **shine** through the paper.

> 画面では、小さなランプの光が紙を透かして輝き始めた。

<a id="x124-14"></a>

**124.14**　One child tried it, and the **next** took a step forward as soon as the light went out.

> 子どもが一人試し、明かりが消えると次の子がすぐ一歩前に出た。

**読みの問い**　放送で広告の代わりに残されたものは何か。

<a id="ex-story-125"></a>

### 125　一枚の写真、二つの肩書

<a id="x125-01"></a>

**125.01**　An exhibition **board** carried pictures of a **vibrant** street market in another country.

> 展示パネルには、外国の活気ある市場の写真が並んでいた。

<a id="x125-02"></a>

**125.02**　The first showed a **proud** market woman in pink, the second a young musician in **purple**.

> 一枚目にはピンクの服を着た誇らしげな商人、二枚目には紫色の服を着た若い音楽家が写っていた。

<a id="x125-03"></a>

**125.03**　A little **green** in the background made the colours stand out.

> 背景に少し緑色があることで、ほかの色が際立った。

<a id="x125-04"></a>

**125.04**　The **pink** in one picture and the purple in the other made a **wonderful** **balance**.

> 一方のピンクともう一方の紫が見事につり合っていた。

<a id="x125-05"></a>

**125.05**　She wanted every visitor to feel at home, regardless of **race**.

> 彼女は、人種にかかわらず、来場者みんなにくつろいでもらいたいと願っていた。

<a id="x125-06"></a>

**125.06**　A critic found the title “Foreign **Folk**” too close to a **racial** **stereotype**.

> ある批評家は「よその国の人々」という題は人種的な固定観念に近すぎると感じた。

<a id="x125-07"></a>

**125.07**　The people came from **multiple** ethnic groups, and their **relationship** was a friendship, not a lesson in **geography**.

> 二人の民族的背景は異なり、その結びつきは友情であって、地理の教材ではなかった。

<a id="x125-08"></a>

**125.08**　“One **human** can **live** more than one kind of life,” the musician told us.

> 「一人の人間だって、いろいろな生き方ができるよ」と音楽家は話した。

<a id="x125-09"></a>

**125.09**　“A picture of my **domestic** **lifestyle** cannot **define** my **sexuality** or my whole **being**.”

> 「家での暮らし方を写した写真で、私の性的なあり方や、私という存在のすべてを言い表せるわけじゃない」

<a id="x125-10"></a>

**125.10**　The woman recalled a **nasty** **affair** in which a politician had tried to **manipulate** one of her photographs.

> 商人は、政治家が自分の写真を都合よく操作しようとした嫌な一件を思い出した。

<a id="x125-11"></a>

**125.11**　That **manipulation** had **provoked** **contempt** for an entire **community**.

> その操作は、ある共同体全体に対する軽蔑を呼び起こした。

<a id="x125-12"></a>

**125.12**　We had no **wish** to **inflict** another such injury or to **spread** a **flawed** **theory**.

> 私たちは同じような傷をまた負わせたり、誤った説を広めたりしたいとは思わなかった。

<a id="x125-13"></a>

**125.13**　After careful **consideration**, we asked the friends to write their own titles for the **corresponding** images.

> よく考えた後、私たちは二人に、それぞれの写真の題名を自分で付けてもらった。

<a id="x125-14"></a>

**125.14**　One was “Making a **living**”; the other was “Making a friend.”

> 一つは「生計を立てる」、もう一つは「友達を作る」だった。

**読みの問い**　二人が自分で付けた題は、写真をどんな見方に引き戻したか。

<a id="ex-story-126"></a>

### 126　消えた名の競売

<a id="x126-01"></a>

**126.01**　A **non-profit** society had arranged an **auction** to pay for the **annual** cleaning of the well.

> 非営利団体が古井戸の年に一度の清掃費をまかなうため、競売を開いた。

<a id="x126-02"></a>

**126.02**　Its most **appealing** item was a picture with a **notable** signature in the lower **margin**.

> いちばん魅力的な品には、下の余白に著名人の署名があった。

<a id="x126-03"></a>

**126.03**　The picture showed a **wedding** and the first **printing** of a **revolutionary** newspaper.

> 絵には結婚式と、革命を目指す新聞の創刊号の印刷風景が描かれていた。

<a id="x126-04"></a>

**126.04**　One guest called it the work of a **genius**; a **local** with years of experience remained **defensive** about the claim.

> ある客は天才の仕事だとたたえたが、長年見てきた地元の人は、その見立てには身構えた。

<a id="x126-05"></a>

**126.05**　An **auction** is not a court, but this one had to **rule** on the **validity** of a name.

> 競売は裁判ではないが、今回は署名が有効か判断しなくてはならなかった。

<a id="x126-06"></a>

**126.06**　“Do not **confine** your search to grand names,” she said; “**dig** through the storage records.”

> 「有名な名前に捜索を限らず、保管記録を掘り返しなさい」と彼女は言った。

<a id="x126-07"></a>

**126.07**　The **storage** **system** held a **certificate** for the original frame, but none for the picture.

> 保管システムには、元の額縁の証明書はあったが、絵自体の証明書はなかった。

<a id="x126-08"></a>

**126.08**　A sheet of paper showed the back of the lost picture, where a child had drawn a cat.

> 一枚の紙にはなくなった絵の裏が写っていて、そこに子どもの猫の絵があった。

<a id="x126-09"></a>

**126.09**　A second look at the cat helped us **recover** the name of the little artist from a **living** relative.

> 猫の絵を改めて見ることが手掛かりとなり、存命の親族から子どもの名前を聞き出せた。

<a id="x126-10"></a>

**126.10**　The artist had signed the frame as a **measure** of respect for his daughter, the true painter.

> 絵を描いたのは娘で、画家は彼女への敬意を表す一つの方法として額に署名していた。

<a id="x126-11"></a>

**126.11**　We thought the child had copied the adult, but the **reverse** was true.

> 私たちは子どもが大人のまねをしたと思っていたが、事実は逆だった。

<a id="x126-12"></a>

**126.12**　The **surprise** was enough to **delight** the room, but not to justify the original price.

> その意外な事実に会場は喜んだが、それで最初の値段が正当化されたわけではなかった。

<a id="x126-13"></a>

**126.13**　The owner chose to **opt** for a loan and **file** a fresh record under her name.

> 持ち主は貸し出す方を選び、少女の名前で新しい記録を登録した。

**読みの問い**　額の証明書があっても埋まらなかった情報は何か。

<a id="ex-story-127"></a>

### 127　暮らしの値段、町の値段

<a id="x127-01"></a>

**127.01**　A historian brought an old **form** with six questions about **farming** and factory **employment**.

> 歴史家が、農業と工場での雇用について六つの問いがある古い用紙を持ってきた。

<a id="x127-02"></a>

**127.02**　The first asked about the **working** of a machine and the **consumption** of coal.

> 最初の問いは機械の動きと石炭の消費量についてだった。

<a id="x127-03"></a>

**127.03**　The next asked how a worker might **maximize** output without an **excess** of waste.

> 次の問いは、無駄を出しすぎずに生産量を最大にする方法を尋ねていた。

<a id="x127-04"></a>

**127.04**　An **early** **formulation** called **modernization** a gain for the town as a **whole**.

> 初期の説明では、近代化は町全体に利益をもたらすとされていた。

<a id="x127-05"></a>

**127.05**　That **conventional** **attitude** had left little room for the **concern** of a mother about long hours.

> その従来の見方では、勤務時間の長さを心配する母親の声はほとんど取り入れられなかった。

<a id="x127-06"></a>

**127.06**　The **emergence** of factories had created an urban **elite** and a new **dependence** on wages.

> 工場の出現によって、都市の有力層が生まれ、賃金への依存も新たに生じた。

<a id="x127-07"></a>

**127.07**　Was **capitalist** growth a benefit for the public **good** or a better **opportunity** for a few people?

> 資本主義的な成長は公益にかなうのか、それとも少数の人にとっての好機なのか。

<a id="x127-08"></a>

**127.08**　It was a point of **contention** between a **leading** economist and a **progressive** teacher.

> 有力な経済学者と進歩的な教師の間では、それが論争の的だった。

<a id="x127-09"></a>

**127.09**　A **balanced** account could **relate** their **ideology** to the **societal** changes they had seen.

> バランスの取れた記述なら、二人の思想を、それぞれが見た社会の変化と結び付けられる。

<a id="x127-10"></a>

**127.10**　A **current** theory must not **discourage** us from listening to a voice outside the **mainstream**.

> 現在の理論が、主流から外れた声に耳を傾けるのを妨げてはいけない。

<a id="x127-11"></a>

**127.11**　Some old machines were still **productive**, and change was not always **desirable**.

> 古い機械の中にもまだ生産力のあるものがあり、変えることが常に望ましいわけではなかった。

<a id="x127-12"></a>

**127.12**　“In our **reconstruction** of the factory, leave at least one of the machines that still work,” we wrote.

> 「工場を再現するとき、今も動く機械を少なくとも一台残して」と私たちは書いた。

**読みの問い**　町全体の生産が増えても、それだけでは答えられないことは何か。

<a id="ex-story-128"></a>

### 128　手の届く宇宙

<a id="x128-01"></a>

**128.01**　A retired teacher had an **extensive** collection of **mathematical** games.

> 退職した先生が数学ゲームをたくさん集めていた。

<a id="x128-02"></a>

**128.02**　One **puzzle** asked us to **model** the earth with a ball and a piece of string.

> あるパズルでは、球とひもで地球の模型を作るよう求められた。

<a id="x128-03"></a>

**128.03**　The **spatial** problem was simple; the **logical** difficulty was more **challenging**.

> 空間に関する問題は単純だったが、論理上の難しさには歯応えがあった。

<a id="x128-04"></a>

**128.04**　If we added a metre to the string, could a cat **crawl** through the gap all around?

> ひもを一メートル伸ばすと、一周どこでも猫がすき間をはい通れるだろうか。

<a id="x128-05"></a>

**128.05**　The string had to **maintain** a circle, and the distance between ball and string had to stay **equivalent** at every point.

> ひもは円形を保ち、球とひもの間の距離はどの点でも等しく保たなければならなかった。

<a id="x128-06"></a>

**128.06**　The **logic** of the teacher did not **rely** on the **mass** of the ball.

> 先生の推論は球の質量にはよらなかった。

<a id="x128-07"></a>

**128.07**　My sister tried to **plot** the size of the gap on a **graphic** display.

> 妹は、すき間の大きさを画面に図示してみた。

<a id="x128-08"></a>

**128.08**　At first the idea was **abstract**; the picture made its **reach** more apparent.

> はじめは抽象的な考えだったが、図にするとどこまで当てはまるかが見えてきた。

<a id="x128-09"></a>

**128.09**　A **glance** at the drawing suggested an answer, but did not **correspond** to a proof.

> 図を一目見ると答えは浮かんだが、それが証明に相当するわけではなかった。

<a id="x128-10"></a>

**128.10**　The solution was **astonishing** to the children and **expected** by the teacher.

> その答えに子どもたちはとても驚いたが、先生の予想どおりだった。

<a id="x128-11"></a>

**128.11**　What looked **magical** from a **front** seat seemed perfectly ordinary from the back.

> 前の方の席からは魔法のように見えたことが、後ろからはごく普通に思えた。

<a id="x128-12"></a>

**128.12**　To **sum** up our answer, we wrote just one line about the **limit** of the gap.

> 答えをまとめるのに、私たちはすき間の限界について一行だけ書いた。

**読みの問い**　球を大きくしただけで一メートルの効果は変わるだろうか。

<a id="ex-story-129"></a>

### 129　同じ顔をした双子の絵

<a id="x129-01"></a>

**129.01**　A visiting psychologist set us a small **cognitive** **challenge**.

> 訪問した心理学者が小さな認知の課題を出した。

<a id="x129-02"></a>

**129.02**　She placed two **hypothetical** family trees beside pictures of two **adult** twins.

> 二つの仮定上の家系図を、成人した双子二人の写真の横に置いた。

<a id="x129-03"></a>

**129.03**　A shared **gene** could influence a feature, but did not **dictate** a career.

> 共通の遺伝子が特徴に影響することはあっても、進路を決めてしまうわけではなかった。

<a id="x129-04"></a>

**129.04**　One **twin** had chosen to **specialize** in lighting; the other had begun to **lecture** on philosophy.

> 一人は照明を専門にする道を選び、もう一人は哲学の講義を始めた。

<a id="x129-05"></a>

**129.05**　Their **philosophical** **disagreement** was not an **abnormal** **phenomenon** in a family.

> 家族の中で哲学上の見解が食い違うのは異常な現象ではなかった。

<a id="x129-06"></a>

**129.06**　A **hypothetical** case could **clarify** one point without saying anything about the twins' **internal** lives.

> 架空の事例を使えば、双子の内面について何も述べずに、一つの点を明らかにすることもできた。

<a id="x129-07"></a>

**129.07**　One pupil tried to **dispute** the claim that everyone had an **intrinsic** need for public **satisfaction**.

> 生徒の一人は、誰もが人前で満足感を得ることを本質的に必要とする、という主張に異議を唱えた。

<a id="x129-08"></a>

**129.08**　Another asked whether **happiness** could **originate** in an activity nobody else saw.

> 他の生徒は、誰にも見られない活動から幸福が生まれ得るかとたずねた。

<a id="x129-09"></a>

**129.09**　Their discussion threatened to **overwhelm** the small **initial** **question**.

> 議論は最初のささやかな問いをのみ込んでしまいそうだった。

<a id="x129-10"></a>

**129.10**　“Bring it back to a **specific** example,” said the teacher.

> 「具体的な例に戻りましょう」と先生は言った。

<a id="x129-11"></a>

**129.11**　“Which twin would you ask to light this room, and how would you know?”

> 「この部屋の照明をどちらに頼みますか。また、どうしてそう分かるのですか」

**読みの問い**　遺伝子の情報と、双子が今何を仕事にしているかという情報は、どちらが照明を任せる判断に直接役立つか。

<a id="ex-story-130"></a>

### 130　放送の恐ろしい役名

<a id="x130-01"></a>

**130.01**　One radio play was about a **terrorist** who threatened a small town with **violence**.

> ラジオ劇の一つは、小さな町を暴力で脅すテロリストを描いていた。

<a id="x130-02"></a>

**130.02**　The actor had to **wear** **ugly** **make-up** for the photograph, although nobody saw his face on air.

> 放送では顔が見えないのに、俳優は写真用に醜い化粧をしなくてはならなかった。

<a id="x130-03"></a>

**130.03**　An **ethnic** symbol on his coat might **induce** people to associate a whole culture with **aggression**.

> コートにつけた民族のシンボルによって、人々がその文化全体を攻撃性と結び付けてしまうおそれがあった。

<a id="x130-04"></a>

**130.04**　His **loyal** **aide** in the play tried to **stem** the **crisis** before a **murder** took place.

> 劇中で忠実な補佐官は、殺人に至る前に危機を食い止めようとした。

<a id="x130-05"></a>

**130.05**　A child had to **scream**, a bottle had to **shatter**, and a door had to **slam**.

> 子どもが叫び、瓶が砕け、ドアが勢いよく閉まるようにしなければならなかった。

<a id="x130-06"></a>

**130.06**　We made the **scream** ourselves to avoid having to **scare** a real child.

> 本物の子どもを怖がらせずに済むよう、悲鳴は私たちで出した。

<a id="x130-07"></a>

**130.07**　An **unpleasant** detail could **alarm** a listener without helping the plot.

> 不快な細部は、筋に役立たないまま聞き手を不安にさせることがある。

<a id="x130-08"></a>

**130.08**　Our producer asked a **responsible** adult to **dub** the voice of the child.

> 制作担当者は、信頼できる大人に子どもの声の吹き替えを頼んだ。

<a id="x130-09"></a>

**130.09**　After a short **break** she asked us to **question** whether the **disturbing** scene was doing any **substantive** work.

> 短い休憩の後、彼女は、不穏な場面が本当に何か実質的な働きをしているか考えてみてほしいと言った。

<a id="x130-10"></a>

**130.10**　The **spoken** warning at the start was **welcome**, but the coat the actor wore still had to change.

> 冒頭に音声で注意が入ったのはありがたかったが、俳優の上着はやはり変える必要があった。

**読みの問い**　冒頭の注意だけで解決しなかったのは何か。

<a id="ex-story-131"></a>

### 131　許可証の裏の文字

<a id="x131-01"></a>

**131.01**　During a street **protest** the mayor sent a **harsh** warning about **smoking** in the square.

> 街頭抗議の最中、市長から広場での喫煙に厳しい警告が出た。

<a id="x131-02"></a>

**131.02**　A new **provision** allowed a **fine**, but only inside areas with signs.

> 新しい規定は、標識のある区域内にかぎり罰金を科すことを認めていた。

<a id="x131-03"></a>

**131.03**　A young officer saw a man **smoke** beside the sign and tried to **execute** the order.

> 若い職員は標識の横で男性がたばこを吸うのを見て、命令を執行しようとした。

<a id="x131-04"></a>

**131.04**　The visitor said that his permit appeared to **license** him to smoke there.

> 訪問者は、自分の許可証によればここで喫煙してもよいように読めると言った。

<a id="x131-05"></a>

**131.05**　It said, “Activities are **subject** to the **current** rules.”

> そこには「活動は現行規則に従うものとする」と書かれていた。

<a id="x131-06"></a>

**131.06**　That was not the **equivalent** of permission, but it was a **reasonable** source of **difficulty**.

> それは許可に相当する文言ではなかったが、迷うのも無理はなかった。

<a id="x131-07"></a>

**131.07**　The man agreed to **comply** and pay a **lesser** **sanction** if he had to.

> 男性は規則に従い、必要ならより少額の罰金を支払うことに同意した。

<a id="x131-08"></a>

**131.08**　A lawyer agreed to **refer** to the **legislative** record and **answer** his **request** in writing.

> 弁護士は立法記録に当たり、男性の問い合わせに書面で答えることを約束した。

<a id="x131-09"></a>

**131.09**　The local office could **regulate** where people smoked, but it had no power to **proclaim** a **global** ban.

> 地元の役所には喫煙場所を規制する力はあっても、世界規模の禁止を宣言する力はなかった。

<a id="x131-10"></a>

**131.10**　The argument left a **split** among the visitors, but no one tried to **sue** the town.

> 来場者の間に意見の分裂は残ったが、町を訴えようとした人はいなかった。

**読みの問い**　許可証を持っていることと、広場での喫煙が許されることは同じか。

<a id="ex-story-132"></a>

### 132　水をこぼさない工夫

<a id="x132-01"></a>

**132.01**　During our **next** morning session the children could **pick** one building **option** for the new park.

> 次の朝の集まりで、子どもたちは新しい公園の施設案を一つ選べた。

<a id="x132-02"></a>

**132.02**　Some asked for a **swing** from which they could see over the little wall.

> 低い塀の向こうをのぞけるブランコを望む子もいた。

<a id="x132-03"></a>

**132.03**　They wanted to **erect** a **slide** shaped like a fish with a silver tail.

> 銀の尾を持つ魚の形の滑り台を建てたいという。

<a id="x132-04"></a>

**132.04**　Construction would **involve** the **utilization** of wood already in **stock**.

> 建設には、すでに在庫のある木材を使うことになる。

<a id="x132-05"></a>

**132.05**　A man from the building team agreed to **drive** the wood over and **empty** the truck beside the gate.

> 職人は木材を車で運び、門の横で荷台を空にすることに同意した。

<a id="x132-06"></a>

**132.06**　The children had to **push** a wooden box up a slope without letting it **tip**.

> 子どもたちは、木箱を傾けずに斜面の上へ押し上げる必要があった。

<a id="x132-07"></a>

**132.07**　They could **split** the load in **half** or attach a rope and give it a **pull**.

> 荷物を半分に分ける手も、縄を付けて引く手もあった。

<a id="x132-08"></a>

**132.08**　They let the rope **trail** along the path and stopped whenever a visitor came near.

> 縄を道に引きずり、来場者が近づくたびに止まった。

<a id="x132-09"></a>

**132.09**　A rough **tackle** during football practice could **break** the thin fence or make the slide **collapse**.

> サッカーの練習中の激しいタックルで、薄い柵が壊れたり、滑り台が崩れたりするおそれがあった。

<a id="x132-10"></a>

**132.10**　The team agreed to **kick** the ball at the far end of the park.

> チームは公園の反対端でボールを蹴ることにした。

<a id="x132-11"></a>

**132.11**　One **risky** crossing could **disadvantage** a child in a chair with wheels.

> 危険な横断箇所が一つあるだけで、車いすの子に不利になる。

<a id="x132-12"></a>

**132.12**　An improved design let all the children **have** a turn without a separate entrance.

> 設計を改めると、別々の入口を設けず、すべての子が順番に参加できた。

<a id="x132-13"></a>

**132.13**　The project took **coordination**, **creativity** and a **measure** of practical **solidarity**.

> この計画には調整力と創造力、そしてある程度の、行動に表れる連帯が必要だった。

**読みの問い**　チームがボールを蹴る場所を変更したことは、なぜ公園づくりに関係するか。

<a id="ex-story-133"></a>

### 133　二人の決心

<a id="x133-01"></a>

**133.01**　In the station hall a girl was **alone** with a **troubled** dog and a broken umbrella.

> 駅のホールには、不安げな犬を連れ、壊れた傘を持った少女が一人いた。

<a id="x133-02"></a>

**133.02**　“My parents will **divorce**,” she told us, “but I still **hope** to keep the dog.”

> 「お父さんとお母さんは離婚するの。でも犬は手放さなくてすむといいな」と彼女は話した。

<a id="x133-03"></a>

**133.03**　She had been **dependent** on the dog since her father had first fallen ill.

> 父親が初めて病気になったときから、少女はその犬を頼りにしてきた。

<a id="x133-04"></a>

**133.04**　She could **admit** she felt **miserable** without being **ashamed** of it.

> 少女は、自分がひどくつらい気持ちでいることを、恥じずに認めることができた。

<a id="x133-05"></a>

**133.05**　Her father had a **terminal** illness and wanted the dog to stay with her.

> 父親の病気は末期で、犬が娘と一緒に暮らし続けることを望んでいた。

<a id="x133-06"></a>

**133.06**　Our **hunt** for the owner suddenly seemed **irrelevant** beside her trouble.

> 持ち主を捜す私たちの仕事は、少女の悩みの前では急にどうでもよく思えた。

<a id="x133-07"></a>

**133.07**　She said the latest news about her father was better and looked **relieved**.

> 父親の容体についての最新の知らせは、より良いものだったと言い、ほっとした顔をした。

<a id="x133-08"></a>

**133.08**　“We cannot **save** everything,” she said, “but we can **save** a place at home for him.”

> 「全部を救うことはできないけれど、家にお父さんの居場所を取っておくことはできる」と言った。

<a id="x133-09"></a>

**133.09**　The smallest **touch** of that little nose appeared to **assure** her that she was not alone.

> 犬の鼻先がそっと触れると、自分は一人ではないと彼女に伝わるようだった。

<a id="x133-10"></a>

**133.10**　At last her mother **arrived** to **greet** her with a smile.

> やがて母親がやって来て、笑顔で娘を迎えた。

<a id="x133-11"></a>

**133.11**　The umbrella was neither a prize nor a test of loyalty, just an umbrella in the rain.

> 傘は賞品でも、誰かの忠誠心を試す道具でもなかった。ただ、雨の中にある一本の傘だった。

**読みの問い**　二回の save がそれぞれ何を表すか。

<a id="ex-story-134"></a>

### 134　半分だけ光る月

<a id="x134-01"></a>

**134.01**　The **dream** of one child for the opening was a moon that would **soar** above the market.

> 子どもが開会式のために夢見たのは、市場の上空へ舞い上がる月だった。

<a id="x134-02"></a>

**134.02**　He used to **dream** of flying a balloon made of silver paper.

> 銀色の紙で作った風船を飛ばすのが、かねてからの夢だった。

<a id="x134-03"></a>

**134.03**　He had an **amazing** picture of it and no clear idea how to make it fly.

> イメージはすばらしかったが、飛ばし方はよく分からなかった。

<a id="x134-04"></a>

**134.04**　One engineer offered to **develop** a simple lift and **pioneer** a way of using **organic** waste to make gas.

> ある技師は簡単な昇降装置を開発し、有機廃棄物からガスを作る方法を開拓しようと申し出た。

<a id="x134-05"></a>

**134.05**　The **ecological** benefits were real, but that supply could not be ready by morning.

> 環境上の利点は本物だが、朝までにガスを用意することはできなかった。

<a id="x134-06"></a>

**134.06**　“Would string be **OK**?” asked a **bored** child who had lost interest in the **dull** calculations.

> 「ひもでいい？」と、退屈な計算に興味を失って飽きた子が聞いた。

<a id="x134-07"></a>

**134.07**　Someone gave the string a pull; the paper moon began to **sink**, then **burst**.

> 誰かがひもを引くと、紙の月が下がり始め、ぱんとはじけた。

<a id="x134-08"></a>

**134.08**　The sound made the audience **glance** up, then **surge** forward to help.

> その音に観衆はちらりと見上げ、一斉に前へ出て助けに来た。

<a id="x134-09"></a>

**134.09**　It took little time to **rid** the frame of broken paper and stretch a new sheet over **half** of it.

> 破れた紙を枠から取り去り、半分に新しい紙を張るのはすぐだった。

<a id="x134-10"></a>

**134.10**　“A half moon!” the boy said; “that is **super**!”

> 「半月だ！　すごいね！」と男の子が言った。

<a id="x134-11"></a>

**134.11**　An **unfortunate** accident had produced an **exciting** sight with **minimal** effort.

> 不運な事故から、ほんのわずかな手間で胸の躍る眺めが生まれた。

<a id="x134-12"></a>

**134.12**　For once the most **worthwhile** part of the **endeavour** had come after the failure.

> 今回にかぎっては、試みの中で一番やる価値のあった部分は失敗の後に来た。

**読みの問い**　子どもの最初の夢は、一部を変えた後でもかなったか。

<a id="ex-story-135"></a>

### 135　反対の声の居場所

<a id="x135-01"></a>

**135.01**　A **presidential** candidate came to discuss the **influence** of public exhibitions.

> 公開展示の影響について話し合うため、大統領候補がやって来た。

<a id="x135-02"></a>

**135.02**　His **doctrine** held that art should **consolidate** a common idea of **civilization**.

> 彼の主義によれば、芸術は文明についての共通の考えを確かなものにするべきだった。

<a id="x135-03"></a>

**135.03**　He could not **accept** a **literary** work that seemed to **undermine** national **pride**.

> 国の誇りを損なうように思える文学作品は受け入れられないという。

<a id="x135-04"></a>

**135.04**　The poet believed the **contrary** and asked us to **contemplate** the **complexity** of a single town.

> 詩人は逆の立場をとり、一つの町の複雑さにじっくり思いを巡らせるよう求めた。

<a id="x135-05"></a>

**135.05**　“Does every book have to **adhere** to a **standard** picture of the town?” she asked.

> 「どの本も町の標準的な姿に合わせなくてはいけませんか」と尋ねた。

<a id="x135-06"></a>

**135.06**　“Do we **intend** our pictures to **impress** visitors or to help them **think**?”

> 「来場者を感心させるのが目的でしょうか。それとも考える手助けをするためでしょうか」

<a id="x135-07"></a>

**135.07**　The candidate answered in the **negative** for the first question.

> 一つ目の問いについて、候補者の答えは否定だった。

<a id="x135-08"></a>

**135.08**　He could **appreciate** a critical account, he said, provided it drew on **fact**.

> 事実を根拠にした批判的な記述なら価値を認められる、と彼は言った。

<a id="x135-09"></a>

**135.09**　It was an **irony** that the most **instrumental** speaker in changing his mind was the one he had come to **criticize**.

> 彼の心を変えるのにいちばん大きな役割を果たしたのが、彼が批判しに来た当の人だったのは皮肉だった。

<a id="x135-10"></a>

**135.10**　His **regard** for her grew during that conversation, despite their **numerous** differences.

> 二人には数多くの相違があったが、その会話を通して彼女への敬意は増した。

<a id="x135-11"></a>

**135.11**　The **prospect** of a full **resolution** remained **unclear**, but a **hopeful** silence followed.

> 完全に解決できる見込みはまだはっきりしなかったが、その後には希望を含んだ静けさが訪れた。

**読みの問い**　二人の主張が完全に一致する前に、すでに何が変わったか。

<a id="ex-story-136"></a>

### 136　赤い点は商標か

<a id="x136-01"></a>

**136.01**　Our final **subject** was the umbrella that had started our search.

> 最後に取り上げる主題は、捜索のきっかけになったあの傘だった。

<a id="x136-02"></a>

**136.02**　A collector wanted to know the **latest** about the red dot.

> 収集家が赤い点についての最新の情報を知りたがった。

<a id="x136-03"></a>

**136.03**　Could it be a **trademark** shared by all the umbrellas, or merely a **coincidence**?

> どの傘にも共通する商標なのか、それとも単なる偶然の一致なのか。

<a id="x136-04"></a>

**136.04**　The question had become an **obsession**; even at dinner my sister talked of little else.

> その問いは執着に変わり、夕食でも妹はそのことばかり話していた。

<a id="x136-05"></a>

**136.05**　We did not want that one detail to **inhibit** other ideas or **interfere** with the exhibition.

> 私たちは一つの細部のためにほかの考えが抑えられたり、展覧会に支障が出たりすることは望まなかった。

<a id="x136-06"></a>

**136.06**　An old man who made umbrellas showed us how wood and leather **age** and **contract** at different rates.

> 年配の傘職人が、木と革では古びる速さや縮む速さが異なることを見せてくれた。

<a id="x136-07"></a>

**136.07**　“Some marks **persist**, and others **tend** to fade.”

> 「ずっと残る印もあれば、たいてい薄れていく印もあります」

<a id="x136-08"></a>

**136.08**　He showed us the **ease** with which a spot of red paint came off on a wet hand.

> 赤い塗料の点が、濡れた手にいとも簡単に移ることも見せてくれた。

<a id="x136-09"></a>

**136.09**　It was a **reminder** of the little red drop that had once run down my hand.

> それで私は、以前、自分の手を伝い落ちた赤いしずくを思い出した。

<a id="x136-10"></a>

**136.10**　We had tried to **battle** uncertainty, yet a little uncertainty could be **fascinating**.

> 私たちは不確かさと懸命に闘ってきたが、少し不確かなところがあるのも、面白いのかもしれない。

**読みの問い**　職人の実演は、赤い印が商標かという問いに最終的な答えを与えたか。

<a id="ex-story-137"></a>

### 137　いくらと言ったのは誰か

<a id="x137-01"></a>

**137.01**　At the ticket desk, a girl put a small blue boat on the counter.

> 切符売り場で、女の子が小さな青い舟をカウンターに置いた。

<a id="x137-02"></a>

**137.02**　“I offer you a pound for the boat,” said the man behind her.

> 「その舟、一ポンドで買いましょう」と後ろの男性が言った。

<a id="x137-03"></a>

**137.03**　“I made you an offer,” he added when she did not answer.

> 返事がないので「買値を言ったんですよ」と付け加えた。

<a id="x137-04"></a>

**137.04**　The girl pushed the boat towards the clerk.

> 女の子は舟を窓口の人の方へ押した。

<a id="x137-05"></a>

**137.05**　“I offered to carry this boat for the boy outside.”

> 「外にいる子に、これを運んであげるって申し出たんです」

<a id="x137-06"></a>

**137.06**　“So you can offer me a pound, but I cannot offer you the boat.”

> 「だから私に一ポンドを差し出すことはできても、私からこの舟を渡すことはできません」

<a id="x137-07"></a>

**137.07**　The man put his money away and offered to hold the door.

> 男性はお金をしまい、代わりにドアを押さえていましょうと申し出た。

**読みの問い**　三人のあいだに行き交った申し出のうち、金額を提示したのは誰か。

<a id="ex-story-138"></a>

### 138　最終列車の前に

<a id="x138-01"></a>

**138.01**　Half an hour before closing, we began to **hurry** through the last box.

> 閉館の三十分前、私たちは最後の箱を急いで調べ始めた。

<a id="x138-02"></a>

**138.02**　The worst **scenario** was that we might **lose** one of the stories before it reached the archive.

> 最悪の場合、話が資料庫に届く前にどれか一つをなくすかもしれなかった。

<a id="x138-03"></a>

**138.03**　Our **tactical** choice was to **attempt** one small job at a time and leave each finished card on the left.

> そこで一度に小さな作業を一つずつ試み、済んだカードは左側に置くことにした。

<a id="x138-04"></a>

**138.04**　One boy could not **spell** his name in our language and was afraid he would **mess** up the label.

> ある男の子は自分の名前をこちらの言葉でつづれず、札を台無しにするのではと不安だった。

<a id="x138-05"></a>

**138.05**　“Please **remind** me how you say it,” my sister said.

> 「なんて言うのか、もう一度教えて」と妹が言った。

<a id="x138-06"></a>

**138.06**　He told her; the sound of his name became a little **extra** in the spoken record.

> 教えてもらった名前の響きは、音声記録にささやかなおまけとして加わった。

<a id="x138-07"></a>

**138.07**　Our hosts agreed to **cater** for the visitors who would **embark** on the morning boat.

> 主催者側は、朝の船に乗る来場者に食事を用意することにした。

<a id="x138-08"></a>

**138.08**　One visitor asked whether lunch was **included** in the ticket price.

> 昼食が切符の値段に含まれるのか、ある客がたずねた。

<a id="x138-09"></a>

**138.09**　“Of course; it would be **awful** to promise a meal and hand you a bill at sea.”

> 「もちろん。食事を約束しておいて沖で請求書を渡すなんて、ひどいでしょう」

<a id="x138-10"></a>

**138.10**　The little boat had no **supreme** authority to decide which story was true.

> どの話が本当かを決める最高の権限が、この小舟にあるわけではなかった。

<a id="x138-11"></a>

**138.11**　What it offered was **continuity**, because someone on the next bank could open the box and listen again.

> この舟がもたらすのはつながりだった。次の岸の誰かが箱を開け、また話に耳を傾けられる。

**読みの問い**　箱が向こう岸に着いたとき、次の人が受け取るのは結論だけか。

### 第2篇　読みの確認

**[90　水位の印](#ex-story-090)**　妹は波の高さを見た。父は流れの向きから、潮だけでは説明できないと考えた。

**[91　六本の傘が向かう家](#ex-story-091)**　訪ねた人がこの傘の持ち主ではなかった場合にも、その人の話を書き留めるよう頼まれた。

**[92　道を選ぶ白い線](#ex-story-092)**　印は普段の渡り場を示したままだ。増水した今そこを渡れるかどうかは、動物によって違う。

**[93　ゆっくり育つリンゴ](#ex-story-093)**　店は早く利益を得たかったが、作り手は食べごろになるまで一か月待てた。

**[94　開く傘、閉じた手](#ex-story-094)**　道具そのものではなく、その仕組みを描いたスケッチと、持ち手の工夫だった。

**[95　畑におとずれた春](#ex-story-095)**　巣が涼しかったのが傘のおかげか、傘がなくてもそうだったかを比べるため。

**[96　待合室の灯](#ex-story-096)**　医師は検査画像を見てから、どの処置が適切かを判断するつもりだった。

**[97　薬を飲む人の話](#ex-story-097)**　描いた子自身に題名を聞いた。同じ形でも同じ意味とは限らないからだ。

**[98　幕は港の絵](#ex-story-098)**　クマの役を演じた歌手。かぶり物が落ちたことで生まれた笑いを気に入った。

**[99　歌を返す壁](#ex-story-099)**　そうだ。座る位置によって、どちらの感想も成り立つ可能性があった。

**[100　スポーツ館の置き忘れ](#ex-story-100)**　単に失敗をやり直すのではなく、人を助けたために失った機会を取り戻すことになる。

**[101　勝者の賞金](#ex-story-101)**　いいえ。体力の回復などを目指す人にも支援が届くことを求めた。

**[102　新聞に載せる一枚](#ex-story-102)**　チームがその広告での使用や宣伝内容を認めていたかどうか。

**[103　集会の二つの票](#ex-story-103)**　決まっていない。最初に尋ねたのは、同意をどう確かめるかだった。

**[104　裁判所の時計](#ex-story-104)**　証人は見た時計を正直に信じていた。その時計が止まっていたので、時刻の証言は正確とはいえなかった。

**[105　名前を書かない扉](#ex-story-105)**　日付や土地の特徴だけでも本人が推測され得るから。何を公開するかは彼女が決めることだった。

**[106　閉じた扉から来た手紙](#ex-story-106)**　本人の手記には変化と、なお残る問いの両方があったから。

**[107　手紙に残った戦争](#ex-story-107)**　引き金の音は覚えているが、引くべきだった理由は語れない。

**[108　井戸に映った空](#ex-story-108)**　年代を絞れても、頭上の印が冠か太陽かは別の証拠が要る。

**[109　炭鉱で消えた白い手](#ex-story-109)**　個人の体験を集団全体の中に位置づけ、病気がどれほど広がっていたかを示す。

**[110　病院の予算会議](#ex-story-110)**　選べない。看護師の人数、移動の負担、特別なケアを必要とする人をどう扱うかも比べる必要がある。

**[111　二枚の切符と一枚の領収書](#ex-story-111)**　ならない。客は一度の旅行の切符を二枚示し、返金を求めている。

**[112　画面の中の忘れ物](#ex-story-112)**　二本が重なって、別々のものとして見えなくなるおそれがあった。

**[113　画面が教えない数字](#ex-story-113)**　待ち時間のほか、来場者の年齢構成なども日ごとに違ったから。

**[114　見えない棚にも重さがある](#ex-story-114)**　支えが見えにくくなるという外観であり、荷物を支えられる重さではない。

**[115　台所の記憶](#ex-story-115)**　料理の手順は再現しながら、飲み物をどの温度で飲むかなどは各自が選べた。

**[116　池から来た手紙](#ex-story-116)**　細菌が毒を作ったのか、魚や人に危険があるのかはまだ分からない。

**[117　砂漠を運ぶ箱](#ex-story-117)**　見た人が複数の説明を自分で考え、専門家の説明とも比べられるようにするため。

**[118　空港で消えた点](#ex-story-118)**　いいえ。一つの機体が画面の誤差で二度表示され、衝突するように見えた。

**[119　隣の国の傘](#ex-story-119)**　ダイヤは協力して組めるが、相手国の運賃決定権までは移らない。

**[120　選挙をする教室](#ex-story-120)**　当選者は他のグループの話も先に聞くと約束した。

**[121　三人の客が同じ部屋を見た](#ex-story-121)**　料金、休息、移動しやすさなど、各自が部屋や設備に求めるものが異なっていた。

**[122　葬列の最後の楽譜](#ex-story-122)**　演奏を最後まで自分のペースで続けさせてくれる思いやりとして受け取った。

**[123　額の外に出る物語](#ex-story-123)**　語義に加えて、話し手の言い回しや訛り、あえて語らない間も残したかった。

**[124　手作りの番組](#ex-story-124)**　娯楽に偏らないでほしいという地元の人の言葉と、その人が選んだ次の話し手。

**[125　一枚の写真、二つの肩書](#ex-story-125)**　国や集団の典型としてではなく、働き、人と出会う一人ひとりの生活として見られるようにした。

**[126　消えた名の競売](#ex-story-126)**　中の絵を実際に描いた人の名であり、それは裏の猫の絵と親族の証言から分かった。

**[127　暮らしの値段、町の値段](#ex-story-127)**　誰が利益を得て、誰が長時間労働などの負担を負ったのかは別に確かめる必要がある。

**[128　手の届く宇宙](#ex-story-128)**　円の形と均等な間隔という条件では、半径の増分は円周の増分だけで決まるので変わらない。

**[129　同じ顔をした双子の絵](#ex-story-129)**　この場合は、照明を専門に選んだという情報の方が直接役立つ。

**[130　放送の恐ろしい役名](#ex-story-130)**　一人の登場人物の行動を民族全体と結びつけかねない衣装の問題だった。

**[131　許可証の裏の文字](#ex-story-131)**　同じではない。許可証には活動が現行規則に従うと書かれ、喫煙場所には別の制限があった。

**[132　水をこぼさない工夫](#ex-story-132)**　子どもたちが使う施設や、その施設に向かう人とボールが衝突する危険を減らせたから。

**[133　二人の決心](#ex-story-133)**　一つ目は救うこと、二つ目は家に場所を空けて取っておくこと。

**[134　半分だけ光る月](#ex-story-134)**　円い月ではなく半月になったが、市場の上に月を浮かべることはできた。

**[135　反対の声の居場所](#ex-story-135)**　候補者は相手の考えを聞き、批評が持つ価値を認め、詩人への敬意を深めた。

**[136　赤い点は商標か](#ex-story-136)**　与えていない。塗料が別の物に移り得るという、もう一つの可能性を示した。

**[137　いくらと言ったのは誰か](#ex-story-137)**　後ろの男性だけ。女の子は舟を運ぶ行為を、最後に男性はドアを押さえる行為を申し出た。

**[138　最終列車の前に](#ex-story-138)**　一人ひとりの声や物語も受け取る。次の人がもう一度聞き、考える余地が残る。

---

<a id="exp-part-3"></a>

## 第3篇　箱に残る声

落とし物窓口に届いたかばんには、写真と手紙が入っていた。橋に残された赤い印を追うと、写っている人だけでなく、記録を作った人の姿も少しずつ見えてくる。

[139　閉館後に届いた箱](#ex-story-139) ／ [140　写真の端にいる人](#ex-story-140) ／ [141　毛糸の持ち主](#ex-story-141) ／ [142　市場を通る匂い](#ex-story-142)

[143　漁師と赤い糸](#ex-story-143) ／ [144　病院の窓辺](#ex-story-144) ／ [145　患者の昔の仕事](#ex-story-145) ／ [146　救助記録の閲覧室](#ex-story-146)

[147　草地の下を通るもの](#ex-story-147) ／ [148　地下室のシャツ](#ex-story-148) ／ [149　鉄道の時刻を巻き戻す](#ex-story-149) ／ [150　橋の影が二つある理由](#ex-story-150)

[151　音を記憶する劇場](#ex-story-151) ／ [152　劇場の値段](#ex-story-152) ／ [153　学校で写真を読む](#ex-story-153) ／ [154　二つの名札](#ex-story-154)

[155　海を渡った家族](#ex-story-155) ／ [156　箱の持ち主をめぐる投票](#ex-story-156) ／ [157　署名の行方](#ex-story-157) ／ [158　新聞が先に決めたこと](#ex-story-158)

[159　二本の川の一枚の図](#ex-story-159) ／ [160　小さな温室の実験](#ex-story-160) ／ [161　天気を借りる農場](#ex-story-161) ／ [162　倉庫で一ガロンを量る](#ex-story-162)

[163　走らなかった選手](#ex-story-163) ／ [164　肖像の前の二人](#ex-story-164) ／ [165　平和の部屋](#ex-story-165) ／ [166　二つの国の同じ切手](#ex-story-166)

[167　署名をしたのはだれか](#ex-story-167) ／ [168　劇場が避難所になった夜](#ex-story-168) ／ [169　本部で鳴ったベル](#ex-story-169) ／ [170　こわれた箱を開く](#ex-story-170)

[171　一番遅いニュース](#ex-story-171) ／ [172　人が作る機械](#ex-story-172) ／ [173　どこにでもある一点](#ex-story-173) ／ [174　診察室の天井](#ex-story-174)

[175　水の標本、恐怖の標本](#ex-story-175) ／ [176　観光船が来る前に](#ex-story-176) ／ [177　塗り替えられる看板](#ex-story-177) ／ [178　実演はどこから始まるのか](#ex-story-178)

[179　音楽家が置いていった火](#ex-story-179) ／ [180　町の冬はまだ来ない](#ex-story-180) ／ [181　三分でできる仕事](#ex-story-181) ／ [182　外に出る権利](#ex-story-182)

[183　資料の中の偏見](#ex-story-183) ／ [184　走る人の年金](#ex-story-184) ／ [185　一枚の白いポスター](#ex-story-185) ／ [186　五分だけの国](#ex-story-186)

[187　牧師が持ってきた劇](#ex-story-187) ／ [188　客席で消えた音](#ex-story-188) ／ [189　木片で暮らしを読む](#ex-story-189) ／ [190　十字架のない墓標](#ex-story-190)

[191　お金の表と裏](#ex-story-191) ／ [192　引退した足にパスを](#ex-story-192) ／ [193　橋の下に入った白い鳥](#ex-story-193) ／ [194　二つの台所](#ex-story-194)

[195　出口のない投票](#ex-story-195) ／ [196　声だけで作った肖像](#ex-story-196) ／ [197　乾いた紙と、紙を乾かす人](#ex-story-197) ／ [198　駅までの話し相手](#ex-story-198)

<a id="ex-story-139"></a>

### 139　閉館後に届いた箱

<a id="x139-01"></a>

**139.01**　The **bell** above the lost property desk **rang** just before **midnight**.

> 真夜中になる少し前、落とし物窓口の上のベルが鳴った。

<a id="x139-02"></a>

**139.02**　A **retired** railway worker stood at the **door** with a **heavy** **bag**.

> 入口には引退した鉄道員が、重いかばんを提げて立っていた。

<a id="x139-03"></a>

**139.03**　He put a **red** **glove** beside the umbrella and **asked** me to **look** inside the bag.

> 彼は赤い手袋を傘の横に置き、かばんの中を見てくれと言った。

<a id="x139-04"></a>

**139.04**　Inside lay a **notebook**, a **camera** and a **card** from the town **museum**.

> 入っていたのは手帳とカメラ、それに町の博物館からのカードだった。

<a id="x139-05"></a>

**139.05**　On the **back** page someone had drawn a map and marked our **bridge** with a red **cross**.

> 最後のページには地図が描かれ、町の橋に赤い十字がついていた。

<a id="x139-06"></a>

**139.06**　A **packet** of letters was **wrapped** in **brown** paper and tied with **string**.

> 手紙の束が茶色い紙で包まれ、ひもで結ばれていた。

<a id="x139-07"></a>

**139.07**　A **tag** carried one **line** of **writing**.

> 荷札には一行だけ字があった。

<a id="x139-08"></a>

**139.08**　“Please **keep** these until you **learn** whose mark this is.”

> 「この印が誰のものか分かるまで、これを預かってください」

<a id="x139-09"></a>

**139.09**　“Do you **want** a receipt?” I asked the **stranger**.

> 「預かり証はいりますか」と見知らぬ男に尋ねた。

<a id="x139-10"></a>

**139.10**　He gave a little **bow** and a **peculiar** **smile**.

> 男は軽く頭を下げ、妙な笑みを浮かべた。

<a id="x139-11"></a>

**139.11**　“I **own** the bag, but who owns the **memory**?”

> 「かばんは私のものだが、記憶は誰のものだろう」

**読みの問い**　男が所有していると言い切ったものと、持ち主を問い直したものは？

<a id="ex-story-140"></a>

### 140　写真の端にいる人

<a id="x140-01"></a>

**140.01**　At the **weekly** meeting the **photographer** **showed** us a **print** of the bridge.

> 週ごとの集まりで、写真家が橋の写真を見せてくれた。

<a id="x140-02"></a>

**140.02**　A **girl** with a **pink** band in her hair had one foot on the **edge** of the water.

> ピンクのヘアバンドを着けた女の子が、水際に片足を置いていた。

<a id="x140-03"></a>

**140.03**　Her **brother** held a fishing **rod** in his left hand.

> 兄は左手に釣りざおを握っていた。

<a id="x140-04"></a>

**140.04**　Near his **elbow** I caught a **glimpse** of a **blue** **jacket**.

> その肘のそばに青い上着がちらりと写っていた。

<a id="x140-05"></a>

**140.05**　My **uncle** took one **look** and shook his head.

> 叔父はひと目見ると、首を振った。

<a id="x140-06"></a>

**140.06**　“You may recognize a coat by its **colour**, but you cannot identify a **body** by one arm in a blue coat.”

> 「上着は色で見分けられるかもしれない。でも青い上着の腕一本で誰の体かまでは見分けられない」

<a id="x140-07"></a>

**140.07**　We **hung** the picture beside a **mirror** and tried a **different** **angle**.

> 私たちは鏡のそばに写真を掛け、別の角度から眺めた。

<a id="x140-08"></a>

**140.08**　The **shadow** fell to the **west**, not the **south**.

> 影は南ではなく西に伸びていた。

<a id="x140-09"></a>

**140.09**　The picture had been taken in the **morning**, although the **diary** said **evening**.

> 日記には夕方とあったが、撮られたのは朝だった。

<a id="x140-10"></a>

**140.10**　The **difference** did not **prove** that anyone had told a **lie**.

> その食い違いだけで誰かがうそをついたとは証明できなかった。

**読みの問い**　影は写真の何を判断する手掛かりになり、何を証明できなかったか。

<a id="ex-story-141"></a>

### 141　毛糸の持ち主

<a id="x141-01"></a>

**141.01**　The girl in the picture was now a **married** woman with a **baby** and two dogs.

> 写真の女の子は今では結婚し、赤ん坊と犬二匹と暮らしていた。

<a id="x141-02"></a>

**141.02**　Her **spouse** had **baked** a **cake** for the **twin** dogs on their shared **birthday**.

> 連れ合いは双子の犬の誕生日に、二匹のためにケーキを焼いていた。

<a id="x141-03"></a>

**141.03**　“Does a dog **mind** the **date**?” I asked.

> 「犬は日付を気にしますか」と私は聞いた。

<a id="x141-04"></a>

**141.04**　“No, but my **dad** likes a good excuse for a party.”

> 「いいえ。でも父は、お祝いする口実があるとうれしいんです」

<a id="x141-05"></a>

**141.05**　She cut a **piece** for me and **began** her **narrative**.

> 彼女は私に一切れ切り、話を始めた。

<a id="x141-06"></a>

**141.06**　Her **sibling** had hated that **silly** hair band and had **pulled** it off.

> 兄はあのばかばかしいヘアバンドが大嫌いで、引っぱって取ってしまった。

<a id="x141-07"></a>

**141.07**　It had fallen into a **nest** of wool in the basket beside their mother.

> ヘアバンドは、母の横のかごに入っていた、巣のようにまとまった毛糸の中に落ちた。

<a id="x141-08"></a>

**141.08**　She still had the little **set** of needles and the **rest** of the wool.

> 彼女は今も、その小さな編み針の組と、残りの毛糸を持っていた。

<a id="x141-09"></a>

**141.09**　We compared the thread on the umbrella with the wool, but the **texture** was wrong.

> 傘に残った糸と毛糸を比べたが、手触りが違った。

<a id="x141-10"></a>

**141.10**　“We can **exclude** one possibility without knowing the whole story,” she said.

> 「話を全部知らなくても、可能性を一つ消すことはできますね」と彼女は言った。

**読みの問い**　一家を訪ねて何が前進したか。

<a id="ex-story-142"></a>

### 142　市場を通る匂い

<a id="x142-01"></a>

**142.01**　That **Friday** we followed the smell of **coffee** from the **harbour** to a market **stall**.

> その金曜日、私たちはコーヒーの香りをたどって港から市場の露店まで歩いた。

<a id="x142-02"></a>

**142.02**　A **merchant** was **mixing** **cream** into a **spicy** **sauce**.

> 商人が辛いソースにクリームを混ぜていた。

<a id="x142-03"></a>

**142.03**　His wife **ground** the **spice** by hand and sold **banana** bread to a **queue** of children.

> 妻は香辛料を手で挽き、行列した子どもたちにバナナパンを売っていた。

<a id="x142-04"></a>

**142.04**　I ordered a **sandwich** and a **salad** for **breakfast**.

> 私は朝食にサンドイッチとサラダを注文した。

<a id="x142-05"></a>

**142.05**　“Has the price of **meat** gone up?” a **customer** asked.

> 「肉は値上がりしましたか」と客が聞いた。

<a id="x142-06"></a>

**142.06**　“The **cow** still eats the same **grain**,” said the merchant, “but its **feed** costs more.”

> 「牛が食べる穀物は同じですよ」と商人は言った。「でも、その飼料が高くなったんです」

<a id="x142-07"></a>

**142.07**　He offered a **discount** on the soup and a free **drink** for the **youngster** at the front.

> 商人はスープの値引きを申し出、先頭の子には無料の飲み物を勧めた。

<a id="x142-08"></a>

**142.08**　The child held up a little soup in a spoon, watched a **bubble** burst and **smelt** the steam.

> その子はスープを少しすくったスプーンを持ち上げ、泡がはじけるのを見て、湯気のにおいをかいだ。

<a id="x142-09"></a>

**142.09**　“I know this smell from our **kitchen**,” she said, carefully returning the **spoon**.

> 「このにおい、うちの台所のにおいだ」と言い、そっとスプーンを返した。

<a id="x142-10"></a>

**142.10**　The merchant had cooked for her grandparents before he **retired** from the school.

> 商人は学校を退職する前、あの子の祖父母にも食事を作っていた。

**読みの問い**　子どもと祖父母の世代を結びつけたものは何か。

<a id="ex-story-143"></a>

### 143　漁師と赤い糸

<a id="x143-01"></a>

**143.01**　At the **coast** we met a man who caught fish for a living and could tie a **loose** thread with one hand.

> 海岸で、ほどけた糸を片手で結べる漁師に会った。

<a id="x143-02"></a>

**143.02**　He made a tiny loop and put his thumb through the **hole**.

> 彼は小さな輪を作って、その穴に親指を通した。

<a id="x143-03"></a>

**143.03**　“The **grip** must be firm, but you must **let** the thread run,” he said.

> 「握りはしっかり、でも糸は滑るようにするんだ」と彼は言った。

<a id="x143-04"></a>

**143.04**　He **tightened** the red thread round the **stem** of a yellow flower.

> 彼は黄色い花の茎に赤い糸を巻いて締めた。

<a id="x143-05"></a>

**143.05**　“The same mark was on every rope we used in the **rescue**.”

> 「救助で使ったロープにはどれにも同じ印がついていた」

<a id="x143-06"></a>

**143.06**　A **storm** had once driven their **ship** against a **stone** wall.

> かつて嵐で船が石の壁にたたきつけられたことがあった。

<a id="x143-07"></a>

**143.07**　The **captain** had ordered the crew to **secure** the **deck** and **wait** for a boat.

> 船長は乗組員に、甲板の物を固定して舟を待つよう命じた。

<a id="x143-08"></a>

**143.08**　A boy who was **unable** to swim had slipped from a **beam** into the water.

> 泳げない少年が梁から滑り落ちて水に入った。

<a id="x143-09"></a>

**143.09**　A **swim** in cold water is one thing; a rescue in rough water is another.

> 冷たい水で泳ぐのと、荒れた水面で人を救うのとは話が違う。

<a id="x143-10"></a>

**143.10**　The man had dived after him before anyone could throw a rope.

> 誰かがロープを投げるより先に、漁師は後を追って飛び込んでいた。

<a id="x143-11"></a>

**143.11**　“You saved his life,” I said, but he pointed to the boy in the photograph.

> 「あなたが命を救ったんですね」と私が言うと、彼は写真の少年を指した。

<a id="x143-12"></a>

**143.12**　“He was the one who **caught** the rope and saved us both.”

> 「ロープをつかんで二人とも助けてくれたのは、あの子だよ」

**読みの問い**　語り手と漁師とでは、救った人を誰だと捉えているか。

<a id="ex-story-144"></a>

### 144　病院の窓辺

<a id="x144-01"></a>

**144.01**　We found the boy, now a **senior** **instructor**, on a visit to the hospital.

> 私たちは病院を訪ね、今では上級指導員になったあの少年に会った。

<a id="x144-02"></a>

**144.02**　His **hip** was still painful after surgery, but his **breathing** was back to **normal**.

> 手術後も腰骨の辺りはまだ痛んだが、呼吸は普段どおりに戻っていた。

<a id="x144-03"></a>

**144.03**　A **gentle** nurse **lowered** the bed and checked the flow of **oxygen**.

> 静かな物腰の看護師がベッドを下げ、酸素の流れを確かめた。

<a id="x144-04"></a>

**144.04**　“My **heart** is fine,” he said, “but that **bone** takes a long time to **heal**.”

> 「心臓は元気なんだが」と彼は言った。「あの骨がなかなか治らん」

<a id="x144-05"></a>

**144.05**　A **thin** **tube** ran into a **vein** in his arm.

> 細い管が腕の静脈に入っていた。

<a id="x144-06"></a>

**144.06**　On the **table** was a small **card** for a **visitor** to sign.

> テーブルには見舞客が署名する小さなカードが載っていた。

<a id="x144-07"></a>

**144.07**　The nurse had to **administer** a medicine and **monitor** the patient for a possible **complication**.

> 看護師は薬を投与し、合併症が起きないか患者を観察する必要があった。

<a id="x144-08"></a>

**144.08**　She **reassured** him that the treatment could **proceed** after lunch.

> 昼食のあとで治療を進められると説明して、彼を安心させた。

<a id="x144-09"></a>

**144.09**　He **promised** to let me see his old **fishing** **gear** after his next **consultation**.

> 次の診察が済んだら昔の釣り道具を見せようと約束してくれた。

**読みの問い**　この場面で monitor は、何が起きるかもしれないから必要だったのか。

<a id="ex-story-145"></a>

### 145　患者の昔の仕事

<a id="x145-01"></a>

**145.01**　Our new friend had taught students to **care** for people with a **disability**.

> 新しい知人は、障害のある人のケアを学生に教えていた。

<a id="x145-02"></a>

**145.02**　He had prepared a lesson about **consciousness** for a **psychiatric** unit.

> 精神科の病棟で使う、意識に関する授業も準備していた。

<a id="x145-03"></a>

**145.03**　A **conscious** patient could hear a voice even when **unable** to give a **clear** **sign**.

> 意識のある患者は、はっきりした合図が出せなくても、声を聞いていることがあった。

<a id="x145-04"></a>

**145.04**　An **unconscious** patient needed a **different** kind of **protection**.

> 意識を失っている患者には、別の種類の保護が必要だった。

<a id="x145-05"></a>

**145.05**　“One **observation** cannot give you a **diagnosis**,” he told a **curious** **pupil**.

> 「一度の観察だけで診断はできない」と、彼は好奇心の強い生徒に言った。

<a id="x145-06"></a>

**145.06**　“A high **fever** may accompany the **flu**, but the fever alone cannot name the **virus**.”

> 「インフルエンザで高熱が出ることはある。でも熱だけではウイルスの名前は分からない」

<a id="x145-07"></a>

**145.07**　A **surgical** team had seen a rare **syndrome** in an adolescent patient.

> 外科チームは、思春期の患者に珍しい症候群を見たことがあった。

<a id="x145-08"></a>

**145.08**　They had **discussed** the **case** before anyone dared to **prescribe** a new form of **therapy**.

> 新しい治療法の処方に踏み切る前に、チームでその症例について話し合っていた。

<a id="x145-09"></a>

**145.09**　“Does that **cure** the fear as well?” asked the **child** in the next bed.

> 「それで怖い気持ちも治るの？」と隣のベッドの子が尋ねた。

<a id="x145-10"></a>

**145.10**　“Sometimes a **chat** does more for that,” he said.

> 「それなら話をするほうが効くこともあるよ」と彼は言った。

**読みの問い**　病名を判断する場面と、隣の子の問いでは、必要としていたものがどう違うか。

<a id="ex-story-146"></a>

### 146　救助記録の閲覧室

<a id="x146-01"></a>

**146.01**　At the town hall a **polite** **official** gave us **access** to the rescue records.

> 町役場で、礼儀正しい職員が救助記録を見せてくれた。

<a id="x146-02"></a>

**146.02**　In **accordance** with one **strict** **regulation** we left our **mobiles** on a **shelf**.

> 厳しい規則に従い、私たちは携帯電話を棚に置いた。

<a id="x146-03"></a>

**146.03**　We could **borrow** a **pen**, but we needed **written** **permission** to photograph a page.

> ペンは借りられたが、ページを撮影するには書面の許可が必要だった。

<a id="x146-04"></a>

**146.04**　Every **entry** gave the **job** and **rank** of the person making the **statement**.

> 各項目には陳述した人の仕事と階級が記されていた。

<a id="x146-05"></a>

**146.05**　One **blank** against a family name was filled with a single red dot.

> 姓の横にある空欄の一つには、赤い点が一個打ってあった。

<a id="x146-06"></a>

**146.06**　The **red** of the dot matched the ink on the next page.

> 点の赤色は、次のページのインクの色と同じだった。

<a id="x146-07"></a>

**146.07**　The **above**, said the note, was a **temporary** **replacement** for a **missing** signature.

> 注によると、上記の印は抜けている署名の仮の代わりだった。

<a id="x146-08"></a>

**146.08**　“It does not **matter** who made it,” said my uncle, “if all we **need** is the **information**.”

> 「情報さえ分かれば、誰が印を付けたかは問題じゃない」と叔父は言った。

<a id="x146-09"></a>

**146.09**　The **secretary** gave a little **laugh** and a **direct** reply.

> 事務員は少し笑い、まっすぐに答えた。

<a id="x146-10"></a>

**146.10**　“It **matters** to the **worker** whose name is missing.”

> 「名前が抜けている職員にとっては、大事なことですよ」

**読みの問い**　同じ matter を使う二人は何を重要視しているか。

<a id="ex-story-147"></a>

### 147　草地の下を通るもの

<a id="x147-01"></a>

**147.01**　An old **architect** had left us a **plan** of the **common** between the **school** and the **mill**.

> 学校と製粉所の間にある共有の草地の図面を、年配の建築家が私たちに残していた。

<a id="x147-02"></a>

**147.02**　A **pipe** ran under the **lawn** from its **north** corner to a **pump** at the **southern** end.

> 北の角から南端のポンプまで、芝生の下に管が通っていた。

<a id="x147-03"></a>

**147.03**　The **upper** **floor** of the mill had been used to **store** **timber** and **wood** for the winter.

> 製粉所の上階は冬を越すための木材や薪の保管に使われた。

<a id="x147-04"></a>

**147.04**　A **tunnel** under the road could **accommodate** a small truck, but its **width** was only just **sufficient**.

> 道の下のトンネルには小型トラックが通れたが、幅にはぎりぎりの余裕しかなかった。

<a id="x147-05"></a>

**147.05**　We **measured** a **sharp** **bend** where the ground began to rise.

> 地面が高くなり始める場所で、急な曲がり角の寸法を測った。

<a id="x147-06"></a>

**147.06**　Our **contractor** wanted to **widen** the narrow **lane** and **reinforce** the **roof**.

> 請負業者は、細い通路を広げ、屋根を補強したがっていた。

<a id="x147-07"></a>

**147.07**　“The **alteration** could **damage** the **adjacent** **wall**,” the architect warned in a note.

> 「その改造で隣の壁を傷めるおそれがある」と建築家は書き残していた。

<a id="x147-08"></a>

**147.08**　With a **laser** we could **map** the **interior** without making a single cut.

> レーザーを使い、一か所も切らずに内部を測って図にすることができた。

<a id="x147-09"></a>

**147.09**　The **precise** **layout** **revealed** a **separate** room behind a sheet of grey metal.

> 正確な見取り図から、灰色の金属板の奥に別の部屋があると分かった。

**読みの問い**　地図を作る方法を変えたおかげで何が両立したか。

<a id="ex-story-148"></a>

### 148　地下室のシャツ

<a id="x148-01"></a>

**148.01**　A **lock** with a broken spring held the door, so I **pressed** it with my **shoulder**.

> ばねの壊れた錠が扉にかかっていたので、肩で押した。

<a id="x148-02"></a>

**148.02**　The metal felt **hard** and cold beneath my hand.

> 手を触れると金属は硬く、冷たかった。

<a id="x148-03"></a>

**148.03**　The outer layer of **paint** was **cream**, but the inner layer was **orange**.

> 塗料の外側の層はクリーム色で、内側はオレンジ色だった。

<a id="x148-04"></a>

**148.04**　A **cluster** of hooks held a **shoe**, a **sock** and some **scattered** **clothing**.

> 集まって並んだフックには、片方の靴と靴下、それに何着かの衣類が、ばらばらに掛かっていた。

<a id="x148-05"></a>

**148.05**　A folded shirt of fine **cotton** lay beside a packet of **underwear**.

> たたんだ上質な綿のシャツが、下着の包みのそばにあった。

<a id="x148-06"></a>

**148.06**　Everything was dry and **intact** except the **bottom** button of the shirt.

> シャツのいちばん下のボタンを除き、どれも乾いたままで傷んでいなかった。

<a id="x148-07"></a>

**148.07**　Someone had **stuck** a **feather** through that hole to mark the spot.

> 誰かがその穴に羽を挿して、場所の目印にしていた。

<a id="x148-08"></a>

**148.08**　My uncle **rubbed** the **heel** of the shoe and found the mark of a boot covered in mud.

> 叔父が靴のかかとをこすると、泥のついたブーツの跡が見つかった。

<a id="x148-09"></a>

**148.09**　“People came here for shelter,” he said, “and left in a **rush**.”

> 「人々がここに避難してきて、急いで出ていったんだ」と叔父は言った。

<a id="x148-10"></a>

**148.10**　The last thing we found was a dry **cigarette** in a **closed** box marked “Please do not smoke.”

> 最後に見つけたのは、閉じた箱の中の乾いたたばこだった。箱には「禁煙」と書いてあった。

**読みの問い**　intact がかかる範囲には、どんな例外があったか。

<a id="ex-story-149"></a>

### 149　鉄道の時刻を巻き戻す

<a id="x149-01"></a>

**149.01**　On **Thursday** we bought a **single** to the old **railway** station at the **eastern** border.

> 木曜日、東の境にある古い鉄道駅まで片道切符を買った。

<a id="x149-02"></a>

**149.02**　A **familiar** voice made an announcement about a **lengthy** **delay**.

> 聞き慣れた声が長い遅延を知らせた。

<a id="x149-03"></a>

**149.03**　The train could not **proceed** until the crew moved a **motor** vehicle off the track.

> 乗務員が線路上の自動車を移動させるまで、列車は先に進めなかった。

<a id="x149-04"></a>

**149.04**　We used the **lift** to reach the waiting room upstairs.

> 私たちは上の階の待合室までエレベーターで上がった。

<a id="x149-05"></a>

**149.05**　A station **employee** used her **telephone** to **contact** the **manager**.

> 駅員が電話で責任者に連絡した。

<a id="x149-06"></a>

**149.06**　She **arranged** a **taxi** for a **couple** with a tight **schedule**.

> 予定の詰まった二人連れのためにタクシーを手配した。

<a id="x149-07"></a>

**149.07**　A **pilot** on his way to the **airport** **chose** to **wait**.

> 空港に向かうパイロットは待つことを選んだ。

<a id="x149-08"></a>

**149.08**　“I could **board** another train,” he said, “but where is its **destination**?”

> 「別の列車には乗れます。でも行き先はどこでしょう」と彼は言った。

<a id="x149-09"></a>

**149.09**　At last a woman walked down the **track** and **waved** a **working** lamp.

> ようやく女性が線路沿いを歩いてきて、ちゃんと点灯するランプを振った。

<a id="x149-10"></a>

**149.10**　“Now you can **book** a return,” the clerk said, “since you know the **date** of your **arrival**.”

> 「到着日が分かったから、これで往復切符も予約できますね」と窓口係は言った。

**読みの問い**　single を買った人たちに、最後にどんな選択肢が加わったか。

<a id="ex-story-150"></a>

### 150　橋の影が二つある理由

<a id="x150-01"></a>

**150.01**　The man with the **bag** had given the **museum** a whole **portfolio** of bridge photographs.

> かばんの男性は、橋の写真をまとめた作品集を博物館に寄せていた。

<a id="x150-02"></a>

**150.02**　One **image** showed an **artificial** sun above a **level** surface.

> 一枚の画像には、水平な面の上に人工の太陽が写っていた。

<a id="x150-03"></a>

**150.03**　An **optical** instrument made a **double** **shadow** on a square of white paper.

> 光学器具で、正方形の白紙の上に二重の影ができていた。

<a id="x150-04"></a>

**150.04**　“An extra shadow need not imply an **extra** **object**,” said the **physics** **tutor**.

> 「影が一つ多いからといって、物が一つ多いとは限らない」と物理の指導員は言った。

<a id="x150-05"></a>

**150.05**　He **set** the lamp to its lowest level and placed the **mirror** at the **exact** **angle** shown in the photograph.

> 指導員はランプをいちばん暗く設定し、写真に写っていたまさにその角度で鏡を置いた。

<a id="x150-06"></a>

**150.06**　A **thin** **wire** then produced a whole **spectrum** of colours on the far wall.

> 次に細い針金を使うと、遠くの壁にさまざまな色が帯になって現れた。

<a id="x150-07"></a>

**150.07**　“What a **terrific** trick,” I said when I saw both shadows move together.

> 二つの影が一緒に動くのを見て、「なんてすばらしい仕掛けだ」と私は言った。

<a id="x150-08"></a>

**150.08**　We watched a **linear** **pattern** **disappear** when he bent the wire.

> 彼が針金を曲げると、直線状の模様が消えた。

<a id="x150-09"></a>

**150.09**　A minor **adjustment** of the light made both shadows overlap.

> 光をほんの少し調整すると、二つの影が重なった。

<a id="x150-10"></a>

**150.10**　“Your **inference** about the time of day is only as good as your **basis** for it.”

> 「時刻についての推論がどこまで確かかは、よりどころにしたもの次第ですよ」

**読みの問い**　影ができる仕組みを知って、先に立てた撮影時刻の推論はどう変わるか。

<a id="ex-story-151"></a>

### 151　音を記憶する劇場

<a id="x151-01"></a>

**151.01**　An **amateur** **orchestra** agreed to **perform** the music in a lost **film**.

> アマチュア楽団が、失われた映画の音楽を演奏してくれることになった。

<a id="x151-02"></a>

**151.02**　The **producer** had a **DVD** with no sound and an **audio** **recording** with no picture.

> 制作者は、無音のDVDと映像のない録音を持っていた。

<a id="x151-03"></a>

**151.03**　A **click** followed by a heavy **beat** helped us **align** the two.

> カチッという音の後に強い拍があり、二つの位置を合わせる手掛かりになった。

<a id="x151-04"></a>

**151.04**　The **drama** began with a **dance** on the **deck** of a sailing boat.

> 劇は帆船の甲板での踊りから始まった。

<a id="x151-05"></a>

**151.05**　A **ballet** dancer, **dressed** in a **purple** coat, lifted an **imaginary** **sword**.

> 紫の上着を着たバレエの踊り手が、想像上の剣を持ち上げた。

<a id="x151-06"></a>

**151.06**　His **partner**, a **jazz** singer, **switched** from **pop** to a **traditional** song.

> 相方のジャズ歌手は、ポップ音楽から伝統の歌に切り替えた。

<a id="x151-07"></a>

**151.07**　Their **duo** gave a **live** performance behind the **curtain** while we watched the **screening**.

> 私たちが上映を見ている間、その二人組は幕の裏で生のパフォーマンスを披露した。

<a id="x151-08"></a>

**151.08**　A bird **flew** across the screen and seemed to **wave** its wing in time with the music.

> 画面を飛ぶ鳥が、音楽に合わせて羽を振っているように見えた。

<a id="x151-09"></a>

**151.09**　At the **close** of the show a **critic** described the ending as **amusing** but **unexpected**.

> 上演が終わると、ある批評家は結末を「面白いけれど意外だ」と評した。

<a id="x151-10"></a>

**151.10**　“The bird had better timing than the leader of the orchestra,” she added.

> 「コンサートマスターより、あの鳥のほうが拍を取るのが上手でしたよ」と彼女は付け加えた。

**読みの問い**　画面の鳥まで音楽に合わせているように見えたのはなぜか。

<a id="ex-story-152"></a>

### 152　劇場の値段

<a id="x152-01"></a>

**152.01**　The theatre was a **profitable** **business** in the tourist **season**, but not all year.

> 劇場は観光シーズンには利益が出たが、一年中そうではなかった。

<a id="x152-02"></a>

**152.02**　The **rent** was **fixed** and the **weekly** **wage** bill was **high**.

> 家賃は定額で、毎週かかる賃金も高かった。

<a id="x152-03"></a>

**152.03**　“Full houses do not **guarantee** a **profit**,” its **boss** said.

> 「満席だからといって利益が出るとは限りません」と経営者は言った。

<a id="x152-04"></a>

**152.04**　She let us **inspect** the books and **count** the **money** in the office.

> 私たちは帳簿を調べ、事務所にある現金を数えさせてもらった。

<a id="x152-05"></a>

**152.05**　A **loan** had covered the purchase of new **equipment** and **furniture**.

> 新しい機材と家具の購入費は借入金でまかなった。

<a id="x152-06"></a>

**152.06**　The town had **granted** permission for the repairs and offered a **grant**, but it could not **compensate** every **loss**.

> 町は修繕を許可して助成金を申し出たが、あらゆる損失を補うことはできなかった。

<a id="x152-07"></a>

**152.07**　A small **company** had offered to **sponsor** a show in return for **publicity**.

> 小さな会社が、宣伝してもらう代わりに、一公演のスポンサーになると申し出ていた。

<a id="x152-08"></a>

**152.08**　A bright **banner** in the **reception** area would **display** its name.

> 受付に鮮やかな垂れ幕を掛け、そこに社名を掲げるという案だった。

<a id="x152-09"></a>

**152.09**　“Must we **brand** every **chair** as well?” asked an **annoyed** **artist**.

> 「椅子にも一脚ずつ社名をつけなきゃいけないんですか」と芸術家がいら立って言った。

<a id="x152-10"></a>

**152.10**　The **offer** went back for **negotiation** before anybody made a **promise**.

> 誰かが約束をする前に、その申し出は再交渉に回された。

**読みの問い**　なぜ満席なのに交渉が必要になったか。

<a id="ex-story-153"></a>

### 153　学校で写真を読む

<a id="x153-01"></a>

**153.01**　At the **campus** a young **academic** was teaching a **module** on pictures as evidence.

> 大学では若い研究者が、証拠としての写真を扱う授業をしていた。

<a id="x153-02"></a>

**153.02**　Her **academic** interest was the **interaction** between **journalism** and history.

> 彼女が研究で関心を寄せていたのは、報道と歴史の関わりだった。

<a id="x153-03"></a>

**153.03**　An **educator** asked how she would introduce the **concept** to an **elementary** class.

> 教育者が、その考えを初歩のクラスにどう導入するか尋ねた。

<a id="x153-04"></a>

**153.04**　She passed one **print** to each **pupil** and gave them a practical task.

> 彼女は生徒に写真を一枚ずつ配り、実際に手を動かす課題を与えた。

<a id="x153-05"></a>

**153.05**　“**List** what you can see before you **speculate** about its **cause**.”

> 「原因を推測する前に、見える物を列挙してください」

<a id="x153-06"></a>

**153.06**　The **aim** of the **lesson** was a **distinction** between description and **explanation**.

> 授業の狙いは、記述と説明を区別できるようになることだった。

<a id="x153-07"></a>

**153.07**　For **homework** they had to **record** one **accurate** detail and one **informed** **guess**.

> 宿題では、正確に確認した細部を一つ、見たことを踏まえた推測を一つ記録することになった。

<a id="x153-08"></a>

**153.08**　One **adolescent** wrote, “An umbrella has fallen, so there must have been a **fight**.”

> 思春期の生徒の一人は「傘が落ちているから、きっとけんかがあった」と書いた。

<a id="x153-09"></a>

**153.09**　His friend wrote a single **query** in the margin: “Could the owner have dropped it?”

> 友達は余白に問いを一つだけ書いた。「持ち主が落としたのかも？」

<a id="x153-10"></a>

**153.10**　The teacher kept both for her next **lecture** on **critical** **thinking**.

> 先生は、批判的思考を扱う次の講義のために両方を取っておいた。

**読みの問い**　二人目の生徒は最初の説明を否定したのか。

<a id="ex-story-154"></a>

### 154　二つの名札

<a id="x154-01"></a>

**154.01**　The **organizer** asked a young **designer** to **design** labels with **clear** directions.

> 主催者が若いデザイナーに、案内の分かりやすい札をデザインしてほしいと頼んだ。

<a id="x154-02"></a>

**154.02**　The **guideline** was simple: **label** each picture with its **principal** **theme**.

> 指針は単純だった。それぞれの写真に、その主題を書き添えるのだ。

<a id="x154-03"></a>

**154.03**　An **experienced** **collector** was to **sort** the pictures by **type** and **genre**.

> 経験豊かな収集家が、種類やジャンルで写真を仕分けることになった。

<a id="x154-04"></a>

**154.04**　“Does one **classification** have to **exclude** another?” asked his **assistant** editor.

> 「一つの分類は、もう一つを排除しないといけないんですか」と副編集者が聞いた。

<a id="x154-05"></a>

**154.05**　A **documentary** about a **historical** **battle** could make use of a **family** photograph.

> 歴史上の戦闘のドキュメンタリーで、家族写真を使うこともある。

<a id="x154-06"></a>

**154.06**　The **overlap** was real, but two labels might confuse a **prospective** customer.

> 重なる部分が実際にあっても、札が二つあると購入を考えている人は戸惑うかもしれなかった。

<a id="x154-07"></a>

**154.07**　We **chose** a **dual** system with a short **paragraph** of **context** on the **back**.

> 私たちは二通りの見方を示す方式を選び、裏面に背景を一段落で書いた。

<a id="x154-08"></a>

**154.08**　A **reader** could follow either **line** of thought, or combine the two.

> 読む人はどちらかの考え方をたどっても、二つを合わせてもよかった。

**読みの問い**　同じ一枚を二種類に分けても矛盾しないのはなぜか。

<a id="ex-story-155"></a>

### 155　海を渡った家族

<a id="x155-01"></a>

**155.01**　A **refugee** standing by the photograph **told** us about his father and an armed **militant**.

> 写真のそばにいた難民の男性が、父親と武装した活動家の話をしてくれた。

<a id="x155-02"></a>

**155.02**　The man had escaped from his **country** during a **violent** **riot**.

> 男性は激しい暴動のさなかに自国を脱出した。

<a id="x155-03"></a>

**155.03**　His family had been separated at the border, and his **passport** had been taken by a **policeman**.

> 国境で家族は離れ離れになり、警官が彼の旅券を取り上げた。

<a id="x155-04"></a>

**155.04**　A temporary camp had offered food and a **tent**, but little privacy.

> 仮設の野営地で食料とテントは得られたが、プライバシーはほとんど守られなかった。

<a id="x155-05"></a>

**155.05**　“At first I felt no anger, just **terror** and a desperate **need** for **sleep**.”

> 「最初は怒りすらなく、ただ怖くて、たまらなく眠りたかった」

<a id="x155-06"></a>

**155.06**　He had been a **solicitor**; his wife had been a **civilian** doctor in the **army** hospital.

> 彼は事務弁護士で、妻は軍病院に勤める民間の医師だった。

<a id="x155-07"></a>

**155.07**　In **exile** they had to **earn** a living before they could **practise** either **profession**.

> 亡命先では、それぞれの専門職に戻る前に生活費を稼ぐ必要があった。

<a id="x155-08"></a>

**155.08**　A **sympathetic** **counsellor** provided **assistance** with **immigration** forms and a **job** application.

> 親身な相談員が移民手続きの書類と仕事への応募を手伝ってくれた。

<a id="x155-09"></a>

**155.09**　The first **rejection** was a **blow**, but he did not **surrender** his **hope**.

> 最初に断られたときは痛手だったが、望みは捨てなかった。

<a id="x155-10"></a>

**155.10**　His most valued possession was an old **card** bearing his father's **familiar** writing.

> いちばん大事な持ち物は、見慣れた父の筆跡が残る古いカードだった。

**読みの問い**　国境で家族が離れ離れになった後も、男性にとって残ったつながりは何だったか。

<a id="ex-story-156"></a>

### 156　箱の持ち主をめぐる投票

<a id="x156-01"></a>

**156.01**　The **governor** called a public **debate** over legal ownership of the box.

> 知事は、箱の法的な所有権をめぐって公開討論を開いた。

<a id="x156-02"></a>

**156.02**　The **agenda** gave each **candidate** three minutes to present a proposal.

> 議事日程では候補者に三分ずつ、案を発表する時間が与えられた。

<a id="x156-03"></a>

**156.03**　A **democratic** **choice** would require a secret **poll**, said the **commissioner**.

> 民主的に決めるには無記名投票が必要だと委員が言った。

<a id="x156-04"></a>

**156.04**　A vocal **supporter** wanted to **nominate** the **trustee** whose **farm** stood by the river.

> 積極的に発言する支持者は、川辺に農場を持つ受託者を候補に推したがった。

<a id="x156-05"></a>

**156.05**　That **nominee** refused to **represent** the town on **behalf** of one **household**.

> その候補者は、一世帯の代理で町全体を代表することを断った。

<a id="x156-06"></a>

**156.06**　“My **opinion** is my own; it does not **equal** the opinion of the **majority**.”

> 「私の意見は私個人のものです。多数派の意見と同じものではありません」

<a id="x156-07"></a>

**156.07**　A local **referendum** could **determine** our **willingness** to pay for a town archive.

> 住民投票をすれば、町の資料庫に費用を払う意思があるかは確かめられる。

<a id="x156-08"></a>

**156.08**　It could not **confer** a **legal** right over someone else's **property**.

> ただしそれで他人の財産を所有する法的な権利まで与えられるわけではない。

<a id="x156-09"></a>

**156.09**　The **chair** decided to **post** two **distinct** questions before the **deadline**.

> 議長は締め切り前に、内容の異なる二つの問いを掲示することにした。

**読みの問い**　一度の投票で決められることと決められないことは何か。

<a id="ex-story-157"></a>

### 157　署名の行方

<a id="x157-01"></a>

**157.01**　An **investigator** arrived with a formal **enquiry** about a **breach** of trust.

> 捜査員が、信頼を裏切る行為について正式に調べに来た。

<a id="x157-02"></a>

**157.02**　A former **executive** was under intense pressure to **disclose** a **secret** payment.

> 元幹部は秘密の支払いを明らかにするよう強く求められていた。

<a id="x157-03"></a>

**157.03**　We had an **insider** account of **corruption**, but no independent confirmation.

> 汚職について内部の人の話はあったが、独立した裏づけはなかった。

<a id="x157-04"></a>

**157.04**　An **objective** **audit** could **correct** a **minor** **error** without proving a **crime**.

> 客観的な監査で小さな誤りを訂正できても、それが犯罪の証明になるとは限らない。

<a id="x157-05"></a>

**157.05**　The **detective** asked the witness to **repeat** his **testimony** before a **judge**.

> 刑事は証人に、裁判官の前で同じ証言をもう一度するよう求めた。

<a id="x157-06"></a>

**157.06**　The **content** of the report mattered more than the name on its cover.

> その報告書では、表紙の名前よりも中身のほうが重要だった。

<a id="x157-07"></a>

**157.07**　“Did you see him **steal** the money, or did you hear the **rumour** afterwards?”

> 「彼がお金を盗むのを見たのですか、それともあとでうわさを聞いたのですか」

<a id="x157-08"></a>

**157.08**　The witness had heard a **cry** and seen a dark shape, but never a **face**.

> 証人は叫び声を聞き、黒い影を見たが、顔は見ていなかった。

<a id="x157-09"></a>

**157.09**　A **careless** translation might **render** his **assertion** more **convincing** than it was.

> 不注意な翻訳によって、その主張が本来よりも説得力のあるものになってしまうかもしれなかった。

<a id="x157-10"></a>

**157.10**　The **prosecution** asked for a short delay, and the **jury** went home.

> 検察側が短い延期を求め、陪審員たちは帰宅した。

<a id="x157-11"></a>

**157.11**　A **conviction** would require evidence that the witness simply could not give.

> 有罪判決には、この証人がどうしても示せない証拠が必要だった。

**読みの問い**　会計上の誤りが見つかっても、なぜ誰かを犯人と呼べないのか。

<a id="ex-story-158"></a>

### 158　新聞が先に決めたこと

<a id="x158-01"></a>

**158.01**　The **editorial** page of the town **newsletter** called the case a **scandal**.

> 町の広報紙の社説欄は、この件を不祥事と呼んだ。

<a id="x158-02"></a>

**158.02**　A **spokesperson** for the **press** said there was **nationwide** **outrage**.

> 報道側の広報担当者は、全国で怒りの声が上がっていると言った。

<a id="x158-03"></a>

**158.03**　A young reporter found that nearly every **media** **outlet** had quoted the **same** sentence.

> 若い記者が調べると、ほぼすべての報道機関が同じ一文を引用していた。

<a id="x158-04"></a>

**158.04**　A **radio** **commentator** had been the first to **mention** a possible **conspiracy**.

> 共謀の可能性に初めて触れたのはラジオの解説者だった。

<a id="x158-05"></a>

**158.05**　“Did the **repeated** claim **multiply** the evidence or just its **circulation**?” the reporter asked.

> 「同じ主張が繰り返されたことで、証拠が増えたのですか。それとも、その話が広まっただけですか」と記者は問うた。

<a id="x158-06"></a>

**158.06**　She **edited** the **reporting** to distinguish an **explicit** charge from an **indirect** hint.

> 彼女は記事を編集し、明示的な告発と遠回しなほのめかしを区別した。

<a id="x158-07"></a>

**158.07**　A **magazine** **credited** her with the change, but its headline was **incorrect**.

> 雑誌は訂正を彼女の手柄としたが、その見出しにも誤りがあった。

<a id="x158-08"></a>

**158.08**　“The **revision** was a **collective** effort,” she wrote in her **mail** to the editor.

> 「今回の修正はみんなで行ったものです」と彼女は編集者あての便りに書いた。

<a id="x158-09"></a>

**158.09**　One **subscriber** sent a **thoughtful** **remark**: “Who checks the correction?”

> ある購読者が、よく考えた言葉を寄せた。「訂正を確かめるのは誰ですか」

**読みの問い**　同じ主張を五紙で読んだとしても、独立した五件の証拠にならない理由は？

<a id="ex-story-159"></a>

### 159　二本の川の一枚の図

<a id="x159-01"></a>

**159.01**　We asked a **mathematics** teacher to interpret a **survey** of the river **region**.

> 川の流域を調べた調査の読み方を、数学の教師に尋ねた。

<a id="x159-02"></a>

**159.02**　A **drop** in the **rate** of illness had **coincided** with an **increase** in clean water supplies.

> 病気になる割合の低下と、きれいな水の供給増加が同じ時期に起きていた。

<a id="x159-03"></a>

**159.03**　“Does that **correlation** establish a **cause**?” a student asked.

> 「その相関が原因の証明になりますか」と生徒が聞いた。

<a id="x159-04"></a>

**159.04**　“The two towns **differ** in population, and that is another **factor** to **consider**.”

> 「二つの町は人口が違います。それも考慮すべき要因です」

<a id="x159-05"></a>

**159.05**　We divided the reported **incidence** by the number of people in each town to compare a common **indicator**.

> 届出件数をそれぞれの町の人口で割り、共通の指標で比べた。

<a id="x159-06"></a>

**159.06**　The **average** **intake** of clean water had risen by only a **fraction** in one town.

> 一方の町では、きれいな水の平均摂取量はほんの少ししか増えていなかった。

<a id="x159-07"></a>

**159.07**　A large **percentage** on a chart can **represent** a very small **amount** in a small town.

> 小さな町では、図で割合が大きくても、実際の量はわずかなことがある。

<a id="x159-08"></a>

**159.08**　To **validate** our **method** we asked the teacher to check every **sum**.

> 私たちの計算方法が妥当か確かめるため、教師に一つずつ計算を見てもらった。

<a id="x159-09"></a>

**159.09**　One **positive** emerged: at last the two teams had agreed what to count.

> よかった点が一つあった。何を数えるかで、ようやく二つのチームの意見が一致した。

**読みの問い**　割合と実際の量の関係が、町の大きさでどう変わるか。

<a id="ex-story-160"></a>

### 160　小さな温室の実験

<a id="x160-01"></a>

**160.01**　Behind the **nursery** a **keen** **volunteer** looked after a **plant** that would not flower.

> 苗を育てる施設の裏で、熱心なボランティアが、なかなか花をつけない植物の世話をしていた。

<a id="x160-02"></a>

**160.02**　She wanted to **experiment** with the soil before we gave up on the last **seed**.

> 最後の種を諦める前に、土を変えて試してみたいのだという。

<a id="x160-03"></a>

**160.03**　An agricultural specialist took a **sample** and detected a **deficiency** in one **mineral**.

> 農業の専門家が試料を採り、ある一種類のミネラルの不足を見つけた。

<a id="x160-04"></a>

**160.04**　We **added** a small quantity and **observed** the **growth** of each new **leaf**.

> 少量を加え、新しい葉が一枚ずつどう育つか観察した。

<a id="x160-05"></a>

**160.05**　The **beneficial** effect was **localized**: only the plants in one **patch** improved.

> よい効果が出た範囲は限られ、一画の植物だけが元気になった。

<a id="x160-06"></a>

**160.06**　The leaves were **resistant** to a local disease, but the roots were not **immune** to it.

> 葉には土地の病気への抵抗力があったが、根まで免疫があるわけではなかった。

<a id="x160-07"></a>

**160.07**　A **bee** continued to **visit** one **pale** **rose**; a **frog** watched from the **mud**.

> 一匹のハチが淡い色のバラに通い続け、泥の中からカエルが見ていた。

<a id="x160-08"></a>

**160.08**　“Is the bee the **prey**?” a child asked as a **bat** flew past.

> コウモリが飛び過ぎたとき、子どもが「ハチが獲物なの？」と尋ねた。

<a id="x160-09"></a>

**160.09**　“Not here,” said the volunteer, “but every **creature** needs a **habitat** in which it can **thrive**.”

> 「ここでは違うよ。でも、どの生き物にも育っていけるすみかが要るね」とボランティアは答えた。

**読みの問い**　葉の病気への強さを見て、根について同じ結論を出せないのはなぜか。

<a id="ex-story-161"></a>

### 161　天気を借りる農場

<a id="x161-01"></a>

**161.01**　The **aftermath** of a **hurricane** could be seen in every field on the coast.

> 沿岸のどの畑にも、ハリケーンの爪痕が残っていた。

<a id="x161-02"></a>

**161.02**　In a **rural** area, a **failed** **harvest** could **affect** a **whole** **household** for a year.

> 農村では一度の不作が、一家全員の生活に一年間影響することがある。

<a id="x161-03"></a>

**161.03**　Our guide had studied **agriculture** before finding full-time work in **conservation**.

> 案内人は農業を学び、そのあと自然保全の常勤職に就いた。

<a id="x161-04"></a>

**161.04**　He explained the **advantage** of planting trees as a **buffer** against the wind.

> 風を和らげる緩衝帯として木を植える利点を説明してくれた。

<a id="x161-05"></a>

**161.05**　A young **forest** had survived on the **slope** because its trees could **bend** without breaking.

> 斜面の若い森は生き残った。木々は折れずにしなうことができたのだ。

<a id="x161-06"></a>

**161.06**　A **persistent** **weed** had spread along a water channel and begun to **restrict** the flow of water.

> しぶとい雑草が溝に沿って広がり、水の流れを妨げ始めていた。

<a id="x161-07"></a>

**161.07**　We cleared it away to **prevent** a **subsequent** flood and **help** the water **drain**.

> 次にまた水があふれるのを防ぎ、排水をよくするために雑草を取り除いた。

<a id="x161-08"></a>

**161.08**　“A flood can destroy a crop and carry useful **earth** to the next field,” he said.

> 「洪水は作物を壊す一方で、隣の畑に役に立つ土を運ぶこともあります」と彼は言った。

<a id="x161-09"></a>

**161.09**　His **advice** was to **avoid** a **generalization** until we had walked the land ourselves.

> 自分たちの足で土地を歩くまでは、一般化を避けなさい、と彼は助言した。

**読みの問い**　農場で、同じ洪水に二つの見方が出たのはなぜか。

<a id="ex-story-162"></a>

### 162　倉庫で一ガロンを量る

<a id="x162-01"></a>

**162.01**　Next door stood a **manufacturing** company that made **fuel** from waste **food**.

> 隣には食品廃棄物から燃料を作る製造会社があった。

<a id="x162-02"></a>

**162.02**　Its **executive** board had voted to **purchase** a new **electric** motor for the factory.

> 経営陣は、工場用の新しい電動モーターの購入を決めていた。

<a id="x162-03"></a>

**162.03**　A **solar** panel provided power when the **sun** reached the roof.

> 太陽の光が屋根に届くときは、太陽光パネルが電力を供給した。

<a id="x162-04"></a>

**162.04**　One **gallon** of **petrol** stood in a sealed **container** beside a tank of **gas**.

> タンクに入ったガスの横に、密閉容器に入れた一ガロンのガソリンが置かれていた。

<a id="x162-05"></a>

**162.05**　The engineer used a small **tube** to **transfer** gas and **measure** the **emission** from the test engine.

> 技術者は細い管でガスを移し、試験用エンジンから出る排気を測った。

<a id="x162-06"></a>

**162.06**　A **costly** **error** might **release** **hydrogen** into the room, so the door stayed shut.

> 大きな損失につながる誤りを犯すと水素が室内に漏れかねないため、入り口の扉は閉じたままだった。

<a id="x162-07"></a>

**162.07**　“Never let it **accumulate** in a **closed** space; the **accumulation** is a **hazard**,” she said.

> 「閉じた空間にたまらせてはいけません。たまること自体が危険です」と彼女は言った。

<a id="x162-08"></a>

**162.08**　Above the door a **bright** signal told us the air was being drawn outside.

> 扉の上では明るい表示灯が、空気を屋外に排出していることを知らせていた。

<a id="x162-09"></a>

**162.09**　She asked us to **weigh** the empty container before trying to estimate the weight of the gas.

> ガスの重量を見積もる前に、空の容器の重さを量るように言われた。

**読みの問い**　この場面で accumulation は、一回の放出とどう違うか。

<a id="ex-story-163"></a>

### 163　走らなかった選手

<a id="x163-01"></a>

**163.01**　For the rescue **anniversary** the town had planned a **race** from the **castle** to the river.

> 救助の記念日に、町は城から川までの競走を計画していた。

<a id="x163-02"></a>

**163.02**　A **male** **champion** and a female runner would **start** in the **arena** at noon.

> 男子の優勝経験者と女子選手が正午に競技場を出ることになっていた。

<a id="x163-03"></a>

**163.03**　The winner of the previous **season** had promised to **lead** the final **climb**.

> 前のシーズンに勝った選手が、最後の上り坂で先頭を務めると約束していた。

<a id="x163-04"></a>

**163.04**　A former **football** player who now coached **rugby** came to **supervise** the **finish**.

> 今はラグビーを教えている元サッカー選手が、ゴールを管理しに来た。

<a id="x163-05"></a>

**163.05**　There was a **cheer** when the runners arrived, but the favourite was **absent**.

> 選手が来ると歓声が上がったが、優勝候補はそこにいなかった。

<a id="x163-06"></a>

**163.06**　A child had lost a **shoe** in the road; the runner had stopped to **help**.

> 子どもが道路で靴をなくし、その選手は手伝うために立ち止まっていた。

<a id="x163-07"></a>

**163.07**　“Did she **quit**?” asked a **supporter** with a disappointed **face**.

> 「やめたの？」と、がっかりした顔の応援客が聞いた。

<a id="x163-08"></a>

**163.08**　“I **reckon** she made a **quick** **choice**,” said the child, holding up the shoe.

> 「すぐにどうするか決めてくれたんだと思う」と子どもは靴を掲げた。

<a id="x163-09"></a>

**163.09**　The **score** board listed her **status** as “Did not start.”

> 成績の掲示板には、彼女は「出走せず」と記されていた。

<a id="x163-10"></a>

**163.10**　It said nothing about her **achievement** that day.

> その日に彼女が成し遂げたことは、そこには書かれなかった。

**読みの問い**　成績の掲示板が正確でも、この選手がしたことを伝えきれないのはなぜか。

<a id="ex-story-164"></a>

### 164　肖像の前の二人

<a id="x164-01"></a>

**164.01**　An old **painting** in the **palace** showed a **king** standing behind a young **prince**.

> 宮殿の古い絵に、若い王子の後ろに立つ王が描かれていた。

<a id="x164-02"></a>

**164.02**　A **servant** held a **gold** cup and a **warrior** carried a **rifle**.

> 召使いは金の杯を持ち、戦士はライフル銃を携えていた。

<a id="x164-03"></a>

**164.03**　The picture looked **medieval** until the guide pointed to the weapon.

> 案内人が武器を指すまでは、中世の絵のように見えた。

<a id="x164-04"></a>

**164.04**　“It was painted for a **play**,” she said, “so you can date the style but not the scene.”

> 「劇のために描いた絵です。絵柄の時代を判断できても、描かれた場面の年代までは決まりません」と彼女は言った。

<a id="x164-05"></a>

**164.05**　A **noble** **lady** was reading a **biography** of an **ancestor** from a **tribal** community.

> 貴婦人が部族社会に生きた先祖の伝記を読んでいた。

<a id="x164-06"></a>

**164.06**　Her **boyfriend**, an **enthusiast** for **contemporary** art, thought the picture a **magnificent** joke.

> 現代美術好きの彼女の恋人は、その絵を壮大な冗談だと思った。

<a id="x164-07"></a>

**164.07**　The **novelist** who wrote the play had borrowed its plot from a tale of **revenge**.

> 劇を書いた小説家は、復讐の物語から筋を借りていた。

<a id="x164-08"></a>

**164.08**　Its hero returned to **fight** a **rebel** and found the rebel had become a **king**.

> 主人公が反逆者と戦うために帰ってみると、当の反逆者は王になっていた。

<a id="x164-09"></a>

**164.09**　“The **point** is who gets to name whom,” said the guide with a hint of **humour**.

> 「肝心なのは、誰が誰を何と呼ぶ権利を持つかです」と案内人は少しおどけて言った。

**読みの問い**　ライフル銃がなぜ手掛かりになるのか。

<a id="ex-story-165"></a>

### 165　平和の部屋

<a id="x165-01"></a>

**165.01**　The next room in the castle held a **tribute** to people killed in **warfare**.

> 城の次の部屋には、戦争で亡くなった人々にささげる展示があった。

<a id="x165-02"></a>

**165.02**　A single **bullet** lay on a square of black cloth beside a broken **watch**.

> 壊れた時計の横、黒い四角の布の上に弾丸が一発置かれていた。

<a id="x165-03"></a>

**165.03**　The time of the **killing** was known; the reason for the **cruel** **act** remained a **mystery**.

> 殺害の時刻は判明していたが、その残酷な行為の理由は謎のままだった。

<a id="x165-04"></a>

**165.04**　A **prison** record described the **torture** of **civilian** prisoners by a **militant** group.

> 刑務所の記録には、武装組織が民間人の囚人に加えた拷問が記されていた。

<a id="x165-05"></a>

**165.05**　An **ambassador** had tried to **secure** their **release** through an **alliance** of neighbouring states.

> ある大使が、近隣諸国の同盟を通じて彼らの釈放を実現しようとした。

<a id="x165-06"></a>

**165.06**　His **intervention** could not **prevent** every **atrocity** or **rescue** every prisoner.

> 彼の介入ですべての残虐行為を防げたわけでも、囚人全員を救えたわけでもなかった。

<a id="x165-07"></a>

**165.07**　At the **cemetery** the guide stopped by the **grave** of a young **male** whose name was unknown.

> 墓地で案内人は、名前の分からない若い男性の墓のそばに立ち止まった。

<a id="x165-08"></a>

**165.08**　No priest had attended his **burial**, but a **villager** had said a short **prayer**.

> 埋葬に立ち会った司祭はいなかったが、村の人が短い祈りをささげていた。

<a id="x165-09"></a>

**165.09**　At each **ceremony** for **peace** the town **honours** that **small** **act** of care.

> 平和を願う式典のたびに、町はその小さな親切に敬意を表す。

<a id="x165-10"></a>

**165.10**　The visitor left a **verse** in the book and asked for a moment of **silence**.

> 来訪者は記帳簿に短い詩を残し、ひとときの黙とうを求めた。

**読みの問い**　この部屋から墓地まで追ったのは、名の残った人だけだったか。

<a id="ex-story-166"></a>

### 166　二つの国の同じ切手

<a id="x166-01"></a>

**166.01**　A stamp from a **communist** **republic** lay beside one from a former kingdom.

> 共産主義の共和国の切手の隣に、かつての王国の切手があった。

<a id="x166-02"></a>

**166.02**　Both carried the same **icon**: a bridge that appeared to **connect** two lands.

> どちらにも同じ図柄があった。二つの土地をつなぐように見える橋だ。

<a id="x166-03"></a>

**166.03**　One **settler** had crossed it in **March**; his son made the return **trip** in **October**.

> ある入植者が三月にそこを渡り、その息子は十月に逆向きの旅をした。

<a id="x166-04"></a>

**166.04**　“Their journeys seem **identical** if you **forget** the **direction**,” the guide **remarked**.

> 「向きを忘れれば、二人の旅は同じに見えます」と案内人は言った。

<a id="x166-05"></a>

**166.05**　The father had crossed to **reside** in a country forty miles from the place where he was born.

> 父は、生まれた土地から四十マイル離れた国に定住するために渡った。

<a id="x166-06"></a>

**166.06**　His son returned for the **liberation** of the town after a **decade** of foreign rule.

> 息子は、十年に及ぶ外国の支配からの町の解放に際して戻った。

<a id="x166-07"></a>

**166.07**　“How can we **portray** the **separation** without making them look like enemies?”

> 「二人が離れ離れになったことを、敵同士のように見せずにどう描けるでしょう」

<a id="x166-08"></a>

**166.08**　The guide **suggested** a **neutral** heading and a short **passage** in each man's own words.

> 案内人は、中立的な見出しをつけ、それぞれの言葉を短く引くのがよいと言った。

<a id="x166-09"></a>

**166.09**　The **combination** gave each traveller his own **view** of the **very** same bridge.

> その組み合わせのおかげで、まさに同じ橋が、旅人ごとに違って見えた。

**読みの問い**　同じ橋が別々の経験を表すのはなぜか。

<a id="ex-story-167"></a>

### 167　署名をしたのはだれか

<a id="x167-01"></a>

**167.01**　The man from the bridge agreed to **document** his **experience** on one condition.

> 橋で会った男性は、一つ条件を付けて自分の経験を記録に残すことに同意した。

<a id="x167-02"></a>

**167.02**　He would describe the **intimate** moment of his **marriage**, but not his later **divorce**.

> 結婚したときの親密な瞬間は語るけれど、その後の離婚は語らないという。

<a id="x167-03"></a>

**167.03**　“It would **distress** my daughter and **upset** her mother,” he said.

> 「娘を苦しめるし、母親を動揺させてしまう」と彼は言った。

<a id="x167-04"></a>

**167.04**　“Being a writer does not give you the **privilege** of entering their **inner** world.”

> 「書き手だからといって、あの二人の内面に踏み込む特権があるわけではない」

<a id="x167-05"></a>

**167.05**　The interviewer **conceded** the **point** and **promised** to **respect** the **constraint**.

> 聞き手はその指摘を認め、その制約を尊重すると約束した。

<a id="x167-06"></a>

**167.06**　She asked whether he would **marry** again or prefer to live on his own.

> 彼女は、また結婚したいか、それとも一人で暮らす方がよいかと尋ねた。

<a id="x167-07"></a>

**167.07**　“Can you **sense** the conflict between that question and your **pledge**?” he asked.

> 「その質問と、いま立てた誓いとの食い違いが分かりますか」と彼は聞いた。

<a id="x167-08"></a>

**167.08**　A brief **whisper** from her **supervisor** ended the interview with **courtesy**.

> 上司がひそひそと一言伝え、聞き手は礼儀を守って取材を終えた。

<a id="x167-09"></a>

**167.09**　The resulting **presentation** said only what he had agreed to share.

> 発表では、彼が共有に同意したことだけを伝えた。

**読みの問い**　聞き手の二番目の質問には、なぜ最初の約束との食い違いがあったか。

<a id="ex-story-168"></a>

### 168　劇場が避難所になった夜

<a id="x168-01"></a>

**168.01**　A weather **alert** came through the **channel** just before **night** fell.

> 日が暮れる直前、放送を通じて気象警報が出た。

<a id="x168-02"></a>

**168.02**　The river began to rise, and a **concerned** **tenant** tried to **phone** his elderly neighbour.

> 川が増水し、心配した借家人が年配の隣人に電話をかけようとした。

<a id="x168-03"></a>

**168.03**　We had to **evacuate** two **suburban** streets and **house** thirty people in the theatre.

> 郊外の通り二本から住民を避難させ、三十人を劇場に泊める必要があった。

<a id="x168-04"></a>

**168.04**　An empty **apartment** above the hall could **shelter** another six in relative comfort.

> 会館の上の空き住戸にも、あと六人が比較的心地よく身を寄せられた。

<a id="x168-05"></a>

**168.05**　The **staff** carried blankets, **warm** **clothing** and a box of **stuff** for children.

> 職員は毛布や暖かい服、子ども用の品を詰めた箱を運んだ。

<a id="x168-06"></a>

**168.06**　One **frightened** child would not **exit** the bus until someone found her missing dog.

> 怖がっていた子が一人、行方不明の犬が見つかるまでバスから降りようとしなかった。

<a id="x168-07"></a>

**168.07**　A policeman in an official car took her back to the dark **landing** outside her **flat**.

> 公用車に乗った警官が、その子を自宅のフラットの外の暗い踊り場まで連れて戻った。

<a id="x168-08"></a>

**168.08**　A dog's **cry** came from below; she called, and a familiar **echo** answered.

> 下で犬の声がした。子どもが呼ぶと、聞き慣れた反響が返ってきた。

<a id="x168-09"></a>

**168.09**　The friendly **cop** gave a sigh of **relief** when the dog came up the stairs.

> 犬が階段を上がってくると、気さくな警官はほっとため息をついた。

<a id="x168-10"></a>

**168.10**　“What a **blessing** that dogs can hear better than people,” the girl said.

> 「犬の耳が人間よりよくて助かったね」とその子は言った。

**読みの問い**　犬を捜す場面で relief が指すのは、人が受け取った物か、気持ちの変化か。

<a id="ex-story-169"></a>

### 169　本部で鳴ったベル

<a id="x169-01"></a>

**169.01**　At rescue **headquarters** our chief engineer tried to **organize** a rapid response.

> 救助本部では主任技師が速やかな対応をまとめようとしていた。

<a id="x169-02"></a>

**169.02**　Her **urgent** **command** was to **deploy** a second **squad** before the river could **invade** the houses.

> 緊急の指令は、水が家々に入り込む前に二つ目の班を投入せよ、というものだった。

<a id="x169-03"></a>

**169.03**　A **competent** **supervisor** knew how to **operate** the boats and **supervise** the lifts.

> 有能な監督者は、舟を操縦し、引き上げ作業を指揮する方法を知っていた。

<a id="x169-04"></a>

**169.04**　He refused to **command** a **passive** crowd by shouting over the noise of the wind.

> 彼は、風の音に負けないように叫んで、指示待ちの群衆を動かすことはしなかった。

<a id="x169-05"></a>

**169.05**　Instead he used a bell to **inform** one person at a time and **limit** the **panic**.

> 代わりにベルを使って一人ずつに知らせ、パニックを抑えた。

<a id="x169-06"></a>

**169.06**　We pulled the last boat up a **steep** bank before another wave could **strike**.

> 次の波が打ち寄せる前に、私たちは最後の舟を急な岸に引き上げた。

<a id="x169-07"></a>

**169.07**　A sudden change in the wind made me **slip**; I could only **cling** to the **outer** rail.

> 風が急に変わって足を滑らせ、私は外側の手すりにしがみつくしかなかった。

<a id="x169-08"></a>

**169.08**　One of the men had to **plunge** in, **seize** the floating rope and drag it within **reach**.

> 一人の男性が飛び込み、浮いたロープをつかんで、手の届くところまで引き寄せなくてはならなかった。

<a id="x169-09"></a>

**169.09**　I could **bear** the cold but could not **tolerate** the **worry** on the girl's face.

> 寒さは耐えられても、あの子の心配そうな顔を見ているのは耐えられなかった。

<a id="x169-10"></a>

**169.10**　She held out her glove and helped me to my feet without a moment of doubt.

> その子は少しもためらわずに手袋をした手を差し出し、私を立ち上がらせてくれた。

**読みの問い**　指揮をとった人がベルを選んだ理由は、周囲のどんな状況から分かるか。

<a id="ex-story-170"></a>

### 170　こわれた箱を開く

<a id="x170-01"></a>

**170.01**　By **today** the rain had stopped, and we had time to **clean** the **mess**.

> 今日までに雨はやみ、散らかった物を片づける時間ができた。

<a id="x170-02"></a>

**170.02**　Old **litter** had begun to **pile** up by the door, and a heavy box was starting to **float**.

> 戸口にごみが積もり、重い箱まで浮き始めていた。

<a id="x170-03"></a>

**170.03**　Its owner did not **wish** to risk the contents, so we agreed to **transport** it upstairs.

> 持ち主は中身を危険にさらしたくなかったので、上の階へ運ぶことにした。

<a id="x170-04"></a>

**170.04**　We had to **screw** a handle to one side, **chain** it to the rail and **pull** together.

> 片側に取っ手をねじで留め、箱を鎖で手すりにつなぎ、皆で引いた。

<a id="x170-05"></a>

**170.05**　To open it, we needed a **tool** from a locked **cabin** beside the bridge.

> 開けるには、橋のそばの鍵のかかった小屋から道具を取ってくる必要があった。

<a id="x170-06"></a>

**170.06**　A small **barrier** blocked the path, and a **tall** bush hid the **opening**.

> 道は小さな柵でふさがれ、背の高い低木が出入口を隠していた。

<a id="x170-07"></a>

**170.07**　We had to **venture** further into the **dark** than either of us had planned.

> 二人とも考えていたより奥の暗がりまで、思い切って踏み込まなくてはならなかった。

<a id="x170-08"></a>

**170.08**　Inside the cabin we found a **black** box of screws and an old **vacuum** cleaner.

> 小屋には黒いねじ箱と古い掃除機があった。

<a id="x170-09"></a>

**170.09**　The boy picked up the screws; I could hardly lift the cleaner off the **carpet**.

> 少年はねじを拾い上げた。私は掃除機をじゅうたんから持ち上げるのもやっとだった。

<a id="x170-10"></a>

**170.10**　Back at the shelter, a **mess** of wet paper proved to be the **treasure** we had saved.

> 避難所に戻ると、私たちが守った宝物はびしょぬれの紙の山だと分かった。

**読みの問い**　中身が濡れた紙でも、持ち主にとって treasure になりうるのはなぜか。

<a id="ex-story-171"></a>

### 171　一番遅いニュース

<a id="x171-01"></a>

**171.01**　The papers were an old town **magazine** and a **poster** for a **forthcoming** exhibition.

> 紙の正体は昔の町の雑誌と、開催予定だった展覧会のポスターだった。

<a id="x171-02"></a>

**171.02**　The **poster** was **modern** for its time; the headline **announced** a **radical** **development** in **industry**.

> 当時としては現代的なポスターで、見出しは産業上の画期的な進展を告げていた。

<a id="x171-03"></a>

**171.03**　A new factory would **employ** two hundred people and **import** a **sophisticated** machine.

> 新工場は二百人を雇い、高度な機械を輸入するという。

<a id="x171-04"></a>

**171.04**　The monthly **import** bill would **total** almost a thousand **pounds**.

> 月々の輸入代金は、合計で千ポンド近くになる予定だった。

<a id="x171-05"></a>

**171.05**　The public had heard of an industrial **boom**, but workers also spoke of **labour** disputes.

> 世間では産業の好況が話題だったが、働く人は労働争議についても語っていた。

<a id="x171-06"></a>

**171.06**　An **organized** group wanted to **lobby** the **ministry** for a **governmental** review.

> 組織をつくった人々は、政府の調査を行うよう省に働きかけたがっていた。

<a id="x171-07"></a>

**171.07**　An **executive** decision could **slash** wages and **terminate** a **part-time** contract without warning.

> 経営側の決定一つで賃金が大幅に削られ、非常勤契約が予告なく打ち切られることもあった。

<a id="x171-08"></a>

**171.08**　The mayor wanted to **attract** **funding**; the union wanted an **assurance** about jobs.

> 市長が望んでいたのは資金の誘致で、組合が求めていたのは雇用についての確約だった。

<a id="x171-09"></a>

**171.09**　Those two **aims** need not **conflict**, but on that **given** day they did.

> その二つの目的は必ずしも衝突しないが、その特定の日には衝突した。

**読みの問い**　町と働く人たちが、それぞれ将来に向けて確保したかったものは何か。

<a id="ex-story-172"></a>

### 172　人が作る機械

<a id="x172-01"></a>

**172.01**　The factory had once asked a boy to **program** a **robot** to **paint** its own name.

> 工場はかつて少年に、ロボット自身の名前を描くようにプログラムしてほしいと頼んだ。

<a id="x172-02"></a>

**172.02**　He sat at a **keyboard** and **typed** an **advanced** set of instructions.

> 少年はキーボードの前に座り、高度な命令を入力した。

<a id="x172-03"></a>

**172.03**　The **user** could **switch** between two settings, but the **configuration** was **complicated**.

> 使う人は二つの設定を切り替えられたが、設定の組み合わせは複雑だった。

<a id="x172-04"></a>

**172.04**　An online **update** might **improve** **efficiency**, or it might introduce a new **weakness**.

> オンラインの更新で効率が上がるかもしれないし、新たな弱点が生まれるかもしれなかった。

<a id="x172-05"></a>

**172.05**　The boy offered an **interactive** **demonstration** to test the machine's **capability**.

> 少年は機械の能力を試せる、参加型の実演を申し出た。

<a id="x172-06"></a>

**172.06**　A visitor could **type** a word and watch a brush **shape** the letters.

> 来場者は単語を入力し、筆が文字を形にするのを見られた。

<a id="x172-07"></a>

**172.07**　The **intelligent** **part** was not the brush; it was the way the boy had **designed** the **input**.

> 賢いのは筆ではなく、少年が設計した入力の仕組みだった。

<a id="x172-08"></a>

**172.08**　“When you **number** the letters, can it spell backwards?” a **shy** child whispered.

> 「文字に番号を振ったら、逆からもつづれる？」と内気な子がささやいた。

<a id="x172-09"></a>

**172.09**　The program had no such **capability**, but their **collaboration** gave the boy a **novel** idea.

> そのプログラムにそんな機能はなかったが、二人が一緒に考えたことで少年は新しい発想を得た。

**読みの問い**　筆が動く所だけを眺めると、どの工夫を見落とすか。

<a id="ex-story-173"></a>

### 173　どこにでもある一点

<a id="x173-01"></a>

**173.01**　A **dedicated** assistant had tried to **track** the red mark through every **domain** on an old **web** site.

> 熱心な助手は、古いウェブサイトにあるすべてのドメインで赤い印を追跡しようとしていた。

<a id="x173-02"></a>

**173.02**　One **download** contained a digital **simulation** of the bridge and a **realistic** model of the river.

> ダウンロードしたファイルの一つには、橋のデジタルシミュレーションと、川をリアルに再現したモデルが入っていた。

<a id="x173-03"></a>

**173.03**　The **modelling** team could **simulate** a storm and predict the **likelihood** of a flood.

> モデルを作ったチームは嵐を再現し、洪水が起きる可能性を予測できた。

<a id="x173-04"></a>

**173.04**　To **operate** it you had to **register** a name and select the **appropriate** **unit** of distance.

> 操作するには名前を登録し、適切な距離の単位を選ぶ必要があった。

<a id="x173-05"></a>

**173.05**　One **specification** gave the **maximum** water level and the minimum height of a boat.

> ある仕様書には、水位の上限と舟の高さの下限が記されていた。

<a id="x173-06"></a>

**173.06**　A **straight** blue line was the water; a series of red dots showed a boat in **motion**.

> 青い直線は水面で、並んだ赤い点は動いている舟を示していた。

<a id="x173-07"></a>

**173.07**　A gap in the **transmission** had removed one point from the **central** **span** of the bridge.

> データ通信の途切れで、橋の中央径間から点が一つ抜けていた。

<a id="x173-08"></a>

**173.08**　The missing point had no **value** until we knew what the other points meant.

> ほかの点が何を意味するか分かるまでは、その欠けた点に価値はなかった。

**読みの問い**　モデルの中の欠けた一点を考えるには、まず何を知る必要があるか。

<a id="ex-story-174"></a>

### 174　診察室の天井

<a id="x174-01"></a>

**174.01**　We went back to the **surgery** to deliver the drawing of the river.

> 川の絵を届けに診療所へ戻った。

<a id="x174-02"></a>

**174.02**　On the **ceiling** was a picture of a **flying** horse with a yellow star on its **lip**.

> 天井には空飛ぶ馬が描かれ、その唇には黄色い星がついていた。

<a id="x174-03"></a>

**174.03**　Children waiting for their turn could **imagine** a **fantastic** **realm** above their heads.

> 順番を待つ子どもたちは、頭上にある不思議な世界を想像できた。

<a id="x174-04"></a>

**174.04**　“It helps them **forget** the **acute** pain for a moment,” explained the doctor.

> 「鋭い痛みを少しのあいだ忘れる助けになります」と医師は言った。

<a id="x174-05"></a>

**174.05**　She never tried to **trick** an **anxious** child into thinking treatment would not hurt.

> 彼女は不安がる子をだまして、治療が無痛だと思わせようとはしなかった。

<a id="x174-06"></a>

**174.06**　She would explain why she had to **inject** the medicine and how to **avoid** an infection.

> なぜ薬を注射する必要があるか、どうすれば感染を避けられるかを説明した。

<a id="x174-07"></a>

**174.07**　A **deadly** virus could **infect** someone through the smallest **bite**.

> ほんの小さなかみ傷からでも、命にかかわるウイルスに感染する可能性があった。

<a id="x174-08"></a>

**174.08**　The doctor did not **exaggerate** the risk or **deny** the child's **human** fear.

> 医師は危険を大げさに言うことも、子どもの人間らしい恐怖を否定することもしなかった。

<a id="x174-09"></a>

**174.09**　“My **gut** tells me to run,” said one girl, “but I **trust** you.”

> 「直感が逃げろって言ってる。でも先生を信じる」と女の子が言った。

<a id="x174-10"></a>

**174.10**　The **horse** on the ceiling had **acquired** a second star by the end of her visit.

> 診察が終わったころには、天井の馬に二つ目の星がついていた。

**読みの問い**　医師は何を認めることで、子どもの信頼に応えたか。

<a id="ex-story-175"></a>

### 175　水の標本、恐怖の標本

<a id="x175-01"></a>

**175.01**　The doctor asked us to **sample** the water before the next **outbreak** of illness.

> 次に病気が流行する前に水を採取してほしいと、医師に頼まれた。

<a id="x175-02"></a>

**175.02**　A dark **compound** on the river wall showed two colours: **grey** in natural light and **yellow** under a lamp.

> 川岸の壁についた黒っぽい化合物は、日の光では灰色、ランプの下では黄色に見えた。

<a id="x175-03"></a>

**175.03**　The **specialist** team took a **routine** reading at a **given** time each day.

> 専門班は毎日一定の時刻に、定例の測定を行った。

<a id="x175-04"></a>

**175.04**　One team would **isolate** the material; another would **hypothesize** about its origin.

> 一方の班が物質を分離し、別の班がその由来の仮説を立てる。

<a id="x175-05"></a>

**175.05**　We could **dissolve** a grain in water or **freeze** a drop for later examination.

> 粒を水に溶かしたり、しずくを凍らせて後で調べたりすることができた。

<a id="x175-06"></a>

**175.06**　The test might **eliminate** a possibility, but its **completion** alone did not give an answer.

> 検査によって可能性は一つ消えるかもしれないが、検査の完了自体が答えをくれるわけではない。

<a id="x175-07"></a>

**175.07**　The most **damaging** **mistake** would be to **base** a warning on our **ignorance**.

> いちばん有害な誤りとなるのは、分からないことを根拠に警告を出すことだろう。

<a id="x175-08"></a>

**175.08**　The most **useful** **tip** came from a child: “Look at it outside while it is still **light**.”

> 最も役に立ったヒントは子どもの言葉だった。「まだ明るいうちに外でも見てみて」

<a id="x175-09"></a>

**175.09**　We found a simple **explanation** for the apparent **variation**: the lamp had a coloured cover.

> 見かけの違いには単純な理由が見つかった。ランプに色つきの覆いがあったのだ。

**読みの問い**　標本を変えずに観察結果だけが変わったのはなぜか。

<a id="ex-story-176"></a>

### 176　観光船が来る前に

<a id="x176-01"></a>

**176.01**　The town council was considering a **large-scale** **tourism** **development**.

> 町の議会は大規模な観光開発を検討していた。

<a id="x176-02"></a>

**176.02**　A travel **company** had made a **bid** for the right to **cruise** through the harbour.

> 旅行会社が港内の遊覧船を運航する権利を得ようと入札した。

<a id="x176-03"></a>

**176.03**　The **availability** of a boat might **facilitate** travel, but its wake could **alter** the banks.

> 舟が使えれば移動は楽になるかもしれないが、引き波で岸の形が変わるおそれがあった。

<a id="x176-04"></a>

**176.04**　A **corporate** visitor praised the **convenience** and the **appeal** of a **fast** crossing.

> 企業から来た人は、速く渡れる便利さと魅力を称賛した。

<a id="x176-05"></a>

**176.05**　A local resident asked who would pay the **toll** and who stood to get a **share**.

> 住民からは、通行料を払うのは誰で、その一部を得るのは誰かという質問が出た。

<a id="x176-06"></a>

**176.06**　A **joint** committee promised to **oversee** every **concession** to the company.

> 合同委員会は会社への譲歩を一つずつ監督すると約束した。

<a id="x176-07"></a>

**176.07**　The company offered a **franchise**, but the people who worked on the boats feared a **monopoly**.

> 会社は営業権の付与を申し出たが、渡し船の労働者は独占を恐れた。

<a id="x176-08"></a>

**176.08**　Some wanted a **decrease** in fares; others wanted a **halt** to the entire project.

> 運賃を下げてほしい人もいれば、計画全体を止めてほしい人もいた。

<a id="x176-09"></a>

**176.09**　The final **endorsement** came with a condition: the boat could not **exploit** the **environmental** **resource** without paying for its protection.

> 最終的な承認には条件がついた。環境を守る費用を負担せずに、その資源を利用することは認めないというものだった。

**読みの問い**　船を走らせる権利があっても、何を無条件でしてよいことにはならないか。

<a id="ex-story-177"></a>

### 177　塗り替えられる看板

<a id="x177-01"></a>

**177.01**　We received an **applicant** for the post of guide who spoke in a **clear**, **comfortable** voice.

> 案内役を志望する人が来た。澄んだ、聞き心地のよい声の人だった。

<a id="x177-02"></a>

**177.02**　Her **aspiration** was to become a **master** of two trades, painting and **teaching**.

> 彼女の志は、絵を描くことと教えることの二つの仕事を究めることだった。

<a id="x177-03"></a>

**177.03**　Her first **practical** was to **craft** a new sign for the shopping street.

> 最初の実習は、商店街の看板を新しく作ることだった。

<a id="x177-04"></a>

**177.04**　Once an **activity** for Sunday **leisure**, painting had become her **means** of support.

> もとは日曜の余暇の楽しみだった絵が、今では生計を支える手段になっていた。

<a id="x177-05"></a>

**177.05**　She was prepared to **devote** every **free** hour to the **improvement** of her **technique**.

> 自由になる時間はすべて、技法を磨くために使う覚悟だった。

<a id="x177-06"></a>

**177.06**　She had an **old-fashioned** brush, a **pretty** tin of **gold** and a knife to work the wet paint.

> 手元にあるのは昔ながらの筆、きれいな缶に入った金色の絵の具と、乾く前の絵の具を扱うナイフだった。

<a id="x177-07"></a>

**177.07**　The **quality** of the sign did not **please** her until the letters could be read from the **west** bank.

> 西岸から文字を読めるようになるまで、彼女は看板の出来に満足しなかった。

<a id="x177-08"></a>

**177.08**　Several **shopping** bags hid the sign from a **low** seat in the waiting room.

> 待合室の低い席からは、いくつもの買い物袋に遮られて看板が見えなかった。

<a id="x177-09"></a>

**177.09**　She did not blame the bags; she climbed up and **painted** a second sign.

> 彼女は袋のせいにせず、上に登ってもう一枚看板を描いた。

**読みの問い**　看板の質を最後に判断した基準は何だったか。

<a id="ex-story-178"></a>

### 178　実演はどこから始まるのか

<a id="x178-01"></a>

**178.01**　An **opening** **talk** on **psychology** began with a **ridiculous** **bet**.

> 心理学を取り上げる最初の講話は、おかしな賭けから始まった。

<a id="x178-02"></a>

**178.02**　The speaker would **stage** a **deliberate** **mistake** and invite us to guess when it had happened.

> 話し手は意図的に間違えてみせ、いつ間違えたかを私たちに当てさせると言った。

<a id="x178-03"></a>

**178.03**　She placed a **cute** wooden bird in her **pocket** and pretended to **bite** an apple.

> 愛らしい木の鳥をポケットに入れ、リンゴをかじるふりをした。

<a id="x178-04"></a>

**178.04**　“Was it an apple?” she asked, and opened her hand to show a **square** piece of bread.

> 「リンゴでしたか」と聞き、手を開いて四角いパンを見せた。

<a id="x178-05"></a>

**178.05**　Our **instant** **recognition** had been **based** on the gesture and our own **expectation**.

> 一瞬で「リンゴだ」と思ったのは、しぐさとこちらの予想に基づいていた。

<a id="x178-06"></a>

**178.06**　She had used the power of **suggestion** to **bias** our judgement.

> 暗示の力で私たちの判断を偏らせたのだ。

<a id="x178-07"></a>

**178.07**　A boy **laughed** and **joked** that bread should sue her for **discrimination**.

> 少年は笑い、パンは差別だと彼女を訴えたほうがいい、と冗談を言った。

<a id="x178-08"></a>

**178.08**　“Would the same **approach** **work** if I warned you again?” she asked.

> 「もう一度予告しても、同じやり方は通用するでしょうか」

<a id="x178-09"></a>

**178.09**　The second time, no one had seen what happened to the wooden bird.

> 二度目は、木の鳥がどうなったかを誰も見ていなかった。

**読みの問い**　二度目の実演で、何に注意しているあいだに何を見落としたか。

<a id="ex-story-179"></a>

### 179　音楽家が置いていった火

<a id="x179-01"></a>

**179.01**　The evening show would **comprise** three acts and a **musical** **adaptation** of the river story.

> 夜の公演は三つの演目と、川の物語を音楽にした作品で構成する予定だった。

<a id="x179-02"></a>

**179.02**　The **narrative** songs would **blend** into dance, and the lights would **complement** the music.

> 物語を語る歌は踊りへ溶け込み、照明が音楽を引き立てる。

<a id="x179-03"></a>

**179.03**　The **related** acts had been chosen for their **charm** rather than their popularity.

> 関連する演目は、人気よりもそれぞれの味わいを重視して選んでいた。

<a id="x179-04"></a>

**179.04**　The **highlight** was a single **firework** over the water, a **substitute** for a whole night of noise.

> 見せ場は水上に上がる花火一発で、一晩じゅう音を鳴らす代わりだった。

<a id="x179-05"></a>

**179.05**　The **authority** to set it off belonged to the **personnel** on the river, not the singer on the stage.

> 花火を打ち上げる権限は、舞台の歌手ではなく川にいる担当者にあった。

<a id="x179-06"></a>

**179.06**　An **explosive** in the wrong hands could **kill** or blind, so the crew followed a **protocol**.

> 爆発物は、扱うべきでない人の手に渡ると、人を死なせたり失明させたりするおそれがあるため、担当者は手順に従った。

<a id="x179-07"></a>

**179.07**　At the **very** last moment a **frustrated** singer asked us to **delay** the final note.

> まさに最後の瞬間に、歌手がもどかしそうに、最後の音を少し待ってほしいと言った。

<a id="x179-08"></a>

**179.08**　We expected a **stunning** **finish**, but a bird had crossed the path of the firework.

> 私たちは鮮やかな幕切れを期待していたが、花火の通り道に鳥が横切っていたのだ。

<a id="x179-09"></a>

**179.09**　She gave no **command** until it was gone, and that **restraint** was the true **highlight**.

> 鳥が通り過ぎるまで彼女は合図を出さなかった。その自制こそが本当の見せ場だった。

**読みの問い**　ここで restraint を示す行動は何か。

<a id="ex-story-180"></a>

### 180　町の冬はまだ来ない

<a id="x180-01"></a>

**180.01**　The picture taken in **May** showed bright **snow** on a **ski** slope above the town.

> 五月に撮影された写真に、町を見下ろすスキー場のまぶしい雪が写っていた。

<a id="x180-02"></a>

**180.02**　My **favourite** outdoor **activity** was **skiing**, but I had never been able to **ski** in May.

> 私のいちばん好きな野外活動はスキーだったが、五月に滑れたことはなかった。

<a id="x180-03"></a>

**180.03**　A local guide offered to **film** our **descent** and **text** the result to the museum.

> 地元の案内人が、私たちが滑り降りる様子を撮影し、その映像をメッセージで博物館に送ろうと申し出た。

<a id="x180-04"></a>

**180.04**　“Does it **snow** here so late?” I asked, watching water **drift** past the lower station.

> 「こんなに遅い時期にもここでは雪が降るの？」と、麓の駅のそばを水が流れていくのを見ながら私は尋ねた。

<a id="x180-05"></a>

**180.05**　“It can **rain** at the bottom and snow at the top,” she said, “and clouds can conceal both.”

> 「麓では雨、頂上では雪ということがあります。どちらも雲に隠れることだってありますよ」

<a id="x180-06"></a>

**180.06**　At the top a **motorcycle** stood beside a **trailer** equipped for mountain rescue.

> 頂上には山岳救助用のトレーラーの横にオートバイが止まっていた。

<a id="x180-07"></a>

**180.07**　On the **interior** wall a chart marked the **target** time for reaching a fallen skier.

> 内壁の図には、転倒した人にたどり着くまでの目標時間が記されていた。

<a id="x180-08"></a>

**180.08**　“A **jump** is fun, but a broken **skull** can turn a holiday into a **disaster**,” said the guide.

> 「ジャンプは楽しいけれど、頭蓋骨を折ったら休日は惨事になります」と案内人が言った。

<a id="x180-09"></a>

**180.09**　The **worst** **situation** was to **rush** down a slope without checking where it ended.

> いちばんまずいのは、斜面の先を確かめずに急いで滑り降りることだった。

<a id="x180-10"></a>

**180.10**　We brought back a picture of the sun on snow while the town below lay in rain.

> 私たちが持ち帰ったのは、下の町で雨が降る間、雪に日が差す様子を撮った写真だった。

**読みの問い**　写真を見た人が、町の天気を取り違えうる理由は？

<a id="ex-story-181"></a>

### 181　三分でできる仕事

<a id="x181-01"></a>

**181.01**　The town **department** had received a **delivery** marked “Models for the new exhibition.”

> 町の担当部署に「新しい展覧会のための模型」と書かれた荷物が届いた。

<a id="x181-02"></a>

**181.02**　Its small **tower** was meant to **fit** a model **city** that was already built to scale.

> 荷物の中の小さな塔は、すでに一定の縮尺で作られた町の模型に、サイズが合うはずのものだった。

<a id="x181-03"></a>

**181.03**　The owner agreed to **scale** the drawing down so that every building would **fit**.

> すべての建物が収まるよう、所有者は図面を縮小することに同意した。

<a id="x181-04"></a>

**181.04**　The **enormous** model had taken a year to **build**; the **extension** took three minutes.

> 巨大な模型の製作には一年かかったが、増築は三分で済んだ。

<a id="x181-05"></a>

**181.05**　We wanted to **recycle** the box into a base for the **sculpture** and **wash** the glass cover.

> 箱は彫刻の台に再利用し、ガラスのカバーは洗おうと思った。

<a id="x181-06"></a>

**181.06**　The **efficient** method was to **dip** the glass in water and let it dry in the air.

> ガラスを水に浸し、自然に乾かすのが効率的だった。

<a id="x181-07"></a>

**181.07**　If we **spilt** the water, a **mere** **drop** could mark the paper buildings.

> 水をこぼせば、ほんの一滴でも紙の建物に染みをつけかねない。

<a id="x181-08"></a>

**181.08**　We had no **valid** reason to take that risk; we could just **buy** a second sheet of glass.

> その危険を冒すもっともな理由はなかった。もう一枚ガラスを買えば済むからだ。

<a id="x181-09"></a>

**181.09**　In the end the owner found a **matching** cover in his **reserve** of spare parts.

> 結局、所有者が予備の部品の蓄えから、ちょうど合うカバーを見つけてくれた。

**読みの問い**　所要時間を比べるとき、どの二つの工程を区別しているか。

<a id="ex-story-182"></a>

### 182　外に出る権利

<a id="x182-01"></a>

**182.01**　A **homeless** man had lent his coat to the exhibition for an entire month.

> 家のない男性が、自分の上着を一か月、展覧会に貸してくれた。

<a id="x182-02"></a>

**182.02**　At the **opening** we gave him a warm **welcome**, but a guard refused him **membership** of the club next door.

> 開会時には私たちは彼を温かく迎えたのに、隣のクラブの門番は入会を認めなかった。

<a id="x182-03"></a>

**182.03**　“Do I have to **qualify** as a member to get my coat back?” he asked in a quiet **tone**.

> 「上着を返してもらうにも会員資格がいるんですか」と彼は静かに尋ねた。

<a id="x182-04"></a>

**182.04**　The rule did not **apply** to the museum, yet the two doors shared a common entrance.

> その規則は博物館には適用されなかったが、二つの扉は入口を共用していた。

<a id="x182-05"></a>

**182.05**　The guard was **confused**, and the man was **reluctant** to **start** an argument.

> 門番は事情がのみ込めず、男性も口論を始めたくはなかった。

<a id="x182-06"></a>

**182.06**　The director came to **apologize** for the **embarrassment** and **invite** him inside.

> 館長は、気まずい思いをさせたことをわび、男性を中に招き入れるために来た。

<a id="x182-07"></a>

**182.07**　We had to **enforce** a **consistent** **standard** of **conduct** without making poverty sound like a **vice**.

> 貧しさを悪徳扱いせずに、一貫した行動規範を守らせる必要があった。

<a id="x182-08"></a>

**182.08**　His **withdrawal** of the coat would be a **choice** we could all understand, said the director.

> 上着を引き上げるのは理解できる選択だ、と館長は言った。

<a id="x182-09"></a>

**182.09**　“I will let it stay if a **hungry** person who is cold can **get** it before I do.”

> 「寒い思いをしている空腹の人が、私より先に使えるなら、置いていきます」

<a id="x182-10"></a>

**182.10**　His **contribution** was now something a piece of glass could not contain.

> 彼が差し出したものは、いまや一枚のガラスに閉じ込められるものではなかった。

**読みの問い**　上着の持ち主は、展示を続けるためにどんな条件を加えたか。

<a id="ex-story-183"></a>

### 183　資料の中の偏見

<a id="x183-01"></a>

**183.01**　We had to **deal** with some **offensive** remarks in a diary written by a former guard.

> 昔の門番の日記に、他人を侮辱する記述があり、扱いを考える必要があった。

<a id="x183-02"></a>

**183.02**　Some entries **expressed** **racism**; others showed **prejudice** about **sexual** relationships.

> 人種差別を表す記述もあれば、性的な関係についての偏見が表れた記述もあった。

<a id="x183-03"></a>

**183.03**　“Can we **combat** the harm without hiding the evidence?” asked a **feminist** historian.

> 「その証拠を隠さずに、害に立ち向かうことはできるでしょうか」とフェミニストの歴史家が尋ねた。

<a id="x183-04"></a>

**183.04**　She did not **hate** the writer; she wanted to **contest** the claims he had made.

> 彼女は書き手を憎んでいたのではなく、その人の主張に異議を唱えたかった。

<a id="x183-05"></a>

**183.05**　He had tried to **characterize** an entire community by one **trait** in one person.

> 書き手は一個人のある特徴で、共同体全体の性格を決めようとしていた。

<a id="x183-06"></a>

**183.06**　His **hostility** was an **element** in the **culture** of that **workplace**, she said.

> 彼の敵意は、そこの職場文化の一要素だったと彼女は言った。

<a id="x183-07"></a>

**183.07**　Such **destructive** words could **breed** fear and **spark** an attack on a **living** person.

> そうした破壊的な言葉は恐怖を育て、生きている人への攻撃を引き起こしかねない。

<a id="x183-08"></a>

**183.08**　Our **dilemma** was whether a warning could explain the **injustice** without repeating the insult.

> 私たちのジレンマは、侮辱を繰り返さずに、不公正を注意書きで説明できるかどうかだった。

<a id="x183-09"></a>

**183.09**　We **invited** a member of the community to **contribute** her own account beside his.

> 私たちはその共同体の一人に、彼の記述の隣にご自身の証言を寄せてほしいと頼んだ。

<a id="x183-10"></a>

**183.10**　She accepted, on condition that the **latter** account would have the same space as the former.

> 彼女は、後に加える証言に最初の記述と同じだけの場所を与えることを条件に引き受けた。

**読みの問い**　二つの証言を同じ広さで並べる条件は何を変えるか。

<a id="ex-story-184"></a>

### 184　走る人の年金

<a id="x184-01"></a>

**184.01**　The oldest member of the running club had lived on a **pension** since his **retirement**.

> 走友会の最年長の会員は、退職以来、年金で暮らしていた。

<a id="x184-02"></a>

**184.02**　He had never had the **luxury** of paying for an **overseas** race.

> 海外のレースに費用を払って参加するようなぜいたくはできなかった。

<a id="x184-03"></a>

**184.03**　The club wanted to **aid** him with the entry fee, but he would **decline** a personal **favour**.

> クラブは参加費を援助したかったが、個人的な便宜なら彼は断ってしまうだろう。

<a id="x184-04"></a>

**184.04**　His **rival** had an **approach** he liked: make travel money available to any **willing** competitor.

> ライバルが彼も気に入る案を持っていた。意欲のある選手なら誰でも旅費補助を受けられるようにするのだ。

<a id="x184-05"></a>

**184.05**　The club could **tax** ticket sales to finance the fund and ask the **general** public for **backing**.

> クラブは券の売り上げに一定の負担金をかけて基金をまかない、一般の人にも支援を求めることができた。

<a id="x184-06"></a>

**184.06**　To **ensure** **fairness**, each payment would depend on **financial** **need**.

> 公平性を確保するため、支給額は経済的な必要に応じて決めることになった。

<a id="x184-07"></a>

**184.07**　The **strength** of the idea was its **clarity**; its **weakness** was the lack of a **robust** **process** for appeals.

> 提案の強みは分かりやすさ、弱みは異議申し立てに対応できるしっかりした手続きがないことだった。

<a id="x184-08"></a>

**184.08**　The older runner offered his **knowledge** of club **routine**, and the younger runner drew up a form.

> 年長の選手はクラブの日頃の運営に関する知識を提供し、若い選手は用紙を作った。

<a id="x184-09"></a>

**184.09**　Their **cooperation** was worth more than the **deposit** in the new account.

> 二人の協力には、新しい口座の預け金以上の価値があった。

**読みの問い**　助成を「年長の会員だけ」に限らなかったことにはどんな意味があったか。

<a id="ex-story-185"></a>

### 185　一枚の白いポスター

<a id="x185-01"></a>

**185.01**　A **controversial** picture had been removed just before the **opening** and a blank sheet put in its place.

> 議論を呼んだ絵が開会の直前に外され、代わりに白い紙が置かれていた。

<a id="x185-02"></a>

**185.02**　The **resignation** of the director seemed **inevitable** after the **suspension** of the show.

> 展覧会が中断されたため、館長の辞任は避けられないように見えた。

<a id="x185-03"></a>

**185.03**　Her **predecessor** had called for greater **involvement** by the public in the selection **process**.

> 前任者は、作品を選ぶ過程にもっと市民が関われるよう求めていた。

<a id="x185-04"></a>

**185.04**　The new director had to **govern** an institution with an **ethic** of free speech at its **core**.

> 新館長は、発言の自由を中心的な倫理とする機関を運営する必要があった。

<a id="x185-05"></a>

**185.05**　A sponsor might **demand** the **disposal** of a picture, but that was not an order she had to obey.

> 資金提供者が絵の処分を要求しても、館長が必ず従うべき命令にはならなかった。

<a id="x185-06"></a>

**185.06**　She **asserted** that the museum could refuse to **commit** itself to **inappropriate** conditions.

> 博物館は不適切な条件に縛られる約束を拒める、と彼女は明言した。

<a id="x185-07"></a>

**185.07**　“A **rational** decision requires **patience**; loud **rhetoric** does not establish **rationality**.”

> 「理性的な決定には忍耐が要ります。声高な弁舌は、理性的であることの証明にはなりません」

<a id="x185-08"></a>

**185.08**　Then the **frustrated** artist arrived holding a fresh sheet still wet with paint.

> そこへいらだった画家が、まだ絵の具の乾いていない新しい一枚を持って現れた。

<a id="x185-09"></a>

**185.09**　“Who gave you the right to **suppose** the blank one was a protest?” she asked.

> 「白いほうが抗議だなんて、誰が決めてよいと言いました？」と彼女は尋ねた。

**読みの問い**　空白をめぐる推測は、何をまだ確かめていなかったか。

<a id="ex-story-186"></a>

### 186　五分だけの国

<a id="x186-01"></a>

**186.01**　A group of pupils **proposed** to **enact** a law in an **imaginary** country for five minutes.

> 生徒たちが、架空の国で法律を制定する、五分間の試みを提案した。

<a id="x186-02"></a>

**186.02**　The rule would **forbid** anyone to **interrupt** a speaker or **insult** an opponent.

> 発言する人を遮ったり、意見の違う相手を侮辱したりすることを禁じるという規則だった。

<a id="x186-03"></a>

**186.03**　The **chief** **problem** was how to **convict** an offender after a **simultaneous** exchange of words.

> 問題の中心は、二人が同時にしゃべった場合にどうやって違反を認定するかだった。

<a id="x186-04"></a>

**186.04**　They had no court to **approve** a fine, and nobody was prepared to **fine** a friend.

> 罰金を科すことを認める裁判所はなく、友人に罰金を科す覚悟のある人もいなかった。

<a id="x186-05"></a>

**186.05**　A quiet girl offered to **patrol** the room and **record** each **relevant** occurrence.

> おとなしい女の子が、室内を見回って、関係する出来事を記録すると言った。

<a id="x186-06"></a>

**186.06**　“Would you call that public service or would you call it work for a spy?”

> 「それは公共のための仕事？　それともスパイの仕事？」

<a id="x186-07"></a>

**186.07**　She did not want to **spy** on people; she wanted them to **cooperate** in their own government.

> 彼女は人をひそかに監視したかったのではなく、皆が自分たちの政治に協力することを望んだ。

<a id="x186-08"></a>

**186.08**　“Can we **reform** the rule before we **apply** it?” she said when the five minutes ended.

> 「実際に適用する前に規則を改めてもいい？」と、五分が終わったとき彼女は言った。

<a id="x186-09"></a>

**186.09**　The vote ended in **defeat** for the law and a small victory for discussion.

> 投票の結果、法案は敗れ、討論には小さな勝利がもたらされた。

**読みの問い**　国の遊びが終わったとき、生徒たちは規則の何を試せたか。

<a id="ex-story-187"></a>

### 187　牧師が持ってきた劇

<a id="x187-01"></a>

**187.01**　In the old **parish** hall our local theatre group met to **plan** a play about a **ghost**.

> 古い教区会館で地元の劇団が集まり、幽霊の劇を企画した。

<a id="x187-02"></a>

**187.02**　The actors hoped to **revive** a **tradition** and to **foster** the **spirit** of the town.

> 役者たちは伝統をよみがえらせ、町の人々の一体感を育みたいと思っていた。

<a id="x187-03"></a>

**187.03**　For the **introduction**, the stage was empty except for a **marker** and a chair.

> 導入部では、目印と椅子のほかには舞台に何もなかった。

<a id="x187-04"></a>

**187.04**　“The **soul** can leave the body while the body is still **alive**,” said a character in the play.

> 「体がまだ生きているうちに魂が体を離れることもある」と劇中の登場人物は言った。

<a id="x187-05"></a>

**187.05**　His friend told him that his **sense** of **self** would never leave him.

> 友人は彼に、自分が自分であるという感覚までは決して離れないと言った。

<a id="x187-06"></a>

**187.06**　They had a **long-standing** **dislike** of each other's ideas, but a deeper **loyalty** to each other.

> 二人は長年互いの考えを嫌っていたが、相手を大切にし、支え続ける気持ちは、それよりも深かった。

<a id="x187-07"></a>

**187.07**　The director did not **associate** their argument with **divine** judgement or **eternal** punishment.

> 演出家は、二人の言い争いを神の裁きや永遠の罰には結びつけなかった。

<a id="x187-08"></a>

**187.08**　“I am **fond** of them because they can **chat** as easily as they can **struggle**,” she said.

> 「ぶつかり合うのと同じくらい気軽におしゃべりもできる二人だから、私は好きなんです」と彼女は言った。

<a id="x187-09"></a>

**187.09**　A **charming** boy came out to say **hello** to the ghost, and nobody was **afraid**.

> 愛嬌のある少年が出てきて幽霊にあいさつすると、誰も怖がらなかった。

**読みの問い**　二人が意見を違えながらも会話を続けられるのはなぜか。

<a id="ex-story-188"></a>

### 188　客席で消えた音

<a id="x188-01"></a>

**188.01**　The play was a **hit**, and the **attendance** soon exceeded our most **promising** estimate.

> 劇はヒットし、観客数はやがて最も見込みのよかった予測さえ上回った。

<a id="x188-02"></a>

**188.02**　Its chief **attraction** was an actor who could **stun** a whole hall with a **whisper**.

> 最大の呼び物は、ささやき一つで会場中の人々に息をのませる役者だった。

<a id="x188-03"></a>

**188.03**　A single **characteristic** of his voice made people **cease** to **talk** when he opened his **mouth**.

> 彼の声にはある特徴があり、口を開くと人々はおしゃべりをやめた。

<a id="x188-04"></a>

**188.04**　In one **episode** he lifted a cup of **wine** to his lips and let his hand shake.

> ある場面で彼はワインの杯を口元まで上げ、手を震わせた。

<a id="x188-05"></a>

**188.05**　The cup held no **alcoholic** drink, but the room shared his **emotional** **struggle**.

> 杯に酒は入っていなかったのに、会場の人々は彼の心の葛藤を分かち合った。

<a id="x188-06"></a>

**188.06**　Then he would **sigh** and **descend** the steps so slowly that the silence seemed **endless**.

> それから彼はため息をつき、静寂がいつまでも続きそうなほどゆっくり階段を降りた。

<a id="x188-07"></a>

**188.07**　After a short **spell** in the dark the lights returned and the audience seemed to **revive**.

> 少しのあいだ暗闇が続いた後で明かりが戻り、観客は息を吹き返したようだった。

<a id="x188-08"></a>

**188.08**　“It is hard to tell how much time passed,” said a woman leaving in a thoughtful **mood**.

> 「どれだけ時間がたったのか分からないわ」と、何かを考えながら帰る女性が言った。

<a id="x188-09"></a>

**188.09**　“Good acting does not **rob** you of time; it can **alter** what a minute feels like.”

> 「いい芝居は時間を奪うものじゃない。一分間の感じ方を変えられるんです」

**読みの問い**　舞台の静けさは、観客の時間の感じ方にどう影響したか。

<a id="ex-story-189"></a>

### 189　木片で暮らしを読む

<a id="x189-01"></a>

**189.01**　The children's **forum** took place in the boat house, a new **establishment** on the river.

> 子どもたちの話し合いは、川辺に新しくできた舟の保管庫で開かれた。

<a id="x189-02"></a>

**189.02**　The **focus** was the **evolution** of small boats and the town's **sailing** **heritage**.

> 中心の話題は小舟の変化と、町に伝わる舟の文化だった。

<a id="x189-03"></a>

**189.03**　The group gathered by a table for the **initiation** of a project on the **formation** of boat crews.

> 舟の乗組員の編成を調べる計画を始めるにあたり、一同はテーブルを囲んだ。

<a id="x189-04"></a>

**189.04**　Each child could **express** **curiosity** about a different part of the **preparation**.

> 準備のどの部分に興味があるのか、子どもたちはそれぞれ自由に示すことができた。

<a id="x189-05"></a>

**189.05**　“To **advance** this project, we need to **gather** accounts from people who still know the boats.”

> 「この計画を進めるには、今も舟をよく知る人たちの話を集める必要があります」

<a id="x189-06"></a>

**189.06**　One girl asked to **undertake** the **handling** of the sails and learn by doing.

> ある女の子は帆の取り扱いを自分に任せてほしい、やりながら覚えたいと言った。

<a id="x189-07"></a>

**189.07**　A boy preferred to **detail** the various tools and learn the right **terminology** for each.

> 男の子は、さまざまな道具を詳しく記録し、それぞれの正しい呼び方を知りたがった。

<a id="x189-08"></a>

**189.08**　“Your **progress** will **range** from slow to fast,” said the teacher, “and that is the **nature** of learning.”

> 「上達が遅いときも速いときもある。それが学ぶということだよ」と先生は言った。

<a id="x189-09"></a>

**189.09**　She gave them **encouragement** without promising **excellence** in a week.

> 一週間で抜群にうまくなるなどとは言わずに、先生は子どもたちを励ました。

**読みの問い**　舟について学ぶ二人の入口は、どう違っていたか。

<a id="ex-story-190"></a>

### 190　十字架のない墓標

<a id="x190-01"></a>

**190.01**　A carved stone in the church garden served as a **marker**, but it bore no name.

> 教会の敷地には目印になる彫刻石があったが、名前はなかった。

<a id="x190-02"></a>

**190.02**　“Is the **identification** of the dead our task?” asked a woman **involved** in the repairs.

> 「亡くなった人が誰かを確かめるのも私たちの務めですか」と修繕に関わる女性が聞いた。

<a id="x190-03"></a>

**190.03**　Her question carried a **grave** warning about the **threat** of a false name.

> その問いは、誤った名前を書き込む危険への重大な警告を含んでいた。

<a id="x190-04"></a>

**190.04**　The guide asked us to **enquire** at the archive and **cite** the source of every name.

> 案内人は資料庫に問い合わせ、名前を挙げるときは一つずつ出典を示すように言った。

<a id="x190-05"></a>

**190.05**　The witness did not **lie**, but her memory could still betray her.

> 目撃者はうそをついてはいなかったが、記憶に裏切られることはありえた。

<a id="x190-06"></a>

**190.06**　“I do not **doubt** her **goodness**,” said the guide, “but I **suspect** that this picture was taken later.”

> 「彼女の善良さを疑ってはいません。ただ、この写真はもっと後に撮られた気がするのです」と案内人は言った。

<a id="x190-07"></a>

**190.07**　A date on the back was a **timely** reminder that the photograph did not **precede** the flood.

> 裏の日付のおかげで、洪水より前の写真ではないと、ちょうどよいところで思い出せた。

<a id="x190-08"></a>

**190.08**　Yet the woman in it was **capable** of remembering faces long after a name had gone.

> それでも、そこに写った女性は名前を忘れて久しくても顔を覚えていられる人だった。

<a id="x190-09"></a>

**190.09**　We left the stone as it was rather than **swear** that we knew whose grave it marked.

> 誰の墓かを知っていると言い切る代わりに、私たちは石をそのままにした。

**読みの問い**　目撃者が誠実でも、証言を確かめる必要が残るのはなぜか。

<a id="ex-story-191"></a>

### 191　お金の表と裏

<a id="x191-01"></a>

**191.01**　The exhibition team had to prepare a **total** budget and discuss **finance** in an **open** meeting.

> 展示チームは総予算をまとめ、公開の会議で資金について話し合う必要があった。

<a id="x191-02"></a>

**191.02**　The **listing** of costs included a deposit on a hall and a week's **worth** of **food**.

> 費用の一覧には、会場の手付金と一週間分の食料が含まれた。

<a id="x191-03"></a>

**191.03**　The **gross** income from tickets looked impressive, but it did not show the actual **worth** of the event.

> 切符の総収入は立派に見えたが、それで催しの本当の価値まで分かるわけではなかった。

<a id="x191-04"></a>

**191.04**　There was a **catch**: free tickets did not cover the cost of serving a drink.

> 落とし穴が一つあった。無料券では飲み物を出す費用がまかなえなかった。

<a id="x191-05"></a>

**191.05**　A **negative** balance was **unlikely** to shock the members, but an **excessive** loss would.

> 赤字が出ても会員は驚かないだろうが、損失が大きすぎれば驚くはずだった。

<a id="x191-06"></a>

**191.06**　“We shall **incur** the expense once, not on every occasion,” said the woman in charge of the money.

> 「その費用が発生するのは一度だけで、開催するたびにかかるわけではありません」と会計係は言った。

<a id="x191-07"></a>

**191.07**　The **opposition** asked what could **constrain** future spending if more people came.

> 反対する人々は、参加者が増えた場合、将来の支出をどう抑えるのかと聞いた。

<a id="x191-08"></a>

**191.08**　The **prepared** answer concerned a **big** donation, but no one had seen it yet.

> 用意された答えは大口の寄付に関するものだったが、まだ誰もそれを受け取っていなかった。

<a id="x191-09"></a>

**191.09**　“Do not confuse a **potential** gift with cash,” said the woman from the bank.

> 「寄付の見込みと手元の現金は別ですよ」と銀行から来た女性が言った。

**読みの問い**　総収入・手元のお金・催しの価値は、なぜ別々に考える必要があるか。

<a id="ex-story-192"></a>

### 192　引退した足にパスを

<a id="x192-01"></a>

**192.01**　The football club was **based** in an old school beside the bridge.

> そのサッカークラブは、橋のそばの古い学校を拠点にしていた。

<a id="x192-02"></a>

**192.02**　Its next **fixture** was a match between the present team and players who had left school fifty years before.

> 次に組まれていた試合は、現役のチームと、五十年前に学校を卒業した選手たちとの対戦だった。

<a id="x192-03"></a>

**192.03**　“Do you **fancy** a game?” a woman asked the railway worker who had brought us the bag.

> 「試合に出てみませんか」と、例のかばんを持ってきた鉄道員に女性が声をかけた。

<a id="x192-04"></a>

**192.04**　“I can **exercise**, but running the whole length of that **pitch** would be **impossible**.”

> 「運動はできます。でもあのグラウンドを端から端まで走るのは無理ですよ」

<a id="x192-05"></a>

**192.05**　The woman had an idea that sounded **mad** but was **fun** to play once we tried it.

> 女性には一つ案があった。聞いたときはばかげているようだったが、実際にやってみると楽しかった。

<a id="x192-06"></a>

**192.06**　When a player passed the ball, the other team had to walk until it touched the ground.

> 選手がパスを出したら、ボールが地面に触れるまで相手チームは歩かなければならない。

<a id="x192-07"></a>

**192.07**　He was **pleased** to find that he could **score** even against a team with **superior** speed.

> 相手の方が速くても得点できると分かり、彼はうれしそうだった。

<a id="x192-08"></a>

**192.08**　The school team did **defeat** the older players, but the best pass of the day was his.

> 勝ったのは現役のチームだったが、その日いちばんのパスを出したのは彼だった。

<a id="x192-09"></a>

**192.09**　The match proved so **popular** that both sides wanted another in the **near** future.

> 試合はたいそう好評で、どちらのチームも近いうちにまたやりたいと言った。

**読みの問い**　鉄道員が得点できたのは、速さで勝ったからか。

<a id="ex-story-193"></a>

### 193　橋の下に入った白い鳥

<a id="x193-01"></a>

**193.01**　A **gang** of children had asked to **camp** beside the river after the match.

> 試合のあと、子どもたちの一団が、川辺でキャンプさせてほしいと頼んだ。

<a id="x193-02"></a>

**193.02**　Their **excitement** grew as a white bird appeared with two young ones.

> 白い鳥が二羽のひなを連れて現れると、子どもたちはますます興奮した。

<a id="x193-03"></a>

**193.03**　One of the young birds was caught in a **trap** made of old fishing line.

> ひなの一羽が、古い釣り糸がつくったわなにかかった。

<a id="x193-04"></a>

**193.04**　The adult bird was a **female** with a dark mark on her head.

> 親鳥は頭に黒い印のある雌だった。

<a id="x193-05"></a>

**193.05**　She began to **attack** a stick that kept the line tight.

> 母鳥は、糸を張らせていた小枝に襲いかかった。

<a id="x193-06"></a>

**193.06**　My first **instinct** was to go in after the bird, but my uncle caught me by the arm.

> 私はとっさに川へ入ってひなを助けに行こうとしたが、叔父が私の腕をつかんだ。

<a id="x193-07"></a>

**193.07**　“People can **drown** in water as still as this,” he said.

> 「こんなに静かな水でも人は溺れて死ぬことがあるんだ」と言った。

<a id="x193-08"></a>

**193.08**　He used his umbrella to **divert** the fishing line around the stick and let it fall loose.

> 叔父は傘で釣り糸を小枝の向こうへと押しやり、たるませた。

<a id="x193-09"></a>

**193.09**　With a single **leap** the young bird broke free, and its next **dive** came as a relief to us all.

> ひなはひと跳びで抜け出した。もう一度水に飛び込んだのを見て、私たちはみなほっとした。

<a id="x193-10"></a>

**193.10**　“What would you have done without the umbrella?” asked a child.

> 「傘がなかったら、どうしたの？」と子どもが尋ねた。

<a id="x193-11"></a>

**193.11**　“I would have asked for another stick,” my uncle said.

> 「別の枝を頼んだだろうね」と叔父は答えた。

**読みの問い**　叔父が傘で動かしたのは何だったか。

<a id="ex-story-194"></a>

### 194　二つの台所

<a id="x194-01"></a>

**194.01**　The children returned to find a **chemistry** class in the kitchen of the town hall.

> 子どもたちが戻ると、町の会館の台所で化学の授業が開かれていた。

<a id="x194-02"></a>

**194.02**　The teacher cut away the **fat** from a piece of meat and then cut into the soft **flesh** of a fruit.

> 先生は肉の脂身を切り落とし、次に果物の柔らかな果肉に切り込んだ。

<a id="x194-03"></a>

**194.03**　Her lesson on how salt and water **interact** was **based** on these **everyday** foods.

> 塩と水がどう相互に作用するかを扱う授業で、材料はこうした身近な食べ物だった。

<a id="x194-04"></a>

**194.04**　She did not **hint** at the answer until each group had made a prediction.

> どの班も予想を立て終えるまで、先生は答えをほのめかすこともしなかった。

<a id="x194-05"></a>

**194.05**　A wet mark began to grow around one sample, and there was some **confusion** about its cause.

> ある試料の周囲にぬれた跡が広がり始め、原因をめぐって少し混乱した。

<a id="x194-06"></a>

**194.06**　A second test brought a **stark** contrast between the two plates.

> 二度目の実験では、二枚の皿にはっきりした違いが現れた。

<a id="x194-07"></a>

**194.07**　“Did the change **occur** before or after you added the salt?” she asked.

> 「その変化は、塩を加える前に起きましたか、それともあとでしたか」と先生は尋ねた。

<a id="x194-08"></a>

**194.08**　The answer was **disappointing** to a boy whose prediction had been wrong.

> 予想を外した少年にとって、答えはがっかりするものだった。

<a id="x194-09"></a>

**194.09**　His friend found the result **unrelated** to her own question about the smell of the meat.

> その少年の友人は、その結果は肉のにおいについての自分の問いとは関係がないと気づいた。

<a id="x194-10"></a>

**194.10**　The teacher praised her **competence** in seeing where one question ended and another began.

> 先生は、どこまでが一つの問いで、どこからが別の問いかを見分けた彼女の力を褒めた。

**読みの問い**　先生が、全ての班が予想を立て終えるまで答えをほのめかさなかったのはなぜか。

<a id="ex-story-195"></a>

### 195　出口のない投票

<a id="x195-01"></a>

**195.01**　A visitor had complained that the public vote offered two **horrible** choices.

> 来場者から、公開投票の選択肢は二つともひどいという苦情が来た。

<a id="x195-02"></a>

**195.02**　“At one **extreme**, we close the hall to children,” he said.

> 「一方の極端な案は、子どもが会館に入れなくしてしまうことです」と彼は言った。

<a id="x195-03"></a>

**195.03**　“At the other, we let anyone **abuse** the right to use it at any time.”

> 「反対の極端な案では、誰でもいつでも利用する権利を悪用できてしまいます」

<a id="x195-04"></a>

**195.04**　The clerk was **furious** with the writer of the notice, and the argument began to **escalate**.

> 係員は掲示を書いた人に腹を立て、口論は激しくなり始めた。

<a id="x195-05"></a>

**195.05**　“I **fear** the way these two choices speak for us,” said a boy.

> 「この二択で僕たちの考えが決まったことにされるのが怖い」と少年が言った。

<a id="x195-06"></a>

**195.06**　“What does **concern** me is that nobody asked us what the **trouble** was.”

> 「僕が本当に気にしているのは、何に困っているかを誰も僕たちに聞かなかったことだよ」

<a id="x195-07"></a>

**195.07**　A **shocking** photograph of a broken window had made adults **suspicious** of all the children.

> 割れた窓の衝撃的な写真を見て、大人たちは子どもたち全員を疑うようになっていた。

<a id="x195-08"></a>

**195.08**　“The picture may **shock** us, but what should **outrage** us is blaming a child who was not even here.”

> 「写真には驚くかもしれない。でも怒るべきなのは、ここにいさえしなかった子を責めることだよ」

<a id="x195-09"></a>

**195.09**　His **solution** was to let one adult and two children **manage** the hall together for a week.

> 彼が出した解決策は、一週間、大人一人と子ども二人で会館を一緒に管理することだった。

<a id="x195-10"></a>

**195.10**　It was a **problematic** plan for working parents, but a **succession** of offers soon covered every day.

> 働く親には難点のある案だったが、次々と申し出が集まり、すぐに全日を埋められた。

**読みの問い**　子どもの提案によって、投票に欠けていたものはどう補われたか。

<a id="ex-story-196"></a>

### 196　声だけで作った肖像

<a id="x196-01"></a>

**196.01**　The railway worker had a previous **engagement** and asked to speak before the hall closed.

> 鉄道員は先約があり、閉館前に話す時間が欲しいと頼んだ。

<a id="x196-02"></a>

**196.02**　It was his first **occasion** to speak in public since the death of his wife.

> 妻を亡くして以来、人前で話すのは初めてだった。

<a id="x196-03"></a>

**196.03**　“The house can be a **depressing** place at six,” he said, “because that was when she came home.”

> 「六時になると、家にいるのがつらくなることがあります。妻が帰ってきた時間ですから」と話した。

<a id="x196-04"></a>

**196.04**　He had lived in **isolation** until a **dynamic** young neighbour invited him to a **social** evening.

> 活気のある若い隣人に交流会へ誘われるまで、彼は孤立して暮らしていた。

<a id="x196-05"></a>

**196.05**　There he came to see conversation as a **medium** for making portraits of absent people.

> そこで彼は、その場にいない人の姿を描く手段として会話を捉えるようになった。

<a id="x196-06"></a>

**196.06**　A woman whose hands were too weak to paint had given him the **inspiration** for his first portrait.

> 最初の肖像の着想をくれたのは、手の力が弱くて絵を描けない女性だった。

<a id="x196-07"></a>

**196.07**　“Can you **encourage** people to remember my brother without showing them his face?” she had asked.

> 「私の兄弟の顔を見せずに、皆があの人を思い出せるように働きかけてくれませんか」と彼女は尋ねた。

<a id="x196-08"></a>

**196.08**　His **philosophy** was simple: a voice could **embody** a whole life in a few **vital** details.

> 彼の考え方は単純だ。いくつかの肝心な細部を声にのせれば、その人の一生が立ち現れる。

<a id="x196-09"></a>

**196.09**　He had no wish to **unveil** a perfect image or to prove that he possessed a **unique** kind of **intelligence**.

> 完璧な肖像を披露したいわけでも、特別な知性を持つと証明したいわけでもなかった。

<a id="x196-10"></a>

**196.10**　The **stimulation** of listening to **various** voices had given him the courage to try.

> さまざまな人の声を聞く刺激が、やってみる勇気をくれたのだ。

<a id="x196-11"></a>

**196.11**　“When I **succeed**, somebody who knew the person adds another detail.”

> 「うまくいくと、その人を知っていた誰かが、もう一つ細部を加えてくれるんです」

<a id="x196-12"></a>

**196.12**　That night the old man did **fulfil** his promise to the woman.

> その晩、老人は女性との約束を確かに果たした。

**読みの問い**　鉄道員にとって、声の肖像がうまくいったと分かるのはどんなときか。

<a id="ex-story-197"></a>

### 197　乾いた紙と、紙を乾かす人

<a id="x197-01"></a>

**197.01**　Two letters from the box lay on a towel.

> 箱から出した二通の手紙が、タオルの上に載っていた。

<a id="x197-02"></a>

**197.02**　“This sheet is dry,” I said.

> 「この紙は乾いている」と私は言った。

<a id="x197-03"></a>

**197.03**　“The other sheet is drying,” said my uncle.

> 「もう一枚は乾いてきているね」と叔父が言った。

<a id="x197-04"></a>

**197.04**　He took the towel to dry his hands.

> 叔父は手を拭くためにタオルを手に取った。

<a id="x197-05"></a>

**197.05**　“Did you dry the first sheet too?” I asked.

> 「一枚目の紙も叔父さんが乾かしたの？」と私は聞いた。

<a id="x197-06"></a>

**197.06**　“I found it dry when I opened the box.”

> 「箱を開けたときには、もう乾いていたよ」

<a id="x197-07"></a>

**197.07**　I wrote that down before a state became a story about who had caused it.

> ある状態が、誰がそうしたのかという話に変わってしまう前に、私はそれを書き留めた。

**読みの問い**　乾いている状態、乾く途中、誰かが乾かす動作は、それぞれどう言い分けたか。

<a id="ex-story-198"></a>

### 198　駅までの話し相手

<a id="x198-01"></a>

**198.01**　On our way back we stopped to **hail** a taxi for the railway worker.

> 帰り道、私たちは立ち止まり、鉄道員のためにタクシーに合図をして呼び止めた。

<a id="x198-02"></a>

**198.02**　The driver recognized him from the exhibition and asked about the **transformation** of the hall.

> 運転手は展示会で彼を見たと気づき、会館がどう様変わりしたかを尋ねた。

<a id="x198-03"></a>

**198.03**　“Is all this interest in the past a **trend** that will end next year?”

> 「昔のことへの関心は、来年には終わるような流行ですか」

<a id="x198-04"></a>

**198.04**　“I do not know,” the old man said, “but the **pursuit** of one umbrella brought me into your car.”

> 「さあ。でも傘を一本追いかけたおかげで、私は今あなたの車に乗っている」と老人は言った。

<a id="x198-05"></a>

**198.05**　The driver turned down the radio to hear the rest of the story.

> 運転手は話の続きを聞くため、ラジオの音を小さくした。

<a id="x198-06"></a>

**198.06**　Perhaps the **legacy** of the exhibition would be an old man telling a new friend about his wife.

> 展示が後に残すものは、一人の老人が新しい友人に妻の話をしている、そんな光景かもしれなかった。

**読みの問い**　運転手がラジオの音を小さくしたのはなぜか。

### 第3篇　読みの確認

**[139　閉館後に届いた箱](#ex-story-139)**　かばんは自分のものだと言い、そこに残る記憶は誰のものかと問い返した。

**[140　写真の端にいる人](#ex-story-140)**　撮影時刻を考える手掛かりにはなったが、誰かがうそをついたことまでは証明できなかった。

**[141　毛糸の持ち主](#ex-story-141)**　持ち主は分からなかったが、かごに残った毛糸が傘の糸の出所だという可能性を除けた。

**[142　市場を通る匂い](#ex-story-142)**　同じ料理人が作るスープのにおいだった。

**[143　漁師と赤い糸](#ex-story-143)**　語り手は飛び込んだ漁師に、漁師はロープをつかんだ少年に注目している。

**[144　病院の窓辺](#ex-story-144)**　合併症が起きる可能性があったから。

**[145　患者の昔の仕事](#ex-story-145)**　前者では観察や症例の検討に基づく判断、後者では怖い気持ちを和らげる助けが求められた。会話が助けになることもある、と語られている。

**[146　救助記録の閲覧室](#ex-story-146)**　叔父は記録から情報を得ることを、事務員は記録から名前が抜けている職員本人にとっての意味を重視している。

**[147　草地の下を通るもの](#ex-story-147)**　壁を守りながら、奥の部屋の存在を確かめられた。

**[148　地下室のシャツ](#ex-story-148)**　保存された衣類などの大部分は無傷で、例外はシャツのいちばん下のボタンだった。

**[149　鉄道の時刻を巻き戻す](#ex-story-149)**　往復切符を予約するという選択肢が加わった。

**[150　橋の影が二つある理由](#ex-story-150)**　影を太陽だけが作ったとは限らず、鏡や別の光の影響も考える必要が出てくる。

**[151　音を記憶する劇場](#ex-story-151)**　別々に保存されていた音と映像の位置を、共通の拍を手掛かりに合わせ直したから。

**[152　劇場の値段](#ex-story-152)**　年間を通した家賃や賃金がかかり、満席の公演があっても利益が保証されないため。

**[153　学校で写真を読む](#ex-story-153)**　別の説明が成り立つ可能性を示した。けんかがなかったとまでは言っていない。

**[154　二つの名札](#ex-story-154)**　写真が何を記録しているかと、それが家族にとってどんな写真かは別の観点だから。

**[155　海を渡った家族](#ex-story-155)**　父親の筆跡が残ったカードが、父親とのつながりを保っていた。

**[156　箱の持ち主をめぐる投票](#ex-story-156)**　住民の負担意思は問えるが、他人の所有権を投票だけで移すことはできない。

**[157　署名の行方](#ex-story-157)**　誤りがあったことと、特定の人物が意図して盗んだことは別々に立証する必要がある。

**[158　新聞が先に決めたこと](#ex-story-158)**　五紙とも、最初の一人の発言を引用しているかもしれないから。

**[159　二本の川の一枚の図](#ex-story-159)**　人口が少なければ、割合の大きな変化でも、実際の人数や量は小さくなりうる。

**[160　小さな温室の実験](#ex-story-160)**　葉にはその病気への抵抗力がある一方、根には免疫がないと述べられている。葉の性質をそのまま根にも当てはめることはできない。

**[161　天気を借りる農場](#ex-story-161)**　ある畑では作物を壊し、その一方で別の畑には有益な土を運ぶことがあるため。

**[162　倉庫で一ガロンを量る](#ex-story-162)**　放出されたものがその場に残り、次第に増えていくことを指す。

**[163　走らなかった選手](#ex-story-163)**　成績の掲示板が記録するのは出走の有無で、走らずに人を助けた事情までは記録しないから。

**[164　肖像の前の二人](#ex-story-164)**　他の部分から想像できる中世の場面とライフル銃の取り合わせが、これは昔の出来事をそのまま写したものか、という疑問を生む。

**[165　平和の部屋](#ex-story-165)**　名前の分からない若者と、埋葬のときに祈った村人の行為もたどっている。

**[166　二つの国の同じ切手](#ex-story-166)**　父と息子では渡った向き、時期、旅の目的が違うから。

**[167　署名をしたのはだれか](#ex-story-167)**　将来について聞く形を取りながら、本人が記録に残したくないとした私生活に再び踏み込んだから。

**[168　劇場が避難所になった夜](#ex-story-168)**　無事な姿を見て、心配が和らいだという気持ちの変化。

**[169　本部で鳴ったベル](#ex-story-169)**　風が非常に強く、大勢にいっせいに叫ぶより、一人ずつに伝えるほうが混乱を抑えられたから。

**[170　こわれた箱を開く](#ex-story-170)**　価値は紙の値段だけでは決まらず、そこに残る記録や記憶にもあるから。

**[171　一番遅いニュース](#ex-story-171)**　町は投資資金を、働く人たちは雇用が守られるという確約を求めた。

**[172　人が作る機械](#ex-story-172)**　動きの前にある入力方法の設計と、試した人とのやり取りから新しい発想が生まれる過程を見落とす。

**[173　どこにでもある一点](#ex-story-173)**　ほかの点が何を意味するか。赤い点の並びは、動いている舟を示している。

**[174　診察室の天井](#ex-story-174)**　痛みや恐怖が現実にあることを認め、注射をする理由を説明した。

**[175　水の標本、恐怖の標本](#ex-story-175)**　光源の覆いに色がついており、照明条件によって見えた色が違ったから。

**[176　観光船が来る前に](#ex-story-176)**　環境を守る費用を負担せず、利益だけを得てよいことにはならない。

**[177　塗り替えられる看板](#ex-story-177)**　西岸や待合室の低い席など、実際に読む人の位置から文字が見えること。

**[178　実演はどこから始まるのか](#ex-story-178)**　リンゴかパンかという先ほどの問題に注意を向ける間に、木の鳥の行方を見落とした。

**[179　音楽家が置いていった火](#ex-story-179)**　すぐに観客を喜ばせることができても、鳥が安全な位置に移るまで合図を待つこと。

**[180　町の冬はまだ来ない](#ex-story-180)**　山上と麓では同じ時刻でも天候が違うことがあるから。

**[181　三分でできる仕事](#ex-story-181)**　町の模型全体を造る工程と、できあがった模型に塔を追加する工程。

**[182　外に出る権利](#ex-story-182)**　空腹で寒い思いをしている人が、持ち主より先に上着を使えること。

**[183　資料の中の偏見](#ex-story-183)**　一方が説明されるだけの対象になるのを避け、その人自身の声から状況を読めるようになる。

**[184　走る人の年金](#ex-story-184)**　特定の人への恩恵にせず、費用が必要な選手が同じ基準で申請できる制度にしたこと。

**[185　一枚の白いポスター](#ex-story-185)**　白い紙が抗議を表しているのか、その紙が置かれた事情や意図。

**[186　五分だけの国](#ex-story-186)**　規則の趣旨に賛成できても、違反を判断して適用する手続きには問題が残るということ。

**[187　牧師が持ってきた劇](#ex-story-187)**　考え方を嫌う気持ちより、お互いを大切にする気持ちのほうが強いから。

**[188　客席で消えた音](#ex-story-188)**　役者がゆっくり階段を降りる間の静けさは、果てしなく続くように感じられた。観客は実際にどれだけ時間がたったか、判断しにくくなっていた。

**[189　木片で暮らしを読む](#ex-story-189)**　一人は帆を実際に扱うことから入り、もう一人は道具を記録して名称を調べることから入った。

**[190　十字架のない墓標](#ex-story-190)**　人をだます意図の有無と、その人の記憶が事実に合うかどうかは別だから。

**[191　お金の表と裏](#ex-story-191)**　総収入には経費が反映されず、予定の寄付もまだ現金ではなく、催しの価値には金額以外の面もあるから。

**[192　引退した足にパスを](#ex-story-192)**　違う。パスの間は相手が歩くという仕組みを生かしたから。

**[193　橋の下に入った白い鳥](#ex-story-193)**　鳥そのものではなく、小枝に張っていた釣り糸。

**[194　二つの台所](#ex-story-194)**　答えの手掛かりを与える前に、それぞれがどんな変化を予想するのかを明らかにするため。

**[195　出口のない投票](#ex-story-195)**　閉鎖か無制限の利用かという二択に、当事者が協力して運営する具体的な第三案が加わった。

**[196　声だけで作った肖像](#ex-story-196)**　その人を知っている別の誰かが、自分の覚えている細部を足してくれるとき。

**[197　乾いた紙と、紙を乾かす人](#ex-story-197)**　is dry は観察した状態。is drying は進行中の変化。dry his hands や dry the first sheet では、動作をする人と対象がある。

**[198　駅までの話し相手](#ex-story-198)**　鉄道員の話の続きを聞くため。

---

<a id="exp-part-4"></a>

## 第4篇　町が開く展覧会

赤い点を目印に、人も品物も展示の会場に集まる。名前のない持ち物を前にして、町の人たちは、何を手掛かりに誰へ返せばよいかを考える。

[199　消えたのは傘か、それとも印か](#ex-story-199) ／ [200　写真の外側](#ex-story-200) ／ [201　手に残った青](#ex-story-201) ／ [202　誰が何を見たか](#ex-story-202)

[203　印を読む実験](#ex-story-203) ／ [204　貸し出し記録](#ex-story-204) ／ [205　公聴会に椅子を一脚](#ex-story-205) ／ [206　水面を走った光](#ex-story-206)

[207　菓子の印](#ex-story-207) ／ [208　舞台を一歩降りると](#ex-story-208) ／ [209　切れた幕の向こう](#ex-story-209) ／ [210　列車の最後尾](#ex-story-210)

[211　分刻みの移動](#ex-story-211) ／ [212　せりにかけられた絵](#ex-story-212) ／ [213　負ける確率、勝つ理由](#ex-story-213) ／ [214　地下で揺れた家](#ex-story-214)

[215　音が届かない席](#ex-story-215) ／ [216　連絡のつかない晩](#ex-story-216) ／ [217　何を残すか](#ex-story-217) ／ [218　泥の中の麦](#ex-story-218)

[219　蝋の跡がついた手紙](#ex-story-219) ／ [220　法廷の椅子に座る](#ex-story-220) ／ [221　調剤室の白い傘](#ex-story-221) ／ [222　声を置く場所](#ex-story-222)

[223　働く人の会計簿](#ex-story-223) ／ [224　橋に上げた三つの旗](#ex-story-224) ／ [225　月に向いた傘](#ex-story-225) ／ [226　化石に糸はつかない](#ex-story-226)

[227　言葉の博覧会](#ex-story-227) ／ [228　赤い点を送れない](#ex-story-228) ／ [229　広報誌に載る前に](#ex-story-229) ／ [230　古いビラの貸出日](#ex-story-230)

[231　壊れた車を組み直す](#ex-story-231) ／ [232　安全な水までの距離](#ex-story-232) ／ [233　見えない境界線](#ex-story-233) ／ [234　教室で議長を変える](#ex-story-234)

[235　傘の柄から出た手品師](#ex-story-235) ／ [236　橋を踏んだ音](#ex-story-236) ／ [237　夜を渡ってきた鍋](#ex-story-237) ／ [238　口にしなかった一言](#ex-story-238)

[239　発明家が置いた箱](#ex-story-239) ／ [240　決める前の一分](#ex-story-240) ／ [241　最後の展示は空っぽだった](#ex-story-241) ／ [242　赤は誰のもの](#ex-story-242)

[243　額の中に足りないもの](#ex-story-243) ／ [244　借りた傘を返す前に](#ex-story-244)

<a id="ex-story-199"></a>

### 199　消えたのは傘か、それとも印か

<a id="x199-01"></a>

**199.01**　The first **guest** arrived before the **announcement**.

> 開会を知らせる前に、最初の客がやって来た。

<a id="x199-02"></a>

**199.02**　My **daughter** ran to **welcome** him with the umbrella.

> 娘は例の傘を持って彼を迎えに走った。

<a id="x199-03"></a>

**199.03**　She came back with a **blank** look on her face.

> 戻ってきた娘は、ぽかんとした顔をしていた。

<a id="x199-04"></a>

**199.04**　“The umbrella is here, but the red is gone.”

> 「傘はあるのに、赤いところが消えてる」

<a id="x199-05"></a>

**199.05**　On the **back** of the cloth, a **tiny** hole let the **light** through.

> 布の裏に小さな穴があり、そこから光が漏れていた。

<a id="x199-06"></a>

**199.06**　A **needle** still hung from a **loop** of **silver** thread.

> 銀色の糸の輪に、まだ針がぶら下がっていた。

<a id="x199-07"></a>

**199.07**　“Do you **recognize** the **make**?” the old **gentleman** asked.

> 「どこの製品か分かりますか」と年配の男性が尋ねた。

<a id="x199-08"></a>

**199.08**　I shook my **head**.

> 私は首を横に振った。

<a id="x199-09"></a>

**199.09**　“Then how can you be **certain** this is the **right** umbrella?”

> 「では、どうしてこれがその傘だと言い切れるんですか」

<a id="x199-10"></a>

**199.10**　We agreed to **abandon** one assumption at a **time**.

> 私たちは、思い込みを一つずつ手放していくことにした。

<a id="x199-11"></a>

**199.11**　We would first look for the umbrella in the opening photograph.

> まず開会時の写真の中に、その傘が写っているか探すことにした。

**読みの問い**　最初に確かめる必要があるのは何か。

<a id="ex-story-200"></a>

### 200　写真の外側

<a id="x200-01"></a>

**200.01**　The **photography** **workshop** occupied the **downstairs** **room** at the **station**.

> 撮影講座は駅の階下の一室で開かれていた。

<a id="x200-02"></a>

**200.02**　A **student** in **jeans** was teaching her **grandfather** to **photograph** his own **hand**.

> ジーンズ姿の学生が、祖父に、祖父自身の手をどう撮影するか教えていた。

<a id="x200-03"></a>

**200.03**　“**Focus** on the **palm** and let the background **fade**.”

> 「手のひらにピントを合わせて、背景はぼかしてね」

<a id="x200-04"></a>

**200.04**　The old man **smiled** when he saw the **scratch** by his **joint**.

> 関節のそばの引っかき傷が見えると、老人はほほえんだ。

<a id="x200-05"></a>

**200.05**　“I had that before your **mum** was born.”

> 「これはおまえのお母さんが生まれる前からあるよ」

<a id="x200-06"></a>

**200.06**　The teacher found the opening photograph in a brown **envelope**.

> 講師は茶色い封筒から開会時の写真を見つけた。

<a id="x200-07"></a>

**200.07**　A red **balloon** filled the **corner** of the picture.

> 写真の隅を赤い風船が占めていた。

<a id="x200-08"></a>

**200.08**　Behind it we could just **distinguish** a **curly** head and the **curve** of a handle.

> その向こうに、巻き毛の頭と取っ手の曲線がかろうじて見分けられた。

<a id="x200-09"></a>

**200.09**　My daughter **pointed** to a dark shape near the **rear** **gate**.

> 娘が裏門近くの黒っぽい形を指さした。

<a id="x200-10"></a>

**200.10**　“Here is the same handle again.”

> 「ここにも同じ取っ手がある」

<a id="x200-11"></a>

**200.11**　The teacher put a mirror along the **fold** in the print.

> 講師は写真の折り目に沿って鏡を置いた。

<a id="x200-12"></a>

**200.12**　“One handle and its **reflection** can look like a perfect match.”

> 「取っ手一本でも、映った姿と並べば、そっくりな二本に見えるよ」

**読みの問い**　二本目の取っ手があるように見えた理由は何か。

<a id="ex-story-201"></a>

### 201　手に残った青

<a id="x201-01"></a>

**201.01**　At the **hospital** a **doctor** had a different **account** of the opening.

> 病院では、ある医師が開会時の様子について違った説明をした。

<a id="x201-02"></a>

**201.02**　A child had run to him with a **burn** on one **knee**.

> 膝にやけどをした子が駆け寄ってきたという。

<a id="x201-03"></a>

**201.03**　He had poured **cool** **water** over the **wound**.

> 医師は患部に冷たい水をかけた。

<a id="x201-04"></a>

**201.04**　The child left a **coat** on a **blanket** beside a **folding** **seat**.

> その子は、折り畳み椅子の横の毛布の上に、コートを置いていった。

<a id="x201-05"></a>

**201.05**　“I have a memory of **blue** on my thumb.”

> 「親指に青い色がついていた記憶があります」

<a id="x201-06"></a>

**201.06**　A **dirty** **strip** of cloth had come away in his hand.

> 汚れた細長い布が手の中で取れたのだという。

<a id="x201-07"></a>

**201.07**　He had used **soap** to wash the **ink** off.

> 医師は石けんでインクを洗い落としていた。

<a id="x201-08"></a>

**201.08**　His **assistant** opened the **cabinet** and took out a **pad**.

> 助手が戸棚を開け、メモ帳を取り出した。

<a id="x201-09"></a>

**201.09**　On the **chart**, a **bent** **arrow** led from a **drawing** of the coat to a **basket**.

> 図では、折れ曲がった矢印がコートの絵からかごへ延びていた。

<a id="x201-10"></a>

**201.10**　“We record where we put the things each **patient** brings.”

> 「患者さんが持ってきた物をどこに置いたか、記録しています」

<a id="x201-11"></a>

**201.11**　The basket still held a blue **belt** with a red **pin**.

> かごには、赤いピンを付けた青いベルトが残っていた。

<a id="x201-12"></a>

**201.12**　No umbrella had entered the **clinic** that **afternoon**.

> その日の午後、診療所に傘は一本も持ち込まれていなかった。

**読みの問い**　青いインクが医師の手についていたことだけで、傘の持ち主を特定できるか。

<a id="ex-story-202"></a>

### 202　誰が何を見たか

<a id="x202-01"></a>

**202.01**　The town **journalist** wanted a **short** **description** of the **incident**.

> 町の記者は出来事の簡単な説明を求めた。

<a id="x202-02"></a>

**202.02**　“Was there an **accident**, or did somebody take it?”

> 「事故だったんですか、それとも誰かが持っていったんですか」

<a id="x202-03"></a>

**202.03**　“Please do not **accuse** anybody on my **account**,” my daughter said.

> 「私のために誰かを犯人扱いしないでください」と娘は言った。

<a id="x202-04"></a>

**202.04**　The journalist closed her **pad** and began to **listen**.

> 記者はメモ帳を閉じて耳を傾けた。

<a id="x202-05"></a>

**202.05**　Her **interview** began with a single **straightforward** question.

> 取材は、ごく率直な一つの質問から始まった。

<a id="x202-06"></a>

**202.06**　“What did you actually **see**?”

> 「実際に、何を見たの？」

<a id="x202-07"></a>

**202.07**　A **painter** had seen a **narrow** **ray** of **light** move across the ceiling.

> 画家は細い光が天井を横切るのを見ていた。

<a id="x202-08"></a>

**202.08**　A **dancer** had felt something **touch** her bare **toe**.

> 踊り手は素足の指先に何かが触れるのを感じていた。

<a id="x202-09"></a>

**202.09**　A **sailor** had heard a **shout** from the **river**.

> 船乗りは川の方から叫び声を聞いていた。

<a id="x202-10"></a>

**202.10**　The reporter **drew** three circles on the **outside** of the envelope.

> 記者は封筒の外側に三つの丸を描いた。

<a id="x202-11"></a>

**202.11**　“Let us resist the **desire** to **combine** them too soon.”

> 「早くひとまとめにしたくなるけれど、まだ別々にしておこう」

**読みの問い**　記者が丸を三つに分けたのはなぜか。

<a id="ex-story-203"></a>

### 203　印を読む実験

<a id="x203-01"></a>

**203.01**　In the **lab**, an **insect** rested beside a **bottle** of **acid**.

> 実験室では、酸の瓶のそばで一匹の虫がじっとしていた。

<a id="x203-02"></a>

**203.02**　“Never put your **specimen** in that!” said the **biology** **lecturer**.

> 「その瓶に標本を入れちゃだめだよ」と生物学の講師が言った。

<a id="x203-03"></a>

**203.03**　He handed us a leaf and a thin **slice** of **lemon**.

> 葉を一枚と、薄く切ったレモンを一切れ渡してくれた。

<a id="x203-04"></a>

**203.04**　We **squeezed** the lemon over the leaf and tested its **acid** juice on blue paper.

> 葉の上でレモンを絞り、その酸性の果汁を青い試験紙につけた。

<a id="x203-05"></a>

**203.05**　A **striking** red appeared before our eyes.

> 目の前に鮮やかな赤が現れた。

<a id="x203-06"></a>

**203.06**　“Is the change in colour a **reliable** indication of the **identity** of the **liquid**?”

> 「色の変化は、その液体が何かを見分けるための、信頼できる手がかりになるかな」

<a id="x203-07"></a>

**203.07**　My daughter shook her head and asked for another sample.

> 娘は首を振り、別の試料を頼んだ。

<a id="x203-08"></a>

**203.08**　A second clear **fluid** produced a **comparable** **effect**.

> 二つ目の透明な液も似た効果を生んだ。

<a id="x203-09"></a>

**203.09**　“The aim of the **experiment** is to **examine** a **hypothesis**,” he said.

> 「実験の目的は仮説を調べることだ」と講師が言った。

<a id="x203-10"></a>

**203.10**　“A **positive** **finding** can **weaken** one idea without proving another.”

> 「ある反応が出れば一つの考えは弱まるかもしれない。でも別の考えの証明になるとは限らないよ」

<a id="x203-11"></a>

**203.11**　She added a **diagram** and a **detailed** note on her **methodology**.

> 娘は図を描き、自分の調べ方について詳しく書き添えた。

<a id="x203-12"></a>

**203.12**　She also noted one **methodological** **defect**: we had used the same **instrument** twice.

> 方法上の欠点も一つ記した。同じ器具を二度使っていたのだ。

**読みの問い**　二種類の液を試したことで、どんな結論を急がずにすんだか。

<a id="ex-story-204"></a>

### 204　貸し出し記録

<a id="x204-01"></a>

**204.01**　We went to **examine** the **register** in the **main** library.

> 中央図書館で台帳を調べた。

<a id="x204-02"></a>

**204.02**　The first **column** gave the date of **purchase**, the second the **price**.

> 最初の欄には購入日、次の欄には値段が載っていた。

<a id="x204-03"></a>

**204.03**　An entry in **August** showed the **hire** of twelve umbrellas at a **modest** **cost**.

> 八月には、手頃な料金で傘を十二本借りた記録があった。

<a id="x204-04"></a>

**204.04**　A **prior** **arrangement** let the library **distribute** them to **eligible** **guests**.

> 前もって取り決めがあり、図書館は対象となる来場者に傘を配れた。

<a id="x204-05"></a>

**204.05**　A deposit was **due** on **departure**, with an **exception** for anyone staying at the **hotel**.

> 出発の際には預かり金が必要だったが、ホテルに泊まる人は例外だった。

<a id="x204-06"></a>

**204.06**　“Does the **closure** of an **account** **indicate** that the umbrella came back?”

> 「口座が閉じられた記録があれば、傘も返ったということですか」

<a id="x204-07"></a>

**204.07**　“No, it can also mean the **client** paid to **replace** it.”

> 「いいえ、利用者が弁償したという場合もあります」

<a id="x204-08"></a>

**204.08**　The **landlord** of the hotel had written a **letter** to confirm the **total**.

> ホテルの主人が総数を確認する手紙を出していた。

<a id="x204-09"></a>

**204.09**　His signature was **genuine**, but the **count** was **wrong**.

> 署名は本物だったが、数が間違っていた。

<a id="x204-10"></a>

**204.10**　We found the error when we added a **further** delivery that had come in **September**.

> 九月に届いた追加分を足すと、間違いが分かった。

<a id="x204-11"></a>

**204.11**　“Who checks the **accuracy** of these returns?”

> 「こうした報告の内容が正確かどうかは、誰が調べるんですか」

<a id="x204-12"></a>

**204.12**　The clerk took off her **hat** and pointed to herself.

> 係の女性は帽子を取ると、自分を指さした。

**読みの問い**　口座が閉じられただけで傘の返却を確認できないのはなぜか。

<a id="ex-story-205"></a>

### 205　公聴会に椅子を一脚

<a id="x205-01"></a>

**205.01**　The **council** had called an **official** **meeting** on the **allocation** of public money.

> 議会では、公金の配分を話し合う公式の会議が開かれていた。

<a id="x205-02"></a>

**205.02**　In the **absence** of the **chairman**, a **delegate** from the **northern** district agreed to **chair** it.

> 議長が欠席したため、北部地区の代表が議事を進めることになった。

<a id="x205-03"></a>

**205.03**　An **eager** **advocate** for better **housing** stood by the **spare** chair.

> 住宅事情の改善に熱心な活動家が、空いた椅子のそばに立っていた。

<a id="x205-04"></a>

**205.04**　“Does our **mandate** **extend** to the **estate** beyond the highway?” she asked.

> 「大通りの向こうの住宅団地まで、私たちに権限はあるんですか」

<a id="x205-05"></a>

**205.05**　The **mayor** brought out a map to **locate** the exact boundary.

> 町長は地図を出して正確な境界を探した。

<a id="x205-06"></a>

**205.06**　The estate lay in a **neighbouring** district under a different **administration**.

> 団地は別の行政機関が管轄する隣の地区にあった。

<a id="x205-07"></a>

**205.07**　“Then we need a **partnership**,” she said, “and a **concrete** plan.”

> 「それなら、協力関係と具体的な計画が必要ですね」

<a id="x205-08"></a>

**205.08**　A **taxpayer** argued that a **substantial** **deficit** would **weaken** both districts.

> ある納税者は、大幅な赤字が出たら両地区とも苦しくなると主張した。

<a id="x205-09"></a>

**205.09**　The mayor offered a **compromise**: **share** a single **facility** and **divide** the **cost**.

> 町長は施設を一つ共同で使い、費用を分担する妥協案を出した。

<a id="x205-10"></a>

**205.10**　The woman asked them to **amend** the proposal to **include** tenants in the decision.

> 女性は、借り手も決定に加われるよう提案を修正してほしいと求めた。

<a id="x205-11"></a>

**205.11**　There was **vocal** opposition, then a long **pause**, then a **vote**.

> 声を上げて反対する人がいた。長い間を置いてから採決に入った。

<a id="x205-12"></a>

**205.12**　The **outcome** was clear: tenants could now send their own representative.

> 結論は明快だった。借り手は今後、自分たちで代表を出せる。

<a id="x205-13"></a>

**205.13**　A girl in a wet coat sat down in the spare chair.

> ぬれたコートの少女が、空いていた椅子に腰掛けた。

**読みの問い**　女性が費用の分担以外に求めたのは何か。

<a id="ex-story-206"></a>

### 206　水面を走った光

<a id="x206-01"></a>

**206.01**　A **crowd** had gathered along the **shore** of the **lake** to **await** the evening **race**.

> 夕方のレースを待つ人々が湖岸に集まっていた。

<a id="x206-02"></a>

**206.02**　A **sailor** checked the **anchor** and the **protective** **net** at the **front** of his boat.

> 船乗りが、いかりと船首の防護網を調べた。

<a id="x206-03"></a>

**206.03**　A child on the shore had found a **shell** with a hole just like the one in our umbrella.

> 岸辺の子どもが、私たちの傘に開いたのとそっくりな穴のある貝殻を見つけていた。

<a id="x206-04"></a>

**206.04**　The **light** racing boat had no room for a **passenger**.

> 軽い競技艇には、客が乗る余地がなかった。

<a id="x206-05"></a>

**206.05**　The **coach** made his **team** practise the first stroke before the **signal**.

> コーチは合図が出る前に、最初のひとかきを練習させた。

<a id="x206-06"></a>

**206.06**　At first the boat **rocked** from **side** to side.

> 最初、艇は左右に揺れた。

<a id="x206-07"></a>

**206.07**　“**Grasp** the handle with a **light** grip and keep the **rhythm**,” he called.

> 「軽く握って、リズムを保って」と声が飛んだ。

<a id="x206-08"></a>

**206.08**　The **pace** began to **accelerate** as the team found their balance.

> こぎ手たちが姿勢の安定をつかむと、次第にペースが上がった。

<a id="x206-09"></a>

**206.09**　Their nearest **opponent** tried to **steer** across their path.

> いちばん近い相手が、進路を横切るようにかじを切った。

<a id="x206-10"></a>

**206.10**　A **wise** change of direction prevented a **clash**.

> 賢明な方向転換で衝突を避けられた。

<a id="x206-11"></a>

**206.11**　The setting sun made a path of **copper** across the water.

> 夕日が水面に銅色の道を作っていた。

<a id="x206-12"></a>

**206.12**　At the **end** of that path we could see the red **flag** on the **mainland**.

> その道の端に、本土側の赤旗が見えた。

<a id="x206-13"></a>

**206.13**　The sailor turned to me: “That was the **shout** I heard.”

> 船乗りは私に向き直った。「私が聞いた叫び声は、あれだったんです」

**読みの問い**　船乗りの証言は何を手がかりに意味が分かったか。

<a id="ex-story-207"></a>

### 207　菓子の印

<a id="x207-01"></a>

**207.01**　At the **market** a **cook** offered me a **bowl** of hot **beef** and **bean** soup.

> 市場で料理人が、牛肉と豆の温かいスープを一杯差し出した。

<a id="x207-02"></a>

**207.02**　My daughter chose a **slice** of **bread** with **cheese** from a **nearby** **dairy**.

> 娘は、近くの乳製品店のチーズをのせたパンを一切れ選んだ。

<a id="x207-03"></a>

**207.03**　“Bread has no **flavour** without a little salt,” the cook said.

> 「パンは塩を少し入れないと味がしない」と料理人が言った。

<a id="x207-04"></a>

**207.04**　He took some **flour** and a **nut** from the shelf and asked us to guess the recipe.

> 棚から小麦粉と木の実を取ると、どんなレシピか当ててみてと言った。

<a id="x207-05"></a>

**207.05**　He **chopped** the nut, added a spoon of fat and pressed the **mix** into a **flat** **disc**.

> 木の実を刻み、脂をひとさじ加え、混ぜたものを平たい円盤状に押し広げた。

<a id="x207-06"></a>

**207.06**　On each **biscuit** he used a **fork** to **draw** a **distinctive** line.

> ビスケット一つ一つにフォークで特徴のある線を引いた。

<a id="x207-07"></a>

**207.07**　“Now the ones with nuts look different.”

> 「これで木の実入りのものは見分けがつくだろう」

<a id="x207-08"></a>

**207.08**　He pointed to a **plain** **can** of **tomatoes** near the **fridge**.

> 冷蔵庫近くの飾り気のないトマト缶を指した。

<a id="x207-09"></a>

**207.09**　“My wife leaves one red mark for the sweet ones and two for the **acid** ones.”

> 「妻は甘いものには赤い印を一つ、酸っぱいものには二つ付けるんだ」

<a id="x207-10"></a>

**207.10**　A customer pushed a **coin** into his **palm** and took the last warm biscuit.

> 客が料理人の手のひらに硬貨を押し込み、最後の温かいビスケットを取った。

<a id="x207-11"></a>

**207.11**　The cook had given us a new **alternative**: the mark might **identify** the **contents**.

> 料理人のおかげで新しい可能性に気づいた。印は中身を区別していたのかもしれない。

**読みの問い**　菓子の線と缶の赤い印に共通する働きは何か。

<a id="ex-story-208"></a>

### 208　舞台を一歩降りると

<a id="x208-01"></a>

**208.01**　At the **academy**, an **actor** was teaching a **classroom** full of children to **act** without a **stage**.

> 芸術学校では、俳優が教室いっぱいの子どもたちに、舞台を使わず演じる方法を教えていた。

<a id="x208-02"></a>

**208.02**　“**Enter** as a **royal** **princess** who has just lost her **kingdom**.”

> 「国を失ったばかりの王女になって入ってごらん」

<a id="x208-03"></a>

**208.03**　My daughter took one **step**, then **paused** in the **midst** of the **crowd**.

> 娘は一歩踏み出し、人々の真ん中で立ち止まった。

<a id="x208-04"></a>

**208.04**　A boy with **golden** **hair** went down on one knee to **kiss** her hand.

> 金髪の少年が片膝をついて娘の手に口づけした。

<a id="x208-05"></a>

**208.05**　“Will you **defend** me against a **brutal** **enemy**?” she asked.

> 「むごい敵から私を守ってくださいますか」と娘は尋ねた。

<a id="x208-06"></a>

**208.06**　“I will, but my **knee** is already **hurt**,” he said, and the room filled with **laughter**.

> 「お守りします。でも、もう膝が痛いです」と少年が言い、部屋中に笑いが広がった。

<a id="x208-07"></a>

**208.07**　The boy pretended to throw a **punch**, then held his hand out to help the princess up.

> 少年はパンチを繰り出すふりをしてから、王女を起こそうと手を差し伸べた。

<a id="x208-08"></a>

**208.08**　The actor **praised** the **comic** **turn** and the **clever** shift from grief to **comedy**.

> 俳優は、滑稽な展開と、悲しみから喜劇に移る巧みさを褒めた。

<a id="x208-09"></a>

**208.09**　“The **plot** can stay the same while the **characterization** changes.”

> 「筋が同じでも、人物の描き方は変わるんだ」

<a id="x208-10"></a>

**208.10**　He invited a **quiet** girl to **direct** a more **romantic** **version**.

> 次は物静かな少女に、もっとロマンチックな版の演出を任せた。

<a id="x208-11"></a>

**208.11**　Her princess **refused** the crown and invited her **dear** friend to **dance**.

> 彼女の王女は王冠を断り、親友を踊りに誘った。

<a id="x208-12"></a>

**208.12**　She crossed the room with such **grace** that nobody noticed her heavy shoes.

> 優雅に部屋を横切ったので、重い靴を履いていることには誰も気づかなかった。

<a id="x208-13"></a>

**208.13**　For the last performance, my daughter played the **sole** **observer** at a **grand** **celebration**.

> 最後の上演では、娘は盛大な祝宴をただ一人眺めている役を演じた。

<a id="x208-14"></a>

**208.14**　“Her **role** is to **note** who **leaves**,” the director said.

> 「この役の仕事は、誰が出ていくかに気づくこと」と演出役の少女が言った。

<a id="x208-15"></a>

**208.15**　For the first **time** I noticed all the actors who made a party look **crowded** before they went home.

> 帰る前に宴を人でいっぱいに見せてくれていた大勢の役者に、私はそこで初めて気づいた。

**読みの問い**　王女が冠を受け取らない結末は、何を変える練習だったか。

<a id="ex-story-209"></a>

### 209　切れた幕の向こう

<a id="x209-01"></a>

**209.01**　The **cinema** behind the academy was showing a **cult** film about an **alien** who wanted a **visa**.

> 学校の裏の映画館では、ビザを欲しがる宇宙人を描いた、熱烈なファンのいる作品がかかっていた。

<a id="x209-02"></a>

**209.02**　Its **director** had once been a **contemporary** of the old **film-maker** at our table.

> 監督は、私たちのテーブルにいた年配の映画作家と同時代の人だった。

<a id="x209-03"></a>

**209.03**　“People **remember** the **frightening** **monster** and forget the **ordinary** clerk,” he said.

> 「怖い怪物は覚えていても、普通の窓口係の方は忘れられる」と映画作家は言った。

<a id="x209-04"></a>

**209.04**　“The clerk has the **ability** to **terrify** the monster with a **basic** **application** form.”

> 「その係は、ごく基本的な申請書で怪物をおびえさせる力を持っているんだよ」

<a id="x209-05"></a>

**209.05**　On screen, the alien tried to **conceive** of a world without the **existence** of borders.

> 画面の中で宇宙人は、国境というものが存在しない世界を思い描こうとしていた。

<a id="x209-06"></a>

**209.06**　A clerk asked for **confirmation** of its **residence** and the **duration** of its **stay**.

> 係員は住所と滞在期間の確認を求めた。

<a id="x209-07"></a>

**209.07**　A **confusing** form gave the creature a choice of **gender** and **ethnicity** but no space for its **native** **language**.

> 紛らわしい用紙には性別と民族の選択欄はあったが、母語を書く場所がなかった。

<a id="x209-08"></a>

**209.08**　A **lesbian** couple offered to **accompany** it to the **embassy** and **speak** on its behalf.

> レズビアンのカップルが、大使館まで付き添って代わりに話そうと申し出た。

<a id="x209-09"></a>

**209.09**　One was a lawyer who had won **asylum** for a **seeker** after a **previous** **refusal**.

> 片方は、一度申請を拒否された人のために、庇護を認めさせた弁護士だった。

<a id="x209-10"></a>

**209.10**　The other was her **wife**, a **journalist** who knew the **importance** of a **correct** **spelling**.

> もう一人はその弁護士の妻で、正しくつづることの大切さを知る記者だった。

<a id="x209-11"></a>

**209.11**　Then **black** filled the screen and the entire audience began to **worry**.

> そこで画面が暗転し、観客みんなが心配し始めた。

<a id="x209-12"></a>

**209.12**　The old man **smiled**: “The film is over; the rest is your **story**.”

> 老人はほほえんだ。「映画はここまで。その先は君たちの物語だ」

**読みの問い**　宇宙人の場面で、書類が障壁になる様子はどう描かれたか。

<a id="ex-story-210"></a>

### 210　列車の最後尾

<a id="x210-01"></a>

**210.01**　At the **junction** two **trains** stood on **parallel** lines beneath a **dense** **cloud** of **smoke**.

> 分岐点では、濃い煙の下、並行する線路に二本の列車が停まっていた。

<a id="x210-02"></a>

**210.02**　The **engine** of the first needed a new **component**, a **mechanic** explained.

> 片方の機関車には新しい部品が要ると整備士が説明した。

<a id="x210-03"></a>

**210.03**　He would **strip** away the outer layer, **fix** the **electrical** contact and **seal** the **joint**.

> 外層を剥がし、電気接点を直して、継ぎ目を密閉するという。

<a id="x210-04"></a>

**210.04**　The second train was ready to **depart**, but we had the **wrong** **ticket**.

> もう一本は出発できる状態だったが、私たちの切符はその列車のものではなかった。

<a id="x210-05"></a>

**210.05**　At the **rear** of the last **carriage** an **aged** **gentleman** held up a **bunch** of keys.

> 最後の車両の後部で、年配の紳士が鍵の束を掲げた。

<a id="x210-06"></a>

**210.06**　“**Grab** the **bar** and **lift** the window,” he told the guard.

> 「棒をつかんで窓を持ち上げてください」と彼は車掌に言った。

<a id="x210-07"></a>

**210.07**　A red thread had been caught in the **narrow** **gap** between two sheets of glass.

> 二枚のガラスの狭い隙間に赤い糸が挟まっていた。

<a id="x210-08"></a>

**210.08**　We could **hook** it out, but we might **rip** the **delicate** **fibre**.

> 引っかけて取り出せそうだったが、繊細な繊維を裂いてしまうおそれがあった。

<a id="x210-09"></a>

**210.09**　“**Try** a **fine** needle,” suggested an **alert** **passenger** in a **silk** coat.

> 「細い針でやってみて」と絹のコートを着た目ざとい乗客が言った。

<a id="x210-10"></a>

**210.10**　The thread came free and fell across my **palm** like a **minute** **crack**.

> 糸は外れて手のひらに落ち、小さなひびのような線を描いた。

<a id="x210-11"></a>

**210.11**　Its colour was brown on the **outside** and red in the **deep** **fold**.

> 糸は外側が茶色で、深い折れ目の中が赤かった。

**読みの問い**　糸の取り出し方に注意したのはなぜか。

<a id="ex-story-211"></a>

### 211　分刻みの移動

<a id="x211-01"></a>

**211.01**　We had a **wait** of one hour before the next **service**, so we walked into **town**.

> 次の便まで一時間の待ち時間があり、私たちは町へ歩いた。

<a id="x211-02"></a>

**211.02**　A **motorist** stopped when a **spare** **tyre** fell from a **van** onto the **highway**.

> バンの予備タイヤが幹線道路に落ち、運転中の人が車を止めた。

<a id="x211-03"></a>

**211.03**　A boy on a **bike** had to slow down and **grip** the handle with both hands.

> 自転車の少年は速度を落とし、両手でハンドルをしっかり握らねばならなかった。

<a id="x211-04"></a>

**211.04**　His **helmet** fell against the **side** of a parked car.

> 少年のヘルメットが駐車中の車の側面に当たった。

<a id="x211-05"></a>

**211.05**　We helped him **park** his bike and **clear** the road before the **traffic** could **speed** up.

> 車の流れが速くなる前に、少年が自転車を止めて道を空けるのを手伝った。

<a id="x211-06"></a>

**211.06**　He had a **bad** **cut** on his leg but remained **all right** apart from that.

> 少年は脚をひどく切ったが、それ以外は無事だった。

<a id="x211-07"></a>

**211.07**　A **tourist** offered a **tissue**; his **girlfriend** offered to drive the boy home.

> 旅行者がティッシュを差し出し、彼の恋人は少年を家まで送ろうと申し出た。

<a id="x211-08"></a>

**211.08**　Before he got up, he moved each **limb** in turn.

> 少年は立ち上がる前に、手足を一本ずつ動かしてみた。

<a id="x211-09"></a>

**211.09**　The boy gave them a nod of **thanks** and asked them to phone his parents.

> 少年は感謝してうなずくと、両親に電話してほしいと頼んだ。

<a id="x211-10"></a>

**211.10**　“He had the **courage** to **stand** still,” my daughter said.

> 「あの子、動かずにいる勇気があったね」と娘は言った。

<a id="x211-11"></a>

**211.11**　“He had the **wisdom** to wait for a clear road,” I said.

> 「道が空くまで待つ判断ができたんだ」と私は言った。

**読みの問い**　少年が危険を広げずに済んだのはなぜか。

<a id="ex-story-212"></a>

### 212　せりにかけられた絵

<a id="x212-01"></a>

**212.01**　A **regional** **artwork** **competition** had just ended at the gallery.

> 画廊で地域の美術コンクールが終わったところだった。

<a id="x212-02"></a>

**212.02**　The winner had donated her **prize** to a **fundraising** **venture** for the local **youth** club.

> 優勝者は、地元の青少年クラブの資金集めに賞品を寄付した。

<a id="x212-03"></a>

**212.03**　I watched a **businessman** **bid** for a painting of a **coastal** **province** at night.

> 夜の沿岸地域を描いた絵に、実業家が値をつけた。

<a id="x212-04"></a>

**212.04**　A **fan** of the painter offered to **top** his bid by one **buck**.

> 画家のファンが、そこに一ドル上乗せすると申し出た。

<a id="x212-05"></a>

**212.05**　“You cannot **afford** that!” cried her **cousin** from the back **row**.

> 「そんなに払えないだろう」と後ろの列からいとこが叫んだ。

<a id="x212-06"></a>

**212.06**　“I can if we **trade** the **golf** clubs we never use,” she said.

> 「使っていないゴルフクラブを売れば払えるよ」と彼女は答えた。

<a id="x212-07"></a>

**212.07**　A small percentage of every **transaction** would **benefit** the students; the artist was the other **beneficiary**.

> 売買ごとに代金のわずかな割合が生徒たちのために使われ、画家もまた、その取引から恩恵を受けることになっていた。

<a id="x212-08"></a>

**212.08**　They **completed** the **deal** by shaking hands, without a single **cent** in **cash** changing hands.

> 現金を一セントも受け渡さないまま、握手で取引は成立した。

<a id="x212-09"></a>

**212.09**　The picture showed a **vast** **sky** above a **western** **horizon** and the **hollow** remains of a **factory**.

> 絵には、西の地平線に広がる大空と、中が空洞になった工場跡が描かれていた。

<a id="x212-10"></a>

**212.10**　Its **beauty** lay in a contrast between bright **white** and **deep** **brown**.

> その絵の美しさは、明るい白と深い茶色の対比にあった。

<a id="x212-11"></a>

**212.11**　The artist kept a **modest** smile and began to **sign** the frame.

> 画家は控えめにほほえみ、額縁に署名を始めた。

**読みの問い**　握手の時点で現金が動かなかったのに、何が成立したか。

<a id="ex-story-213"></a>

### 213　負ける確率、勝つ理由

<a id="x213-01"></a>

**213.01**　In the **park** a **noisy** **band** welcomed the **players** to the town **championship**.

> 公園では、にぎやかな楽団が町の選手権に出る選手たちを迎えていた。

<a id="x213-02"></a>

**213.02**　My **son** had come to **bat** against the top player in his age **category**.

> 息子は同年代の部門で最強の選手の球を打つために来ていた。

<a id="x213-03"></a>

**213.03**　His **ambition** was to **win** one **run** for his team.

> チームのために一点を取るのが息子の夢だった。

<a id="x213-04"></a>

**213.04**　At the first ball he was too **impatient** and gave the ground a **kick**.

> 最初の球では焦りすぎて、地面をひと蹴りした。

<a id="x213-05"></a>

**213.05**　“**Time** your swing to the ball,” I said, “and **aim** for the space behind the tree.”

> 「球に合わせて振って、木の後ろの空間を狙うんだよ」と私は言った。

<a id="x213-06"></a>

**213.06**　He had to **compete** against **skilled** children who played **sport** each **week**.

> 相手は毎週スポーツをする、腕の立つ子どもたちだった。

<a id="x213-07"></a>

**213.07**　His sister tried to **boost** his confidence by singing a **lively** **lyric** from his **favourite** song.

> 娘は、息子のお気に入りの歌の元気な一節を歌って、息子を勇気づけようとした。

<a id="x213-08"></a>

**213.08**　The next ball rose to a **great** **height** and cleared the far gate.

> 次の球は高く上がり、遠くの門を越えた。

<a id="x213-09"></a>

**213.09**　Their first **win** in three **consecutive** years brought a **boost** to the whole club.

> 三年ぶりの勝利で、クラブ全体が元気づいた。

<a id="x213-10"></a>

**213.10**　At the **pub**, a **casual** **guy** had tried to **predict** the score and **calculate** the **odds**.

> パブでは気さくな男が得点を予想し、勝つ確率を計算しようとしていた。

<a id="x213-11"></a>

**213.11**　“An **average** tells you about a **team**, not what will **happen** on the next ball,” my son told him.

> 「平均でチームのことは分かっても、次の一球で何が起きるかは分からないよ」と息子は言った。

<a id="x213-12"></a>

**213.12**　He liked a **competitive** game for **fun**; **gambling** would **ruin** it for him.

> 息子は競い合う楽しさが好きで、賭け事を入れたら台なしだと思っていた。

<a id="x213-13"></a>

**213.13**　After the **match** he took both teams to see the umbrella.

> 試合が終わると、息子は両方のチームを誘って傘を見に行った。

**読みの問い**　息子は平均から何が読み取れると考えたか。

<a id="ex-story-214"></a>

### 214　地下で揺れた家

<a id="x214-01"></a>

**214.01**　In a museum **wing** a **virtual** **earthquake** threatened to **devastate** an entire **coastal** **town**.

> 博物館の一棟では、仮想の地震が海沿いの町全体を壊滅させかねなかった。

<a id="x214-02"></a>

**214.02**　The **set-up** let each **participant** **construct** a house on an **unstable** **base**.

> この展示では参加者がそれぞれ、不安定な土台の上に家を建てられた。

<a id="x214-03"></a>

**214.03**　I used a **block** of **iron**; my son chose a **cheap** piece of **plastic**.

> 私は鉄の塊を使い、息子は安いプラスチック片を選んだ。

<a id="x214-04"></a>

**214.04**　When the floor began to **rock**, the **force** of **gravity** made my tower collapse.

> 床が揺れ始めると、私の塔は重力で崩れた。

<a id="x214-05"></a>

**214.05**　Its **destruction** sent **fragments** and **debris** across the board.

> 塔は壊れ、破片やがれきが台の上に飛び散った。

<a id="x214-06"></a>

**214.06**　His house had the **flexibility** to **shift** without falling, a **remarkable** **attribute**.

> ところが息子の家には揺れても倒れない柔軟性があった。見事な特性だった。

<a id="x214-07"></a>

**214.07**　He began to **rebuild** mine on a **stable** **surface** to **demonstrate** a different principle.

> 別の原理を見せようと、息子は私の家を安定した面の上に建て直し始めた。

<a id="x214-08"></a>

**214.08**　“One **screw** here can **strengthen** the structure without changing its **appearance**.”

> 「ここにねじを一本入れれば、見た目を変えずに構造を強くできるよ」

<a id="x214-09"></a>

**214.09**　A **monitor** showed the **intensity** of each **experimental** **shake**.

> モニターには実験で起こした揺れの強さが毎回表示された。

<a id="x214-10"></a>

**214.10**　The **technical** **handout** gave the **formula** for the **optimal** **size** of each support.

> 技術解説の配布資料には、支柱ごとの最適な寸法を求める式が載っていた。

<a id="x214-11"></a>

**214.11**　Our third house could survive a shock that would **level** the first two.

> 三軒目の家は、最初の二軒なら倒壊するほどの衝撃にも耐えられた。

<a id="x214-12"></a>

**214.12**　Only the red umbrella, resting against the wall, fell over every time.

> 壁に立てかけた赤い傘だけは、毎回倒れた。

**読みの問い**　息子の家を最初に守っていた性質は何だったか。

<a id="ex-story-215"></a>

### 215　音が届かない席

<a id="x215-01"></a>

**215.01**　The next **event** was a **moving** **opera** about the **adoption** of a child.

> 次の催しは、ある子どもが養子として迎えられることを描いた、心を動かすオペラだった。

<a id="x215-02"></a>

**215.02**　A **divorced** mother sang to a child who was too **excited** to **sleep**.

> 離婚した母親が、興奮して眠れない子どもに歌いかけた。

<a id="x215-03"></a>

**215.03**　“Nothing will hurt you here,” went the song, with a **piano** to **accompany** her.

> ピアノの伴奏に乗せて、「ここでは何もあなたを傷つけない」と歌った。

<a id="x215-04"></a>

**215.04**　A **choir** began to **sing** behind the audience, and the **sound** seemed to **surround** us.

> 客席の後ろで合唱団が歌い始め、音に包まれるようだった。

<a id="x215-05"></a>

**215.05**　My **neighbour** could not **hear** the soft notes because one **speaker** had failed.

> スピーカーが一つ壊れ、隣の人には弱い音が聞こえなかった。

<a id="x215-06"></a>

**215.06**　A boy left his **seat** to **tap** the shoulder of the nearest **professional**.

> 少年が席を立ち、近くの専門スタッフの肩を軽くたたいた。

<a id="x215-07"></a>

**215.07**　The woman asked him to **give** a **descriptive** **account** of the fault.

> 女性はどんな不具合か具体的に話して、と頼んだ。

<a id="x215-08"></a>

**215.08**　“When the choir sings, we hear them; when the mother sings, we see her mouth move.”

> 「合唱団が歌うと声が聞こえます。お母さんが歌うと、口が動くのが見えます」

<a id="x215-09"></a>

**215.09**　It was an **excellent** **comparison**; the engineer knew which part to **replace**.

> 見事な比較だった。技師はどの部品を取り替えるべきか分かった。

<a id="x215-10"></a>

**215.10**　This **substitution** took a **third** of the time we had expected.

> 交換にかかった時間は予想の三分の一だった。

<a id="x215-11"></a>

**215.11**　The **revival** of the **music** brought an **immediate** change in the **emotion** on every face.

> 音楽が戻るとすぐに、みんなの表情に浮かぶ感情が変わった。

<a id="x215-12"></a>

**215.12**　My neighbour called the boy a **hero**; he was **content** just to enjoy the rest of the show.

> 隣の人は少年を英雄と呼んだ。少年は残りの舞台を楽しめれば満足そうだった。

**読みの問い**　少年の説明で、技師はどうして故障箇所を絞れたか。

<a id="ex-story-216"></a>

### 216　連絡のつかない晩

<a id="x216-01"></a>

**216.01**　In the **darkness** outside, **rain** began to **flood** the steps of the **underground** station.

> 外は暗く、雨で地下駅の階段に水があふれ始めていた。

<a id="x216-02"></a>

**216.02**　The **constant** noise of **driving** rain made it difficult to hear.

> 激しく打ちつける雨の音が絶えず、声が聞き取りにくかった。

<a id="x216-03"></a>

**216.03**　A **phone** **message** warned of a **restriction** on **transit** after ten.

> 電話には十時以降の通行制限を知らせるメッセージが来ていた。

<a id="x216-04"></a>

**216.04**　Water could **leak** into the **hardware** and **trigger** a **fire** **alarm**.

> 水が機器に入り込み、火災報知器を作動させるおそれがあった。

<a id="x216-05"></a>

**216.05**　The **operational** plan was to **pump** the water into a spare **tank**.

> 作業計画は、水を予備タンクにポンプでくみ上げるというものだった。

<a id="x216-06"></a>

**216.06**　Its **capacity** was limited, and the **infrastructure** was already under **pressure**.

> 容量は限られ、設備はすでに負荷を受けていた。

<a id="x216-07"></a>

**216.07**　We needed a **backup** way to **communicate** if the **broadband** link went down.

> ブロードバンド回線が切れた場合に備え、別の連絡手段が必要だった。

<a id="x216-08"></a>

**216.08**　My son tried to **email** an update to the **website**, but the **internet** had stopped working.

> 息子は最新情報をウェブサイト宛てにメールしようとしたが、インターネットは使えなくなっていた。

<a id="x216-09"></a>

**216.09**　A man on a bike could still **carry** a **memo** across the bridge.

> それでも自転車の使者なら、橋を渡って連絡票を届けられる。

<a id="x216-10"></a>

**216.10**　The clerk gave him a clear **outline** of the **task** and a **short** **summary** of the **notice**.

> 係員は仕事内容をはっきり説明し、告知の短い要約も伝えた。

<a id="x216-11"></a>

**216.11**　He offered to **mail** the report later, when the **present** **chaos** had passed.

> 今の混乱が収まったら、報告書をあとで郵送すると彼は申し出た。

<a id="x216-12"></a>

**216.12**　“You can **postpone** the report,” said the clerk, “but the news cannot wait.”

> 「報告書は後回しで構いません。でもこの知らせは待ったなしです」と係員は言った。

**読みの問い**　回線が切れたあと、代わりに何が機能したか。

<a id="ex-story-217"></a>

### 217　何を残すか

<a id="x217-01"></a>

**217.01**　The man on the bike delivered his note at a **colonial** **residence** with **extraordinary** **architecture**.

> 使者は、並外れた建築様式を持つ植民地時代の邸宅に連絡票を届けた。

<a id="x217-02"></a>

**217.02**　A committee there was holding a **discussion** on the **preservation** of a **sacred** painting.

> そこでは委員会が、神聖な絵の保存を話し合っていた。

<a id="x217-03"></a>

**217.03**　The artistic **style** was **foreign**, but the subject was a **native** **animal**.

> 画風は外国由来だったが、題材は地元に生息する動物だった。

<a id="x217-04"></a>

**217.04**　A **legendary** **elephant** carried a dead soldier from a **battlefield** to the **sea**.

> 伝説の象が、亡くなった兵士を戦場から海まで運んでいる。

<a id="x217-05"></a>

**217.05**　The artist had used **wool** and **silk** to **decorate** the **elaborate** frame.

> 作り手は羊毛と絹を使って、凝った額縁を飾っていた。

<a id="x217-06"></a>

**217.06**　The **congregation** that owned the picture wanted another **generation** to **inherit** it.

> この絵を所有する宗教共同体は、次の世代へ引き継ぎたかった。

<a id="x217-07"></a>

**217.07**　A **secular** **institute** offered a **long-term** **investment** in its **care**.

> 宗教的な性格を持たない機関が、絵の維持管理に長期的な資金を投じると申し出た。

<a id="x217-08"></a>

**217.08**　One conservative member expressed a **sincere** **objection**: who would **control** the display?

> 保守的な一員が率直な異議を唱えた。展示を決める権限は誰が持つのか。

<a id="x217-09"></a>

**217.09**　His **faith** was **integral** to his **life**, and he wanted visitors to respect the picture.

> 信仰は彼の人生に欠かせず、来館者にもその絵を大切にしてほしかった。

<a id="x217-10"></a>

**217.10**　An **educated** **neighbour** offered to **mediate** the **dispute** and find **mutual** **terms**.

> 学識のある近隣住民が、争いを仲裁し、双方が納得する条件を探ろうと申し出た。

<a id="x217-11"></a>

**217.11**　They reached a **consensus**: both groups would **guard** the painting, and the ownership would remain clear.

> 両者で絵を守り、所有権が誰にあるかは明確にしておくという合意に達した。

**読みの問い**　保存費用を出すという申し出だけでは、なぜ話がまとまらなかったか。

<a id="ex-story-218"></a>

### 218　泥の中の麦

<a id="x218-01"></a>

**218.01**　A **farmer** who had come from the **countryside** spoke of the last **drought**.

> 田舎から来た農家の人が、前回の干ばつを語った。

<a id="x218-02"></a>

**218.02**　“We used to **farm** **wheat** and keep a **pig** behind the house.”

> 「以前は小麦を作り、家の裏で豚を一頭飼っていました」

<a id="x218-03"></a>

**218.03**　The **heat** rose above the critical **threshold** for ten days in a **row**.

> 気温は十日連続で危険な水準を超えた。

<a id="x218-04"></a>

**218.04**　A **tropical** **breed** of pig had once done well there, but even its **offspring** grew **sick**.

> 熱帯地方の品種の豚は、かつてはその土地でよく育っていたが、その子どもまで具合が悪くなった。

<a id="x218-05"></a>

**218.05**　The family could not let the animals **starve**, so they began to sell their **goods**.

> 動物を飢えさせるわけにいかず、一家は持ち物を売り始めた。

<a id="x218-06"></a>

**218.06**　A **reduction** in local **poverty** would take more than a single harvest or a small **saving**.

> 地元の貧困を減らすには、一度の収穫やわずかな節約以上のものが必要だった。

<a id="x218-07"></a>

**218.07**　They formed an **enterprise** to **process** **surplus** grain and **provide** feed to other farms.

> そこで余った穀物を加工し、ほかの農場に飼料を供給する事業を立ち上げた。

<a id="x218-08"></a>

**218.08**　Its first **product** had a high **proportion** of **protein** and one added **vitamin**.

> 最初の製品はたんぱく質の割合が高く、ビタミンを一種類加えていた。

<a id="x218-09"></a>

**218.09**　That was their **breakthrough**: a **viable** **remedy** for two **associated** problems.

> これが突破口だった。一つの現実的な対策で、関連する二つの問題に対処できた。

<a id="x218-10"></a>

**218.10**　The family could **supplement** its **revenue** without increasing the **quantity** of land under wheat.

> 一家は小麦畑を増やさずに収入を補えた。

<a id="x218-11"></a>

**218.11**　A **sustainable** **future**, the farmer said, depended on the **survival** of the whole village.

> 農家の人は、持続可能な将来の前提は村全体が生き残ることだと言った。

**読みの問い**　新しい事業が同時に扱った二つの問題は何か。

<a id="ex-story-219"></a>

### 219　蝋の跡がついた手紙

<a id="x219-01"></a>

**219.01**　In **December** the museum had obtained a **manuscript** from a former **prisoner** of **war**.

> 十二月、博物館は元戦争捕虜から原稿を譲り受けていた。

<a id="x219-02"></a>

**219.02**　A **candle** had left a **sticky** mark across the **original** **declaration** of **independence** inside.

> 中に挟まれた独立宣言の原本に、ろうそくがべたつく跡を残していた。

<a id="x219-03"></a>

**219.03**　The **prisoner** had been a **civilian** until the **invasion** of his **nation**.

> 祖国が侵攻されるまで、彼は民間人だった。

<a id="x219-04"></a>

**219.04**　Under **martial** law the **military** could **detain** anybody without a **trial**.

> 戒厳令の下では、軍は誰でも裁判なしに拘束できた。

<a id="x219-05"></a>

**219.05**　His description of the **capture** of the capital differed from the **state** **version**.

> 首都陥落についての彼の記述は、国家の説明とは違っていた。

<a id="x219-06"></a>

**219.06**　A **commander** had refused an **order** to **shoot** people taking part in a **political** **march**.

> ある指揮官が政治的な行進の参加者を撃てとの命令を拒んだという。

<a id="x219-07"></a>

**219.07**　He feared a **bomb** attack but would not **assume** every protester was an **extremist**.

> 爆弾による襲撃を恐れてはいたが、抗議する人が皆過激派だと決めつけるつもりはなかった。

<a id="x219-08"></a>

**219.08**　The **dictator** had blamed him for the **rebellion** and called his **behaviour** a **violation** of the law.

> 独裁者は反乱の責任を彼に負わせ、その行動を違法と呼んだ。

<a id="x219-09"></a>

**219.09**　The commander had agreed to **obey** one final order: to **resign** and await arrest.

> 指揮官が従うと決めた最後の命令は、辞任して逮捕を待てというものだった。

<a id="x219-10"></a>

**219.10**　After the **assassination** of the dictator, a rumour spread that the commander had helped **murder** him.

> 独裁者が暗殺されたあと、指揮官が殺害に手を貸したという噂が広がった。

<a id="x219-11"></a>

**219.11**　“The **denial** in this letter came from him,” said the guide, “but his **guilt** cannot be settled by a letter.”

> 「この手紙で彼は否定しています。でも手紙一通で有罪かどうかは決まりません」と案内人は言った。

<a id="x219-12"></a>

**219.12**　My daughter noticed that the **military** **stamp** had been added after the mark from the candle had begun to **dry**.

> 娘は、ろうそくの跡が乾きかけたあとから軍の印が押されたことに気づいた。

**読みの問い**　手紙で分かることと、その手紙だけでは決まらないことは何か。

<a id="ex-story-220"></a>

### 220　法廷の椅子に座る

<a id="x220-01"></a>

**220.01**　A court set up for the exhibition let visitors **judge** an **infamous** case using **authentic** **documentation**.

> 模擬法廷では、実際の文書を使って悪名高い事件を判断できた。

<a id="x220-02"></a>

**220.02**　The **prosecutor** read the **indictment** and asked a **witness** to **recount** the arrest.

> 検察役が起訴状を読み、証人に逮捕時の様子を語り直すよう求めた。

<a id="x220-03"></a>

**220.03**　She could **allege** **fraud** but lacked the evidence to **prosecute** the **high-profile** **agent**.

> 詐欺の疑いは指摘できても、その有名な代理人を訴追する証拠が足りなかった。

<a id="x220-04"></a>

**220.04**　A **criminal** had used the **ID** of the agent to **deposit** money, the witness said.

> 証人によると、犯罪者が代理人の身分証を使って入金していた。

<a id="x220-05"></a>

**220.05**　“Can you **verify** the **identity** of the person in the **line-up**?”

> 「並んでいる人物が当人だとあなたは確認できますか」

<a id="x220-06"></a>

**220.06**　“I am **sorry**; from that distance I could only **infer** his **identity**.”

> 「申し訳ありません。あの距離からでは誰かを推測するしかありませんでした」

<a id="x220-07"></a>

**220.07**　My son wanted to **sentence** the man to **jail**, but another visitor asked about **bail**.

> 息子は男に収監を言い渡そうとしたが、別の来館者が保釈について尋ねた。

<a id="x220-08"></a>

**220.08**　“The accused is **innocent** in law until we find him **guilty**,” said the judge.

> 「有罪と判断するまでは、法の下では無罪です」と裁判官役が言った。

<a id="x220-09"></a>

**220.09**　A **procedural** error could **compromise** a **fair** hearing and **result** in a **judicial** order for a new one.

> 手続きの誤りが公正な審理を損なえば、司法の命令でやり直しになることもある。

<a id="x220-10"></a>

**220.10**　We could **invoke** a **precedent** but could not **impose** a **penalty** without more proof.

> 先例を引くことはできても、証拠が増えなければ罰は科せなかった。

<a id="x220-11"></a>

**220.11**　“**Justice** includes the **right** to an answer,” our daughter said, and voted to **overturn** the first **judgement**.

> 「答えを得る権利も、公正さには含まれる」と娘は言い、最初の判断を覆す方に票を投じた。

<a id="x220-12"></a>

**220.12**　The witness looked **hurt**; she had tried to be **honest** about the **extent** of her uncertainty.

> 証人役は傷ついた表情だった。自分がどの程度確信を持てないかを、正直に話そうとしていたのだ。

**読みの問い**　証人が正直でも、その証言だけで身元を断定できないのはなぜか。

<a id="ex-story-221"></a>

### 221　調剤室の白い傘

<a id="x221-01"></a>

**221.01**　The **patient** who next approached us had a **chronic** **illness** and carried a white umbrella.

> 次に私たちに近づいてきた患者は持病があり、白い傘を持っていた。

<a id="x221-02"></a>

**221.02**　He had tried to **ease** pain with **medication** left over from a **past** **prescription**.

> 以前の処方で余った薬を使って痛みを和らげようとしたことがあるそうだ。

<a id="x221-03"></a>

**221.03**　A **qualified** nurse took time to **describe** how one extra **dose** could cause **harmful** **effects**.

> 資格を持つ看護師は時間をかけて、一回分多く薬を飲むだけでも、どのように有害な影響が生じ得るかを説明した。

<a id="x221-04"></a>

**221.04**　One **tablet** contained a medicine his **liver** could not **process** as quickly as before.

> その錠剤には、彼の肝臓が以前ほど速く処理できなくなった薬が含まれていた。

<a id="x221-05"></a>

**221.05**　The nurse used a **generic** name to **differentiate** the medicine from a **supplement** with similar packaging.

> 看護師は一般名を使い、似た包装のサプリメントとの違いを伝えた。

<a id="x221-06"></a>

**221.06**　A **biological** test could aid the doctor, but it could not **diagnose** every cause of the pain.

> 生物学的な検査は医師の助けになるが、痛みの原因がすべて診断できるわけではなかった。

<a id="x221-07"></a>

**221.07**　His **recovery** began when the nurse asked how his **treatment** fitted his daily **life**.

> 治療が日々の暮らしにどう合っているかを看護師が尋ねたころ、回復が始まった。

<a id="x221-08"></a>

**221.08**　His biggest difficulty was his **inability** to open the bottle when his fingers felt **tender**.

> いちばんの困りごとは、指が痛むときに瓶のふたを開けられないことだった。

<a id="x221-09"></a>

**221.09**　They found a **suitable** bottle and talked about the safe disposal of the old one.

> 二人は適した瓶を見つけ、古いものの安全な処分方法を話し合った。

<a id="x221-10"></a>

**221.10**　“I can **dispose** of it for you,” said the nurse, “and you can use this bag to **bring** the rest.”

> 「こちらで処分できます。残りもこの袋に入れてお持ちください」と看護師は言った。

<a id="x221-11"></a>

**221.11**　The patient **thanked** her and opened his umbrella over a child who had forgotten hers.

> 患者は礼を言い、傘を忘れた子の上に自分の傘を広げた。

**読みの問い**　薬の種類を確認したあとで、看護師が暮らしについて尋ねたのはなぜか。

<a id="ex-story-222"></a>

### 222　声を置く場所

<a id="x222-01"></a>

**222.01**　Under that umbrella stood a girl who had come to a **supportive** group for people living with **addiction**.

> その傘の下にいたのは、依存症とともに暮らす人を支える集まりに来た少女だった。

<a id="x222-02"></a>

**222.02**　“My father is in **recovery**,” she said, “and I have come to **volunteer**.”

> 「父が回復の途中なんです。私は手伝いに来ました」と言った。

<a id="x222-03"></a>

**222.03**　A **leaflet** gave a **comprehensive** **overview** of local **health** and **welfare** services.

> リーフレットには、地域の保健・福祉サービスを広く見渡せる案内が載っていた。

<a id="x222-04"></a>

**222.04**　One **section** concerned **depression** and the **psychological** **impact** of **trauma**.

> 一つの節では、うつ病と心の傷の心理的な影響を扱っていた。

<a id="x222-05"></a>

**222.05**　Another explained how to **respond** when someone spoke of **suicide** or showed signs of **distress**.

> 別の節では、自殺について口にした人や、苦しむ様子を見せた人への応じ方を説明していた。

<a id="x222-06"></a>

**222.06**　The girl took a **cup** of tea to a man in the **lobby** and gave him time to **drink**.

> 少女はロビーにいた男性にお茶を一杯運び、ゆっくり飲めるようにした。

<a id="x222-07"></a>

**222.07**　“I do not need **pity**,” he said, “but some **rest** would be **helpful**.”

> 「同情は要らないけれど、少し休めると助かる」と彼は言った。

<a id="x222-08"></a>

**222.08**　She found a seat and asked what else might **relieve** his **stress**.

> 少女は席を見つけ、ほかに何が負担を和らげるか尋ねた。

<a id="x222-09"></a>

**222.09**　On a **difficult** evening, she explained, a familiar sound could **wake** a **frightening** memory.

> つらい晩には、聞き慣れた音が怖い記憶を呼び起こすこともある、と少女は説明した。

<a id="x222-10"></a>

**222.10**　The father came out to **embrace** her, **glad** she had found a way to help.

> 父親が出てきて娘を抱きしめた。娘なりの手伝い方が見つかってうれしそうだった。

<a id="x222-11"></a>

**222.11**　For a **moment** they remained there, **content** to hold the umbrella together.

> 二人はしばらくそこにいた。一緒に傘を持っていられれば十分だった。

**読みの問い**　男性が実際に求め、少女が応じたことは何か。

<a id="ex-story-223"></a>

### 223　働く人の会計簿

<a id="x223-01"></a>

**223.01**　At a **grocery** beside the **mall**, a **shareholder** and an employee were arguing about pay.

> ショッピングモールの隣の食料品店で、株主と従業員が賃金をめぐって言い争っていた。

<a id="x223-02"></a>

**223.02**　The **firm** gave a **bonus** to anyone who could **attain** a monthly sales **quota**.

> その会社は月ごとの販売目標を達成した人に賞与を出していた。

<a id="x223-03"></a>

**223.03**　The **employer** hoped to **motivate** the **workforce** and **reward** a **successful** campaign.

> 雇い主は従業員のやる気を引き出し、販売活動の成功に報いたかった。

<a id="x223-04"></a>

**223.04**　“But my **salary** buys less every month because of **inflation**,” the employee said.

> 「でも物価が上がって、私の給料で買えるものは毎月減っています」と働く人は言った。

<a id="x223-05"></a>

**223.05**　The **recession** had reduced **demand** for **exotic** food and put the **mortgage** on her flat at risk.

> 景気後退で珍しい食品の需要が減り、彼女の住宅ローンの返済も危うくなった。

<a id="x223-06"></a>

**223.06**　An **export** business could **expand** abroad, but this one depended on the local **consumer**.

> 輸出業なら海外に販路を広げられるが、この店は地元の消費者が頼りだった。

<a id="x223-07"></a>

**223.07**　The shareholder tried to **blame** higher **shipping** costs and changes in **currency** values.

> 株主は、輸送費の上昇と通貨価値の変動のせいにしようとした。

<a id="x223-08"></a>

**223.08**　“Your **calculation** leaves out my **unemployment** last winter,” she answered.

> 「その計算には昨冬、私に仕事がなかったことが入っていません」と彼女は答えた。

<a id="x223-09"></a>

**223.09**　They invited an **economics** teacher to **assess** the **relation** between hours worked and goods sold.

> 二人は経済学の先生を招き、労働時間と売れた量の関係を調べてもらった。

<a id="x223-10"></a>

**223.10**　“Sales may **correlate** with **effort** without being a **fair** measure of it,” she said.

> 「売上と努力に関連があっても、売上が努力を公平に測れるとは限りません」と先生は言った。

<a id="x223-11"></a>

**223.11**　In the **end** the employer agreed to **raise** the minimum rate and **reduce** the bonus.

> 結局、雇い主は賃金の最低額を上げ、賞与を減らすことに同意した。

<a id="x223-12"></a>

**223.12**　That would **ease** the **pressure** to **price** every item as high as possible.

> それなら、どの商品にも可能な限り高い値をつけようという圧力が和らぐ。

**読みの問い**　売上だけで努力を測ると、何が見落とされるか。

<a id="ex-story-224"></a>

### 224　橋に上げた三つの旗

<a id="x224-01"></a>

**224.01**　A **socialist** and a **conservative** prepared to **debate** the **election** on a bridge above **downtown**.

> 社会主義者と保守派の人が、中心街を見下ろす橋で選挙について討論しようとしていた。

<a id="x224-02"></a>

**224.02**　A **feminist** with a **bold** plan for **equal** pay joined them at the **far** end.

> 賃金平等に向けた大胆な案を持つフェミニストも、橋の向こう端で加わった。

<a id="x224-03"></a>

**224.03**　She wanted to **campaign** against **inequality** and **confront** the **exploitation** of workshop staff.

> 彼女は不平等に反対する運動を起こし、工房で働く人たちの搾取に立ち向かおうとしていた。

<a id="x224-04"></a>

**224.04**　“Does a **minority** have to **overcome** a higher **threshold** to gain **representation**?” she asked.

> 「少数派が代表を送り出すには、より高い壁を越えなければならないのですか」と彼女は尋ねた。

<a id="x224-05"></a>

**224.05**　A **hostile** listener began to **argue** that any change would **offend** the **present** majority.

> 敵対的な態度の聴衆の一人が、少しでも変えれば今の多数派が不快に思うと言い始めた。

<a id="x224-06"></a>

**224.06**　Her opponent **countered** that **liberty** and **respect** applied to all **people** there.

> 討論相手は、自由と尊重はそこにいる全員に当てはまると切り返した。

<a id="x224-07"></a>

**224.07**　One man called the guard a **racist**; she asked him to **describe** a specific **action** instead.

> ある男性が警備員を人種差別主義者と呼んだ。彼女は、具体的にどんな行為があったか話してほしいと頼んだ。

<a id="x224-08"></a>

**224.08**　He spoke of a rule that let a clerk **reject** a **foreign** ID on **arbitrary** grounds.

> 彼は、外国の身分証を恣意的な理由で係員が拒める規則について話した。

<a id="x224-09"></a>

**224.09**　A **federal** law could **address** that **issue** but would require a **commitment** from each **individual** office.

> 連邦法でその問題に取り組めるが、それぞれの窓口が実行を引き受ける必要があった。

<a id="x224-10"></a>

**224.10**　The **spokeswoman** asked the parties to **pledge** a **united** response to **institutional** discrimination.

> 広報担当者は、制度上の差別に対して足並みをそろえて取り組むと各党に約束するよう求めた。

<a id="x224-11"></a>

**224.11**　Some wanted to **withdraw**; others **opposed** any attempt to **suppress** the **discussion**.

> 引き下がろうとする人もいれば、話し合いを封じる動きに反対する人もいた。

<a id="x224-12"></a>

**224.12**　A girl tied three flags to the bridge, one for each speaker, at an **equal** **height**.

> 少女は橋に三本の旗を結んだ。話し手それぞれに一本ずつ、同じ高さだった。

**読みの問い**　聴衆の批判が、人物の呼び方から具体的な規則の話へ変わったきっかけは何か。

<a id="ex-story-225"></a>

### 225　月に向いた傘

<a id="x225-01"></a>

**225.01**　The **expedition** to the **moon** began in a tent in the town **square**.

> 月を目指す探検は、町の広場のテントから始まった。

<a id="x225-02"></a>

**225.02**　We had to **orient** our map with **north** at the top and find a **coordinate** on its **grid**.

> 地図の上が北になるよう向きを合わせ、格子の中で一つの座標を見つける必要があった。

<a id="x225-03"></a>

**225.03**　A **satellite** turned above a model of the earth, completing one **rotation** in a minute.

> 地球の模型の上で衛星が回り、一分で一回転した。

<a id="x225-04"></a>

**225.04**　The model showed the **rise** of a **brilliant** **star** above the **far** shore of a **continent**.

> 模型では、大陸の遠い岸辺の向こうに明るい星が昇った。

<a id="x225-05"></a>

**225.05**　The guide **set** the tube on the table so we were **able** to **gaze** up at a star.

> 案内人が筒を机に置いてくれたので、私たちは星を見上げることができた。

<a id="x225-06"></a>

**225.06**　A **smart** **navigation** **program** helped us **select** a route and **launch** a model **plane**.

> 賢い航法プログラムを使い、進路を選んで模型飛行機を発進させることができた。

<a id="x225-07"></a>

**225.07**　It had to **curve** around a mountain **peak** and **slope** down towards the **camp**.

> 山頂を回り込むように曲がり、野営地に向かって斜めに降下する必要があった。

<a id="x225-08"></a>

**225.08**　One **random** **deviation** of a **kilometre** would **force** a change of **strategy**.

> 偶然一キロずれるだけで、やり方を変えざるを得なくなる。

<a id="x225-09"></a>

**225.09**　The first time we let the plane **crash**; on the second **go** we learnt to **reverse** the controls.

> 初回は機体を墜落させた。二度目で操作を逆にするこつをつかんだ。

<a id="x225-10"></a>

**225.10**　The guide credited our **triumph** to **practice** rather than **luck**.

> 案内人はうまくいったのは運より練習の成果だと言った。

<a id="x225-11"></a>

**225.11**　My son was **thrilled** by the **adventure**, but my daughter remembered the angle of the umbrella.

> 息子は冒険に大喜びだったのに、娘が覚えていたのは傘の角度だった。

<a id="x225-12"></a>

**225.12**　“It faced the lamp,” she said, “just as the plane faced the star.”

> 「傘はランプを向いていた。ちょうど飛行機が星を向いていたみたいに」と言った。

**読みの問い**　模型飛行機の進路を試すことが、傘についてどんな観察につながったか。

<a id="ex-story-226"></a>

### 226　化石に糸はつかない

<a id="x226-01"></a>

**226.01**　At the **science** tent, a **fossil** lay beside a **raw** **crystal** in a case marked with a red dot.

> 科学展示のテントでは、赤い点の付いたケースに化石と加工前の結晶が並んでいた。

<a id="x226-02"></a>

**226.02**　A **specialized** **printer** could **reproduce** their shape in three **dimensions**.

> 特殊なプリンターで立体的な形を再現できた。

<a id="x226-03"></a>

**226.03**　“When this **liquid** material becomes a **solid**, it **behaves** in a different way,” said the guide.

> 「この液状の材料は固体になると振る舞い方が変わります」と案内人が説明した。

<a id="x226-04"></a>

**226.04**　We watched a **new** copy slowly **shrink** as it cooled.

> できたばかりの複製は、冷めるにつれてゆっくり縮んだ。

<a id="x226-05"></a>

**226.05**　A **wide** band of colour showed which **phase** of **processing** was in progress.

> 色のついた太い帯が、加工のどの段階まで進んだかを示していた。

<a id="x226-06"></a>

**226.06**　A **technical** drawing gave a **perspective** we could not get by looking through glass.

> 技術図面では、ガラス越しに見るだけでは分からない視点を得られた。

<a id="x226-07"></a>

**226.07**　“**Spot** the **tooth** mark,” said a boy whose **hobby** was collecting fossils.

> 「歯形を見つけてみて」と化石集めが趣味の少年が言った。

<a id="x226-08"></a>

**226.08**　A **spider** began to **creep** across the case as he spoke; its shadow seemed to **loom** over the fossil.

> 彼が話している間にクモがケースの表面をはい始め、その影が化石の上に大きく覆いかぶさるように見えた。

<a id="x226-09"></a>

**226.09**　My son was **amazed** that a real spider could look like a **giant** from so close.

> すぐそばから見ると本物のクモが巨人に見えることに、息子は驚いた。

<a id="x226-10"></a>

**226.10**　A **weird** **trick** of light had changed our **perception** without changing the **material** object.

> 妙な光のいたずらで、物自体は同じなのに私たちの見え方が変わった。

<a id="x226-11"></a>

**226.11**　“The lamp again,” said my daughter, and wrote the word in the **log**.

> 「またランプだ」と娘は言い、記録帳にそう書いた。

**読みの問い**　大きく見えたクモは実際に大きくなったのか。

<a id="ex-story-227"></a>

### 227　言葉の博覧会

<a id="x227-01"></a>

**227.01**　At a **college** **seminar** an **undergraduate** invited us to **explore** an **intriguing** **analogy**.

> 大学のゼミで、ある学部生が興味深いたとえを一緒に考えようと私たちを誘った。

<a id="x227-02"></a>

**227.02**　“A word is a room,” she said, “and **reading** gives us **countless** ways to **enter** it.”

> 「単語を部屋だとすると、読書はそこへ入る無数の方法をくれます」

<a id="x227-03"></a>

**227.03**　The guide asked whether we could **teach** **literacy** without a formal **exam**.

> 正式な試験をしなくても読み書きは教えられるか、案内人が尋ねた。

<a id="x227-04"></a>

**227.04**　One **exercise** let us **categorize** the content of a **poem** without giving it a **rating**.

> ある練習では、詩に点数をつけずに内容を分類した。

<a id="x227-05"></a>

**227.05**　The **imagery** of a **thirsty** animal seeking a spring gave the poem its **unity**.

> のどが渇いて泉を探す動物のイメージが、詩全体を一つに結びつけていた。

<a id="x227-06"></a>

**227.06**　Another **contributor** quoted a **myth** in which water became a **symbol** of **mercy**.

> 別の参加者は、水が慈悲の象徴になる神話を引用した。

<a id="x227-07"></a>

**227.07**　In a **legend** of the same region it stood for **wealth**; in a **spiritual** song it stood for grace.

> 同じ地方のある伝説では富を、ある宗教的な歌では神の恵みを表していた。

<a id="x227-08"></a>

**227.08**　A **theology** student wrote a **thesis** on the **relation** between **religion** and the water in these stories.

> 神学を学ぶ学生は、そうした物語の水と宗教の関係について論文を書いた。

<a id="x227-09"></a>

**227.09**　The stream was a **feature** of all three works, yet its meaning continued to **unfold**.

> 三つの作品すべてに流れが登場するけれど、その意味は少しずつ開かれていった。

<a id="x227-10"></a>

**227.10**　“Do not **presume** that **equivalence** in one line guarantees it in the next.”

> 「ある一行で同じ意味になったからといって、次の行でも同じとは決めつけないでください」

<a id="x227-11"></a>

**227.11**　We could **quote** the poem or **write** our own **reply**, and either choice could **enrich** the **discussion**.

> 詩を引用することも、自分なりの返事を書くこともできた。どちらを選んでも、話し合いを豊かにできた。

**読みの問い**　三つの作品に出てくる水には、どんな違いがあったか。

<a id="ex-story-228"></a>

### 228　赤い点を送れない

<a id="x228-01"></a>

**228.01**　Next to the **television** a small **tablet** displayed a **bug** in the **software** for the exhibition.

> テレビの横の小さなタブレット端末に、展示用ソフトの不具合が映っていた。

<a id="x228-02"></a>

**228.02**　A **viewer** could **download** a picture, but the program would **delete** any red dot in it.

> 画像はダウンロードできるのに、赤い点があるとプログラムが消してしまう。

<a id="x228-03"></a>

**228.03**　The **annoying** fault had damaged the **credibility** of the **website** and its **ongoing** **research** project.

> この厄介な不具合で、ウェブサイトと進行中の研究の信用が損なわれていた。

<a id="x228-04"></a>

**228.04**　A **creative** pupil offered to **collaborate** with the designer on an **upgrade**.

> 工夫好きの生徒が、改良の作業に協力したいと設計者に申し出た。

<a id="x228-05"></a>

**228.05**　The pupil used a **password** to get in and began to **key** the code into the system.

> 生徒はパスワードで入り、コードをシステムに打ち込み始めた。

<a id="x228-06"></a>

**228.06**　When the program tried to **encode** an image, it would **merge** red dots with the dark background.

> 画像を符号化するとき、プログラムが赤い点を暗い背景とまとめてしまうのだった。

<a id="x228-07"></a>

**228.07**　A new **procedure** would **filter** out dust but **permit** the red marks to remain.

> 新しい手順なら、ほこりを取り除きつつ赤い印を残せる。

<a id="x228-08"></a>

**228.08**　For **validation** we decided to **scan** one hundred pictures and **quantify** the loss.

> 検証として百枚の画像を読み込み、どれくらい失われるかを数値にすることにした。

<a id="x228-09"></a>

**228.09**　The **empirical** evidence was **overwhelming**: our **systematic** **testing** showed a **pronounced** improvement.

> 実際のデータには圧倒的な説得力があった。系統立てた試験で、はっきりした改善を確認できた。

<a id="x228-10"></a>

**228.10**　“Have you **updated** the **graphics** on the **TV** as well?” a **sceptical** **viewer** asked.

> 「テレビの画像も更新したの？」と半信半疑の観客が尋ねた。

<a id="x228-11"></a>

**228.11**　We had; my daughter was **impressed** by the pupil but **aware** that a missing dot on paper might have another cause.

> 更新は済んでいた。娘は生徒の働きに感心しつつ、紙の上で点が消えた理由は別かもしれないと分かっていた。

**読みの問い**　画像を入力する前にはあった赤い点が見えなくなった原因は何か。

<a id="ex-story-229"></a>

### 229　広報誌に載る前に

<a id="x229-01"></a>

**229.01**　On **Tuesday** a fresh **edition** of the **newspaper** was due to **feature** our search on the front page.

> 火曜日に出る新聞の新しい号では、私たちの傘探しを一面で取り上げる予定だった。

<a id="x229-02"></a>

**229.02**　The **publishing** **firm** wanted to **advertise** a **subscription** with a **sexy** picture from a film.

> 出版社は映画から取ったセクシーな写真で定期購読を宣伝したがっていた。

<a id="x229-03"></a>

**229.03**　The young editor refused to let a sales **promotion** **dominate** a story **intended** for children.

> 若い編集者は、子ども向けの記事で販促が中心になることを認めなかった。

<a id="x229-04"></a>

**229.04**　She had the **approval** of a **few** readers and **mixed** **feedback** from the rest.

> 何人かの読者は賛成し、ほかの読者からは賛否の入り混じった反応が来た。

<a id="x229-05"></a>

**229.05**　“We can **dislike** a picture without wanting to **suppress** a **personal** view,” she wrote.

> 「写真を好まないことと、個人の意見を封じたいことは別です」と彼女は書いた。

<a id="x229-06"></a>

**229.06**　The **convention** was to **rank** the articles by **popularity**, but a **ranking** measured interest, not **truth**.

> 記事を人気順に並べるのが慣例だった。ただ、その順位が示すのは関心の高さで、真実かどうかではない。

<a id="x229-07"></a>

**229.07**　In the **meantime** a **serial** story about a **cheat** had begun to **interest** our son.

> 一方で、いかさま師の連載物語に息子は興味を持ち始めた。

<a id="x229-08"></a>

**229.08**　The man had tried to **cheat** a **lottery** winner out of her entire **prize**.

> その男は宝くじの当選者から賞金を全部だまし取ろうとしていた。

<a id="x229-09"></a>

**229.09**　Whether the woman would **spot** the **trick** in time was a matter of **speculation**.

> 女性が間に合ううちに策略を見抜けるかは、まだ推測するしかなかった。

<a id="x229-10"></a>

**229.10**　The editor asked for a **prediction**; my son offered two lines of dialogue and no **conclusion**.

> 編集者に先を予想してと言われ、息子は二行のせりふを渡したが、結末は書かなかった。

<a id="x229-11"></a>

**229.11**　“I would hate to **disappoint** the reader by telling her what to expect.”

> 「先に展開を教えて、読む人をがっかりさせたくないから」

**読みの問い**　編集者が新聞記事の順位を考える際、区別した二つの事柄は何か。

<a id="ex-story-230"></a>

### 230　古いビラの貸出日

<a id="x230-01"></a>

**230.01**　A **rental** agreement in the archive covered a **family** **holiday** at a house beside the sea.

> 資料室には、海辺の一軒家を家族旅行で借りたときの契約書が残っていた。

<a id="x230-02"></a>

**230.02**　The **permit** would **expire** on **Sunday**, but the family could **renew** it by post.

> 許可は日曜に切れるが、家族は郵便で更新できた。

<a id="x230-03"></a>

**230.03**　An entry from **November** gave an **overview** of the **terms** and made no **mention** of a red mark.

> 十一月の記載は契約条件を概説していたが、赤い印には触れていなかった。

<a id="x230-04"></a>

**230.04**　A written **recommendation** was folded into the **correspondence** beside it.

> その横の往復書簡に、推薦状が折り畳んで入れてあった。

<a id="x230-05"></a>

**230.05**　The writer spoke of the father with **respect** for his **honesty**, his **dedication** and his **skill** at repairing clocks.

> 書き手は、父親の誠実さと献身、そして時計を直す技量について、敬意を込めて語っていた。

<a id="x230-06"></a>

**230.06**　His **occupation** had often involved a long **drive** and a night away from home.

> 父親の職業では、長距離の車移動と外泊がよく必要だった。

<a id="x230-07"></a>

**230.07**　He would **hire** a car or use the bus; the **last** of the buses left at six.

> 車を借りるかバスを使っていたが、最終バスは六時発だった。

<a id="x230-08"></a>

**230.08**　The woman who owned the house offered to **charge** him less for a longer stay and to **discount** the third night.

> 女主人は長く泊まれば料金を下げ、三泊目を割り引くと申し出た。

<a id="x230-09"></a>

**230.09**　The child had wanted a **bath** and an evening of **swimming**, whatever the weather.

> 子どもの願いは、天気がどうでも、お風呂に入り夕方は泳ぐことだった。

<a id="x230-10"></a>

**230.10**　The rent was a **sacrifice** the parents could afford only once, yet the memory of that **childhood** week stayed.

> 両親がほかのことを犠牲にして宿代を工面できたのは一度きりだった。それでも幼い日に過ごしたその一週間は記憶に残った。

<a id="x230-11"></a>

**230.11**　The daughter had kept the contract as a **valuable** **possession** long after its **obvious** **utility** had passed.

> 契約として役目を終えてずいぶん後も、娘はその書類を大事な持ち物として取っておいた。

**読みの問い**　娘にとって、期限が切れた契約書が残す価値は何か。

<a id="ex-story-231"></a>

### 231　壊れた車を組み直す

<a id="x231-01"></a>

**231.01**　A **used** **auto** from across the ocean stood in the transport **complex** behind the library.

> 図書館の裏の交通展示施設には、海を渡ってきた中古車があった。

<a id="x231-02"></a>

**231.02**　A **fat** cat lay asleep on the front seat.

> 太った猫が前の座席で眠っていた。

<a id="x231-03"></a>

**231.03**　A wide tyre and a red mark on its **tail** gave it a **classic** **appearance**.

> 幅広のタイヤと後部の赤い印が、昔ながらの姿を作っていた。

<a id="x231-04"></a>

**231.04**　Its **functional** design made it **easy** to **study** how the wheels **functioned**.

> 実用的な設計のおかげで、車輪がどう働くかを調べやすかった。

<a id="x231-05"></a>

**231.05**　“**Scratch** my model and I shall **forgive** you,” the owner said, “but please do not **scratch** the car.”

> 「模型に傷をつけても許すよ。でも本物の車には傷をつけないでね」と持ち主は言った。

<a id="x231-06"></a>

**231.06**　He let my daughter **master** the controls on an **intermediate** model before she took a driving lesson.

> 娘が運転を体験する前に、中級用模型で操作を覚えさせてくれた。

<a id="x231-07"></a>

**231.07**　A green light let her **commence** the journey and a red one told her when to **halt**.

> 緑のランプで走り始め、赤で止まる仕組みだった。

<a id="x231-08"></a>

**231.08**　Her brother stood at the bus **stop** and asked her to **close** the door after him.

> 息子は停留所に立ち、自分がドアを通ったら、その後で閉めてくれと娘に頼んだ。

<a id="x231-09"></a>

**231.09**　At the next **turn**, she had to **balance** the need for speed against the danger of a **casualty**.

> 次の曲がり角では、速さの必要性と、死傷者を出す危険を天秤にかけなければならなかった。

<a id="x231-10"></a>

**231.10**　She did not **hesitate** to stop when a little dog ran into the road in front of her.

> 小さな犬が目の前の道路へ飛び出すと、娘は迷わず止まった。

<a id="x231-11"></a>

**231.11**　Her **lead** in the game disappeared, but she had no regret about losing it.

> ゲームのリードは消えたが、それを失ったことは少しも悔やんでいなかった。

<a id="x231-12"></a>

**231.12**　“On the **plus** side, nobody got hurt,” my son said, **surprised** to mean every word.

> 「いい面を見れば、誰もけがしなかったよ」と息子は言った。自分でも驚くほど本心だった。

**読みの問い**　娘は速さよりも何を優先したか。

<a id="ex-story-232"></a>

### 232　安全な水までの距離

<a id="x232-01"></a>

**232.01**　A broken **pipeline** had carried **waste** water into a river, according to the next display.

> 次の展示によると、破損した導管から廃水が川に流れ出たことがあった。

<a id="x232-02"></a>

**232.02**　The **regulator** had ordered a **mandatory** **assessment** of the **pollution** before swimming could **continue**.

> 規制当局は、遊泳の再開前に汚染を評価するよう義務づけた。

<a id="x232-03"></a>

**232.03**　A **sampling** **scheme** let teams **designate** ten points and **coordinate** visits at **frequent** intervals.

> 採水計画では、調査班が十地点を指定し、短い間隔で回る日程を調整できた。

<a id="x232-04"></a>

**232.04**　The route chosen for **administrative** convenience created an **inherent** **disadvantage** for one village.

> 事務処理の都合で選んだ経路は、一つの村に構造的な不利をもたらした。

<a id="x232-05"></a>

**232.05**　Its homes were **located** above the last bridge, where effects could be worse or much **lower**.

> その村は最後の橋より上流にあり、影響はもっと悪い可能性も、ずっと小さい可能性もあった。

<a id="x232-06"></a>

**232.06**　A **representative** sample had to **contain** water from that reach to make the survey **meaningful**.

> 調査に意味を持たせるには、全体を代表する試料にその区間の水を含める必要があった。

<a id="x232-07"></a>

**232.07**　The first tests found **poison** in a small **portion** of the river; no test offered an **absolute** **guarantee**.

> 最初の検査では川の一部に有毒物質が見つかったが、どの検査も絶対の保証にはならなかった。

<a id="x232-08"></a>

**232.08**　The clerk refused to **claim** **absolute** **certainty** about the **fate** of every fish.

> 係員は、すべての魚がどうなったか絶対に確かだとは言わなかった。

<a id="x232-09"></a>

**232.09**　To **minimize** harm the council would **issue** a warning and **suspend** permits for a week.

> 被害を抑えるため議会は警報を出し、一週間許可を停止することにした。

<a id="x232-10"></a>

**232.10**　It also promised to **research** the **adverse** effects of long-term **warming** on the water.

> 長期的な温暖化が川の水に及ぼす悪影響も調べると約束した。

<a id="x232-11"></a>

**232.11**　Clear water alone could not **convince** the visitors that it was safe to **drink**.

> 見た目が澄んでいるだけでは、安全に飲めると来館者を納得させられなかった。

**読みの問い**　上流の村を採水地点に加える必要があったのはなぜか。

<a id="ex-story-233"></a>

### 233　見えない境界線

<a id="x233-01"></a>

**233.01**　An international **conference** had asked local students to **present** a model of **globalization**.

> 国際会議から、地元の学生にグローバル化の模型を発表してほしいと依頼があった。

<a id="x233-02"></a>

**233.02**　A red thread for **trade** joined two ports; blue threads stood for **communication** between workers.

> 交易を表す赤い糸で二つの港を結び、青い糸で働く人どうしの連絡を表した。

<a id="x233-03"></a>

**233.03**　Each port was a different **entity**, but together they formed a centre of **commerce**.

> 港はそれぞれ別個の存在だったが、一緒になって商業の中心地を形づくった。

<a id="x233-04"></a>

**233.04**　One ship could **bring** **worldwide** demand to a small port and **transform** the local economy.

> 一隻の船で小さな港に世界規模の需要が届き、地域の経済が変わることもあった。

<a id="x233-05"></a>

**233.05**　Its arrival could also **impact** rents and **exert** pressure on homes outside the port.

> 船の到着は家賃にも影響し、港の外の家庭に負担をかけることもあった。

<a id="x233-06"></a>

**233.06**　The teacher asked us to trace a **parallel** between the **spread** of news and the movement of goods.

> 先生は、ニュースの広がり方と商品の動きの間にどんな共通点があるか、たどってみてと頼んだ。

<a id="x233-07"></a>

**233.07**　The group was **inclined** to **value** speed, until a child raised the question of **sovereignty**.

> ある子が主権の問題を持ち出すまで、班は速さを重んじる方に傾いていた。

<a id="x233-08"></a>

**233.08**　“Can my island decline the ship, or does your **powerful** neighbour decide its **policy**?”

> 「私の島はその船を断れるの？　それともあなたの強い隣国が方針を決めるの？」

<a id="x233-09"></a>

**233.09**　Her **argument** brought the **dynamic** between the ports to life and changed our **conception** of power.

> 彼女の主張で港どうしの力関係が実感でき、力というものの捉え方が変わった。

<a id="x233-10"></a>

**233.10**　We could **admire** the new **technology** without calling every change a change for the **better**.

> 新しい技術を立派だと思っても、あらゆる変化を改善と呼ぶ必要はないのだった。

<a id="x233-11"></a>

**233.11**　A diagram of the two ports would never be complete, but this one was **worth** keeping.

> 二つの港を図に表し尽くすことはできない。それでもこの図は取っておく価値があった。

**読みの問い**　島についての子どもの質問で、何を考える必要が生じたか。

<a id="ex-story-234"></a>

### 234　教室で議長を変える

<a id="x234-01"></a>

**234.01**　At the next table a **procedural** rule let the class **appoint** one of its members to lead each round.

> 隣の机では、手順の取り決めに従い、クラスの一人を毎回の進行役に指名できた。

<a id="x234-02"></a>

**234.02**　The **tenure** lasted five minutes; the **successor** could **end** a round or **commence** a new one.

> 任期は五分。後任にはその回を終えることも、新しく始めることもできた。

<a id="x234-03"></a>

**234.03**　Three children wanted to **found** a club to **promote** **diversity** at school.

> 三人の子が、学校で多様性を広げるクラブを設立したがっていた。

<a id="x234-04"></a>

**234.04**　Their **initiative** aimed to **integrate** new pupils and **equip** them with the words to ask for help.

> この取り組みは、新入生を仲間に迎え、助けを求める言葉を身につけてもらおうとするものだった。

<a id="x234-05"></a>

**234.05**　An **orientation** day could introduce the school, but **integration** took weeks of **partial** understanding.

> 説明会で学校を紹介することはできるが、理解がまだ不十分な中で溶け込んでいくには、何週間もかかった。

<a id="x234-06"></a>

**234.06**　An **adaptive** **learning** exercise let children **progress** at their **respective** speeds.

> 一人ひとりに合わせて変わる学習課題では、それぞれの速さで先に進めた。

<a id="x234-07"></a>

**234.07**　The **predictable** **progression** of a **typical** lesson could **suit** one pupil and **trap** another.

> 普通の授業の予測しやすい進み方は、一人には合っても、別の子は身動きを取れなくなるかもしれない。

<a id="x234-08"></a>

**234.08**　One girl described the **exclusion** she had felt because of her **sex** in a previous school.

> ある女子は、以前の学校で性別のために仲間外れにされたと感じた経験を話した。

<a id="x234-09"></a>

**234.09**　She wanted to be treated as an **equal**, with neither **dismissal** nor **unnecessary** praise.

> 彼女の希望は、軽くあしらわれることも、余分に褒められることもなく、対等に扱われることだった。

<a id="x234-10"></a>

**234.10**　The **key** **insight** was hers: “Give me the same real problem, and ask what help I want.”

> 大切な気づきを示したのは彼女だった。「同じ本物の問題を渡して、どんな助けがいるかは私に聞いて」

<a id="x234-11"></a>

**234.11**　Her comment helped **empower** the next speaker and **inspire** the group to **celebrate** small changes.

> その一言が次の子の発言を後押しし、小さな変化をみんなで喜ぶきっかけになった。

**読みの問い**　「対等に扱う」を、その女子は何をしてほしいという意味で使ったか。

<a id="ex-story-235"></a>

### 235　傘の柄から出た手品師

<a id="x235-01"></a>

**235.01**　A **theatrical** sweep of a **magic** umbrella opened the last act of a **late** show.

> 夜遅い公演の最終幕は、魔法の傘を芝居がかった身ぶりで大きく振るところから始まった。

<a id="x235-02"></a>

**235.02**　The actor wore a **mask** and **medium** grey **trousers** above a pair of red shoes.

> 演者は仮面を着け、明るすぎず暗すぎない灰色のズボンと赤い靴をはいていた。

<a id="x235-03"></a>

**235.03**　His young **assistant** wore bright red **pants** under a white dress for the final **shoot**.

> 若い助手は最後の撮影に向け、白いドレスの下に真っ赤な下着を着けていた。

<a id="x235-04"></a>

**235.04**　He began to **spin** the umbrella, **sweep** the floor with it and **throw** it high in the **air**.

> 手品師は傘を回し、それで床を掃き、空高く放り投げた。

<a id="x235-05"></a>

**235.05**　A crowd began to **line** the path with open umbrellas.

> 観客が開いた傘を手に通路沿いに並び始めた。

<a id="x235-06"></a>

**235.06**　The man borrowed a red coat from a visitor, and it was a perfect **fit**.

> 男が客から赤いコートを借りると、サイズはぴったりだった。

<a id="x235-07"></a>

**235.07**　“**Pin** your **attention** here, **sir**,” he said, “or my **magic** will look like **nonsense**.”

> 「こちらの一点にご注目ください、お客さん。さもないと私の手品は何が何だか分かりませんよ」と言った。

<a id="x235-08"></a>

**235.08**　I thought I saw a red thread fall, but the chance to **hunt** for it had to wait.

> 赤い糸が落ちた気がしたが、探し回るのはあとにしなければならなかった。

<a id="x235-09"></a>

**235.09**　The actor began to **pace** as if a **lost** treasure had begun to **haunt** his dreams.

> 手品師は、失われた宝が夢に出てきて離れないというふうに歩き回り始めた。

<a id="x235-10"></a>

**235.10**　“Do not let the thought **bother** you,” cried my son, “and do not **obsess** over it!”

> 「気に病まないで。いつまでも考え込まないで」と息子が叫んだ。

<a id="x235-11"></a>

**235.11**　The man opened a thick book, gave it a **shake** and found a red button where the **capital** letters began.

> 男が分厚い本を開いて振ると、大文字が始まるところから赤いボタンが出てきた。

<a id="x235-12"></a>

**235.12**　“Now there is a man who knows how to **finish** a good **story**,” said my daughter.

> 「あの人、物語をうまく終わらせる方法を知ってる」と娘が言った。

**読みの問い**　赤いボタンを見つける前、手品師は観客の注意をどう扱ったか。

<a id="ex-story-236"></a>

### 236　橋を踏んだ音

<a id="x236-01"></a>

**236.01**　A musician invited us to **beat** a simple pattern on the bridge with our feet.

> 音楽家が、橋の上で足を使って簡単な拍子を取ってみようと誘った。

<a id="x236-02"></a>

**236.02**　His first **offering** was a **short** piece of **rock**, and ten people began to **march** in time.

> 最初の演目は短いロックの曲で、十人がリズムに合わせて行進を始めた。

<a id="x236-03"></a>

**236.03**　The children wanted to **skip**, but repeated jumps could **pose** a problem on that old bridge.

> 子どもはスキップしたがったが、古い橋の上で何度も跳ぶのは問題を起こしかねなかった。

<a id="x236-04"></a>

**236.04**　“Can music **stimulate** a bridge as well as a **brain**?” my son asked.

> 「音楽は脳だけでなく橋にも刺激を与えられるの？」と息子が聞いた。

<a id="x236-05"></a>

**236.05**　The musician tapped a model and asked us to watch it **react** to the **stimulus**.

> 音楽家は模型を軽くたたき、その刺激にどう反応するか見るように言った。

<a id="x236-06"></a>

**236.06**　After a minute we noticed the **apparent** **instability** of the model and the increasing size of each movement.

> 一分ほどたつと、模型が明らかに不安定になり、揺れがだんだん大きくなっていることに気づいた。

<a id="x236-07"></a>

**236.07**　The **collapse** of a real bridge would be **disastrous**, even if nobody happened to be on it.

> 本物の橋なら、たまたま人がいなくても、崩壊すれば大変なことになる。

<a id="x236-08"></a>

**236.08**　“We cannot **subject** a public bridge to this test,” he said, “but we can **evaluate** a model.”

> 「公共の橋をこの試験にかけられないけれど、模型なら評価できます」と音楽家は言った。

<a id="x236-09"></a>

**236.09**　An **analytical** visitor used **maths** to **figure** out which combinations were **dangerous**.

> 分析好きの来館者が数学を使い、どの組み合わせが危険かを割り出した。

<a id="x236-10"></a>

**236.10**　Their rule treated the speed of sound as a **constant**.

> その計算規則では、音速を定数として扱った。

<a id="x236-11"></a>

**236.11**　Her **interest** lay in the **differentiation** of sounds that seemed identical to the rest of us.

> 彼女の関心は、ほかの人には同じに聞こえる音をどう聞き分けるかにあった。

<a id="x236-12"></a>

**236.12**　To her it was an **artistic** problem too: the same note could **sound** soft or sharp.

> 彼女には芸術上の問題でもあった。同じ音でも、柔らかくも鋭くも響くからだ。

**読みの問い**　本物の橋で試さずに、音楽家は何を見せたか。

<a id="ex-story-237"></a>

### 237　夜を渡ってきた鍋

<a id="x237-01"></a>

**237.01**　A **humanitarian** worker had put a cooking **pot** on display behind a picture of a camp.

> 人道支援に携わる女性が、キャンプの写真の後ろに調理用の鍋を展示していた。

<a id="x237-02"></a>

**237.02**　She had carried **aid** to people driven from their homes by **fighting** near a **nuclear** power station.

> 原子力発電所の近くで起きた戦闘で家を追われた人たちに、救援物資を届けていたという。

<a id="x237-03"></a>

**237.03**　The **premier** had called the attack an act of **terrorism** and promised a rapid response.

> 首相は襲撃をテロ行為と呼び、迅速に対応すると約束していた。

<a id="x237-04"></a>

**237.04**　An **explosive** device had damaged a road, so medical teams had to **retreat** to the **relative** safety of the camp.

> 爆発物で道路が損傷し、医療班は比較的安全なキャンプまで退かなければならなかった。

<a id="x237-05"></a>

**237.05**　Their **retreat** left them with one possible **escape** when the road behind them closed.

> 後方の道が閉ざされた結果、引き返した彼らには逃げ道が一つしか残らなかった。

<a id="x237-06"></a>

**237.06**　The worker asked people to **mobilize** the few boats still able to travel before dark.

> 日が暮れる前に、まだ航行できる数少ない舟を集めてほしいと、女性は頼んだ。

<a id="x237-07"></a>

**237.07**　They were **fortunate** to **escape** across the river with the pot and enough food to **satisfy** their **hunger**.

> 鍋と空腹を満たすだけの食料を持ち、川向こうへ逃れられたのは幸いだった。

<a id="x237-08"></a>

**237.08**　“Food in that pot could **warm** four children,” she said, “and no one would **waste** a piece of bread.”

> 「あの鍋の食事で四人の子どもが温まれました。パン一切れ無駄にする人はいませんでした」

<a id="x237-09"></a>

**237.09**　Her husband had injured his **chest**, and the pain had reduced his **mobility**.

> 夫は胸をけがして、痛みで体を動かしにくくなっていた。

<a id="x237-10"></a>

**237.10**　He knew that any attempt to **crush** the fallen wood might **injure** another person.

> 倒木を押しつぶそうとすれば、ほかの人まで傷つけるかもしれないと分かっていた。

<a id="x237-11"></a>

**237.11**　They chose **caution**; there was no **lack** of courage in waiting for a boat.

> 彼らは慎重に行動した。舟を待つのは勇気が足りないからではなかった。

<a id="x237-12"></a>

**237.12**　“Some would **bless** the boat,” she added, “and some the hands that built it.”

> 「舟に感謝をささげる人もいれば、それを作った人の手に感謝する人もいます」と女性は付け加えた。

**読みの問い**　鍋はキャンプでどんな価値を持っていたか。

<a id="ex-story-238"></a>

### 238　口にしなかった一言

<a id="x238-01"></a>

**238.01**　After the reading a man demanded an **apology** for an article about his **detention**.

> 朗読が終わると、一人の男性が、自分が拘留された件の記事について謝罪を求めた。

<a id="x238-02"></a>

**238.02**　Police had tried to **arrest** him at work, in full view of a customer, after a **scare** at a bank.

> 銀行で騒ぎがあったあと、警察は客の目の前で、仕事中の彼を逮捕しようとした。

<a id="x238-03"></a>

**238.03**　The article made the **victim** of a mistake appear to be a **serial** thief.

> 記事は、誤りによって被害を受けた男性を、常習の窃盗犯のように見せてしまっていた。

<a id="x238-04"></a>

**238.04**　“I was in a **hurry**, but that does not **excuse** my mistake,” the editor said.

> 「急いでいましたが、それで誤りを正当化はできません」と編集者は答えた。

<a id="x238-05"></a>

**238.05**　The man had feared a **lawsuit** might be the only way to restore his **reputation**.

> 男性は、評判を取り戻すには訴訟以外に方法がないかもしれないと、不安に思っていた。

<a id="x238-06"></a>

**238.06**　For two years he had lived with the **misery** of **suspicion**, which he could neither **conquer** nor explain.

> 二年間、彼はぬぐい去ることも説明することもできない疑いに苦しめられていた。

<a id="x238-07"></a>

**238.07**　The editor did not **attribute** his **rage** to **spite** or to a desire for money.

> 編集者は、その激しい怒りを悪意や金目当てのせいにしなかった。

<a id="x238-08"></a>

**238.08**　“You are **bound** to feel **upset** when a stranger says something so **unfair**,” she said.

> 「知らない人にそんな不公平なことを言われたら、動揺するのも当然です」と彼女は言った。

<a id="x238-09"></a>

**238.09**　“Will you **confess** the mistake in public?” he asked, keeping a firm hold on his **tongue**.

> 「公の場で間違いを認めてくれますか」と、男性は言いたいことをぐっとこらえながら尋ねた。

<a id="x238-10"></a>

**238.10**　She decided to **pursue** the matter and publish a correction in the same evening slot.

> 彼女はその件を最後まで追い、同じ夕方の時間枠で訂正を発表すると決めた。

<a id="x238-11"></a>

**238.11**　One **wrong** could not cancel another, but she would **regret** doing nothing even more.

> 一つの過ちは、別の過ちを帳消しにはできない。それでも何もしなければ、彼女はもっと後悔するだろう。

<a id="x238-12"></a>

**238.12**　The answer he gave was **tough** and kind: “I shall be **satisfied** when the readers know.”

> 男性の返事は厳しくも思いやりがあった。「読者に伝われば、私はそれで納得します」

**読みの問い**　男性は、編集者に誤りを認めてもらうだけでなく、何を求めたか。

<a id="ex-story-239"></a>

### 239　発明家が置いた箱

<a id="x239-01"></a>

**239.01**　A newly **engaged** couple had come to the exhibition to **invent** things together.

> 婚約したばかりの二人が、一緒に発明しようと展示会へ来ていた。

<a id="x239-02"></a>

**239.02**　Their first **creation** was a **convenient** **attachment** for an umbrella, a handle that trapped rain.

> 最初の作品は、傘につける便利な部品だった。雨をためられる取っ手だ。

<a id="x239-03"></a>

**239.03**　Inside was a simple pump that could **suck** water through a narrow tube.

> 内部には、細い管を通して水を吸い込める簡単なポンプが入っていた。

<a id="x239-04"></a>

**239.04**　“To **soak** a dry plant, you turn the handle in the **reverse** direction.”

> 「乾いた植物にたっぷり水をやるには、取っ手を逆に回すんです」

<a id="x239-05"></a>

**239.05**　They had yet to obtain a **patent** but refused to **boast** of a right they did not have.

> 特許はまだ取っておらず、持っていない権利を自慢しようとはしなかった。

<a id="x239-06"></a>

**239.06**　A visitor called the whole idea **useless**; another saw a **sensible** use for water otherwise lost.

> 考えそのものが役に立たないと言う人も、失われるはずの雨水の賢い利用法だと見る人もいた。

<a id="x239-07"></a>

**239.07**　“The **relevance** depends on your **circumstances**,” my daughter said, “and on where you can **plant** a tree.”

> 「その道具が自分にとってどれだけ意味を持つかは、自分の状況にもよるし、木をどこに植えられるかにもよるよ」と娘は言った。

<a id="x239-08"></a>

**239.08**　There was a **contradiction** between the **intended** use outdoors and the **predictable** **lack** of rain indoors.

> 外で使う設計なのに、屋内の展示では当然ながら雨が降らないという食い違いがあった。

<a id="x239-09"></a>

**239.09**　They poured water over the open umbrella, then used it to give the dirty window a **wash**.

> 二人は開いた傘に水をかけ、その水で汚れた窓も洗ってみた。

<a id="x239-10"></a>

**239.10**　What we had taken for a red dot was a red button that released water with a **push**.

> 赤い点だと思ったものは、押すと水を出せる赤いボタンだった。

<a id="x239-11"></a>

**239.11**　This umbrella was not ours either, but we had a **variety** of working explanations at last.

> これも私たちの傘ではなかったが、ようやく検討に使える仮の説明がいくつも得られた。

**読みの問い**　赤いボタンには実際にどんな働きがあったか。

<a id="ex-story-240"></a>

### 240　決める前の一分

<a id="x240-01"></a>

**240.01**　The **ethical** question at the final table was whether the school should **sack** a teacher for missing a deadline.

> 最後の机では、期限に遅れた教員を解雇すべきかという倫理上の問いが出された。

<a id="x240-02"></a>

**240.02**　A **cynical** visitor said it was a **sin** for a school to sound so serious about one **stupid** mistake.

> たった一つの愚かな間違いを学校がそこまで大げさに扱うのは罪だ、と皮肉っぽい来館者が言った。

<a id="x240-03"></a>

**240.03**　“The **ironic** thing,” said a parent, “is that her project was intended to **educate** people about mistakes.”

> 「皮肉なのは、その先生の課題が間違いについて教えるためのものだったことです」と保護者が言った。

<a id="x240-04"></a>

**240.04**　The **entertaining** exercise started with a button labelled in **capital** letters: “PRESS IF YOU AGREE.”

> この面白い課題は、大文字で「賛成なら押してください」と書いたボタンから始まった。

<a id="x240-05"></a>

**240.05**　At first twenty people pressed it, but a ten **per cent** rise added two more.

> 最初は二十人が押した。その後一割増え、二十二人になった。

<a id="x240-06"></a>

**240.06**　A new card revealed a **tragic** detail: the teacher had stopped to help another family after a fire.

> 新しいカードには痛ましい事情が書かれていた。火事に遭った別の一家を助けるため立ち止まっていたのだ。

<a id="x240-07"></a>

**240.07**　Could her employer **intervene** without seeming to **breach** the rules or **neglect** a duty?

> 雇い主は、規則を破ったり義務を怠ったりしているように見えずに、介入できるだろうか。

<a id="x240-08"></a>

**240.08**　“This minimum standard is **acceptable** on an ordinary day,” the mother said, “but this day was different.”

> 「普段ならこの最低基準でよいでしょう。でもその日は普段どおりではなかった」と母親が言った。

<a id="x240-09"></a>

**240.09**　A second vote revealed an **evident** change of **mind**, and the teacher kept her job.

> 二回目の投票で、考えが変わったことがはっきり示され、先生は仕事を続けられることになった。

<a id="x240-10"></a>

**240.10**　“Changing a judgement need not **manifest** weakness,” said a visitor who had switched sides.

> 「判断を改めることは、弱さの表れとは限りません」と、意見を変えた来館者が言った。

<a id="x240-11"></a>

**240.11**　“A fixed rule can **tempt** us to **neglect** a person; a story can **urge** us to look again.”

> 「決まった規則があると人を見落としがちになる。物語はもう一度見るよう促してくれる」

**読みの問い**　二回目の投票の前に、参加者にどんな情報が追加されたか。

<a id="ex-story-241"></a>

### 241　最後の展示は空っぽだった

<a id="x241-01"></a>

**241.01**　At the end of the street stood the **ruin** of a house that had once been the pride of the town.

> 通りの端に、かつて町の誇りだった家の廃墟があった。

<a id="x241-02"></a>

**241.02**　One wall had survived; the guide showed us where the fire had begun to **burn** through it.

> 壁が一枚残っていて、案内人は火がその壁を焼き破り始めた場所を示した。

<a id="x241-03"></a>

**241.03**　An older woman remembered the **nightmare** of that evening, though she had lived through **worse** since then.

> 年配の女性は、あの晩の悪夢を覚えていた。その後はもっとつらい経験もしたという。

<a id="x241-04"></a>

**241.04**　My daughter asked about the new exhibition, taking care not to **frighten** the woman with sudden questions.

> 娘はいきなり質問して驚かせないようにしながら、新しい展示のことを尋ねた。

<a id="x241-05"></a>

**241.05**　“For me, **yesterday** was the last day of the old town,” she said, “but you look at the same stones with **optimism**.”

> 「私にとって昨日は昔の町の最後の日だった。でもあなたは同じ石を見て希望を感じているね」と女性は言った。

<a id="x241-06"></a>

**241.06**　An architect had described the site as a meeting of memory and **modernity**, a **synthesis** of old and new.

> 建築家は、記憶と近代性が出会う、新旧を一つにした場所だと説明していた。

<a id="x241-07"></a>

**241.07**　A teenager called that a **construct** that might **appeal** to a designer but meant little to her.

> ある若者は、設計者には魅力的でも自分にはあまり意味のない概念だと言った。

<a id="x241-08"></a>

**241.08**　The guide welcomed this **criticism** and asked what the design might **lack**.

> 案内人は批判を歓迎し、設計に何が足りないと思うか尋ねた。

<a id="x241-09"></a>

**241.09**　“A place to sit,” she said, “and the **transparency** to tell us who chose the design.”

> 「座れる場所。それに、誰が設計を選んだかを明かす透明性」と若者は答えた。

<a id="x241-10"></a>

**241.10**　The first **move** was to carry a seat from the hall, and the second was to put the name of the designer on the wall.

> 最初にしたのは会館から椅子を運ぶこと。次にしたのは設計者の名を壁に掲げることだった。

<a id="x241-11"></a>

**241.11**　Even the old woman smiled: the single seat would do as a **minimum** until the rest arrived.

> 年配の女性もほほえんだ。残りが届くまで、椅子一脚でも最低限の役には立つ。

**読みの問い**　「記憶と近代性」という設計の説明に対して、若者は何を求めたか。

<a id="ex-story-242"></a>

### 242　赤は誰のもの

<a id="x242-01"></a>

**242.01**　The next debate concerned the **dominance** of red in public **discourse** about the exhibition.

> 次に意見が分かれたのは、展示の話題で赤ばかりが目立つことだった。

<a id="x242-02"></a>

**242.02**　To some it was an **ideological** colour; to others it was simply easier to see in the dark.

> 赤を特定の思想と結びつける人もいれば、暗い中で単に見やすいだけだと言う人もいた。

<a id="x242-03"></a>

**242.03**　“There is a **tendency** to call an opinion **unacceptable** before you know its **motivation**,” said the guide.

> 「その意見がどこから出たかを知る前に、受け入れられないと言ってしまいがちですね」と案内人は言った。

<a id="x242-04"></a>

**242.04**　A girl who had shown fierce **resistance** to a blue label said she was **interested** in a practical test.

> 青い札に強く反対していた少女が、実際に試してみたいと言った。

<a id="x242-05"></a>

**242.05**　“My eyes need time to adjust, and I have a **sensitivity** to bright light.”

> 「明るさに目が慣れるまで時間がかかるし、強い光には敏感なんです」

<a id="x242-06"></a>

**242.06**　The test would **consist** of finding two marks, first under a lamp and then beside the window.

> 試験では、まずランプの下で、次に窓際で二つの印を探すことにした。

<a id="x242-07"></a>

**242.07**　The first attempt was **frustrating**; a bright light was **liable** to hide the mark in its own reflection.

> 最初はもどかしかった。明るい光は反射で印を隠してしまいがちだった。

<a id="x242-08"></a>

**242.08**　Nobody called the girl **lazy** when she needed more time to **tackle** the second part.

> 後半の課題に時間がかかっても、少女を怠け者と言う人はいなかった。

<a id="x242-09"></a>

**242.09**　“An **incredible** story might **engage** a crowd,” she said, “but I want a label I can read.”

> 「驚くような物語なら人を引きつけるかもしれない。でも私は自分で読める札が欲しいんです」と少女は言った。

<a id="x242-10"></a>

**242.10**　It was a small request with a **profound** effect on our understanding of the marks.

> ささやかな願いだったが、印に対する私たちの理解を大きく変えた。

**読みの問い**　少女が青い札に反対した根拠を知るため、何が役立ったか。

<a id="ex-story-243"></a>

### 243　額の中に足りないもの

<a id="x243-01"></a>

**243.01**　We had one label left and three pictures without a name.

> 残った札は一枚で、名前のない絵は三枚あった。

<a id="x243-02"></a>

**243.02**　“This label fits the frame,” said my daughter.

> 「この札は額の大きさに合うね」と娘が言った。

<a id="x243-03"></a>

**243.03**　She tried to fit the label into the space below the glass.

> 娘はガラスの下の隙間に札をはめようとした。

<a id="x243-04"></a>

**243.04**　“It fits,” she said.

> 「ぴったり収まるよ」と娘は言った。

<a id="x243-05"></a>

**243.05**　“Does the name fit the picture?” I asked.

> 「その名前は絵の内容にも合うかな」と私は尋ねた。

<a id="x243-06"></a>

**243.06**　The label said “The last boat”, but a second boat could be seen on the river.

> 札には「最後の舟」とあるのに、川にはもう一そう見えた。

<a id="x243-07"></a>

**243.07**　My daughter took the label out again.

> 娘は札をもう一度外した。

<a id="x243-08"></a>

**243.08**　We left a space that was just the right size for a question.

> 私たちは、問いを一つ置くのにちょうどよい大きさの空間を残した。

**読みの問い**　札をはめる場面で使われた fit と、最後に父が尋ねた fit は、何と何の関係を見ているか。

<a id="ex-story-244"></a>

### 244　借りた傘を返す前に

<a id="x244-01"></a>

**244.01**　Our **quest** had begun with the **sheer** delight of seeing a red dot on a familiar umbrella.

> 私たちの探索の出発点には、見慣れた傘に赤い点を見つけた純粋な喜びがあった。

<a id="x244-02"></a>

**244.02**　It was tempting to **conclude** that every red dot told our story.

> どんな赤い点も私たちの物語を伝えてくれる、そう決めたくなる誘惑があった。

<a id="x244-03"></a>

**244.03**　“Would it **annoy** you if I said I still did not know?” my daughter asked.

> 「まだ分からないと言ったら、腹が立つ？」と娘は聞いた。

<a id="x244-04"></a>

**244.04**　“I would be a **fool** to **aspire** to an answer before the evidence is in,” I said.

> 「証拠がそろう前から答えを手に入れたいと思うなら、私は愚かだよ」と私は言った。

<a id="x244-05"></a>

**244.05**　We let the idea **mature** while we took the needle and the loose thread back to the station.

> 考えが熟すのを待ちながら、針と外れた糸を駅に持ち帰った。

<a id="x244-06"></a>

**244.06**　A clerk asked whether the ticket had to **undergo** another check and reached for his stamp.

> 係員は切符をもう一度確認する必要があるかと尋ね、スタンプに手を伸ばした。

<a id="x244-07"></a>

**244.07**　With one punch he made a round hole in the paper and held it in front of the lamp.

> 一打ちで紙に丸い穴を開け、ランプの前に掲げた。

<a id="x244-08"></a>

**244.08**　He pushed the ticket into a narrow **slot** and the time appeared beside the hole.

> 切符を細い差し込み口に押し込むと、穴の横に時刻が印字された。

<a id="x244-09"></a>

**244.09**　When my daughter passed a piece of red cloth behind the hole, the dot came back.

> 娘が穴の後ろに赤い布を通すと、赤い点が戻った。

<a id="x244-10"></a>

**244.10**　She kept the ticket for the next person who might ask what we had actually seen.

> 実際に何を見たのかと次に誰かが尋ねたときのため、娘はその切符を取っておいた。

**読みの問い**　切符の穴と赤い布で、何を実際に示せたか。

### 第4篇　読みの確認

**[199　消えたのは傘か、それとも印か](#ex-story-199)**　手元にある傘が、もともと赤い印のあった傘と同じものかどうか。

**[200　写真の外側](#ex-story-200)**　反射によって、一本の取っ手が二本に見えた可能性がある。

**[201　手に残った青](#ex-story-201)**　できない。そこには青いベルトもあった。

**[202　誰が何を見たか](#ex-story-202)**　三つの証言が同じ出来事を指すとは、まだ確認できていないから。

**[203　印を読む実験](#ex-story-203)**　赤く変わったからといって、それが必ずレモン汁だと決めつけずにすんだ。

**[204　貸し出し記録](#ex-story-204)**　弁償した場合にも口座は閉じられるから。

**[205　公聴会に椅子を一脚](#ex-story-205)**　住宅を借りる当事者も意思決定に参加すること。

**[206　水面を走った光](#ex-story-206)**　湖で競技が行われている場面と、そこで聞こえた声を手がかりにした。

**[207　菓子の印](#ex-story-207)**　中身に何が入っているか、どんな味かを見て分かるようにすること。

**[208　舞台を一歩降りると](#ex-story-208)**　同じ場面でも、人物の描き方や演出で意味を変える練習だった。

**[209　切れた幕の向こう](#ex-story-209)**　いくつも分類欄があるのに、本人の母語さえ書く場所がなかった。

**[210　列車の最後尾](#ex-story-210)**　細い繊維を裂いてしまうおそれがあったから。

**[211　分刻みの移動](#ex-story-211)**　速度を落とし、道が空くまで動かずに待ったから。

**[212　せりにかけられた絵](#ex-story-212)**　絵を買うという取引が成立した。

**[213　負ける確率、勝つ理由](#ex-story-213)**　チーム全体の傾向は分かるが、次の一球の結果までは分からない。

**[214　地下で揺れた家](#ex-story-214)**　倒れずに動ける柔軟性。

**[215　音が届かない席](#ex-story-215)**　二つの音源のうち、聞こえるものと聞こえないものを比較したから。

**[216　連絡のつかない晩](#ex-story-216)**　自転車の使者が紙の連絡票を運ぶ方法。

**[217　何を残すか](#ex-story-217)**　展示の決定権と、信仰上の意味をどう尊重するかも重要だったから。

**[218　泥の中の麦](#ex-story-218)**　動物に与える飼料の不足と、一家の収入の不足。余った穀物の加工は、その両方に対処する手段になった。

**[219　蝋の跡がついた手紙](#ex-story-219)**　指揮官本人の否定は読み取れるが、有罪かどうかは別の証拠も要る。

**[220　法廷の椅子に座る](#ex-story-220)**　遠くから見た人物を推測しただけで、本人だと確かめていなかったから。

**[221　調剤室の白い傘](#ex-story-221)**　治療を実行するうえで、瓶を開けられないという別の困難もあったから。

**[222　声を置く場所](#ex-story-222)**　少し休む場所が欲しいという希望に応じ、席を探した。

**[223　働く人の会計簿](#ex-story-223)**　物価や地域の需要など、働く人の努力以外で売上が動く事情。

**[224　橋に上げた三つの旗](#ex-story-224)**　どの行為を問題にしているのかと、具体的な説明を求められたこと。

**[225　月に向いた傘](#ex-story-225)**　傘とランプの位置関係、特に傘がどちらを向いていたかに目を向けた。

**[226　化石に糸はつかない](#ex-story-226)**　照明と見る位置が変えたのは見え方だけだった。

**[227　言葉の博覧会](#ex-story-227)**　同じ水が、作品に応じて慈悲・富・神の恵みという異なる意味を担っていた。

**[228　赤い点を送れない](#ex-story-228)**　符号化の段階で暗い背景と一緒に処理されたため。

**[229　広報誌に載る前に](#ex-story-229)**　読者の関心の高さと書かれたことが真実かどうか。

**[230　古いビラの貸出日](#ex-story-230)**　家族が一緒に過ごせた、子どものころの一週間の記憶。

**[231　壊れた車を組み直す](#ex-story-231)**　犬をはねずに止まること。ゲームでのリードを失っても構わなかった。

**[232　安全な水までの距離](#ex-story-232)**　便利な経路だけを調べると、その村の水質が調査結果に反映されないから。

**[233　見えない境界線](#ex-story-233)**　物が速く動くかだけでなく、島自身に船を受け入れるか決める権限があるかどうか。

**[234　教室で議長を変える](#ex-story-234)**　同じ意味のある課題に挑戦させ、必要な助けを本人に尋ねてほしいということ。

**[235　傘の柄から出た手品師](#ex-story-235)**　注意を向ける場所を指定し、傘の動きや歩き回る演技で視線を導いた。

**[236　橋を踏んだ音](#ex-story-236)**　模型が刺激に反応し、揺れがだんだん大きくなる様子。

**[237　夜を渡ってきた鍋](#ex-story-237)**　逃げた先でも食事を作り、子どもたちの空腹を満たして体を温められた。

**[238　口にしなかった一言](#ex-story-238)**　元の記事を読んだ人々にも誤りが伝わること。

**[239　発明家が置いた箱](#ex-story-239)**　押すと、取っ手が集めた雨水を出せた。

**[240　決める前の一分](#ex-story-240)**　教員が期限に遅れたのは、火事に遭った一家を助けるためだったこと。

**[241　最後の展示は空っぽだった](#ex-story-241)**　具体的に座れる場所と、設計を選んだ人が分かること。

**[242　赤は誰のもの](#ex-story-242)**　実際の照明の下で印を探し、反射で読めなくなることを確かめたこと。

**[243　額の中に足りないもの](#ex-story-243)**　前者は札が物理的に額の空間に収まるかどうか。最後は題名が絵に描かれたものと意味の上で合うかどうか。

**[244　借りた傘を返す前に](#ex-story-244)**　穴そのものを赤く塗らなくても、背後の布を通して赤い点に見せられること。

---

<a id="exp-index"></a>

## 用例索引

元のCSVの見出し順。数字は「話．文」で、リンク先の英文に該当語がある。同じ綴りでも品詞や見出し番号が違えば、別々の用例を載せている。

<a id="lex-noun"></a>

### 名詞　3,018項目

#### 名詞　A

[ability 209.04](#x209-04)　·　[abnormality 109.11](#x109-11)　·　[abortion 58.02](#x058-02)　·　[above 146.07](#x146-07)　·　[absence 205.02](#x205-02)　·　[abundance 116.02](#x116-02)　·　[abuse 58.02](#x058-02)

[academic 153.01](#x153-01)　·　[academy 208.01](#x208-01)　·　[accent 123.09](#x123-09)　·　[acceptance 50.02](#x050-02)　·　[access 146.01](#x146-01)　·　[accident 202.02](#x202-02)　·　[accommodation 121.01](#x121-01)

[accomplishment 81.10](#x081-10)　·　[accordance 146.02](#x146-02)　·　[account 201.01](#x201-01)　·　[accountability 120.12](#x120-12)　·　[accountant 65.01](#x065-01)　·　[accumulation 162.07](#x162-07)　·　[accuracy 204.11](#x204-11)

[accusation 102.06](#x102-06)　·　[accused 64.03](#x064-03)　·　[achievement 163.10](#x163-10)　·　[acid 203.01](#x203-01)　·　[acquisition 111.05](#x111-05)　·　[acre 60.02](#x060-02)　·　[act 165.03](#x165-03)

[action 224.07](#x224-07)　·　[activation 112.05](#x112-05)　·　[activist 66.06](#x066-06)　·　[activity 177.04](#x177-04)　·　[actor 208.01](#x208-01)　·　[actress 98.02](#x098-02)　·　[ad 65.08](#x065-08)

[adaptation 179.01](#x179-01)　·　[addiction 222.01](#x222-01)　·　[addition 109.10](#x109-10)　·　[address 64.03](#x064-03)　·　[adjustment 150.09](#x150-09)　·　[administration 205.06](#x205-06)　·　[administrator 105.02](#x105-02)

[admission 80.03](#x080-03)　·　[adolescent 153.08](#x153-08)　·　[adoption 215.01](#x215-01)　·　[adult 115.09](#x115-09)　·　[advance 80.04](#x080-04)　·　[advantage 161.04](#x161-04)　·　[adventure 225.11](#x225-11)

[advertisement 102.07](#x102-07)　·　[advertising 65.06](#x065-06)　·　[advice 161.09](#x161-09)　·　[advocate 205.03](#x205-03)　·　[affair 125.10](#x125-10)　·　[affection 72.09](#x072-09)　·　[aftermath 161.01](#x161-01)

[afternoon 201.12](#x201-12)　·　[age 109.09](#x109-09)　·　[agency 65.07](#x065-07)　·　[agenda 156.02](#x156-02)　·　[agent 220.03](#x220-03)　·　[aggression 130.03](#x130-03)　·　[agreement 53.09](#x053-09)

[agriculture 161.03](#x161-03)　·　[aid 237.02](#x237-02)　·　[aide 130.04](#x130-04)　·　[AIDS 79.02](#x079-02)　·　[aim 153.06](#x153-06)　·　[air 235.04](#x235-04)　·　[aircraft 107.03](#x107-03)

[airline 70.01](#x070-01)　·　[airport 149.07](#x149-07)　·　[alarm 216.04](#x216-04)　·　[album 98.10](#x098-10)　·　[alcohol 79.03](#x079-03)　·　[alert 168.01](#x168-01)　·　[alien 209.01](#x209-01)

[alignment 99.07](#x099-07)　·　[allegation 64.06](#x064-06)　·　[alliance 165.05](#x165-05)　·　[allocation 205.01](#x205-01)　·　[allowance 108.05](#x108-05)　·　[ally 66.09](#x066-09)　·　[alteration 147.07](#x147-07)

[alternative 207.11](#x207-11)　·　[aluminium 114.02](#x114-02)　·　[amateur 61.08](#x061-08)　·　[ambassador 165.05](#x165-05)　·　[ambition 213.03](#x213-03)　·　[ambulance 96.02](#x096-02)　·　[amendment 53.11](#x053-11)

[amount 159.07](#x159-07)　·　[analogy 227.01](#x227-01)　·　[analysis 109.10](#x109-10)　·　[analyst 65.04](#x065-04)　·　[ancestor 164.05](#x164-05)　·　[anchor 206.02](#x206-02)　·　[angel 108.09](#x108-09)

[anger 67.05](#x067-05)　·　[angle 140.07](#x140-07)　·　[animal 217.03](#x217-03)　·　[animation 118.11](#x118-11)　·　[ankle 68.05](#x068-05)　·　[anniversary 163.01](#x163-01)　·　[announcement 199.01](#x199-01)

[answer 103.10](#x103-10)　·　[anxiety 76.10](#x076-10)　·　[apartment 168.04](#x168-04)　·　[apology 238.01](#x238-01)　·　[app 112.02](#x112-02)　·　[apparatus 57.05](#x057-05)　·　[appeal 176.04](#x176-04)

[appearance 214.08](#x214-08)　·　[appetite 93.04](#x093-04)　·　[apple 59.04](#x059-04)　·　[applicant 177.01](#x177-01)　·　[application 209.04](#x209-04)　·　[appointment 98.01](#x098-01)　·　[appreciation 84.08](#x084-08)

[approach 178.08](#x178-08)　·　[approval 229.04](#x229-04)　·　[approximation 104.07](#x104-07)　·　[April 52.02](#x052-02)　·　[architect 147.01](#x147-01)　·　[architecture 217.01](#x217-01)　·　[archive 105.01](#x105-01)

[area 69.02](#x069-02)　·　[arena 163.02](#x163-02)　·　[argument 233.09](#x233-09)　·　[arm 96.04](#x096-04)　·　[arms 75.03](#x075-03)　·　[army 155.06](#x155-06)　·　[arrangement 204.04](#x204-04)

[array 116.05](#x116-05)　·　[arrest 64.05](#x064-05)　·　[arrival 149.10](#x149-10)　·　[arrow 201.09](#x201-09)　·　[art 123.10](#x123-10)　·　[article 67.03](#x067-03)　·　[artist 152.09](#x152-09)

[artwork 212.01](#x212-01)　·　[ash 109.06](#x109-06)　·　[aspect 71.07](#x071-07)　·　[aspiration 177.02](#x177-02)　·　[assassination 219.10](#x219-10)　·　[assault 106.01](#x106-01)　·　[assembly 66.05](#x066-05)

[assertion 157.09](#x157-09)　·　[assessment 232.02](#x232-02)　·　[asset 109.03](#x109-03)　·　[assignment 79.02](#x079-02)　·　[assistance 155.08](#x155-08)　·　[assistant 201.08](#x201-08)　·　[association 95.06](#x095-06)

[assumption 81.09](#x081-09)　·　[assurance 171.08](#x171-08)　·　[asylum 209.09](#x209-09)　·　[athlete 100.10](#x100-10)　·　[atmosphere 76.02](#x076-02)　·　[atrocity 165.06](#x165-06)　·　[attachment 239.02](#x239-02)

[attack 107.08](#x107-08)　·　[attempt 84.03](#x084-03)　·　[attendance 188.01](#x188-01)　·　[attention 235.07](#x235-07)　·　[attitude 127.05](#x127-05)　·　[attorney 64.05](#x064-05)　·　[attraction 188.02](#x188-02)

[attribute 214.06](#x214-06)　·　[auction 126.01](#x126-01)　·　[audience 55.07](#x055-07)　·　[audit 157.04](#x157-04)　·　[August 204.03](#x204-03)　·　[aunt 93.02](#x093-02)　·　[author 61.10](#x061-10)

[authority 179.05](#x179-05)　·　[auto 231.01](#x231-01)　·　[autonomy 119.08](#x119-08)　·　[autumn 60.03](#x060-03)　·　[availability 176.03](#x176-03)　·　[average 213.11](#x213-11)　·　[award 101.07](#x101-07)

[awareness 84.10](#x084-10)

#### 名詞　B

[baby 141.01](#x141-01)　·　[back 199.05](#x199-05)　·　[backdrop 98.02](#x098-02)　·　[background 67.07](#x067-07)　·　[backing 184.05](#x184-05)　·　[backup 216.07](#x216-07)　·　[bacteria 116.09](#x116-09)

[badge 54.04](#x054-04)　·　[bag 139.02](#x139-02)　·　[bail 220.07](#x220-07)　·　[balance 125.04](#x125-04)　·　[ball 80.08](#x080-08)　·　[ballet 151.05](#x151-05)　·　[balloon 200.07](#x200-07)

[ballot 103.02](#x103-02)　·　[ban 66.04](#x066-04)　·　[banana 142.03](#x142-03)　·　[band 213.01](#x213-01)　·　[bank (money) 111.02](#x111-02)　·　[bank (river) 51.01](#x051-01)　·　[banner 152.08](#x152-08)

[bar 210.06](#x210-06)　·　[bargain 121.03](#x121-03)　·　[barrel 56.03](#x056-03)　·　[barrier 170.06](#x170-06)　·　[base 214.02](#x214-02)　·　[baseball 100.05](#x100-05)　·　[basement 52.01](#x052-01)

[basis 150.10](#x150-10)　·　[basket 201.09](#x201-09)　·　[basketball 100.02](#x100-02)　·　[bass¹ 55.03](#x055-03)　·　[bat 160.08](#x160-08)　·　[bath 230.09](#x230-09)　·　[bathroom 121.02](#x121-02)

[battery 53.05](#x053-05)　·　[battle 154.05](#x154-05)　·　[battlefield 217.04](#x217-04)　·　[bay 90.02](#x090-02)　·　[beach 51.06](#x051-06)　·　[beam 143.08](#x143-08)　·　[bean 207.01](#x207-01)

[bear (animal) 98.08](#x098-08)　·　[beast 72.05](#x072-05)　·　[beat 151.03](#x151-03)　·　[beauty 212.10](#x212-10)　·　[bed 121.05](#x121-05)　·　[bedroom 80.05](#x080-05)　·　[bee 160.07](#x160-07)

[beef 207.01](#x207-01)　·　[beer 115.09](#x115-09)　·　[beginning 57.03](#x057-03)　·　[behalf 156.05](#x156-05)　·　[behaviour 219.08](#x219-08)　·　[being 125.09](#x125-09)　·　[belief 67.03](#x067-03)

[bell 139.01](#x139-01)　·　[belt 201.11](#x201-11)　·　[bench 90.04](#x090-04)　·　[benchmark 82.06](#x082-06)　·　[bend 147.05](#x147-05)　·　[beneficiary 212.07](#x212-07)　·　[benefit 110.04](#x110-04)

[best 87.06](#x087-06)　·　[bet 178.01](#x178-01)　·　[better 233.10](#x233-10)　·　[bias 113.10](#x113-10)　·　[bicycle 69.04](#x069-04)　·　[bid 176.02](#x176-02)　·　[bike 211.03](#x211-03)

[bill 111.03](#x111-03)　·　[bin 69.07](#x069-07)　·　[biography 164.05](#x164-05)　·　[biology 203.02](#x203-02)　·　[bird 95.02](#x095-02)　·　[birth 58.01](#x058-01)　·　[birthday 141.02](#x141-02)

[biscuit 207.06](#x207-06)　·　[bishop 108.10](#x108-10)　·　[bit 59.05](#x059-05)　·　[bite 174.07](#x174-07)　·　[black 209.11](#x209-11)　·　[blade 94.02](#x094-02)　·　[blame 69.09](#x069-09)

[blank 146.05](#x146-05)　·　[blanket 201.04](#x201-04)　·　[blast 107.04](#x107-04)　·　[blend 59.06](#x059-06)　·　[blessing 168.10](#x168-10)　·　[block 214.03](#x214-03)　·　[blog 102.06](#x102-06)

[blood 57.08](#x057-08)　·　[blow 155.09](#x155-09)　·　[blue 201.05](#x201-05)　·　[board 125.01](#x125-01)　·　[boat 51.01](#x051-01)　·　[body 140.06](#x140-06)　·　[bomb 219.07](#x219-07)

[bombing 107.03](#x107-03)　·　[bond 79.11](#x079-11)　·　[bone 144.04](#x144-04)　·　[bonus 223.02](#x223-02)　·　[book 120.01](#x120-01)　·　[booking 70.01](#x070-01)　·　[boom 171.05](#x171-05)

[boost 213.09](#x213-09)　·　[boot 92.12](#x092-12)　·　[border 56.02](#x056-02)　·　[boss 152.03](#x152-03)　·　[bottle 203.01](#x203-01)　·　[bottom 91.06](#x091-06)　·　[boundary 51.08](#x051-08)

[bow¹ 139.10](#x139-10)　·　[bowl 207.01](#x207-01)　·　[box 95.02](#x095-02)　·　[boy 59.05](#x059-05)　·　[boyfriend 164.06](#x164-06)　·　[brain 236.04](#x236-04)　·　[branch 90.10](#x090-10)

[brand 65.07](#x065-07)　·　[breach 157.01](#x157-01)　·　[bread 207.02](#x207-02)　·　[break 130.09](#x130-09)　·　[breakdown 74.09](#x074-09)　·　[breakfast 142.04](#x142-04)　·　[breakthrough 218.09](#x218-09)

[breast 108.07](#x108-07)　·　[breath 55.10](#x055-10)　·　[breathing 144.02](#x144-02)　·　[breed 218.04](#x218-04)　·　[brick 90.07](#x090-07)　·　[bride 65.08](#x065-08)　·　[bridge 139.05](#x139-05)

[broadband 216.07](#x216-07)　·　[broadcast 124.01](#x124-01)　·　[broadcaster 69.01](#x069-01)　·　[brother 140.03](#x140-03)　·　[brown 212.10](#x212-10)　·　[browser 112.09](#x112-09)　·　[brush 54.06](#x054-06)

[bubble 142.08](#x142-08)　·　[buck 212.04](#x212-04)　·　[buddy 121.04](#x121-04)　·　[budget 53.06](#x053-06)　·　[buffer 161.04](#x161-04)　·　[bug 228.01](#x228-01)　·　[building 114.01](#x114-01)

[bulk 65.03](#x065-03)　·　[bullet 165.02](#x165-02)　·　[bunch 210.05](#x210-05)　·　[burden 111.04](#x111-04)　·　[bureaucracy 87.04](#x087-04)　·　[burial 165.08](#x165-08)　·　[burn 201.02](#x201-02)

[bus 96.03](#x096-03)　·　[bush 60.04](#x060-04)　·　[business 152.01](#x152-01)　·　[businessman 212.03](#x212-03)　·　[butter 115.06](#x115-06)　·　[button 54.04](#x054-04)

#### 名詞　C

[cabin 170.05](#x170-05)　·　[cabinet 201.08](#x201-08)　·　[cable 114.11](#x114-11)　·　[cafe 65.08](#x065-08)　·　[cake 141.02](#x141-02)　·　[calculation 223.08](#x223-08)　·　[call 118.05](#x118-05)

[calm 76.10](#x076-10)　·　[camera 139.04](#x139-04)　·　[camp 225.07](#x225-07)　·　[campaign 119.03](#x119-03)　·　[camping 70.03](#x070-03)　·　[campus 153.01](#x153-01)　·　[can² 207.08](#x207-08)

[canal 90.03](#x090-03)　·　[cancer 79.02](#x079-02)　·　[candidate 156.02](#x156-02)　·　[candle 219.02](#x219-02)　·　[canvas 98.02](#x098-02)　·　[cap 54.03](#x054-03)　·　[capability 172.05](#x172-05)

[capacity 216.06](#x216-06)　·　[capital 107.03](#x107-03)　·　[capitalism 82.04](#x082-04)　·　[captain 143.07](#x143-07)　·　[capture 219.05](#x219-05)　·　[car 121.04](#x121-04)　·　[carbon 78.08](#x078-08)

[card 139.04](#x139-04)　·　[care 217.07](#x217-07)　·　[career 123.02](#x123-02)　·　[cargo 56.02](#x056-02)　·　[carpet 170.09](#x170-09)　·　[carriage 210.05](#x210-05)　·　[carrot 93.03](#x093-03)

[cartoon 63.03](#x063-03)　·　[case 145.08](#x145-08)　·　[cash 212.08](#x212-08)　·　[casino 106.02](#x106-02)　·　[cast 61.03](#x061-03)　·　[castle 163.01](#x163-01)　·　[casualty 231.09](#x231-09)

[cat 121.11](#x121-11)　·　[catalogue 71.09](#x071-09)　·　[catch 191.04](#x191-04)　·　[category 213.02](#x213-02)　·　[cattle 92.09](#x092-09)　·　[causation 57.11](#x057-11)　·　[cause 153.05](#x153-05)

[caution 237.11](#x237-11)　·　[cave 117.02](#x117-02)　·　[CD 55.09](#x055-09)　·　[ceiling 174.02](#x174-02)　·　[celebration 208.13](#x208-13)　·　[celebrity 124.04](#x124-04)　·　[cell 77.04](#x077-04)

[cemetery 165.07](#x165-07)　·　[cent 212.08](#x212-08)　·　[centre 110.07](#x110-07)　·　[century 81.01](#x081-01)　·　[ceremony 165.09](#x165-09)　·　[certainty 232.08](#x232-08)　·　[certificate 126.07](#x126-07)

[chain 65.01](#x065-01)　·　[chair 152.09](#x152-09)　·　[chairman 205.02](#x205-02)　·　[challenge 123.08](#x123-08)　·　[chamber 61.06](#x061-06)　·　[champion 163.02](#x163-02)　·　[championship 213.01](#x213-01)

[chance 100.13](#x100-13)　·　[change 65.08](#x065-08)　·　[channel 168.01](#x168-01)　·　[chaos 216.11](#x216-11)　·　[chapter 120.01](#x120-01)　·　[character 72.03](#x072-03)　·　[characteristic 188.03](#x188-03)

[characterization 208.09](#x208-09)　·　[charge 101.07](#x101-07)　·　[charity 68.01](#x068-01)　·　[charm 179.03](#x179-03)　·　[chart 201.09](#x201-09)　·　[charter 108.05](#x108-05)　·　[chase 77.08](#x077-08)

[chat 145.10](#x145-10)　·　[cheat 229.07](#x229-07)　·　[check 114.07](#x114-07)　·　[cheek 64.04](#x064-04)　·　[cheer 163.05](#x163-05)　·　[cheese 207.02](#x207-02)　·　[chef 115.01](#x115-01)

[chemical 60.05](#x060-05)　·　[chemistry 194.01](#x194-01)　·　[chest 237.09](#x237-09)　·　[chicken 93.03](#x093-03)　·　[chief 56.06](#x056-06)　·　[child 145.09](#x145-09)　·　[childhood 230.10](#x230-10)

[chip 115.04](#x115-04)　·　[chocolate 59.05](#x059-05)　·　[choice 156.03](#x156-03)　·　[choir 215.04](#x215-04)　·　[chunk 106.07](#x106-07)　·　[church 75.02](#x075-02)　·　[cigarette 148.10](#x148-10)

[cinema 209.01](#x209-01)　·　[circle 97.05](#x097-05)　·　[circuit 53.04](#x053-04)　·　[circulation 158.05](#x158-05)　·　[circumstance 239.07](#x239-07)　·　[citizen 103.09](#x103-09)　·　[citizenship 67.02](#x067-02)

[city 181.02](#x181-02)　·　[civilian 219.03](#x219-03)　·　[civilization 135.02](#x135-02)　·　[claim 65.10](#x065-10)　·　[clarity 184.07](#x184-07)　·　[clash 206.10](#x206-10)　·　[class 113.06](#x113-06)

[classic 85.06](#x085-06)　·　[classification 154.04](#x154-04)　·　[classroom 208.01](#x208-01)　·　[clause 103.05](#x103-05)　·　[clerk 53.09](#x053-09)　·　[click 151.03](#x151-03)　·　[client 204.07](#x204-07)

[cliff 117.02](#x117-02)　·　[climate 77.02](#x077-02)　·　[climb 163.03](#x163-03)　·　[clinic 201.12](#x201-12)　·　[clip 112.12](#x112-12)　·　[clock 50.08](#x050-08)　·　[close¹ 151.09](#x151-09)

[closure 204.06](#x204-06)　·　[cloth 93.02](#x093-02)　·　[clothes 54.01](#x054-01)　·　[clothing 148.04](#x148-04)　·　[cloud 210.01](#x210-01)　·　[club 100.05](#x100-05)　·　[clue 83.08](#x083-08)

[cluster 148.04](#x148-04)　·　[coach 206.05](#x206-05)　·　[coal 109.02](#x109-02)　·　[coalition 66.05](#x066-05)　·　[coast 143.01](#x143-01)　·　[coat 201.04](#x201-04)　·　[cocktail 115.09](#x115-09)

[code 73.06](#x073-06)　·　[coffee 142.01](#x142-01)　·　[coin 207.10](#x207-10)　·　[coincidence 136.03](#x136-03)　·　[cold 84.01](#x084-01)　·　[collaboration 172.09](#x172-09)　·　[collapse 236.07](#x236-07)

[colleague 99.08](#x099-08)　·　[collection 73.06](#x073-06)　·　[collector 154.03](#x154-03)　·　[college 227.01](#x227-01)　·　[collision 118.05](#x118-05)　·　[colony 63.02](#x063-02)　·　[colour 140.06](#x140-06)

[column 204.02](#x204-02)　·　[columnist 102.03](#x102-03)　·　[combat 75.07](#x075-07)　·　[combination 166.09](#x166-09)　·　[comedy 208.08](#x208-08)　·　[comfort 94.10](#x094-10)　·　[comic 72.05](#x072-05)

[command 169.02](#x169-02)　·　[commander 219.06](#x219-06)　·　[comment 102.03](#x102-03)　·　[commentary 63.10](#x063-10)　·　[commentator 158.04](#x158-04)　·　[commerce 233.03](#x233-03)　·　[commercial 124.07](#x124-07)

[commission 71.02](#x071-02)　·　[commissioner 156.03](#x156-03)　·　[commitment 224.09](#x224-09)　·　[committee 101.09](#x101-09)　·　[commodity 65.03](#x065-03)　·　[common 147.01](#x147-01)　·　[communication 233.02](#x233-02)

[community 122.02](#x122-02)　·　[companion 54.08](#x054-08)　·　[company 152.07](#x152-07)　·　[comparison 215.09](#x215-09)　·　[compassion 122.13](#x122-13)　·　[compensation 64.10](#x064-10)　·　[competence 194.10](#x194-10)

[competition 212.01](#x212-01)　·　[competitor 101.04](#x101-04)　·　[complaint 67.08](#x067-08)　·　[completion 175.06](#x175-06)　·　[complex 231.01](#x231-01)　·　[complexity 135.04](#x135-04)　·　[compliance 74.05](#x074-05)

[complication 144.07](#x144-07)　·　[component 210.02](#x210-02)　·　[composer 99.01](#x099-01)　·　[composition 71.03](#x071-03)　·　[compound 175.02](#x175-02)　·　[compromise 205.09](#x205-09)　·　[computer 112.02](#x112-02)

[concentration 78.03](#x078-03)　·　[concept 153.03](#x153-03)　·　[conception 233.09](#x233-09)　·　[concern 127.05](#x127-05)　·　[concert 55.01](#x055-01)　·　[concession 176.06](#x176-06)　·　[conclusion 229.10](#x229-10)

[concrete 114.02](#x114-02)　·　[condition 53.08](#x053-08)　·　[conduct 182.07](#x182-07)　·　[conference 233.01](#x233-01)　·　[confession 106.04](#x106-04)　·　[confidence 74.07](#x074-07)　·　[configuration 172.03](#x172-03)

[confirmation 209.06](#x209-06)　·　[conflict 102.05](#x102-05)　·　[confrontation 66.09](#x066-09)　·　[confusion 194.05](#x194-05)　·　[congregation 217.06](#x217-06)　·　[connection 112.06](#x112-06)　·　[conscience 76.03](#x076-03)

[consciousness 145.02](#x145-02)　·　[consensus 217.11](#x217-11)　·　[consent 96.08](#x096-08)　·　[consequence 76.03](#x076-03)　·　[conservation 161.03](#x161-03)　·　[conservative 224.01](#x224-01)　·　[consideration 125.13](#x125-13)

[consistency 81.05](#x081-05)　·　[conspiracy 158.04](#x158-04)　·　[constant 236.10](#x236-10)　·　[constituency 103.02](#x103-02)　·　[constitution 61.05](#x061-05)　·　[constraint 167.05](#x167-05)　·　[construct 241.07](#x241-07)

[construction 114.02](#x114-02)　·　[consultant 73.04](#x073-04)　·　[consultation 144.09](#x144-09)　·　[consumer 223.06](#x223-06)　·　[consumption 127.02](#x127-02)　·　[contact 79.09](#x079-09)　·　[container 162.04](#x162-04)

[contemporary 209.02](#x209-02)　·　[contempt 125.11](#x125-11)　·　[contender 61.10](#x061-10)　·　[content 157.06](#x157-06)　·　[content¹ 207.11](#x207-11)　·　[contention 127.08](#x127-08)　·　[contest 83.01](#x083-01)

[context 154.07](#x154-07)　·　[continent 225.04](#x225-04)　·　[continuity 138.11](#x138-11)　·　[contract 53.08](#x053-08)　·　[contractor 147.06](#x147-06)　·　[contradiction 239.08](#x239-08)　·　[contrary 135.04](#x135-04)

[contrast 65.04](#x065-04)　·　[contribution 182.10](#x182-10)　·　[contributor 227.06](#x227-06)　·　[control 95.07](#x095-07)　·　[controversy 64.09](#x064-09)　·　[convenience 176.04](#x176-04)　·　[convention 229.06](#x229-06)

[conversation 102.11](#x102-11)　·　[conversion 81.09](#x081-09)　·　[conviction 157.11](#x157-11)　·　[cook 207.01](#x207-01)　·　[cooker 115.01](#x115-01)　·　[cooking 55.09](#x055-09)　·　[cooperation 184.09](#x184-09)

[coordinate 225.02](#x225-02)　·　[coordination 132.13](#x132-13)　·　[coordinator 68.02](#x068-02)　·　[cop 168.09](#x168-09)　·　[copper 206.11](#x206-11)　·　[copy 105.10](#x105-10)　·　[copyright 71.10](#x071-10)

[core 185.04](#x185-04)　·　[corner 200.07](#x200-07)　·　[corporation 101.02](#x101-02)　·　[correction 54.08](#x054-08)　·　[correlation 159.03](#x159-03)　·　[correspondence 230.04](#x230-04)　·　[correspondent 102.03](#x102-03)

[corridor 55.10](#x055-10)　·　[corruption 157.03](#x157-03)　·　[cost 204.03](#x204-03)　·　[costume 98.04](#x098-04)　·　[cottage 60.01](#x060-01)　·　[cotton 148.05](#x148-05)　·　[council 205.01](#x205-01)

[councillor 103.02](#x103-02)　·　[counselling 58.02](#x058-02)　·　[counsellor 155.08](#x155-08)　·　[count 204.09](#x204-09)　·　[counter (long flat surface) 91.02](#x091-02)　·　[counterpart 81.04](#x081-04)　·　[country 155.02](#x155-02)

[countryside 218.01](#x218-01)　·　[county 103.01](#x103-01)　·　[coup 61.04](#x061-04)　·　[couple 149.06](#x149-06)　·　[courage 211.10](#x211-10)　·　[course 118.04](#x118-04)　·　[court 64.01](#x064-01)

[courtesy 167.08](#x167-08)　·　[cousin 212.05](#x212-05)　·　[cover 102.02](#x102-02)　·　[coverage 69.08](#x069-08)　·　[cow 142.06](#x142-06)　·　[crack 210.10](#x210-10)　·　[craft 94.11](#x094-11)

[crash 69.01](#x069-01)　·　[cream 142.02](#x142-02)　·　[creation 239.02](#x239-02)　·　[creativity 132.13](#x132-13)　·　[creator 71.06](#x071-06)　·　[creature 160.09](#x160-09)　·　[credibility 228.03](#x228-03)

[credit 111.02](#x111-02)　·　[crew 56.01](#x056-01)　·　[crime 157.04](#x157-04)　·　[criminal 220.04](#x220-04)　·　[crisis 130.04](#x130-04)　·　[criterion 80.10](#x080-10)　·　[critic 151.09](#x151-09)

[criticism 241.08](#x241-08)　·　[critique 123.01](#x123-01)　·　[crop 60.02](#x060-02)　·　[cross 139.05](#x139-05)　·　[crowd 206.01](#x206-01)　·　[crown 108.10](#x108-10)　·　[cruise 56.04](#x056-04)

[cry 157.08](#x157-08)　·　[crystal 226.01](#x226-01)　·　[cue 99.04](#x099-04)　·　[cult 86.01](#x086-01)　·　[culture 183.06](#x183-06)　·　[cup 222.06](#x222-06)　·　[cupboard 91.02](#x091-02)

[cure 57.06](#x057-06)　·　[curiosity 189.04](#x189-04)　·　[currency 223.07](#x223-07)　·　[current 90.06](#x090-06)　·　[curriculum 79.02](#x079-02)　·　[curtain 151.07](#x151-07)　·　[curve 200.08](#x200-08)

[custody 106.07](#x106-07)　·　[custom 80.07](#x080-07)　·　[customer 142.05](#x142-05)　·　[cut 211.06](#x211-06)　·　[cutting 94.04](#x094-04)　·　[cycle 68.02](#x068-02)

#### 名詞　D

[dad 141.04](#x141-04)　·　[dairy 207.02](#x207-02)　·　[dam 90.09](#x090-09)　·　[damage 52.04](#x052-04)　·　[dance 151.04](#x151-04)　·　[dancer 202.08](#x202-08)　·　[dancing 99.04](#x099-04)

[danger 70.05](#x070-05)　·　[dark 170.07](#x170-07)　·　[darkness 216.01](#x216-01)　·　[data 112.05](#x112-05)　·　[database 73.04](#x073-04)　·　[date 141.03](#x141-03)　·　[daughter 199.02](#x199-02)

[dawn 90.01](#x090-01)　·　[day 50.02](#x050-02)　·　[deadline 156.09](#x156-09)　·　[deal 212.08](#x212-08)　·　[dealer 102.11](#x102-11)　·　[death 63.09](#x063-09)　·　[debate 156.01](#x156-01)

[debris 214.05](#x214-05)　·　[debt 111.02](#x111-02)　·　[debut 61.08](#x061-08)　·　[decade 166.06](#x166-06)　·　[December 219.01](#x219-01)　·　[decision 100.14](#x100-14)　·　[decision-making 58.07](#x058-07)

[deck 143.07](#x143-07)　·　[declaration 219.02](#x219-02)　·　[decline 116.07](#x116-07)　·　[decoration 71.04](#x071-04)　·　[decrease 176.08](#x176-08)　·　[dedication 230.05](#x230-05)　·　[deed 108.06](#x108-06)

[default 65.05](#x065-05)　·　[defeat 186.09](#x186-09)　·　[defect 203.12](#x203-12)　·　[defence 107.12](#x107-12)　·　[defender 64.06](#x064-06)　·　[deficiency 160.03](#x160-03)　·　[deficit 205.08](#x205-08)

[definition 103.07](#x103-07)　·　[degree 79.04](#x079-04)　·　[delay 149.02](#x149-02)　·　[delegate 205.02](#x205-02)　·　[delegation 103.09](#x103-09)　·　[delight 80.10](#x080-10)　·　[delivery 181.01](#x181-01)

[demand 223.05](#x223-05)　·　[democracy 120.01](#x120-01)　·　[demon 76.04](#x076-04)　·　[demonstration 172.05](#x172-05)　·　[denial 219.11](#x219-11)　·　[density 116.06](#x116-06)　·　[dentist 79.05](#x079-05)

[department 181.01](#x181-01)　·　[departure 204.05](#x204-05)　·　[dependence 127.06](#x127-06)　·　[deployment 74.05](#x074-05)　·　[deposit 184.09](#x184-09)　·　[depression 222.04](#x222-04)　·　[depth 92.07](#x092-07)

[deputy 66.04](#x066-04)　·　[descent 180.03](#x180-03)　·　[description 202.01](#x202-01)　·　[desert 117.01](#x117-01)　·　[design 71.03](#x071-03)　·　[designer 154.01](#x154-01)　·　[desire 202.11](#x202-11)

[desk 91.08](#x091-08)　·　[desktop 73.03](#x073-03)　·　[destination 149.08](#x149-08)　·　[destruction 214.05](#x214-05)　·　[detail 104.10](#x104-10)　·　[detection 57.11](#x057-11)　·　[detective 157.05](#x157-05)

[detention 238.01](#x238-01)　·　[determinant 110.08](#x110-08)　·　[determination 70.09](#x070-09)　·　[development 171.02](#x171-02)　·　[deviation 225.08](#x225-08)　·　[device 94.02](#x094-02)　·　[devil 76.05](#x076-05)

[diagnosis 145.05](#x145-05)　·　[diagram 203.11](#x203-11)　·　[dialogue 123.07](#x123-07)　·　[diamond 62.03](#x062-03)　·　[diary 140.09](#x140-09)　·　[dictator 219.08](#x219-08)　·　[dictionary 123.09](#x123-09)

[diet 57.10](#x057-10)　·　[difference 140.10](#x140-10)　·　[differentiation 236.11](#x236-11)　·　[difficulty 131.06](#x131-06)　·　[dignity 58.04](#x058-04)　·　[dilemma 183.08](#x183-08)　·　[dimension 226.02](#x226-02)

[dinner 94.01](#x094-01)　·　[diplomat 66.10](#x066-10)　·　[direction 166.04](#x166-04)　·　[director 209.02](#x209-02)　·　[directory 112.03](#x112-03)　·　[dirt 54.03](#x054-03)　·　[disability 145.01](#x145-01)

[disadvantage 232.04](#x232-04)　·　[disagreement 107.13](#x107-13)　·　[disappointment 84.03](#x084-03)　·　[disaster 180.08](#x180-08)　·　[disc 207.05](#x207-05)　·　[discipline 117.09](#x117-09)　·　[disclosure 58.03](#x058-03)

[discount 142.07](#x142-07)　·　[discourse 242.01](#x242-01)　·　[discovery 117.09](#x117-09)　·　[discretion 57.09](#x057-09)　·　[discrimination 178.07](#x178-07)　·　[discussion 217.02](#x217-02)　·　[disease 109.08](#x109-08)

[dish 59.04](#x059-04)　·　[dislike 187.06](#x187-06)　·　[dismissal 234.09](#x234-09)　·　[disorder 106.11](#x106-11)　·　[display 58.09](#x058-09)　·　[disposal 185.05](#x185-05)　·　[dispute 217.10](#x217-10)

[disruption 111.09](#x111-09)　·　[distance 51.06](#x051-06)　·　[distinction 153.06](#x153-06)　·　[distress 222.05](#x222-05)　·　[distribution 113.07](#x113-07)　·　[district 57.01](#x057-01)　·　[dive 193.09](#x193-09)

[diversity 234.03](#x234-03)　·　[divide 116.05](#x116-05)　·　[division 83.01](#x083-01)　·　[divorce 167.02](#x167-02)　·　[doctor 201.01](#x201-01)　·　[doctrine 135.02](#x135-02)　·　[document 57.07](#x057-07)

[documentary 154.05](#x154-05)　·　[documentation 220.01](#x220-01)　·　[dog 92.05](#x092-05)　·　[dollar 65.03](#x065-03)　·　[domain 173.01](#x173-01)　·　[dominance 242.01](#x242-01)　·　[donation 111.04](#x111-04)

[donor 73.03](#x073-03)　·　[door 139.02](#x139-02)　·　[dose 221.03](#x221-03)　·　[dot 90.13](#x090-13)　·　[doubt 58.03](#x058-03)　·　[download 173.02](#x173-02)　·　[downtown 224.01](#x224-01)

[dozen 115.08](#x115-08)　·　[draft 53.11](#x053-11)　·　[drama 151.04](#x151-04)　·　[drawing 201.09](#x201-09)　·　[dream 134.01](#x134-01)　·　[dress 62.01](#x062-01)　·　[drink 142.07](#x142-07)

[drive 230.06](#x230-06)　·　[driver 96.05](#x096-05)　·　[driving 87.04](#x087-04)　·　[drop 159.02](#x159-02)　·　[drought 218.01](#x218-01)　·　[drug 96.09](#x096-09)　·　[drum 55.02](#x055-02)

[duo 151.07](#x151-07)　·　[duration 209.06](#x209-06)　·　[dust 109.06](#x109-06)　·　[duty 86.02](#x086-02)　·　[DVD 151.02](#x151-02)　·　[dynamic 233.09](#x233-09)

#### 名詞　E

[ear 99.12](#x099-12)　·　[earnings 65.01](#x065-01)　·　[earth 161.08](#x161-08)　·　[earthquake 214.01](#x214-01)　·　[ease 136.08](#x136-08)　·　[east 56.02](#x056-02)　·　[echo 168.08](#x168-08)

[economics 223.09](#x223-09)　·　[economist 110.02](#x110-02)　·　[economy 82.02](#x082-02)　·　[edge 140.02](#x140-02)　·　[edition 229.01](#x229-01)　·　[editor 102.02](#x102-02)　·　[education 79.01](#x079-01)

[educator 153.03](#x153-03)　·　[effect 203.08](#x203-08)　·　[effectiveness 110.11](#x110-11)　·　[efficacy 81.04](#x081-04)　·　[efficiency 172.04](#x172-04)　·　[effort 223.10](#x223-10)　·　[egg 95.04](#x095-04)

[ego 72.05](#x072-05)　·　[elbow 140.04](#x140-04)　·　[election 224.01](#x224-01)　·　[electricity 111.03](#x111-03)　·　[electronics 55.05](#x055-05)　·　[element 183.06](#x183-06)　·　[elephant 217.04](#x217-04)

[elite 127.06](#x127-06)　·　[email 73.09](#x073-09)　·　[embarrassment 182.06](#x182-06)　·　[embassy 209.08](#x209-08)　·　[emergence 127.06](#x127-06)　·　[emergency 59.01](#x059-01)　·　[emission 162.05](#x162-05)

[emotion 215.11](#x215-11)　·　[emphasis 124.05](#x124-05)　·　[empire 63.01](#x063-01)　·　[employee 149.05](#x149-05)　·　[employer 223.03](#x223-03)　·　[employment 127.01](#x127-01)　·　[encounter 61.06](#x061-06)

[encouragement 189.09](#x189-09)　·　[end 206.12](#x206-12)　·　[endeavour 134.12](#x134-12)　·　[ending 61.10](#x061-10)　·　[endorsement 176.09](#x176-09)　·　[enemy 208.05](#x208-05)　·　[energy 116.06](#x116-06)

[enforcement 64.10](#x064-10)　·　[engagement 196.01](#x196-01)　·　[engine 210.02](#x210-02)　·　[engineer 90.09](#x090-09)　·　[engineering 78.10](#x078-10)　·　[enquiry 157.01](#x157-01)　·　[enterprise 218.07](#x218-07)

[entertainment 124.05](#x124-05)　·　[enthusiasm 72.02](#x072-02)　·　[enthusiast 164.06](#x164-06)　·　[entity 233.03](#x233-03)　·　[entrance 98.01](#x098-01)　·　[entrepreneur 53.07](#x053-07)　·　[entry 146.04](#x146-04)

[envelope 200.06](#x200-06)　·　[environment 116.03](#x116-03)　·　[epidemic 57.02](#x057-02)　·　[episode 188.04](#x188-04)　·　[equal 234.09](#x234-09)　·　[equality 120.08](#x120-08)　·　[equation 65.05](#x065-05)

[equipment 152.05](#x152-05)　·　[equivalence 227.10](#x227-10)　·　[equivalent 131.06](#x131-06)　·　[era 75.08](#x075-08)　·　[error 157.04](#x157-04)　·　[escape 237.05](#x237-05)　·　[essay 123.03](#x123-03)

[essence 85.05](#x085-05)　·　[establishment 189.01](#x189-01)　·　[estate 205.04](#x205-04)　·　[estimate 110.02](#x110-02)　·　[estimation 82.02](#x082-02)　·　[ethic 185.04](#x185-04)　·　[ethnicity 209.07](#x209-07)

[euro 110.03](#x110-03)　·　[evaluation 70.05](#x070-05)　·　[evening 140.09](#x140-09)　·　[event 215.01](#x215-01)　·　[evidence 103.01](#x103-01)　·　[evil 75.10](#x075-10)　·　[evolution 189.02](#x189-02)

[exam 227.03](#x227-03)　·　[examination 96.08](#x096-08)　·　[example 65.10](#x065-10)　·　[excellence 189.09](#x189-09)　·　[exception 204.05](#x204-05)　·　[excess 127.03](#x127-03)　·　[exchange 65.05](#x065-05)

[excitement 193.02](#x193-02)　·　[exclusion 234.08](#x234-08)　·　[excuse 106.04](#x106-04)　·　[execution 78.05](#x078-05)　·　[executive 157.02](#x157-02)　·　[exercise 227.04](#x227-04)　·　[exhibit 100.14](#x100-14)

[exhibition 50.03](#x050-03)　·　[exile 155.07](#x155-07)　·　[existence 209.05](#x209-05)　·　[exit 114.09](#x114-09)　·　[expansion 65.01](#x065-01)　·　[expectation 178.05](#x178-05)　·　[expedition 225.01](#x225-01)

[expenditure 110.03](#x110-03)　·　[expense 53.01](#x053-01)　·　[experience 167.01](#x167-01)　·　[experiment 203.09](#x203-09)　·　[expert 95.06](#x095-06)　·　[expertise 81.06](#x081-06)　·　[explanation 153.06](#x153-06)

[exploitation 224.03](#x224-03)　·　[exploration 117.02](#x117-02)　·　[explosion 75.06](#x075-06)　·　[explosive 179.06](#x179-06)　·　[export 223.06](#x223-06)　·　[exposure 109.08](#x109-08)　·　[expression 58.08](#x058-08)

[extension 181.04](#x181-04)　·　[extent 220.12](#x220-12)　·　[extra 138.06](#x138-06)　·　[extract 71.10](#x071-10)　·　[extreme 195.02](#x195-02)　·　[extremist 219.07](#x219-07)　·　[eye 96.06](#x096-06)

#### 名詞　F

[fabric 54.02](#x054-02)　·　[face 157.08](#x157-08)　·　[facility 205.09](#x205-09)　·　[fact 135.08](#x135-08)　·　[faction 66.06](#x066-06)　·　[factor 159.04](#x159-04)　·　[factory 212.09](#x212-09)

[faculty 113.01](#x113-01)　·　[failure 73.09](#x073-09)　·　[fairness 184.06](#x184-06)　·　[faith 217.09](#x217-09)　·　[fall 114.06](#x114-06)　·　[fame 82.06](#x082-06)　·　[family 154.05](#x154-05)

[fan 212.04](#x212-04)　·　[fantasy 123.04](#x123-04)　·　[fare 70.02](#x070-02)　·　[farm 156.04](#x156-04)　·　[farmer 218.01](#x218-01)　·　[farming 127.01](#x127-01)　·　[fashion 72.02](#x072-02)

[fat 194.02](#x194-02)　·　[fate 232.08](#x232-08)　·　[father 90.05](#x090-05)　·　[fault 69.08](#x069-08)　·　[favour 184.03](#x184-03)　·　[favourite 213.07](#x213-07)　·　[fear 105.06](#x105-06)

[feat 68.10](#x068-10)　·　[feather 148.07](#x148-07)　·　[feature 227.09](#x227-09)　·　[February 115.02](#x115-02)　·　[fee 53.07](#x053-07)　·　[feed 142.06](#x142-06)　·　[feedback 229.04](#x229-04)

[feel 123.09](#x123-09)　·　[feeling 72.09](#x072-09)　·　[female 193.04](#x193-04)　·　[feminist 224.02](#x224-02)　·　[fence 90.12](#x090-12)　·　[festival 61.01](#x061-01)　·　[fever 145.06](#x145-06)

[fibre 210.08](#x210-08)　·　[fiction 123.02](#x123-02)　·　[field 68.02](#x068-02)　·　[fight 153.08](#x153-08)　·　[fighting 237.02](#x237-02)　·　[figure 104.05](#x104-05)　·　[file 57.01](#x057-01)

[film 151.01](#x151-01)　·　[film-maker 209.02](#x209-02)　·　[filter 112.03](#x112-03)　·　[final 63.10](#x063-10)　·　[finance 191.01](#x191-01)　·　[finding 203.10](#x203-10)　·　[fine 131.02](#x131-02)

[finger 52.03](#x052-03)　·　[finish 163.04](#x163-04)　·　[fire 216.04](#x216-04)　·　[firearm 107.06](#x107-06)　·　[firefighter 69.06](#x069-06)　·　[firework 179.04](#x179-04)　·　[firm 223.02](#x223-02)

[first 91.14](#x091-14)　·　[fish 56.04](#x056-04)　·　[fishing 144.09](#x144-09)　·　[fit 235.06](#x235-06)　·　[fitness 101.06](#x101-06)　·　[fix 73.10](#x073-10)　·　[fixture 192.02](#x192-02)

[flag 206.12](#x206-12)　·　[flame 97.06](#x097-06)　·　[flash 53.04](#x053-04)　·　[flat 168.07](#x168-07)　·　[flavour 207.03](#x207-03)　·　[flaw 112.10](#x112-10)　·　[fleet 56.02](#x056-02)

[flesh 194.02](#x194-02)　·　[flexibility 214.06](#x214-06)　·　[flight 118.06](#x118-06)　·　[flood 51.02](#x051-02)　·　[floor 147.03](#x147-03)　·　[flour 207.04](#x207-04)　·　[flow 90.10](#x090-10)

[flower 60.08](#x060-08)　·　[flu 145.06](#x145-06)　·　[fluid 203.08](#x203-08)　·　[fly 116.01](#x116-01)　·　[flying 77.09](#x077-09)　·　[focus 189.02](#x189-02)　·　[fold 200.11](#x200-11)

[folk 125.06](#x125-06)　·　[following 67.09](#x067-09)　·　[food 162.01](#x162-01)　·　[fool 244.04](#x244-04)　·　[foot 94.08](#x094-08)　·　[footage 69.01](#x069-01)　·　[football 163.04](#x163-04)

[force 214.04](#x214-04)　·　[forecast 111.08](#x111-08)　·　[foreigner 67.01](#x067-01)　·　[forest 161.05](#x161-05)　·　[fork 207.06](#x207-06)　·　[form 127.01](#x127-01)　·　[format 73.05](#x073-05)

[formation 189.03](#x189-03)　·　[formula 214.10](#x214-10)　·　[formulation 127.04](#x127-04)　·　[fortune 65.09](#x065-09)　·　[forum 189.01](#x189-01)　·　[fossil 226.01](#x226-01)　·　[foundation 114.02](#x114-02)

[founder 65.07](#x065-07)　·　[fraction 159.06](#x159-06)　·　[fragment 214.05](#x214-05)　·　[frame 99.06](#x099-06)　·　[framework 76.07](#x076-07)　·　[franchise 176.07](#x176-07)　·　[fraud 220.03](#x220-03)

[freedom 122.11](#x122-11)　·　[frequency 74.02](#x074-02)　·　[Friday 142.01](#x142-01)　·　[fridge 207.08](#x207-08)　·　[friend 122.03](#x122-03)　·　[friendship 72.09](#x072-09)　·　[frog 160.07](#x160-07)

[front 206.02](#x206-02)　·　[fruit 93.07](#x093-07)　·　[frustration 84.02](#x084-02)　·　[fuel 162.01](#x162-01)　·　[fun 213.12](#x213-12)　·　[function 112.11](#x112-11)　·　[fund 53.07](#x053-07)

[funding 171.08](#x171-08)　·　[fundraising 212.02](#x212-02)　·　[funeral 122.01](#x122-01)　·　[fur 76.04](#x076-04)　·　[furniture 152.05](#x152-05)　·　[future 218.11](#x218-11)

#### 名詞　G

[gain 111.05](#x111-05)　·　[gallery 71.01](#x071-01)　·　[gallon 162.04](#x162-04)　·　[gambling 213.12](#x213-12)　·　[game 100.08](#x100-08)　·　[gaming 77.10](#x077-10)　·　[gang 193.01](#x193-01)

[gap 210.07](#x210-07)　·　[garage 94.01](#x094-01)　·　[garden 60.01](#x060-01)　·　[gas 162.04](#x162-04)　·　[gate 200.09](#x200-09)　·　[gathering 103.01](#x103-01)　·　[gaze 61.09](#x061-09)

[gear 144.09](#x144-09)　·　[gender 209.07](#x209-07)　·　[gene 129.03](#x129-03)　·　[general 61.04](#x061-04)　·　[generalization 161.09](#x161-09)　·　[generation 217.06](#x217-06)　·　[genius 126.04](#x126-04)

[genocide 63.08](#x063-08)　·　[genre 154.03](#x154-03)　·　[gentleman 199.07](#x199-07)　·　[geography 125.07](#x125-07)　·　[gesture 61.09](#x061-09)　·　[ghost 187.01](#x187-01)　·　[giant 226.09](#x226-09)

[gift 94.11](#x094-11)　·　[gig 72.01](#x072-01)　·　[girl 140.02](#x140-02)　·　[girlfriend 211.07](#x211-07)　·　[glance 128.09](#x128-09)　·　[glass 59.09](#x059-09)　·　[glimpse 140.04](#x140-04)

[globalization 233.01](#x233-01)　·　[globe 117.08](#x117-08)　·　[glory 75.09](#x075-09)　·　[glove 139.03](#x139-03)　·　[go 225.09](#x225-09)　·　[goal 100.13](#x100-13)　·　[god 75.10](#x075-10)

[gold 177.06](#x177-06)　·　[golf 212.06](#x212-06)　·　[good 127.07](#x127-07)　·　[goodbye 72.07](#x072-07)　·　[goodness 190.06](#x190-06)　·　[goods 218.05](#x218-05)　·　[governance 119.12](#x119-12)

[government 66.02](#x066-02)　·　[governor 156.01](#x156-01)　·　[grace 208.12](#x208-12)　·　[grade 113.03](#x113-03)　·　[graduate 68.03](#x068-03)　·　[grain 142.06](#x142-06)　·　[grandfather 200.02](#x200-02)

[grandmother 115.02](#x115-02)　·　[grandparent 51.05](#x051-05)　·　[grant 152.06](#x152-06)　·　[graphics 228.10](#x228-10)　·　[grasp 94.06](#x094-06)　·　[grass 60.03](#x060-03)　·　[grave (for dead person) 165.07](#x165-07)

[gravity 214.04](#x214-04)　·　[green 125.03](#x125-03)　·　[greenhouse 60.05](#x060-05)　·　[grey 175.02](#x175-02)　·　[grid 225.02](#x225-02)　·　[grief 122.02](#x122-02)　·　[grin 55.11](#x055-11)

[grip 143.03](#x143-03)　·　[grocery 223.01](#x223-01)　·　[ground 92.03](#x092-03)　·　[group 66.01](#x066-01)　·　[growth 160.04](#x160-04)　·　[guarantee 232.07](#x232-07)　·　[guard 104.03](#x104-03)

[guerrilla 75.03](#x075-03)　·　[guess 153.07](#x153-07)　·　[guest 199.01](#x199-01)　·　[guidance 105.09](#x105-09)　·　[guide 52.02](#x052-02)　·　[guideline 154.02](#x154-02)　·　[guilt 219.11](#x219-11)

[guitar 99.02](#x099-02)　·　[gun 61.04](#x061-04)　·　[gut 174.09](#x174-09)　·　[guy 213.10](#x213-10)　·　[gym 100.01](#x100-01)

#### 名詞　H

[habit 59.10](#x059-10)　·　[habitat 160.09](#x160-09)　·　[hair 208.04](#x208-04)　·　[half 132.07](#x132-07)　·　[hall 59.01](#x059-01)　·　[halt 176.08](#x176-08)　·　[hand 200.02](#x200-02)

[handful 90.08](#x090-08)　·　[handle 50.10](#x050-10)　·　[handling 189.06](#x189-06)　·　[handout 214.10](#x214-10)　·　[happiness 129.08](#x129-08)　·　[harassment 67.01](#x067-01)　·　[harbour 142.01](#x142-01)

[hardware 216.04](#x216-04)　·　[harm 104.07](#x104-07)　·　[harmony 55.08](#x055-08)　·　[harvest 161.02](#x161-02)　·　[hat 204.12](#x204-12)　·　[hate 120.11](#x120-11)　·　[hatred 67.04](#x067-04)

[hazard 162.07](#x162-07)　·　[head 199.08](#x199-08)　·　[headache 97.05](#x097-05)　·　[headline 67.09](#x067-09)　·　[headquarters 169.01](#x169-01)　·　[health 222.03](#x222-03)　·　[healthcare 110.01](#x110-01)

[hearing 64.07](#x064-07)　·　[heart 144.04](#x144-04)　·　[heat 218.03](#x218-03)　·　[heating 111.03](#x111-03)　·　[heaven 75.09](#x075-09)　·　[heel 148.08](#x148-08)　·　[height 213.08](#x213-08)

[helicopter 118.01](#x118-01)　·　[hell 76.04](#x076-04)　·　[hello 187.09](#x187-09)　·　[helmet 211.04](#x211-04)　·　[help 96.05](#x096-05)　·　[herb 59.04](#x059-04)　·　[heritage 189.02](#x189-02)

[hero 215.12](#x215-12)　·　[hierarchy 119.10](#x119-10)　·　[high 52.02](#x052-02)　·　[highlight 179.04](#x179-04)　·　[highway 211.02](#x211-02)　·　[hill 92.01](#x092-01)　·　[hint 84.10](#x084-10)

[hip 144.02](#x144-02)　·　[hire 204.03](#x204-03)　·　[historian 107.10](#x107-10)　·　[history 50.05](#x050-05)　·　[hit 188.01](#x188-01)　·　[hobby 226.07](#x226-07)　·　[hockey 100.06](#x100-06)

[hold 80.09](#x080-09)　·　[hole 143.02](#x143-02)　·　[holiday 230.01](#x230-01)　·　[home 90.02](#x090-02)　·　[homeland 62.01](#x062-01)　·　[homework 153.07](#x153-07)　·　[honesty 230.05](#x230-05)

[honour 99.11](#x099-11)　·　[hook 54.05](#x054-05)　·　[hope 155.09](#x155-09)　·　[horizon 212.09](#x212-09)　·　[horn 99.02](#x099-02)　·　[horror 75.09](#x075-09)　·　[horse 174.10](#x174-10)

[hospital 201.01](#x201-01)　·　[host 108.14](#x108-14)　·　[hostage 75.04](#x075-04)　·　[hostility 183.06](#x183-06)　·　[hotel 204.05](#x204-05)　·　[hour 104.06](#x104-06)　·　[house 59.03](#x059-03)

[household 156.05](#x156-05)　·　[housing 205.03](#x205-03)　·　[human 125.08](#x125-08)　·　[humanity 75.08](#x075-08)　·　[humour 164.09](#x164-09)　·　[hunger 237.07](#x237-07)　·　[hunt 133.06](#x133-06)

[hunting 77.05](#x077-05)　·　[hurricane 161.01](#x161-01)　·　[hurry 238.04](#x238-04)　·　[hurt 97.03](#x097-03)　·　[husband 83.04](#x083-04)　·　[hydrogen 162.06](#x162-06)　·　[hypothesis 203.09](#x203-09)

#### 名詞　I

[ice 115.10](#x115-10)　·　[ice cream 59.05](#x059-05)　·　[icon 166.02](#x166-02)　·　[ID 220.04](#x220-04)　·　[idea 95.10](#x095-10)　·　[ideal 82.09](#x082-09)　·　[identification 190.02](#x190-02)

[identity 203.06](#x203-06)　·　[ideology 127.09](#x127-09)　·　[idiot 67.03](#x067-03)　·　[ignorance 175.07](#x175-07)　·　[illness 221.01](#x221-01)　·　[illusion 114.05](#x114-05)　·　[illustration 60.09](#x060-09)

[image 150.02](#x150-02)　·　[imagery 227.05](#x227-05)　·　[imagination 123.08](#x123-08)　·　[immigrant 64.03](#x064-03)　·　[immigration 155.08](#x155-08)　·　[impact 222.04](#x222-04)　·　[implementation 119.07](#x119-07)

[implication 82.05](#x082-05)　·　[import 171.04](#x171-04)　·　[importance 209.10](#x209-10)　·　[impression 102.08](#x102-08)　·　[imprisonment 64.08](#x064-08)　·　[improvement 177.05](#x177-05)　·　[inability 221.08](#x221-08)

[incentive 101.04](#x101-04)　·　[inch 71.05](#x071-05)　·　[incidence 159.05](#x159-05)　·　[incident 202.01](#x202-01)　·　[inclusion 120.10](#x120-10)　·　[income 64.03](#x064-03)　·　[increase 159.02](#x159-02)

[independence 219.02](#x219-02)　·　[index 112.03](#x112-03)　·　[indication 57.08](#x057-08)　·　[indicator 159.05](#x159-05)　·　[indictment 220.02](#x220-02)　·　[individual 97.04](#x097-04)　·　[induction 79.05](#x079-05)

[industry 171.02](#x171-02)　·　[inequality 224.03](#x224-03)　·　[infant 110.09](#x110-09)　·　[infection 57.03](#x057-03)　·　[inference 150.10](#x150-10)　·　[inflation 223.04](#x223-04)　·　[influence 135.01](#x135-01)

[info 73.10](#x073-10)　·　[information 146.08](#x146-08)　·　[infrastructure 216.06](#x216-06)　·　[ingredient 93.05](#x093-05)　·　[inhabitant 67.02](#x067-02)　·　[initiation 189.03](#x189-03)　·　[initiative 234.04](#x234-04)

[injection 96.11](#x096-11)　·　[injury 58.05](#x058-05)　·　[injustice 183.08](#x183-08)　·　[ink 201.07](#x201-07)　·　[inmate 106.01](#x106-01)　·　[innovation 74.07](#x074-07)　·　[input 172.07](#x172-07)

[insect 203.01](#x203-01)　·　[insertion 108.08](#x108-08)　·　[inside 81.03](#x081-03)　·　[insider 157.03](#x157-03)　·　[insight 234.10](#x234-10)　·　[inspection 112.07](#x112-07)　·　[inspector 53.01](#x053-01)

[inspiration 196.06](#x196-06)　·　[instability 236.06](#x236-06)　·　[installation 112.10](#x112-10)　·　[instance 78.10](#x078-10)　·　[instinct 193.06](#x193-06)　·　[institute 217.07](#x217-07)　·　[institution 106.13](#x106-13)

[instruction 85.02](#x085-02)　·　[instructor 144.01](#x144-01)　·　[instrument 203.12](#x203-12)　·　[insult 106.05](#x106-05)　·　[insurance 69.09](#x069-09)　·　[intake 159.06](#x159-06)　·　[integration 234.05](#x234-05)

[integrity 105.09](#x105-09)　·　[intellectual 76.08](#x076-08)　·　[intelligence 196.09](#x196-09)　·　[intensity 214.09](#x214-09)　·　[intent 106.06](#x106-06)　·　[intention 82.05](#x082-05)　·　[interaction 153.02](#x153-02)

[interest 236.11](#x236-11)　·　[interface 112.04](#x112-04)　·　[interference 74.01](#x074-01)　·　[interior 147.08](#x147-08)　·　[internet 216.08](#x216-08)　·　[interpretation 97.08](#x097-08)　·　[interval 55.04](#x055-04)

[intervention 165.06](#x165-06)　·　[interview 202.05](#x202-05)　·　[interviewee 97.08](#x097-08)　·　[interviewer 67.07](#x067-07)　·　[introduction 187.03](#x187-03)　·　[invasion 219.03](#x219-03)　·　[invention 94.08](#x094-08)

[investigation 64.07](#x064-07)　·　[investigator 157.01](#x157-01)　·　[investment 217.07](#x217-07)　·　[investor 111.01](#x111-01)　·　[invitation 50.01](#x050-01)　·　[involvement 185.03](#x185-03)　·　[iron 214.03](#x214-03)

[irony 135.09](#x135-09)　·　[island 51.06](#x051-06)　·　[isolation 196.04](#x196-04)　·　[issue 224.09](#x224-09)　·　[IT 112.01](#x112-01)　·　[item 53.06](#x053-06)

#### 名詞　J

[jacket 140.04](#x140-04)　·　[jail 220.07](#x220-07)　·　[jam 115.07](#x115-07)　·　[January 50.01](#x050-01)　·　[jazz 151.06](#x151-06)　·　[jeans 200.02](#x200-02)　·　[jet 118.02](#x118-02)

[jewellery 62.03](#x062-03)　·　[job 146.04](#x146-04)　·　[joint 200.04](#x200-04)　·　[joke 98.12](#x098-12)　·　[journal 57.02](#x057-02)　·　[journalism 153.02](#x153-02)　·　[journalist 202.01](#x202-01)

[journey 111.10](#x111-10)　·　[joy 84.07](#x084-07)　·　[judge 157.05](#x157-05)　·　[judgement 220.11](#x220-11)　·　[juice 93.06](#x093-06)　·　[July 69.01](#x069-01)　·　[jump 180.08](#x180-08)

[junction 210.01](#x210-01)　·　[June 110.12](#x110-12)　·　[jurisdiction 64.07](#x064-07)　·　[jury 157.10](#x157-10)　·　[justice 220.11](#x220-11)　·　[justification 107.09](#x107-09)

#### 名詞　K

[key 50.06](#x050-06)　·　[keyboard 172.02](#x172-02)　·　[kick 213.04](#x213-04)　·　[kid 100.02](#x100-02)　·　[kidney 57.08](#x057-08)　·　[killing 165.03](#x165-03)　·　[kilometre 225.08](#x225-08)

[kind 122.13](#x122-13)　·　[kind (type) 82.04](#x082-04)　·　[king 164.01](#x164-01)　·　[kingdom 208.02](#x208-02)　·　[kiss 122.08](#x122-08)　·　[kit 70.03](#x070-03)　·　[kitchen 142.09](#x142-09)

[knee 201.02](#x201-02)　·　[knife 98.04](#x098-04)　·　[knock 50.09](#x050-09)　·　[knowledge 184.08](#x184-08)

#### 名詞　L

[lab 203.01](#x203-01)　·　[label 91.03](#x091-03)　·　[laboratory 77.01](#x077-01)　·　[labour 171.05](#x171-05)　·　[lack 237.11](#x237-11)　·　[lad 122.04](#x122-04)　·　[ladder 50.06](#x050-06)

[lady 164.05](#x164-05)　·　[lake 206.01](#x206-01)　·　[lamp 94.03](#x094-03)　·　[land 51.10](#x051-10)　·　[landing 168.07](#x168-07)　·　[landlord 204.08](#x204-08)　·　[landmark 105.08](#x105-08)

[landscape 63.05](#x063-05)　·　[lane 147.06](#x147-06)　·　[language 209.07](#x209-07)　·　[lap 122.04](#x122-04)　·　[laptop 73.03](#x073-03)　·　[laser 147.08](#x147-08)　·　[last¹ (final) 230.07](#x230-07)

[latest 136.02](#x136-02)　·　[latter 83.09](#x083-09)　·　[laugh 146.09](#x146-09)　·　[laughter 208.06](#x208-06)　·　[launch 119.01](#x119-01)　·　[law 63.08](#x063-08)　·　[lawn 147.02](#x147-02)

[lawsuit 238.05](#x238-05)　·　[lawyer 104.01](#x104-01)　·　[layer 52.04](#x052-04)　·　[layout 147.09](#x147-09)　·　[lead¹ 231.11](#x231-11)　·　[leader 119.09](#x119-09)　·　[leadership 82.03](#x082-03)

[leaf 160.04](#x160-04)　·　[leaflet 222.03](#x222-03)　·　[league 100.08](#x100-08)　·　[leak 53.02](#x053-02)　·　[leap 193.09](#x193-09)　·　[learning 234.06](#x234-06)　·　[leather 91.06](#x091-06)

[leave 54.04](#x054-04)　·　[lecture 153.10](#x153-10)　·　[lecturer 203.02](#x203-02)　·　[left 98.04](#x098-04)　·　[leg 54.02](#x054-02)　·　[legacy 198.06](#x198-06)　·　[legend 227.07](#x227-07)

[legislation 103.05](#x103-05)　·　[legislature 66.10](#x066-10)　·　[leisure 177.04](#x177-04)　·　[lemon 203.03](#x203-03)　·　[length 114.03](#x114-03)　·　[lens 73.07](#x073-07)　·　[lesson 153.06](#x153-06)

[letter 204.08](#x204-08)　·　[level 90.07](#x090-07)　·　[liberal 67.04](#x067-04)　·　[liberation 166.06](#x166-06)　·　[liberty 224.06](#x224-06)　·　[library 105.01](#x105-01)　·　[licence 53.10](#x053-10)

[lie² (tell a lie) 140.10](#x140-10)　·　[life 217.09](#x217-09)　·　[lifestyle 125.09](#x125-09)　·　[lifetime 72.10](#x072-10)　·　[lift 149.04](#x149-04)　·　[light (from the sun/a lamp) 199.05](#x199-05)　·　[lighting 94.03](#x094-03)

[like (find sb/sth pleasant) 80.01](#x080-01)　·　[likelihood 173.03](#x173-03)　·　[limb 211.08](#x211-08)　·　[limit 128.12](#x128-12)　·　[limitation 74.09](#x074-09)　·　[line 139.07](#x139-07)　·　[line-up 220.05](#x220-05)

[link 112.01](#x112-01)　·　[lion 76.04](#x076-04)　·　[lip 174.02](#x174-02)　·　[liquid 203.06](#x203-06)　·　[list 100.01](#x100-01)　·　[listener 58.06](#x058-06)　·　[listing 191.02](#x191-02)

[literacy 227.03](#x227-03)　·　[literature 123.06](#x123-06)　·　[litre 59.03](#x059-03)　·　[litter 170.02](#x170-02)　·　[liver 221.04](#x221-04)　·　[living 125.14](#x125-14)　·　[load 69.02](#x069-02)

[loan 152.05](#x152-05)　·　[lobby 222.06](#x222-06)　·　[local 126.04](#x126-04)　·　[location 70.06](#x070-06)　·　[lock 148.01](#x148-01)　·　[log 226.11](#x226-11)　·　[logic 128.06](#x128-06)

[logo 65.07](#x065-07)　·　[look 140.05](#x140-05)　·　[loop 199.06](#x199-06)　·　[lord 108.04](#x108-04)　·　[lorry 69.02](#x069-02)　·　[loss 152.06](#x152-06)　·　[lottery 229.08](#x229-08)

[love 115.13](#x115-13)　·　[low 81.08](#x081-08)　·　[loyalty 187.06](#x187-06)　·　[luck 225.10](#x225-10)　·　[lunch 93.01](#x093-01)　·　[lung 57.03](#x057-03)　·　[luxury 184.02](#x184-02)

[lyric 213.07](#x213-07)

#### 名詞　M

[machine 109.04](#x109-04)　·　[machinery 53.02](#x053-02)　·　[magazine 158.07](#x158-07)　·　[magic 235.07](#x235-07)　·　[magistrate 104.06](#x104-06)　·　[magnitude 70.06](#x070-06)　·　[mail 158.08](#x158-08)

[mainland 206.12](#x206-12)　·　[mainstream 127.10](#x127-10)　·　[maintenance 53.07](#x053-07)　·　[majority 156.06](#x156-06)　·　[make 199.07](#x199-07)　·　[make-up 130.02](#x130-02)　·　[making 81.09](#x081-09)

[male 165.07](#x165-07)　·　[mall 223.01](#x223-01)　·　[man 96.03](#x096-03)　·　[management 81.06](#x081-06)　·　[manager 149.05](#x149-05)　·　[mandate 205.04](#x205-04)　·　[manipulation 125.11](#x125-11)

[manner 74.07](#x074-07)　·　[manufacturing 162.01](#x162-01)　·　[manuscript 219.01](#x219-01)　·　[map 91.08](#x091-08)　·　[marathon 68.01](#x068-01)　·　[March 166.03](#x166-03)　·　[march 219.06](#x219-06)

[margin 126.02](#x126-02)　·　[mark 50.04](#x050-04)　·　[marker 187.03](#x187-03)　·　[market 207.01](#x207-01)　·　[marketing 102.06](#x102-06)　·　[marketplace 72.04](#x072-04)　·　[marriage 167.02](#x167-02)

[mask 235.02](#x235-02)　·　[mass 128.06](#x128-06)　·　[massacre 63.07](#x063-07)　·　[master 177.02](#x177-02)　·　[match (contest/correspond) 213.13](#x213-13)　·　[mate 101.04](#x101-04)　·　[material 54.05](#x054-05)

[mathematics 159.01](#x159-01)　·　[maths 236.09](#x236-09)　·　[matter 105.11](#x105-11)　·　[maximum 81.08](#x081-08)　·　[May 180.01](#x180-01)　·　[mayor 205.05](#x205-05)　·　[meal 93.05](#x093-05)

[meaning 63.08](#x063-08)　·　[means 177.04](#x177-04)　·　[meantime 229.07](#x229-07)　·　[measure 126.10](#x126-10)　·　[measurement 57.07](#x057-07)　·　[meat 142.05](#x142-05)　·　[mechanic 210.02](#x210-02)

[mechanism 94.13](#x094-13)　·　[medal 68.08](#x068-08)　·　[media 158.03](#x158-03)　·　[medication 221.02](#x221-02)　·　[medicine 96.11](#x096-11)　·　[meditation 76.03](#x076-03)　·　[medium 196.05](#x196-05)

[meeting 205.01](#x205-01)　·　[melody 99.02](#x099-02)　·　[member 66.07](#x066-07)　·　[membership 182.02](#x182-02)　·　[memo 216.09](#x216-09)　·　[memoir 123.02](#x123-02)　·　[memorial 54.09](#x054-09)

[memory 139.11](#x139-11)　·　[mention 230.03](#x230-03)　·　[mentor 106.08](#x106-08)　·　[menu 59.04](#x059-04)　·　[merchant 142.02](#x142-02)　·　[mercy 227.06](#x227-06)　·　[merger 111.01](#x111-01)

[merit 80.10](#x080-10)　·　[mess 170.01](#x170-01)　·　[message 216.03](#x216-03)　·　[metal 90.02](#x090-02)　·　[metaphor 72.05](#x072-05)　·　[method 159.08](#x159-08)　·　[methodology 203.11](#x203-11)

[metre 114.03](#x114-03)　·　[middle 71.03](#x071-03)　·　[midnight 139.01](#x139-01)　·　[midst 208.03](#x208-03)　·　[migration 116.04](#x116-04)　·　[mile 51.06](#x051-06)　·　[militant 155.01](#x155-01)

[military 219.04](#x219-04)　·　[militia 107.02](#x107-02)　·　[milk 59.03](#x059-03)　·　[mill 147.01](#x147-01)　·　[mind 240.09](#x240-09)　·　[mine (hole in the ground) 109.02](#x109-02)　·　[miner 52.07](#x052-07)

[mineral 160.03](#x160-03)　·　[minimum 241.11](#x241-11)　·　[mining 109.03](#x109-03)　·　[minister 66.03](#x066-03)　·　[ministry 171.06](#x171-06)　·　[minority 224.04](#x224-04)　·　[minute¹ 118.10](#x118-10)

[miracle 83.05](#x083-05)　·　[mirror 140.07](#x140-07)　·　[misery 238.06](#x238-06)　·　[missile 107.04](#x107-04)　·　[mission 85.01](#x085-01)　·　[mistake 175.07](#x175-07)　·　[mix 207.05](#x207-05)

[mixture 115.06](#x115-06)　·　[mob 63.07](#x063-07)　·　[mobile 146.02](#x146-02)　·　[mobility 237.09](#x237-09)　·　[mode 112.08](#x112-08)　·　[model 53.08](#x053-08)　·　[modelling 173.03](#x173-03)

[modernity 241.06](#x241-06)　·　[modernization 127.04](#x127-04)　·　[modification 74.08](#x074-08)　·　[module 153.01](#x153-01)　·　[moment 222.11](#x222-11)　·　[momentum 120.09](#x120-09)　·　[Monday 67.09](#x067-09)

[money 152.04](#x152-04)　·　[monitor 214.09](#x214-09)　·　[monk 108.11](#x108-11)　·　[monkey 76.04](#x076-04)　·　[monopoly 176.07](#x176-07)　·　[monster 209.03](#x209-03)　·　[month 93.08](#x093-08)

[monument 75.10](#x075-10)　·　[mood 188.08](#x188-08)　·　[moon 225.01](#x225-01)　·　[moral 123.06](#x123-06)　·　[morality 76.03](#x076-03)　·　[morning 140.09](#x140-09)　·　[mortgage 223.05](#x223-05)

[mosque 108.13](#x108-13)　·　[mother 55.09](#x055-09)　·　[motion 173.06](#x173-06)　·　[motivation 242.03](#x242-03)　·　[motive 107.08](#x107-08)　·　[motor 53.02](#x053-02)　·　[motorcycle 180.06](#x180-06)

[motorist 211.02](#x211-02)　·　[mountain 107.01](#x107-01)　·　[mouse 73.03](#x073-03)　·　[mouth 188.03](#x188-03)　·　[move 241.10](#x241-10)　·　[movement 116.05](#x116-05)　·　[movie 72.06](#x072-06)

[mud 160.07](#x160-07)　·　[mum 200.05](#x200-05)　·　[murder 130.04](#x130-04)　·　[muscle 68.05](#x068-05)　·　[museum 139.04](#x139-04)　·　[music 215.11](#x215-11)　·　[musical 98.02](#x098-02)

[musician 55.01](#x055-01)　·　[mystery 165.03](#x165-03)　·　[myth 227.06](#x227-06)

#### 名詞　N

[nail 114.07](#x114-07)　·　[name 54.07](#x054-07)　·　[narrative 141.05](#x141-05)　·　[nation 219.03](#x219-03)　·　[national 119.06](#x119-06)　·　[native 63.03](#x063-03)　·　[nature 189.08](#x189-08)

[navigation 225.06](#x225-06)　·　[necessity 120.12](#x120-12)　·　[neck 52.01](#x052-01)　·　[need 155.05](#x155-05)　·　[needle 199.06](#x199-06)　·　[negative 135.07](#x135-07)　·　[neglect 81.10](#x081-10)

[negotiation 152.10](#x152-10)　·　[neighbour 215.05](#x215-05)　·　[neighbourhood 108.02](#x108-02)　·　[nerve 89.06](#x089-06)　·　[nest 141.07](#x141-07)　·　[net 206.02](#x206-02)　·　[network 111.04](#x111-04)

[news 79.11](#x079-11)　·　[newsletter 158.01](#x158-01)　·　[newspaper 229.01](#x229-01)　·　[next 124.14](#x124-14)　·　[niche 77.08](#x077-08)　·　[night 168.01](#x168-01)　·　[nightmare 241.03](#x241-03)

[noise 99.05](#x099-05)　·　[nomination 85.09](#x085-09)　·　[nominee 156.05](#x156-05)　·　[nonsense 235.07](#x235-07)　·　[noon 100.08](#x100-08)　·　[norm 89.08](#x089-08)　·　[normal 144.02](#x144-02)

[north 225.02](#x225-02)　·　[nose 98.09](#x098-09)　·　[note 50.07](#x050-07)　·　[notebook 139.04](#x139-04)　·　[notice 216.10](#x216-10)　·　[notion 102.05](#x102-05)　·　[novel 61.02](#x061-02)

[novelist 164.07](#x164-07)　·　[November 230.03](#x230-03)　·　[number 99.09](#x099-09)　·　[nurse 57.01](#x057-01)　·　[nursery 160.01](#x160-01)　·　[nut 207.04](#x207-04)　·　[nutrition 115.13](#x115-13)

#### 名詞　O

[obesity 79.06](#x079-06)　·　[object 150.04](#x150-04)　·　[objection 217.08](#x217-08)　·　[objective 97.03](#x097-03)　·　[obligation 58.04](#x058-04)　·　[observation 145.05](#x145-05)　·　[observer 208.13](#x208-13)

[obsession 136.04](#x136-04)　·　[obstacle 78.08](#x078-08)　·　[occasion 196.02](#x196-02)　·　[occupation 230.06](#x230-06)　·　[occurrence 113.07](#x113-07)　·　[ocean 56.01](#x056-01)　·　[October 166.03](#x166-03)

[odds 213.10](#x213-10)　·　[offence 105.06](#x105-06)　·　[offender 86.08](#x086-08)　·　[offer 152.10](#x152-10)　·　[offering 236.02](#x236-02)　·　[office 91.01](#x091-01)　·　[officer 64.04](#x064-04)

[official 146.01](#x146-01)　·　[offspring 218.04](#x218-04)　·　[oil 115.03](#x115-03)　·　[onion 59.04](#x059-04)　·　[opening 170.06](#x170-06)　·　[opera 215.01](#x215-01)　·　[operation 118.10](#x118-10)

[operator 53.03](#x053-03)　·　[opinion 156.06](#x156-06)　·　[opponent 206.09](#x206-09)　·　[opportunity 127.07](#x127-07)　·　[opposite 85.07](#x085-07)　·　[opposition 191.07](#x191-07)　·　[optimism 241.05](#x241-05)

[option 132.01](#x132-01)　·　[orange 59.04](#x059-04)　·　[orchestra 151.01](#x151-01)　·　[order 219.06](#x219-06)　·　[organ 96.07](#x096-07)　·　[organization 82.02](#x082-02)　·　[organizer 154.01](#x154-01)

[orientation 234.05](#x234-05)　·　[origin 108.08](#x108-08)　·　[original 73.02](#x073-02)　·　[outbreak 175.01](#x175-01)　·　[outcome 205.12](#x205-12)　·　[outfit 104.03](#x104-03)　·　[outing 77.01](#x077-01)

[outlet 158.03](#x158-03)　·　[outline 216.10](#x216-10)　·　[outlook 117.07](#x117-07)　·　[output 73.08](#x073-08)　·　[outrage 158.02](#x158-02)　·　[outside 202.10](#x202-10)　·　[outsider 120.09](#x120-09)

[oven 59.02](#x059-02)　·　[overlap 154.06](#x154-06)　·　[overview 222.03](#x222-03)　·　[owner 91.04](#x091-04)　·　[ownership 54.10](#x054-10)　·　[oxygen 144.03](#x144-03)

#### 名詞　P

[pace 206.08](#x206-08)　·　[pack 124.09](#x124-09)　·　[package 80.05](#x080-05)　·　[packet 139.06](#x139-06)　·　[pad 201.08](#x201-08)　·　[page 102.12](#x102-12)　·　[pain 57.05](#x057-05)

[paint 148.03](#x148-03)　·　[painter 202.07](#x202-07)　·　[painting 98.03](#x098-03)　·　[pair 69.06](#x069-06)　·　[palace 164.01](#x164-01)　·　[palm 200.03](#x200-03)　·　[pan 115.03](#x115-03)

[panel 58.07](#x058-07)　·　[panic 169.05](#x169-05)　·　[pants 235.03](#x235-03)　·　[paper 91.13](#x091-13)　·　[parade 82.07](#x082-07)　·　[paragraph 154.07](#x154-07)　·　[parallel 233.06](#x233-06)

[parameter 113.04](#x113-04)　·　[parent 70.08](#x070-08)　·　[parish 187.01](#x187-01)　·　[park 213.01](#x213-01)　·　[parking 121.04](#x121-04)　·　[parliament 66.04](#x066-04)　·　[part 172.07](#x172-07)

[participant 214.02](#x214-02)　·　[participation 113.04](#x113-04)　·　[particular 85.08](#x085-08)　·　[partner 151.06](#x151-06)　·　[partnership 205.07](#x205-07)　·　[party 120.05](#x120-05)　·　[pass 80.03](#x080-03)

[passage 166.08](#x166-08)　·　[passenger 206.04](#x206-04)　·　[passing 122.12](#x122-12)　·　[passion 68.03](#x068-03)　·　[passport 155.03](#x155-03)　·　[password 228.05](#x228-05)　·　[past 108.03](#x108-03)

[pastor 75.08](#x075-08)　·　[patch 160.05](#x160-05)　·　[patent 239.05](#x239-05)　·　[path 92.03](#x092-03)　·　[pathway 80.01](#x080-01)　·　[patience 185.07](#x185-07)　·　[patient 201.10](#x201-10)

[patrol 118.06](#x118-06)　·　[patron 71.01](#x071-01)　·　[pattern 150.08](#x150-08)　·　[pause 205.11](#x205-11)　·　[pay 101.08](#x101-08)　·　[payment 65.11](#x065-11)　·　[peace 165.09](#x165-09)

[peak 225.07](#x225-07)　·　[peasant 108.02](#x108-02)　·　[peer 79.09](#x079-09)　·　[pen 146.03](#x146-03)　·　[penalty 220.10](#x220-10)　·　[pencil 90.07](#x090-07)　·　[penny 65.03](#x065-03)

[pension¹ 184.01](#x184-01)　·　[people 224.06](#x224-06)　·　[pepper 93.03](#x093-03)　·　[per cent 80.04](#x080-04)　·　[percentage 159.07](#x159-07)　·　[perception 226.10](#x226-10)　·　[performance 99.12](#x099-12)

[period 75.09](#x075-09)　·　[permission 146.03](#x146-03)　·　[permit 230.02](#x230-02)　·　[person 91.11](#x091-11)　·　[personality 76.05](#x076-05)　·　[personnel 179.05](#x179-05)　·　[perspective 226.06](#x226-06)

[pet 121.11](#x121-11)　·　[petition 64.09](#x064-09)　·　[petrol 162.04](#x162-04)　·　[phase 226.05](#x226-05)　·　[phenomenon 129.05](#x129-05)　·　[philosopher 76.01](#x076-01)　·　[philosophy 196.08](#x196-08)

[phone 216.03](#x216-03)　·　[photo 95.11](#x095-11)　·　[photograph 53.10](#x053-10)　·　[photographer 140.01](#x140-01)　·　[photography 200.01](#x200-01)　·　[phrase 123.09](#x123-09)　·　[physician 57.02](#x057-02)

[physics 150.04](#x150-04)　·　[piano 215.03](#x215-03)　·　[pick 124.09](#x124-09)　·　[picture 71.01](#x071-01)　·　[piece 141.05](#x141-05)　·　[pig 218.02](#x218-02)　·　[pile 109.05](#x109-05)

[pill 57.06](#x057-06)　·　[pilot 149.07](#x149-07)　·　[pin 201.11](#x201-11)　·　[pink 125.04](#x125-04)　·　[pioneer 77.02](#x077-02)　·　[pipe 147.02](#x147-02)　·　[pipeline 232.01](#x232-01)

[pirate 98.04](#x098-04)　·　[pit 54.08](#x054-08)　·　[pitch 192.04](#x192-04)　·　[pity 222.07](#x222-07)　·　[place 91.10](#x091-10)　·　[placement 71.09](#x071-09)　·　[plan 147.01](#x147-01)

[plane 225.06](#x225-06)　·　[planet 117.06](#x117-06)　·　[planning 81.04](#x081-04)　·　[plant 160.01](#x160-01)　·　[plastic 214.03](#x214-03)　·　[plate 93.02](#x093-02)　·　[platform 66.07](#x066-07)

[play 164.04](#x164-04)　·　[player 213.01](#x213-01)　·　[plea 120.08](#x120-08)　·　[pleasure 76.05](#x076-05)　·　[pledge 167.07](#x167-07)　·　[plot 208.09](#x208-09)　·　[plug 115.10](#x115-10)

[plus¹ 85.09](#x085-09)　·　[pocket 178.03](#x178-03)　·　[poem 227.04](#x227-04)　·　[poet 123.01](#x123-01)　·　[poetry 72.01](#x072-01)　·　[point 164.09](#x164-09)　·　[poison 232.07](#x232-07)

[pole 90.02](#x090-02)　·　[police 64.02](#x064-02)　·　[policeman 155.03](#x155-03)　·　[policy 233.08](#x233-08)　·　[politician 103.03](#x103-03)　·　[politics 67.03](#x067-03)　·　[poll 156.03](#x156-03)

[pollution 232.02](#x232-02)　·　[pond 116.01](#x116-01)　·　[pool 68.06](#x068-06)　·　[pop 151.06](#x151-06)　·　[popularity 229.06](#x229-06)　·　[population 113.05](#x113-05)　·　[port 56.01](#x056-01)

[portfolio 150.01](#x150-01)　·　[portion 232.07](#x232-07)　·　[portrait 102.04](#x102-04)　·　[position 66.10](#x066-10)　·　[positive 159.09](#x159-09)　·　[possession 230.11](#x230-11)　·　[possibility 113.09](#x113-09)

[post 73.03](#x073-03)　·　[poster 171.01](#x171-01)　·　[pot 237.01](#x237-01)　·　[potato 115.03](#x115-03)　·　[potential 82.02](#x082-02)　·　[pound 171.04](#x171-04)　·　[poverty 218.06](#x218-06)

[powder 109.07](#x109-07)　·　[power 53.03](#x053-03)　·　[practical 177.03](#x177-03)　·　[practice 225.10](#x225-10)　·　[practitioner 109.09](#x109-09)　·　[praise 68.10](#x068-10)　·　[prayer 165.08](#x165-08)

[precedent 220.10](#x220-10)　·　[precision 104.07](#x104-07)　·　[predator 60.07](#x060-07)　·　[predecessor 185.03](#x185-03)　·　[prediction 229.10](#x229-10)　·　[preference 115.12](#x115-12)　·　[pregnancy 58.01](#x058-01)

[prejudice 183.02](#x183-02)　·　[premier 237.03](#x237-03)　·　[premise 113.11](#x113-11)　·　[premium 87.05](#x087-05)　·　[preparation 189.04](#x189-04)　·　[prescription 221.02](#x221-02)　·　[presence 121.12](#x121-12)

[present 83.04](#x083-04)　·　[presentation 167.09](#x167-09)　·　[preservation 217.02](#x217-02)　·　[presidency 120.10](#x120-10)　·　[president 66.08](#x066-08)　·　[press 158.02](#x158-02)　·　[pressure 216.06](#x216-06)

[prevalence 109.09](#x109-09)　·　[prevention 79.02](#x079-02)　·　[prey 160.08](#x160-08)　·　[price 204.02](#x204-02)　·　[pride 135.03](#x135-03)　·　[priest 75.04](#x075-04)　·　[prince 164.01](#x164-01)

[princess 208.02](#x208-02)　·　[principal 120.02](#x120-02)　·　[principle 80.02](#x080-02)　·　[print 140.01](#x140-01)　·　[printer 226.02](#x226-02)　·　[printing 126.03](#x126-03)　·　[priority 87.08](#x087-08)

[prison 165.04](#x165-04)　·　[prisoner 219.01](#x219-01)　·　[privacy 105.08](#x105-08)　·　[privatization 66.02](#x066-02)　·　[privilege 167.04](#x167-04)　·　[prize 212.02](#x212-02)　·　[probability 110.04](#x110-04)

[probe 78.01](#x078-01)　·　[problem 186.03](#x186-03)　·　[procedure 228.07](#x228-07)　·　[proceedings 104.01](#x104-01)　·　[proceeds 65.06](#x065-06)　·　[process 184.07](#x184-07)　·　[processing 226.05](#x226-05)

[processor 112.05](#x112-05)　·　[produce 56.04](#x056-04)　·　[producer 151.02](#x151-02)　·　[product 218.08](#x218-08)　·　[production 124.08](#x124-08)　·　[productivity 82.03](#x082-03)　·　[profession 155.07](#x155-07)

[professional 215.06](#x215-06)　·　[professor 113.02](#x113-02)　·　[profile 68.01](#x068-01)　·　[profit 152.03](#x152-03)　·　[program 225.06](#x225-06)　·　[programme 120.01](#x120-01)　·　[programming 73.04](#x073-04)

[progress 189.08](#x189-08)　·　[progression 234.07](#x234-07)　·　[project 97.02](#x097-02)　·　[projection 82.01](#x082-01)　·　[promise 152.10](#x152-10)　·　[promotion 229.03](#x229-03)　·　[proof 104.10](#x104-10)

[propaganda 63.04](#x063-04)　·　[property 156.08](#x156-08)　·　[proportion 218.08](#x218-08)　·　[proposal 91.09](#x091-09)　·　[proposition 76.07](#x076-07)　·　[prosecution 157.10](#x157-10)　·　[prosecutor 220.02](#x220-02)

[prospect 135.11](#x135-11)　·　[prosperity 82.02](#x082-02)　·　[protection 145.04](#x145-04)　·　[protein 218.08](#x218-08)　·　[protest 131.01](#x131-01)　·　[protester 66.05](#x066-05)　·　[protocol 179.06](#x179-06)

[province 212.03](#x212-03)　·　[provision 131.02](#x131-02)　·　[psychologist 58.06](#x058-06)　·　[psychology 178.01](#x178-01)　·　[pub 213.10](#x213-10)　·　[public 101.07](#x101-07)　·　[publication 71.10](#x071-10)

[publicity 152.07](#x152-07)　·　[publishing 229.02](#x229-02)　·　[pull 132.07](#x132-07)　·　[pulse 57.07](#x057-07)　·　[pump 147.02](#x147-02)　·　[punch 208.07](#x208-07)　·　[punishment 106.06](#x106-06)

[punk 72.03](#x072-03)　·　[pupil 145.05](#x145-05)　·　[purchase 204.02](#x204-02)　·　[purple 125.02](#x125-02)　·　[purpose 74.04](#x074-04)　·　[pursuit 198.04](#x198-04)　·　[push 239.10](#x239-10)

[puzzle 128.02](#x128-02)

#### 名詞　Q

[qualification 79.04](#x079-04)　·　[quality 177.07](#x177-07)　·　[quantity 218.10](#x218-10)　·　[quarter 104.08](#x104-08)　·　[queen 61.02](#x061-02)　·　[query 153.09](#x153-09)　·　[quest 244.01](#x244-01)

[question 103.09](#x103-09)　·　[questionnaire 80.01](#x080-01)　·　[queue 142.03](#x142-03)　·　[quota 223.02](#x223-02)　·　[quotation 123.12](#x123-12)　·　[quote 82.10](#x082-10)

#### 名詞　R

[race 163.01](#x163-01)　·　[race (competition) 206.01](#x206-01)　·　[race (people) 125.05](#x125-05)　·　[racing 83.01](#x083-01)　·　[racism 183.02](#x183-02)　·　[racist 224.07](#x224-07)　·　[radar 118.03](#x118-03)

[radiation 78.04](#x078-04)　·　[radio 158.04](#x158-04)　·　[rage 238.07](#x238-07)　·　[raid 107.06](#x107-06)　·　[rail 59.09](#x059-09)　·　[railway 149.01](#x149-01)　·　[rain 216.01](#x216-01)

[rally 120.07](#x120-07)　·　[range 77.05](#x077-05)　·　[rank 146.04](#x146-04)　·　[ranking 229.06](#x229-06)　·　[rape 105.04](#x105-04)　·　[rat 60.06](#x060-06)　·　[rate 159.02](#x159-02)

[rating 227.04](#x227-04)　·　[ratio 110.08](#x110-08)　·　[rationale 78.06](#x078-06)　·　[rationality 185.07](#x185-07)　·　[ray 202.07](#x202-07)　·　[reach 128.08](#x128-08)　·　[reaction 86.06](#x086-06)

[reader 154.08](#x154-08)　·　[reading 227.02](#x227-02)　·　[reality 123.04](#x123-04)　·　[realization 83.10](#x083-10)　·　[realm 174.03](#x174-03)　·　[rear 210.05](#x210-05)　·　[reason 104.09](#x104-09)

[reasoning 76.08](#x076-08)　·　[rebel 164.08](#x164-08)　·　[rebellion 219.08](#x219-08)　·　[receipt 102.09](#x102-09)　·　[receiver 55.02](#x055-02)　·　[reception 152.08](#x152-08)　·　[recession 223.05](#x223-05)

[recipe 115.02](#x115-02)　·　[recipient 73.10](#x073-10)　·　[recognition 178.05](#x178-05)　·　[recommendation 230.04](#x230-04)　·　[reconstruction 127.12](#x127-12)　·　[record 52.05](#x052-05)　·　[recording 151.02](#x151-02)

[recovery 221.07](#x221-07)　·　[recruit 107.02](#x107-02)　·　[recruitment 82.07](#x082-07)　·　[red 146.06](#x146-06)　·　[reduction 218.06](#x218-06)　·　[referee 100.07](#x100-07)　·　[reference 67.10](#x067-10)

[referendum 156.07](#x156-07)　·　[reflection 200.12](#x200-12)　·　[reform 103.11](#x103-11)　·　[refuge 59.01](#x059-01)　·　[refugee 155.01](#x155-01)　·　[refusal 209.09](#x209-09)　·　[regard 135.10](#x135-10)

[regime 63.02](#x063-02)　·　[region 159.01](#x159-01)　·　[register 204.01](#x204-01)　·　[registration 120.03](#x120-03)　·　[regret 86.07](#x086-07)　·　[regulation 146.02](#x146-02)　·　[regulator 232.02](#x232-02)

[rehabilitation 106.09](#x106-09)　·　[reign 61.03](#x061-03)　·　[rejection 155.09](#x155-09)　·　[relation 223.09](#x223-09)　·　[relationship 125.07](#x125-07)　·　[relative 72.08](#x072-08)　·　[release 165.05](#x165-05)

[relevance 239.07](#x239-07)　·　[reliability 113.12](#x113-12)　·　[reliance 78.10](#x078-10)　·　[relief 168.09](#x168-09)　·　[religion 227.08](#x227-08)　·　[remainder 115.08](#x115-08)　·　[remains 75.08](#x075-08)

[remark 158.09](#x158-09)　·　[remedy 218.09](#x218-09)　·　[reminder 136.09](#x136-09)　·　[removal 63.04](#x063-04)　·　[rent 152.02](#x152-02)　·　[rental 230.01](#x230-01)　·　[repair 114.09](#x114-09)

[repeat 55.06](#x055-06)　·　[replacement 146.07](#x146-07)　·　[reply 227.11](#x227-11)　·　[report 95.11](#x095-11)　·　[reporter 64.05](#x064-05)　·　[reporting 158.06](#x158-06)　·　[representation 224.04](#x224-04)

[representative 101.05](#x101-05)　·　[reproduction 71.06](#x071-06)　·　[republic 166.01](#x166-01)　·　[reputation 238.05](#x238-05)　·　[request 122.11](#x122-11)　·　[requirement 78.04](#x078-04)　·　[rescue 143.05](#x143-05)

[research 228.03](#x228-03)　·　[researcher 97.01](#x097-01)　·　[reservation 80.03](#x080-03)　·　[reserve 181.09](#x181-09)　·　[residence 209.06](#x209-06)　·　[resident 105.02](#x105-02)　·　[residue 78.01](#x078-01)

[resignation 185.02](#x185-02)　·　[resistance 242.04](#x242-04)　·　[resolution 135.11](#x135-11)　·　[resort 70.02](#x070-02)　·　[resource 176.09](#x176-09)　·　[respect 224.06](#x224-06)　·　[response 113.03](#x113-03)

[responsibility 86.09](#x086-09)　·　[rest (remaining part) 141.08](#x141-08)　·　[rest (sleep/relax) 222.07](#x222-07)　·　[restaurant 115.01](#x115-01)　·　[restoration 71.01](#x071-01)　·　[restraint 179.09](#x179-09)　·　[restriction 216.03](#x216-03)

[result 99.09](#x099-09)　·　[retail 65.01](#x065-01)　·　[retirement 184.01](#x184-01)　·　[retreat 237.05](#x237-05)　·　[return 96.01](#x096-01)　·　[revelation 87.10](#x087-10)　·　[revenge 164.07](#x164-07)

[revenue 218.10](#x218-10)　·　[reverse 126.11](#x126-11)　·　[review 64.09](#x064-09)　·　[revision 158.08](#x158-08)　·　[revival 215.11](#x215-11)　·　[revolution 119.12](#x119-12)　·　[reward 70.10](#x070-10)

[rhetoric 185.07](#x185-07)　·　[rhythm 206.07](#x206-07)　·　[rice 93.03](#x093-03)　·　[ride 72.04](#x072-04)　·　[rifle 164.02](#x164-02)　·　[right 220.11](#x220-11)　·　[ring¹ 104.02](#x104-02)

[ring² 75.07](#x075-07)　·　[riot 155.02](#x155-02)　·　[rise 225.04](#x225-04)　·　[risk 114.06](#x114-06)　·　[ritual 76.01](#x076-01)　·　[rival 184.04](#x184-04)　·　[river 202.09](#x202-09)

[road 92.02](#x092-02)　·　[robbery 64.02](#x064-02)　·　[robot 172.01](#x172-01)　·　[rock (music) 236.02](#x236-02)　·　[rock (stone) 92.06](#x092-06)　·　[rocket 85.01](#x085-01)　·　[rod 140.03](#x140-03)

[role 208.14](#x208-14)　·　[roll 115.07](#x115-07)　·　[romance 72.10](#x072-10)　·　[roof 147.06](#x147-06)　·　[room 200.01](#x200-01)　·　[root 93.09](#x093-09)　·　[rope 51.03](#x051-03)

[rose 160.07](#x160-07)　·　[rotation 225.03](#x225-03)　·　[round 99.04](#x099-04)　·　[route 51.05](#x051-05)　·　[routine 184.08](#x184-08)　·　[row¹ 212.05](#x212-05)　·　[rubber 94.12](#x094-12)

[rubbish 87.01](#x087-01)　·　[rugby 163.04](#x163-04)　·　[ruin 241.01](#x241-01)　·　[rule 100.10](#x100-10)　·　[ruling 64.10](#x064-10)　·　[rumour 157.07](#x157-07)　·　[run 213.03](#x213-03)

[runner 100.09](#x100-09)　·　[running 68.03](#x068-03)　·　[rush 148.09](#x148-09)

#### 名詞　S

[sacrifice 230.10](#x230-10)　·　[safety 114.12](#x114-12)　·　[sail 56.05](#x056-05)　·　[sailing 189.02](#x189-02)　·　[sailor 202.09](#x202-09)　·　[saint 108.09](#x108-09)　·　[sake 75.05](#x075-05)

[salad 142.04](#x142-04)　·　[salary 223.04](#x223-04)　·　[sale 111.06](#x111-06)　·　[salt 56.03](#x056-03)　·　[sample 160.03](#x160-03)　·　[sampling 232.03](#x232-03)　·　[sanction 131.07](#x131-07)

[sand 56.09](#x056-09)　·　[sandwich 142.04](#x142-04)　·　[satellite 225.03](#x225-03)　·　[satisfaction 129.07](#x129-07)　·　[Saturday 80.03](#x080-03)　·　[sauce 142.02](#x142-02)　·　[saving 218.06](#x218-06)

[say 101.07](#x101-07)　·　[scale 71.05](#x071-05)　·　[scandal 158.01](#x158-01)　·　[scare 238.02](#x238-02)　·　[scenario 138.02](#x138-02)　·　[scene 61.06](#x061-06)　·　[schedule 149.06](#x149-06)

[scheme 232.03](#x232-03)　·　[scholar 108.04](#x108-04)　·　[scholarship 79.01](#x079-01)　·　[school 147.01](#x147-01)　·　[science 226.01](#x226-01)　·　[scientist 116.01](#x116-01)　·　[scope 70.05](#x070-05)

[score 163.09](#x163-09)　·　[scratch 200.04](#x200-04)　·　[scream 130.06](#x130-06)　·　[screen 72.06](#x072-06)　·　[screening 151.07](#x151-07)　·　[screw 214.08](#x214-08)　·　[script 98.11](#x098-11)

[scrutiny 74.08](#x074-08)　·　[sculpture 181.05](#x181-05)　·　[sea 217.04](#x217-04)　·　[seal 116.11](#x116-11)　·　[search 73.06](#x073-06)　·　[season 152.01](#x152-01)　·　[seat 201.04](#x201-04)

[second¹ (unit of time) 100.13](#x100-13)　·　[secret 83.04](#x083-04)　·　[secretary 146.09](#x146-09)　·　[section 222.04](#x222-04)　·　[sector 109.03](#x109-03)　·　[security 74.02](#x074-02)　·　[seed 160.02](#x160-02)

[seeker 209.09](#x209-09)　·　[segment 124.03](#x124-03)　·　[selection 80.01](#x080-01)　·　[self 187.05](#x187-05)　·　[seminar 227.01](#x227-01)　·　[senator 119.03](#x119-03)　·　[sensation 77.09](#x077-09)

[sense 187.05](#x187-05)　·　[sensitivity 242.05](#x242-05)　·　[sentence 106.03](#x106-03)　·　[sentiment 82.10](#x082-10)　·　[separation 166.07](#x166-07)　·　[September 204.10](#x204-10)　·　[sequence 118.03](#x118-03)

[series 72.09](#x072-09)　·　[servant 164.02](#x164-02)　·　[service 211.01](#x211-01)　·　[session 101.10](#x101-10)　·　[set 80.02](#x080-02)　·　[set (group) 141.08](#x141-08)　·　[set-up 214.02](#x214-02)

[setting 123.03](#x123-03)　·　[settlement 63.06](#x063-06)　·　[settler 166.03](#x166-03)　·　[sex 234.08](#x234-08)　·　[sexuality 125.09](#x125-09)　·　[shade 52.08](#x052-08)　·　[shadow 140.08](#x140-08)

[shake 214.09](#x214-09)　·　[shame 105.06](#x105-06)　·　[shape 62.07](#x062-07)　·　[share 176.05](#x176-05)　·　[shareholder 223.01](#x223-01)　·　[sheep 92.09](#x092-09)　·　[sheet 51.05](#x051-05)

[shelf 146.02](#x146-02)　·　[shell 206.03](#x206-03)　·　[shelter 105.03](#x105-03)　·　[shift 79.04](#x079-04)　·　[ship 143.06](#x143-06)　·　[shipping 223.07](#x223-07)　·　[shirt 98.06](#x098-06)

[shock 86.07](#x086-07)　·　[shoe 148.04](#x148-04)　·　[shoot 235.03](#x235-03)　·　[shooting 107.07](#x107-07)　·　[shop 51.10](#x051-10)　·　[shopping 177.08](#x177-08)　·　[shore 206.01](#x206-01)

[shortage 116.02](#x116-02)　·　[shot 69.04](#x069-04)　·　[shoulder 148.01](#x148-01)　·　[shout 202.09](#x202-09)　·　[show 124.04](#x124-04)　·　[shower 73.01](#x073-01)　·　[sibling 141.06](#x141-06)

[side 206.06](#x206-06)　·　[sigh 122.06](#x122-06)　·　[sight 84.07](#x084-07)　·　[sign 145.03](#x145-03)　·　[signal 206.05](#x206-05)　·　[signature 103.08](#x103-08)　·　[significance 89.07](#x089-07)

[silence 165.10](#x165-10)　·　[silk 210.09](#x210-09)　·　[silver 122.10](#x122-10)　·　[similarity 77.10](#x077-10)　·　[simulation 173.02](#x173-02)　·　[sin 240.02](#x240-02)　·　[singer 98.10](#x098-10)

[singing 72.01](#x072-01)　·　[single 149.01](#x149-01)　·　[sir 235.07](#x235-07)　·　[sister 90.03](#x090-03)　·　[site 64.01](#x064-01)　·　[situation 180.09](#x180-09)　·　[size 214.10](#x214-10)

[sketch 102.12](#x102-12)　·　[ski 70.03](#x070-03)　·　[skiing 180.02](#x180-02)　·　[skill 230.05](#x230-05)　·　[skin 109.07](#x109-07)　·　[skirt 62.02](#x062-02)　·　[skull 180.08](#x180-08)

[sky 212.09](#x212-09)　·　[slave 108.07](#x108-07)　·　[slavery 63.01](#x063-01)　·　[sleep 155.05](#x155-05)　·　[slice 203.03](#x203-03)　·　[slide 132.03](#x132-03)　·　[slogan 65.09](#x065-09)

[slope 161.05](#x161-05)　·　[slot 244.08](#x244-08)　·　[smartphone 112.02](#x112-02)　·　[smell 76.02](#x076-02)　·　[smile 139.10](#x139-10)　·　[smoke 210.01](#x210-01)　·　[smoking 131.01](#x131-01)

[snake 60.07](#x060-07)　·　[snow 180.01](#x180-01)　·　[soap 201.07](#x201-07)　·　[soccer 100.07](#x100-07)　·　[society 58.05](#x058-05)　·　[sock 148.04](#x148-04)　·　[software 228.01](#x228-01)

[soil 93.09](#x093-09)　·　[soldier 61.05](#x061-05)　·　[solicitor 155.06](#x155-06)　·　[solid 226.03](#x226-03)　·　[solidarity 132.13](#x132-13)　·　[solo 72.06](#x072-06)　·　[solution 195.09](#x195-09)

[son 213.02](#x213-02)　·　[song 99.03](#x099-03)　·　[sort 89.03](#x089-03)　·　[soul 187.04](#x187-04)　·　[sound 215.04](#x215-04)　·　[soup 115.05](#x115-05)　·　[source 73.04](#x073-04)

[south 140.08](#x140-08)　·　[sovereignty 233.07](#x233-07)　·　[space 117.04](#x117-04)　·　[spam 73.10](#x073-10)　·　[span 173.07](#x173-07)　·　[speaker 215.05](#x215-05)　·　[specialist 105.09](#x105-09)

[species 60.04](#x060-04)　·　[specification 173.05](#x173-05)　·　[specimen 203.02](#x203-02)　·　[spectacle 124.06](#x124-06)　·　[spectator 68.06](#x068-06)　·　[spectrum 150.06](#x150-06)　·　[speculation 229.09](#x229-09)

[speech 96.04](#x096-04)　·　[speed 55.06](#x055-06)　·　[spell 188.07](#x188-07)　·　[spelling 209.10](#x209-10)　·　[spending 110.01](#x110-01)　·　[sphere 85.04](#x085-04)　·　[spice 142.03](#x142-03)

[spider 226.08](#x226-08)　·　[spin 100.04](#x100-04)　·　[spine 73.01](#x073-01)　·　[spirit 187.02](#x187-02)　·　[spite 238.07](#x238-07)　·　[split 131.10](#x131-10)　·　[spokesman 66.01](#x066-01)

[spokesperson 158.02](#x158-02)　·　[spokeswoman 224.10](#x224-10)　·　[sponsor 101.01](#x101-01)　·　[sponsorship 82.08](#x082-08)　·　[spoon 142.09](#x142-09)　·　[sport 213.06](#x213-06)　·　[spot 91.07](#x091-07)

[spotlight 62.07](#x062-07)　·　[spouse 141.02](#x141-02)　·　[spread 233.06](#x233-06)　·　[spring 95.04](#x095-04)　·　[spy 61.06](#x061-06)　·　[squad 169.02](#x169-02)　·　[square 225.01](#x225-01)

[stability 114.05](#x114-05)　·　[stadium 68.06](#x068-06)　·　[staff 168.05](#x168-05)　·　[stage 208.01](#x208-01)　·　[stair 114.10](#x114-10)　·　[stake 60.10](#x060-10)　·　[stall 142.01](#x142-01)

[stamp 219.12](#x219-12)　·　[stance 101.04](#x101-04)　·　[stand 68.06](#x068-06)　·　[standard 182.07](#x182-07)　·　[star 225.04](#x225-04)　·　[start 100.09](#x100-09)　·　[state 87.01](#x087-01)

[statement 146.04](#x146-04)　·　[station 200.01](#x200-01)　·　[statistic 113.09](#x113-09)　·　[statue 75.02](#x075-02)　·　[status 163.09](#x163-09)　·　[stay 209.06](#x209-06)　·　[steam 115.06](#x115-06)

[steel 69.02](#x069-02)　·　[stem 143.04](#x143-04)　·　[step 208.03](#x208-03)　·　[stereotype 125.06](#x125-06)　·　[stick (piece of wood) 51.05](#x051-05)　·　[stimulation 196.10](#x196-10)　·　[stimulus 236.05](#x236-05)

[stock 132.04](#x132-04)　·　[stomach 79.03](#x079-03)　·　[stone 143.06](#x143-06)　·　[stop 231.08](#x231-08)　·　[storage 126.07](#x126-07)　·　[store 65.02](#x065-02)　·　[storm 143.06](#x143-06)

[story 209.12](#x209-12)　·　[strain 111.03](#x111-03)　·　[strand 62.06](#x062-06)　·　[stranger 139.09](#x139-09)　·　[strategy 225.08](#x225-08)　·　[stream 92.02](#x092-02)　·　[street 65.03](#x065-03)

[strength 184.07](#x184-07)　·　[stress 222.08](#x222-08)　·　[stretch 92.03](#x092-03)　·　[strike 66.01](#x066-01)　·　[string 139.06](#x139-06)　·　[strip (long narrow piece) 201.06](#x201-06)　·　[stroke 96.03](#x096-03)

[structure 81.02](#x081-02)　·　[struggle 188.05](#x188-05)　·　[student 200.02](#x200-02)　·　[studio 124.01](#x124-01)　·　[study 65.04](#x065-04)　·　[stuff 168.05](#x168-05)　·　[style 217.03](#x217-03)

[subject 136.01](#x136-01)　·　[submission 82.09](#x082-09)　·　[subscriber 158.09](#x158-09)　·　[subscription 229.02](#x229-02)　·　[subsidy 110.11](#x110-11)　·　[substance 78.02](#x078-02)　·　[substitute 179.04](#x179-04)

[substitution 215.10](#x215-10)　·　[suburb 108.03](#x108-03)　·　[success 79.11](#x079-11)　·　[succession 195.10](#x195-10)　·　[successor 234.02](#x234-02)　·　[suffering 123.06](#x123-06)　·　[sugar 56.03](#x056-03)

[suggestion 178.06](#x178-06)　·　[suicide 222.05](#x222-05)　·　[suit 104.04](#x104-04)　·　[suite 80.04](#x080-04)　·　[sum 159.08](#x159-08)　·　[summary 216.10](#x216-10)　·　[summer 95.03](#x095-03)

[summit 70.07](#x070-07)　·　[sun 162.03](#x162-03)　·　[Sunday 230.02](#x230-02)　·　[supermarket 93.10](#x093-10)　·　[supervision 79.05](#x079-05)　·　[supervisor 167.08](#x167-08)　·　[supplement 221.05](#x221-05)

[supply 91.13](#x091-13)　·　[support 73.09](#x073-09)　·　[supporter 156.04](#x156-04)　·　[surface 214.07](#x214-07)　·　[surge 90.09](#x090-09)　·　[surgeon 57.05](#x057-05)　·　[surgery 174.01](#x174-01)

[surplus 218.07](#x218-07)　·　[surprise 126.12](#x126-12)　·　[surveillance 74.03](#x074-03)　·　[survey 159.01](#x159-01)　·　[survival 218.11](#x218-11)　·　[survivor 105.04](#x105-04)　·　[suspect 64.04](#x064-04)

[suspension 185.02](#x185-02)　·　[suspicion 238.06](#x238-06)　·　[sweater 122.03](#x122-03)　·　[sweet 59.08](#x059-08)　·　[swim 143.09](#x143-09)　·　[swimming 230.09](#x230-09)　·　[swing 132.02](#x132-02)

[switch 53.03](#x053-03)　·　[sword 151.05](#x151-05)　·　[symbol 227.06](#x227-06)　·　[sympathy 122.08](#x122-08)　·　[symptom 57.03](#x057-03)　·　[syndrome 145.07](#x145-07)　·　[synthesis 241.06](#x241-06)

[system 119.04](#x119-04)

#### 名詞　T

[T-shirt 55.08](#x055-08)　·　[table 144.06](#x144-06)　·　[tablet 221.04](#x221-04)　·　[tackle 132.09](#x132-09)　·　[tactic 66.06](#x066-06)　·　[tag 139.07](#x139-07)　·　[tail 231.03](#x231-03)

[tale 91.11](#x091-11)　·　[talent 72.06](#x072-06)　·　[talk 178.01](#x178-01)　·　[tank 216.05](#x216-05)　·　[tap 121.07](#x121-07)　·　[tape 58.03](#x058-03)　·　[target 180.07](#x180-07)

[task 216.10](#x216-10)　·　[taste 93.05](#x093-05)　·　[tax 65.06](#x065-06)　·　[taxi 149.06](#x149-06)　·　[taxpayer 205.08](#x205-08)　·　[tea 115.05](#x115-05)　·　[teacher 63.01](#x063-01)

[teaching 177.02](#x177-02)　·　[team 206.05](#x206-05)　·　[tear¹ 122.09](#x122-09)　·　[tear² 86.10](#x086-10)　·　[technique 177.05](#x177-05)　·　[technology 233.10](#x233-10)　·　[teenager 96.05](#x096-05)

[teens 72.08](#x072-08)　·　[telephone 149.05](#x149-05)　·　[television 228.01](#x228-01)　·　[temperature 95.04](#x095-04)　·　[temple 76.01](#x076-01)　·　[tenant 168.02](#x168-02)　·　[tendency 242.03](#x242-03)

[tennis 100.03](#x100-03)　·　[tension 78.07](#x078-07)　·　[tent 155.04](#x155-04)　·　[tenure 234.02](#x234-02)　·　[term 120.02](#x120-02)　·　[terminal 64.01](#x064-01)　·　[terminology 189.07](#x189-07)

[terms 217.10](#x217-10)　·　[terrain 117.03](#x117-03)　·　[territory 63.02](#x063-02)　·　[terror 155.05](#x155-05)　·　[terrorism 237.03](#x237-03)　·　[terrorist 130.01](#x130-01)　·　[test 57.09](#x057-09)

[testimony 157.05](#x157-05)　·　[testing 228.09](#x228-09)　·　[text 102.09](#x102-09)　·　[textbook 63.02](#x063-02)　·　[texture 141.09](#x141-09)　·　[thanks 211.09](#x211-09)　·　[theatre 98.01](#x098-01)

[theft 64.06](#x064-06)　·　[theme 154.02](#x154-02)　·　[theology 227.08](#x227-08)　·　[theory 125.12](#x125-12)　·　[therapist 58.04](#x058-04)　·　[therapy 145.08](#x145-08)　·　[thesis 227.08](#x227-08)

[thief 104.02](#x104-02)　·　[thing 83.10](#x083-10)　·　[thinking 153.10](#x153-10)　·　[third 215.10](#x215-10)　·　[thought 117.09](#x117-09)　·　[thread 50.07](#x050-07)　·　[threat 190.03](#x190-03)

[threshold 218.03](#x218-03)　·　[throat 97.06](#x097-06)　·　[thumb 51.03](#x051-03)　·　[Thursday 149.01](#x149-01)　·　[ticket 210.04](#x210-04)　·　[tide 90.05](#x090-05)　·　[tie 52.06](#x052-06)

[timber 147.03](#x147-03)　·　[time 199.10](#x199-10)　·　[timing 118.08](#x118-08)　·　[tin 50.06](#x050-06)　·　[tip 175.08](#x175-08)　·　[tissue 211.07](#x211-07)　·　[title 97.10](#x097-10)

[tobacco 79.03](#x079-03)　·　[today 170.01](#x170-01)　·　[toe 202.08](#x202-08)　·　[toilet 121.06](#x121-06)　·　[tolerance 89.08](#x089-08)　·　[toll 176.05](#x176-05)　·　[tomato 207.08](#x207-08)

[tomorrow 124.03](#x124-03)　·　[ton 69.03](#x069-03)　·　[tone 182.03](#x182-03)　·　[tongue 238.09](#x238-09)　·　[tonight 124.02](#x124-02)　·　[tonne 69.03](#x069-03)　·　[tool 170.05](#x170-05)

[tooth 226.07](#x226-07)　·　[top 109.01](#x109-01)　·　[topic 79.03](#x079-03)　·　[torture 165.04](#x165-04)　·　[total 204.08](#x204-08)　·　[touch 133.09](#x133-09)　·　[tour 66.01](#x066-01)

[tourism 176.01](#x176-01)　·　[tourist 211.07](#x211-07)　·　[tournament 101.01](#x101-01)　·　[towel 59.09](#x059-09)　·　[tower 181.02](#x181-02)　·　[town 211.01](#x211-01)　·　[toy 116.08](#x116-08)

[trace 54.03](#x054-03)　·　[track 149.09](#x149-09)　·　[trade 233.02](#x233-02)　·　[trademark 136.03](#x136-03)　·　[trading 63.03](#x063-03)　·　[tradition 187.02](#x187-02)　·　[traffic 211.05](#x211-05)

[tragedy 123.05](#x123-05)　·　[trail 70.03](#x070-03)　·　[trailer 180.06](#x180-06)　·　[train 210.01](#x210-01)　·　[trainer 100.03](#x100-03)　·　[training 60.02](#x060-02)　·　[trait 183.05](#x183-05)

[transaction 212.07](#x212-07)　·　[transcript 124.07](#x124-07)　·　[transfer 66.04](#x066-04)　·　[transformation 198.02](#x198-02)　·　[transit 216.03](#x216-03)　·　[transition 119.11](#x119-11)　·　[translation 73.05](#x073-05)

[transmission 173.07](#x173-07)　·　[transparency 241.09](#x241-09)　·　[transport 110.07](#x110-07)　·　[transportation 70.02](#x070-02)　·　[trap 193.03](#x193-03)　·　[trauma 222.04](#x222-04)　·　[travel 111.08](#x111-08)

[traveller 70.01](#x070-01)　·　[treasure 170.10](#x170-10)　·　[treatment 221.07](#x221-07)　·　[treaty 119.02](#x119-02)　·　[tree 51.01](#x051-01)　·　[trend 198.03](#x198-03)　·　[trial 219.04](#x219-04)

[tribe 107.10](#x107-10)　·　[tribunal 64.10](#x064-10)　·　[tribute 165.01](#x165-01)　·　[trick 226.10](#x226-10)　·　[trigger 107.09](#x107-09)　·　[trio 55.07](#x055-07)　·　[trip 166.03](#x166-03)

[triumph 225.10](#x225-10)　·　[troop 107.02](#x107-02)　·　[trophy 68.09](#x068-09)　·　[trouble 195.06](#x195-06)　·　[trousers 235.02](#x235-02)　·　[truck 109.04](#x109-04)　·　[trust 86.06](#x086-06)

[trustee 156.04](#x156-04)　·　[truth 229.06](#x229-06)　·　[try 100.09](#x100-09)　·　[tsunami 78.01](#x078-01)　·　[tube 144.05](#x144-05)　·　[Tuesday 229.01](#x229-01)　·　[tuition 120.04](#x120-04)

[tune 55.06](#x055-06)　·　[tunnel 147.04](#x147-04)　·　[turn 208.08](#x208-08)　·　[turnout 103.10](#x103-10)　·　[turnover 65.02](#x065-02)　·　[tutor 150.04](#x150-04)　·　[TV 228.10](#x228-10)

[twin 129.04](#x129-04)　·　[twist 69.11](#x069-11)　·　[type 154.03](#x154-03)　·　[tyre 211.02](#x211-02)

#### 名詞　U

[umbrella 90.12](#x090-12)　·　[uncertainty 78.08](#x078-08)　·　[uncle 140.05](#x140-05)　·　[undergraduate 227.01](#x227-01)　·　[understanding 123.08](#x123-08)　·　[undertaking 82.08](#x082-08)　·　[underwear 148.05](#x148-05)

[unemployment 223.08](#x223-08)　·　[uniform 117.05](#x117-05)　·　[union 66.01](#x066-01)　·　[unit 173.04](#x173-04)　·　[unity 227.05](#x227-05)　·　[universe 117.07](#x117-07)　·　[university 73.03](#x073-03)

[update 172.04](#x172-04)　·　[upgrade 228.04](#x228-04)　·　[usage 112.08](#x112-08)　·　[use 74.09](#x074-09)　·　[user 172.03](#x172-03)　·　[utility 230.11](#x230-11)　·　[utilization 132.04](#x132-04)

#### 名詞　V

[vacation 80.06](#x080-06)　·　[vacuum 170.08](#x170-08)　·　[validation 228.08](#x228-08)　·　[validity 113.11](#x113-11)　·　[valley 70.02](#x070-02)　·　[value 173.08](#x173-08)　·　[van 211.02](#x211-02)

[variable 113.05](#x113-05)　·　[variance 78.05](#x078-05)　·　[variation 175.09](#x175-09)　·　[variety 239.11](#x239-11)　·　[vegetable 115.04](#x115-04)　·　[vehicle 69.03](#x069-03)　·　[vein 144.05](#x144-05)

[venture 212.02](#x212-02)　·　[venue 100.01](#x100-01)　·　[verdict 64.09](#x064-09)　·　[verse 165.10](#x165-10)　·　[version 208.10](#x208-10)　·　[vessel 90.04](#x090-04)　·　[veteran 63.07](#x063-07)

[vice 182.07](#x182-07)　·　[victim 238.03](#x238-03)　·　[victory 101.12](#x101-12)　·　[video 69.11](#x069-11)　·　[view 166.09](#x166-09)　·　[viewer 228.02](#x228-02)　·　[viewpoint 102.03](#x102-03)

[village 50.05](#x050-05)　·　[villager 165.08](#x165-08)　·　[violation 219.08](#x219-08)　·　[violence 130.01](#x130-01)　·　[virtue 67.05](#x067-05)　·　[virus 145.06](#x145-06)　·　[visa 209.01](#x209-01)

[vision 114.04](#x114-04)　·　[visit 70.10](#x070-10)　·　[visitor 144.06](#x144-06)　·　[vitamin 218.08](#x218-08)　·　[voice 96.12](#x096-12)　·　[volume 83.03](#x083-03)　·　[volunteer 160.01](#x160-01)

[vote 205.11](#x205-11)　·　[voting 120.06](#x120-06)　·　[vulnerability 58.06](#x058-06)

#### 名詞　W

[wage 152.02](#x152-02)　·　[wait 211.01](#x211-01)　·　[waiter 115.09](#x115-09)　·　[walk 68.04](#x068-04)　·　[wall 147.07](#x147-07)　·　[war 219.01](#x219-01)　·　[ward 97.01](#x097-01)

[warehouse 64.02](#x064-02)　·　[warfare 165.01](#x165-01)　·　[warming 232.10](#x232-10)　·　[warning 90.01](#x090-01)　·　[warrant 64.02](#x064-02)　·　[warrior 164.02](#x164-02)　·　[wash 239.09](#x239-09)

[washing 115.11](#x115-11)　·　[waste 78.03](#x078-03)　·　[watch 165.02](#x165-02)　·　[water 201.03](#x201-03)　·　[wave 90.03](#x090-03)　·　[way 51.10](#x051-10)　·　[weakness 172.04](#x172-04)

[wealth 227.07](#x227-07)　·　[weapon 107.05](#x107-05)　·　[weather 69.02](#x069-02)　·　[web 173.01](#x173-01)　·　[website 216.08](#x216-08)　·　[wedding 122.07](#x122-07)　·　[Wednesday 50.01](#x050-01)

[weed 161.06](#x161-06)　·　[week 213.06](#x213-06)　·　[weekend 100.08](#x100-08)　·　[weight 69.03](#x069-03)　·　[welcome 182.02](#x182-02)　·　[welfare 222.03](#x222-03)　·　[well 108.01](#x108-01)

[well-being 57.10](#x057-10)　·　[west 140.08](#x140-08)　·　[wheat 218.02](#x218-02)　·　[wheel 108.01](#x108-01)　·　[while 76.10](#x076-10)　·　[whisper 167.08](#x167-08)　·　[white 212.10](#x212-10)

[whole 127.04](#x127-04)　·　[widow 54.09](#x054-09)　·　[width 147.04](#x147-04)　·　[wife 209.10](#x209-10)　·　[wildlife 95.06](#x095-06)　·　[will 84.08](#x084-08)　·　[willingness 156.07](#x156-07)

[win 213.09](#x213-09)　·　[wind¹ 90.02](#x090-02)　·　[window 50.08](#x050-08)　·　[wine 188.04](#x188-04)　·　[wing 214.01](#x214-01)　·　[winner 101.02](#x101-02)　·　[winter 51.08](#x051-08)

[wire 150.06](#x150-06)　·　[wisdom 211.11](#x211-11)　·　[wish 122.05](#x122-05)　·　[wit 72.06](#x072-06)　·　[withdrawal 182.08](#x182-08)　·　[witness 220.02](#x220-02)　·　[woman 91.02](#x091-02)

[wonder 84.09](#x084-09)　·　[wood 147.03](#x147-03)　·　[wool 217.05](#x217-05)　·　[word 97.03](#x097-03)　·　[work 72.02](#x072-02)　·　[worker 146.10](#x146-10)　·　[workforce 223.03](#x223-03)

[working 127.02](#x127-02)　·　[workout 68.04](#x068-04)　·　[workplace 183.06](#x183-06)　·　[workshop 200.01](#x200-01)　·　[world 96.13](#x096-13)　·　[worm 60.05](#x060-05)　·　[worry 169.09](#x169-09)

[worse 241.03](#x241-03)　·　[worship 108.13](#x108-13)　·　[worst 86.09](#x086-09)　·　[worth 191.02](#x191-02)　·　[wound 201.03](#x201-03)　·　[wrist 94.07](#x094-07)　·　[writer 61.01](#x061-01)

[writing 139.07](#x139-07)　·　[wrong 238.11](#x238-11)

#### 名詞　Y

[yard 90.12](#x090-12)　·　[year 53.06](#x053-06)　·　[yellow 175.02](#x175-02)　·　[yesterday 241.05](#x241-05)　·　[yield 116.07](#x116-07)　·　[young 72.01](#x072-01)　·　[youngster 142.07](#x142-07)

[youth 212.02](#x212-02)

#### 名詞　Z

[zone 118.01](#x118-01)

<a id="lex-verb"></a>

### 動詞　1,275項目

#### 動詞　A

[abandon 199.10](#x199-10)　·　[abolish 120.03](#x120-03)　·　[absorb 65.06](#x065-06)　·　[abuse 195.03](#x195-03)　·　[accelerate 206.08](#x206-08)　·　[accept 135.03](#x135-03)　·　[access 73.06](#x073-06)

[accommodate 147.04](#x147-04)　·　[accompany 209.08](#x209-08)　·　[accomplish 119.10](#x119-10)　·　[account 65.04](#x065-04)　·　[accumulate 162.07](#x162-07)　·　[accuse 202.03](#x202-03)　·　[achieve 100.13](#x100-13)

[acknowledge 63.09](#x063-09)　·　[acquire 174.10](#x174-10)　·　[act 208.01](#x208-01)　·　[activate 112.04](#x112-04)　·　[adapt 61.03](#x061-03)　·　[add 160.04](#x160-04)　·　[address 224.09](#x224-09)

[adhere 135.05](#x135-05)　·　[adjust 73.07](#x073-07)　·　[administer 144.07](#x144-07)　·　[admire 233.10](#x233-10)　·　[admit 133.04](#x133-04)　·　[adopt 66.10](#x066-10)　·　[advance 189.05](#x189-05)

[advertise 229.02](#x229-02)　·　[advise 95.07](#x095-07)　·　[advocate 82.07](#x082-07)　·　[affect 161.02](#x161-02)　·　[afford 212.05](#x212-05)　·　[age 136.06](#x136-06)　·　[agree 58.07](#x058-07)

[aid 184.03](#x184-03)　·　[aim 213.05](#x213-05)　·　[alarm 130.07](#x130-07)　·　[alert 69.06](#x069-06)　·　[align 151.03](#x151-03)　·　[allege 220.03](#x220-03)　·　[allocate 110.10](#x110-10)

[allow 53.06](#x053-06)　·　[alter 176.03](#x176-03)　·　[amend 205.10](#x205-10)　·　[amount 110.03](#x110-03)　·　[analyse 78.01](#x078-01)　·　[announce 171.02](#x171-02)　·　[annoy 244.03](#x244-03)

[answer 131.08](#x131-08)　·　[anticipate 81.07](#x081-07)　·　[apologize 182.06](#x182-06)　·　[appeal 241.07](#x241-07)　·　[appear 103.06](#x103-06)　·　[applaud 68.07](#x068-07)　·　[apply 182.04](#x182-04)

[appoint 234.01](#x234-01)　·　[appreciate 135.08](#x135-08)　·　[approach 68.07](#x068-07)　·　[approve 186.04](#x186-04)　·　[argue 224.05](#x224-05)　·　[arise 98.12](#x098-12)　·　[arm 75.03](#x075-03)

[arrange 149.06](#x149-06)　·　[arrest 238.02](#x238-02)　·　[arrive 133.10](#x133-10)　·　[articulate 82.05](#x082-05)　·　[ask 139.03](#x139-03)　·　[aspire 244.04](#x244-04)　·　[assault 106.02](#x106-02)

[assemble 80.09](#x080-09)　·　[assert 185.06](#x185-06)　·　[assess 223.09](#x223-09)　·　[assign 121.09](#x121-09)　·　[assist 79.05](#x079-05)　·　[associate 187.07](#x187-07)　·　[assume 219.07](#x219-07)

[assure 133.09](#x133-09)　·　[attach 60.10](#x060-10)　·　[attack 193.05](#x193-05)　·　[attain 223.02](#x223-02)　·　[attempt 138.03](#x138-03)　·　[attend 63.10](#x063-10)　·　[attract 171.08](#x171-08)

[attribute 238.07](#x238-07)　·　[authorize 119.11](#x119-11)　·　[average 82.01](#x082-01)　·　[avoid 161.09](#x161-09)　·　[await 206.01](#x206-01)　·　[award 101.03](#x101-03)

#### 動詞　B

[back 82.08](#x082-08)　·　[bake 141.02](#x141-02)　·　[balance 231.09](#x231-09)　·　[ban 101.09](#x101-09)　·　[bar 86.04](#x086-04)　·　[base 175.07](#x175-07)　·　[bat 213.02](#x213-02)

[battle 136.10](#x136-10)　·　[be 83.07](#x083-07)　·　[bear (deal with) 169.09](#x169-09)　·　[beat 236.01](#x236-01)　·　[become 91.15](#x091-15)　·　[beg 86.02](#x086-02)　·　[begin 141.05](#x141-05)

[behave 226.03](#x226-03)　·　[believe 104.09](#x104-09)　·　[belong 50.11](#x050-11)　·　[bend 161.05](#x161-05)　·　[benefit 212.07](#x212-07)　·　[bet 101.08](#x101-08)　·　[betray 61.07](#x061-07)

[bias 178.06](#x178-06)　·　[bid 212.03](#x212-03)　·　[bill 111.11](#x111-11)　·　[bind 50.07](#x050-07)　·　[bite 178.03](#x178-03)　·　[blame 223.07](#x223-07)　·　[blast 107.05](#x107-05)

[bleed 79.08](#x079-08)　·　[blend 179.02](#x179-02)　·　[bless 237.12](#x237-12)　·　[block 90.10](#x090-10)　·　[blow 84.04](#x084-04)　·　[board 149.08](#x149-08)　·　[boast 239.05](#x239-05)

[boil 115.05](#x115-05)　·　[bomb 75.02](#x075-02)　·　[book 149.10](#x149-10)　·　[boost 213.07](#x213-07)　·　[border 119.02](#x119-02)　·　[born 83.06](#x083-06)　·　[borrow 146.03](#x146-03)

[bother 235.10](#x235-10)　·　[bounce 100.02](#x100-02)　·　[bow¹ 61.09](#x061-09)　·　[brand 152.09](#x152-09)　·　[breach 240.07](#x240-07)　·　[break 132.09](#x132-09)　·　[breathe 57.05](#x057-05)

[breed 183.07](#x183-07)　·　[bring 221.10](#x221-10)　·　[broadcast 124.02](#x124-02)　·　[brush 54.06](#x054-06)　·　[build 181.04](#x181-04)　·　[burn 241.02](#x241-02)　·　[burst 134.07](#x134-07)

[bury 70.04](#x070-04)　·　[buy 181.08](#x181-08)

#### 動詞　C

[calculate 213.10](#x213-10)　·　[call 90.09](#x090-09)　·　[calm 79.07](#x079-07)　·　[camp 193.01](#x193-01)　·　[campaign 224.03](#x224-03)　·　[cancel 121.08](#x121-08)　·　[capture 55.01](#x055-01)

[care 145.01](#x145-01)　·　[carry 216.09](#x216-09)　·　[carve 106.07](#x106-07)　·　[cast 61.08](#x061-08)　·　[catch 143.12](#x143-12)　·　[categorize 227.04](#x227-04)　·　[cater 138.07](#x138-07)

[cause 76.06](#x076-06)　·　[cease 188.03](#x188-03)　·　[celebrate 234.11](#x234-11)　·　[centralize 119.09](#x119-09)　·　[centre 61.03](#x061-03)　·　[chain 170.04](#x170-04)　·　[chair 205.02](#x205-02)

[challenge 102.05](#x102-05)　·　[change 51.08](#x051-08)　·　[characterize 183.05](#x183-05)　·　[charge 230.08](#x230-08)　·　[chart 116.05](#x116-05)　·　[chase 77.06](#x077-06)　·　[chat 187.08](#x187-08)

[cheat 229.08](#x229-08)　·　[check 104.09](#x104-09)　·　[cheer 68.07](#x068-07)　·　[choose 149.07](#x149-07)　·　[chop 207.05](#x207-05)　·　[circle 118.02](#x118-02)　·　[circulate 87.03](#x087-03)

[cite 190.04](#x190-04)　·　[claim 232.08](#x232-08)　·　[clarify 129.06](#x129-06)　·　[classify 77.05](#x077-05)　·　[clean 170.01](#x170-01)　·　[clear 211.05](#x211-05)　·　[click 112.04](#x112-04)

[climb 70.07](#x070-07)　·　[cling 169.07](#x169-07)　·　[close¹ 231.08](#x231-08)　·　[coach 101.11](#x101-11)　·　[code 73.05](#x073-05)　·　[coincide 159.02](#x159-02)　·　[collaborate 228.04](#x228-04)

[collapse 132.09](#x132-09)　·　[collect 78.01](#x078-01)　·　[combat 183.03](#x183-03)　·　[combine 202.11](#x202-11)　·　[come 118.04](#x118-04)　·　[comfort 84.05](#x084-05)　·　[command 169.04](#x169-04)

[commence 231.07](#x231-07)　·　[comment 124.08](#x124-08)　·　[commission 71.01](#x071-01)　·　[commit 185.06](#x185-06)　·　[communicate 216.07](#x216-07)　·　[compare 97.07](#x097-07)　·　[compel 76.07](#x076-07)

[compensate 152.06](#x152-06)　·　[compete 213.06](#x213-06)　·　[compile 112.05](#x112-05)　·　[complain 84.05](#x084-05)　·　[complement 179.02](#x179-02)　·　[complete 212.08](#x212-08)　·　[comply 131.07](#x131-07)

[compose 61.01](#x061-01)　·　[comprise 179.01](#x179-01)　·　[compromise 220.09](#x220-09)　·　[compute 110.04](#x110-04)　·　[conceal 74.04](#x074-04)　·　[concede 167.05](#x167-05)　·　[conceive 209.05](#x209-05)

[concentrate 106.08](#x106-08)　·　[conceptualize 82.06](#x082-06)　·　[concern 195.06](#x195-06)　·　[conclude 244.02](#x244-02)　·　[condemn 107.10](#x107-10)　·　[conduct 81.04](#x081-04)　·　[confer 156.08](#x156-08)

[confess 238.09](#x238-09)　·　[confine 126.06](#x126-06)　·　[confirm 64.06](#x064-06)　·　[conflict 171.09](#x171-09)　·　[confront 224.03](#x224-03)　·　[confuse 104.11](#x104-11)　·　[congratulate 79.11](#x079-11)

[connect 166.02](#x166-02)　·　[conquer 238.06](#x238-06)　·　[consent 105.10](#x105-10)　·　[conserve 87.02](#x087-02)　·　[consider 159.04](#x159-04)　·　[consist 242.06](#x242-06)　·　[consolidate 135.02](#x135-02)

[constitute 69.09](#x069-09)　·　[constrain 191.07](#x191-07)　·　[construct 214.02](#x214-02)　·　[consult 119.07](#x119-07)　·　[consume 60.06](#x060-06)　·　[contact 149.05](#x149-05)　·　[contain 232.06](#x232-06)

[contemplate 135.04](#x135-04)　·　[contend 82.04](#x082-04)　·　[contest 183.04](#x183-04)　·　[continue 232.02](#x232-02)　·　[contract 136.06](#x136-06)　·　[contrast 63.05](#x063-05)　·　[contribute 183.09](#x183-09)

[control 217.08](#x217-08)　·　[convert 99.03](#x099-03)　·　[convey 75.09](#x075-09)　·　[convict 186.03](#x186-03)　·　[convince 232.11](#x232-11)　·　[cook 93.03](#x093-03)　·　[cool 68.06](#x068-06)

[cooperate 186.07](#x186-07)　·　[coordinate 232.03](#x232-03)　·　[cope 117.05](#x117-05)　·　[copy 73.02](#x073-02)　·　[correct 157.04](#x157-04)　·　[correlate 223.10](#x223-10)　·　[correspond 128.09](#x128-09)

[cost 65.03](#x065-03)　·　[count 152.04](#x152-04)　·　[counter (argue against) 224.06](#x224-06)　·　[cover 100.11](#x100-11)　·　[crack 81.05](#x081-05)　·　[craft 177.03](#x177-03)　·　[crash 225.09](#x225-09)

[crawl 114.11](#x114-11)　·　[create 65.07](#x065-07)　·　[credit 158.07](#x158-07)　·　[creep 226.08](#x226-08)　·　[criticize 135.09](#x135-09)　·　[cross 51.02](#x051-02)　·　[cruise 176.02](#x176-02)

[crush 237.10](#x237-10)　·　[cry 122.04](#x122-04)　·　[cultivate 60.02](#x060-02)　·　[cure 145.09](#x145-09)　·　[curve 225.07](#x225-07)　·　[cut 124.07](#x124-07)　·　[cycle 84.02](#x084-02)

#### 動詞　D

[damage 147.07](#x147-07)　·　[dance 208.11](#x208-11)　·　[dare 123.07](#x123-07)　·　[date 85.10](#x085-10)　·　[deal 183.01](#x183-01)　·　[debate 224.01](#x224-01)　·　[decide 94.10](#x094-10)

[declare 66.04](#x066-04)　·　[decline 184.03](#x184-03)　·　[decorate 217.05](#x217-05)　·　[decrease 111.06](#x111-06)　·　[deem 64.08](#x064-08)　·　[defeat 192.08](#x192-08)　·　[defend 208.05](#x208-05)

[define 125.09](#x125-09)　·　[defy 86.04](#x086-04)　·　[delay 179.07](#x179-07)　·　[delete 228.02](#x228-02)　·　[delight 126.12](#x126-12)　·　[deliver 77.07](#x077-07)　·　[demand 185.05](#x185-05)

[demonstrate 214.07](#x214-07)　·　[denote 92.07](#x092-07)　·　[denounce 67.04](#x067-04)　·　[deny 174.08](#x174-08)　·　[depart 210.04](#x210-04)　·　[depend 96.10](#x096-10)　·　[depict 65.08](#x065-08)

[deploy 169.02](#x169-02)　·　[deposit 220.04](#x220-04)　·　[deprive 120.11](#x120-11)　·　[derive 77.10](#x077-10)　·　[descend 188.06](#x188-06)　·　[describe 221.03](#x221-03)　·　[desert 107.11](#x107-11)

[deserve 68.10](#x068-10)　·　[design 154.01](#x154-01)　·　[designate 232.03](#x232-03)　·　[desire 106.10](#x106-10)　·　[destroy 75.02](#x075-02)　·　[detail 189.07](#x189-07)　·　[detain 219.04](#x219-04)

[detect 99.10](#x099-10)　·　[deteriorate 78.08](#x078-08)　·　[determine 156.07](#x156-07)　·　[devastate 214.01](#x214-01)　·　[develop 134.04](#x134-04)　·　[devise 81.01](#x081-01)　·　[devote 177.05](#x177-05)

[diagnose 221.06](#x221-06)　·　[dictate 119.11](#x119-11)　·　[die 54.08](#x054-08)　·　[differ 159.04](#x159-04)　·　[differentiate 221.05](#x221-05)　·　[dig 126.06](#x126-06)　·　[diminish 74.07](#x074-07)

[dip 181.06](#x181-06)　·　[direct 208.10](#x208-10)　·　[disadvantage 132.11](#x132-11)　·　[disagree 67.05](#x067-05)　·　[disappear 150.08](#x150-08)　·　[disappoint 229.11](#x229-11)　·　[discard 112.09](#x112-09)

[discharge 78.03](#x078-03)　·　[disclose 157.02](#x157-02)　·　[discount 230.08](#x230-08)　·　[discourage 127.10](#x127-10)　·　[discover 52.10](#x052-10)　·　[discuss 145.08](#x145-08)　·　[dislike 229.05](#x229-05)

[dismiss 104.10](#x104-10)　·　[displace 70.08](#x070-08)　·　[display 152.08](#x152-08)　·　[dispose 221.10](#x221-10)　·　[dispute 129.07](#x129-07)　·　[disrupt 78.07](#x078-07)　·　[dissolve 175.05](#x175-05)

[distinguish 200.08](#x200-08)　·　[distort 113.07](#x113-07)　·　[distract 62.03](#x062-03)　·　[distress 167.03](#x167-03)　·　[distribute 204.04](#x204-04)　·　[disturb 107.14](#x107-14)　·　[dive 77.06](#x077-06)

[divert 193.08](#x193-08)　·　[divide 205.09](#x205-09)　·　[divorce 133.02](#x133-02)　·　[do¹ 50.05](#x050-05)　·　[document 167.01](#x167-01)　·　[dominate 229.03](#x229-03)　·　[donate 105.07](#x105-07)

[double 65.09](#x065-09)　·　[doubt 190.06](#x190-06)　·　[download 228.02](#x228-02)　·　[draft 117.11](#x117-11)　·　[drag 56.10](#x056-10)　·　[drain 161.07](#x161-07)　·　[draw 202.10](#x202-10)

[dream 134.02](#x134-02)　·　[dress 62.02](#x062-02)　·　[drift 180.04](#x180-04)　·　[drink 222.06](#x222-06)　·　[drive 132.05](#x132-05)　·　[drop 76.09](#x076-09)　·　[drown 193.07](#x193-07)

[dry 219.12](#x219-12)　·　[dub 130.08](#x130-08)　·　[dump 87.02](#x087-02)

#### 動詞　E

[earn 155.07](#x155-07)　·　[ease 221.02](#x221-02)　·　[eat 115.08](#x115-08)　·　[echo 55.06](#x055-06)　·　[edit 158.06](#x158-06)　·　[educate 240.03](#x240-03)　·　[elect 120.02](#x120-02)

[elevate 78.07](#x078-07)　·　[eliminate 175.06](#x175-06)　·　[email 216.08](#x216-08)　·　[embark 138.07](#x138-07)　·　[embed 73.05](#x073-05)　·　[embody 196.08](#x196-08)　·　[embrace 222.10](#x222-10)

[emerge 92.12](#x092-12)　·　[emphasize 71.05](#x071-05)　·　[employ 171.03](#x171-03)　·　[empower 234.11](#x234-11)　·　[empty 132.05](#x132-05)　·　[enable 73.06](#x073-06)　·　[enact 186.01](#x186-01)

[encode 228.06](#x228-06)　·　[encompass 110.09](#x110-09)　·　[encounter 80.06](#x080-06)　·　[encourage 196.07](#x196-07)　·　[end 234.02](#x234-02)　·　[endorse 101.09](#x101-09)　·　[endure 57.05](#x057-05)

[enforce 182.07](#x182-07)　·　[engage 242.09](#x242-09)　·　[enhance 114.05](#x114-05)　·　[enjoy 84.09](#x084-09)　·　[enquire 190.04](#x190-04)　·　[enrich 227.11](#x227-11)　·　[enrol 101.11](#x101-11)

[ensue 87.03](#x087-03)　·　[ensure 184.06](#x184-06)　·　[enter 208.02](#x208-02)　·　[entertain 124.04](#x124-04)　·　[entitle 80.04](#x080-04)　·　[equal 156.06](#x156-06)　·　[equip 234.04](#x234-04)

[erect 132.03](#x132-03)　·　[erupt 66.09](#x066-09)　·　[escalate 195.04](#x195-04)　·　[escape 237.07](#x237-07)　·　[establish 108.08](#x108-08)　·　[estimate 53.01](#x053-01)　·　[evacuate 168.03](#x168-03)

[evaluate 236.08](#x236-08)　·　[evoke 123.04](#x123-04)　·　[evolve 77.08](#x077-08)　·　[exaggerate 174.08](#x174-08)　·　[examine 203.09](#x203-09)　·　[exceed 113.11](#x113-11)　·　[exchange 80.08](#x080-08)

[exclude 141.10](#x141-10)　·　[excuse 238.04](#x238-04)　·　[execute 131.03](#x131-03)　·　[exemplify 82.04](#x082-04)　·　[exercise 192.04](#x192-04)　·　[exert 233.05](#x233-05)　·　[exhibit 91.12](#x091-12)

[exist 75.10](#x075-10)　·　[exit 168.06](#x168-06)　·　[expand 223.06](#x223-06)　·　[expect 93.07](#x093-07)　·　[experience 77.09](#x077-09)　·　[experiment 160.02](#x160-02)　·　[expire 230.02](#x230-02)

[explain 90.09](#x090-09)　·　[explode 75.06](#x075-06)　·　[exploit 176.09](#x176-09)　·　[explore 227.01](#x227-01)　·　[export 119.01](#x119-01)　·　[expose 73.02](#x073-02)　·　[express 183.02](#x183-02)

[extend 205.04](#x205-04)　·　[extract 109.04](#x109-04)

#### 動詞　F

[face 61.04](#x061-04)　·　[facilitate 176.03](#x176-03)　·　[fade 200.03](#x200-03)　·　[fail 111.09](#x111-09)　·　[fall 65.02](#x065-02)　·　[fancy 192.03](#x192-03)　·　[farm 218.02](#x218-02)

[fasten 98.06](#x098-06)　·　[favour 65.11](#x065-11)　·　[fear 195.05](#x195-05)　·　[feature 229.01](#x229-01)　·　[feed 117.04](#x117-04)　·　[feel 51.04](#x051-04)　·　[fight 164.08](#x164-08)

[figure 236.09](#x236-09)　·　[file 126.13](#x126-13)　·　[fill 83.03](#x083-03)　·　[film 180.03](#x180-03)　·　[filter 228.07](#x228-07)　·　[finance 101.02](#x101-02)　·　[find 83.09](#x083-09)

[fine 186.04](#x186-04)　·　[finish 235.12](#x235-12)　·　[fire 107.05](#x107-05)　·　[fish 77.06](#x077-06)　·　[fit 181.02](#x181-02)　·　[fix 210.03](#x210-03)　·　[flash 112.06](#x112-06)

[flee 62.01](#x062-01)　·　[float 170.02](#x170-02)　·　[flood 216.01](#x216-01)　·　[flourish 93.09](#x093-09)　·　[flow 72.07](#x072-07)　·　[fly 151.08](#x151-08)　·　[focus 200.03](#x200-03)

[fold 114.09](#x114-09)　·　[follow 57.04](#x057-04)　·　[forbid 186.02](#x186-02)　·　[force 225.08](#x225-08)　·　[forecast 111.09](#x111-09)　·　[forge 79.11](#x079-11)　·　[forget 166.04](#x166-04)

[forgive 231.05](#x231-05)　·　[form 120.06](#x120-06)　·　[formulate 66.10](#x066-10)　·　[foster 187.02](#x187-02)　·　[found 234.03](#x234-03)　·　[frame 123.11](#x123-11)　·　[free 70.08](#x070-08)

[freeze 175.05](#x175-05)　·　[frighten 241.04](#x241-04)　·　[fry 115.03](#x115-03)　·　[fuel 67.05](#x067-05)　·　[fulfil 196.12](#x196-12)　·　[function 231.04](#x231-04)　·　[fund 101.10](#x101-10)

#### 動詞　G

[gain 79.04](#x079-04)　·　[gather 189.05](#x189-05)　·　[gaze 225.05](#x225-05)　·　[generalize 113.10](#x113-10)　·　[generate 68.01](#x068-01)　·　[get 182.09](#x182-09)　·　[give 215.07](#x215-07)

[glance 134.08](#x134-08)　·　[go 66.07](#x066-07)　·　[govern 185.04](#x185-04)　·　[grab 210.06](#x210-06)　·　[grade 97.07](#x097-07)　·　[graduate 79.04](#x079-04)　·　[grant 152.06](#x152-06)

[grasp 206.07](#x206-07)　·　[greet 133.10](#x133-10)　·　[grin 62.08](#x062-08)　·　[grind 142.03](#x142-03)　·　[grip 211.03](#x211-03)　·　[group 112.08](#x112-08)　·　[grow 60.04](#x060-04)

[guarantee 152.03](#x152-03)　·　[guard 217.11](#x217-11)　·　[guess 93.06](#x093-06)　·　[guide 56.01](#x056-01)

#### 動詞　H

[hail 198.01](#x198-01)　·　[halt 231.07](#x231-07)　·　[hand 91.08](#x091-08)　·　[handle 78.09](#x078-09)　·　[hang 140.07](#x140-07)　·　[happen 213.11](#x213-11)　·　[harm 95.09](#x095-09)

[harvest 60.03](#x060-03)　·　[hate 183.04](#x183-04)　·　[haunt 235.09](#x235-09)　·　[have 132.12](#x132-12)　·　[head 83.01](#x083-01)　·　[heal 144.04](#x144-04)　·　[hear 215.05](#x215-05)

[heat 115.03](#x115-03)　·　[heighten 84.10](#x084-10)　·　[help 161.07](#x161-07)　·　[hesitate 231.10](#x231-10)　·　[hide 98.06](#x098-06)　·　[highlight 53.09](#x053-09)　·　[hint 194.04](#x194-04)

[hire 230.07](#x230-07)　·　[hit 100.04](#x100-04)　·　[hold 53.05](#x053-05)　·　[honour 165.09](#x165-09)　·　[hook 210.08](#x210-08)　·　[hope 133.02](#x133-02)　·　[host 77.01](#x077-01)

[house 168.03](#x168-03)　·　[hunt 235.08](#x235-08)　·　[hurry 138.01](#x138-01)　·　[hurt 68.05](#x068-05)　·　[hypothesize 175.04](#x175-04)

#### 動詞　I

[identify 207.11](#x207-11)　·　[ignore 113.10](#x113-10)　·　[illustrate 56.06](#x056-06)　·　[imagine 174.03](#x174-03)　·　[impact 233.05](#x233-05)　·　[implement 110.12](#x110-12)　·　[imply 65.09](#x065-09)

[import 171.03](#x171-03)　·　[impose 220.10](#x220-10)　·　[impress 135.06](#x135-06)　·　[imprison 61.05](#x061-05)　·　[improve 172.04](#x172-04)　·　[include 205.10](#x205-10)　·　[incorporate 124.07](#x124-07)

[increase 78.03](#x078-03)　·　[incur 191.06](#x191-06)　·　[indicate 204.06](#x204-06)　·　[induce 130.03](#x130-03)　·　[indulge 84.09](#x084-09)　·　[infect 174.07](#x174-07)　·　[infer 220.06](#x220-06)

[inflict 125.12](#x125-12)　·　[influence 76.06](#x076-06)　·　[inform 169.05](#x169-05)　·　[inherit 217.06](#x217-06)　·　[inhibit 136.05](#x136-05)　·　[initiate 86.01](#x086-01)　·　[inject 174.06](#x174-06)

[injure 237.10](#x237-10)　·　[insert 112.07](#x112-07)　·　[insist 66.08](#x066-08)　·　[inspect 152.04](#x152-04)　·　[inspire 234.11](#x234-11)　·　[install 94.03](#x094-03)　·　[instruct 79.08](#x079-08)

[insult 186.02](#x186-02)　·　[integrate 234.04](#x234-04)　·　[intend 135.06](#x135-06)　·　[intensify 78.07](#x078-07)　·　[interact 194.03](#x194-03)　·　[interest 229.07](#x229-07)　·　[interfere 136.05](#x136-05)

[interpret 57.09](#x057-09)　·　[interrupt 186.02](#x186-02)　·　[intervene 240.07](#x240-07)　·　[interview 97.11](#x097-11)　·　[introduce 63.01](#x063-01)　·　[invade 169.02](#x169-02)　·　[invent 239.01](#x239-01)

[invest 111.06](#x111-06)　·　[investigate 63.09](#x063-09)　·　[invite 182.06](#x182-06)　·　[invoke 220.10](#x220-10)　·　[involve 132.04](#x132-04)　·　[iron 62.06](#x062-06)　·　[isolate 175.04](#x175-04)

[issue 232.09](#x232-09)

#### 動詞　J

[jail 106.13](#x106-13)　·　[join 66.05](#x066-05)　·　[joke 178.07](#x178-07)　·　[judge 220.01](#x220-01)　·　[jump 92.05](#x092-05)　·　[justify 67.06](#x067-06)

#### 動詞　K

[keep 139.08](#x139-08)　·　[key 228.05](#x228-05)　·　[kick 132.10](#x132-10)　·　[kidnap 75.04](#x075-04)　·　[kill 179.06](#x179-06)　·　[kiss 208.04](#x208-04)　·　[knock 100.06](#x100-06)

[know 62.09](#x062-09)

#### 動詞　L

[label 154.02](#x154-02)　·　[lack 241.08](#x241-08)　·　[land 118.02](#x118-02)　·　[last¹ (taking time) 57.04](#x057-04)　·　[laugh 178.07](#x178-07)　·　[launch 225.06](#x225-06)　·　[lay 114.08](#x114-08)

[lead 85.07](#x085-07)　·　[lead¹ 163.03](#x163-03)　·　[leak 216.04](#x216-04)　·　[lean 92.10](#x092-10)　·　[leap 77.07](#x077-07)　·　[learn 139.08](#x139-08)　·　[leave 208.14](#x208-14)

[lecture 129.04](#x129-04)　·　[lend 50.04](#x050-04)　·　[let 143.03](#x143-03)　·　[level 214.11](#x214-11)　·　[license 131.04](#x131-04)　·　[lie¹ 69.10](#x069-10)　·　[lie² (tell a lie) 190.05](#x190-05)

[lift 210.06](#x210-06)　·　[light (from the sun/a lamp) 124.10](#x124-10)　·　[like (find sb/sth pleasant) 62.03](#x062-03)　·　[limit 169.05](#x169-05)　·　[line 235.05](#x235-05)　·　[linger 116.04](#x116-04)　·　[link 73.04](#x073-04)

[list 153.05](#x153-05)　·　[listen 202.04](#x202-04)　·　[live¹ 125.08](#x125-08)　·　[load 73.07](#x073-07)　·　[lobby 171.06](#x171-06)　·　[locate 205.05](#x205-05)　·　[lock 114.09](#x114-09)

[log 73.09](#x073-09)　·　[look 139.03](#x139-03)　·　[loom 226.08](#x226-08)　·　[lose 138.02](#x138-02)　·　[love 75.10](#x075-10)　·　[lower 144.03](#x144-03)

#### 動詞　M

[mail 216.11](#x216-11)　·　[maintain 128.05](#x128-05)　·　[make 85.01](#x085-01)　·　[manage 195.09](#x195-09)　·　[manifest 240.10](#x240-10)　·　[manipulate 125.10](#x125-10)　·　[manufacture 62.04](#x062-04)

[map 147.08](#x147-08)　·　[march 236.02](#x236-02)　·　[mark 90.07](#x090-07)　·　[market 53.08](#x053-08)　·　[marry 167.06](#x167-06)　·　[master 231.06](#x231-06)　·　[match (contest/correspond) 116.06](#x116-06)

[mate 77.02](#x077-02)　·　[matter 146.08](#x146-08)　·　[mature 244.05](#x244-05)　·　[maximize 127.03](#x127-03)　·　[mean 71.02](#x071-02)　·　[measure 147.05](#x147-05)　·　[mediate 217.10](#x217-10)

[meet 120.13](#x120-13)　·　[melt 59.06](#x059-06)　·　[mention 158.04](#x158-04)　·　[merge 228.06](#x228-06)　·　[mess 138.04](#x138-04)　·　[migrate 77.02](#x077-02)　·　[mind 141.03](#x141-03)

[minimize 232.09](#x232-09)　·　[miss 99.05](#x099-05)　·　[mistake 56.07](#x056-07)　·　[mix 142.02](#x142-02)　·　[mobilize 237.06](#x237-06)　·　[model 128.02](#x128-02)　·　[modify 71.05](#x071-05)

[monitor 144.07](#x144-07)　·　[motivate 223.03](#x223-03)　·　[mount 114.08](#x114-08)　·　[move 50.08](#x050-08)　·　[multiply 158.05](#x158-05)　·　[murder 219.10](#x219-10)

#### 動詞　N

[name 91.04](#x091-04)　·　[narrow 81.07](#x081-07)　·　[need 146.08](#x146-08)　·　[neglect 240.07](#x240-07)　·　[negotiate 111.07](#x111-07)　·　[nod 62.08](#x062-08)　·　[nominate 156.04](#x156-04)

[note 208.14](#x208-14)　·　[notice 92.06](#x092-06)　·　[notify 68.05](#x068-05)　·　[number 172.08](#x172-08)

#### 動詞　O

[obey 219.09](#x219-09)　·　[object 121.11](#x121-11)　·　[oblige 86.03](#x086-03)　·　[observe 160.04](#x160-04)　·　[obsess 235.10](#x235-10)　·　[obtain 111.07](#x111-07)　·　[occupy 77.08](#x077-08)

[occur 194.07](#x194-07)　·　[offend 224.05](#x224-05)　·　[offer 93.10](#x093-10)　·　[open 50.08](#x050-08)　·　[operate 169.03](#x169-03)　·　[oppose 224.11](#x224-11)　·　[opt 126.13](#x126-13)

[order 80.06](#x080-06)　·　[organize 169.01](#x169-01)　·　[orient 225.02](#x225-02)　·　[originate 129.08](#x129-08)　·　[outline 74.04](#x074-04)　·　[outrage 195.08](#x195-08)　·　[overcome 224.04](#x224-04)

[overlap 112.10](#x112-10)　·　[overlook 87.07](#x087-07)　·　[oversee 176.06](#x176-06)　·　[overturn 220.11](#x220-11)　·　[overwhelm 129.09](#x129-09)　·　[owe 81.10](#x081-10)　·　[own 139.11](#x139-11)

#### 動詞　P

[pace 235.09](#x235-09)　·　[pack 117.04](#x117-04)　·　[package 83.02](#x083-02)　·　[paint 172.01](#x172-01)　·　[park 211.05](#x211-05)　·　[participate 97.02](#x097-02)　·　[pass 54.10](#x054-10)

[patrol 186.05](#x186-05)　·　[pause 208.03](#x208-03)　·　[pay 110.07](#x110-07)　·　[perceive 76.06](#x076-06)　·　[perform 151.01](#x151-01)　·　[permit 228.07](#x228-07)　·　[persist 136.07](#x136-07)

[persuade 66.05](#x066-05)　·　[phone 168.02](#x168-02)　·　[photograph 200.02](#x200-02)　·　[pick 132.01](#x132-01)　·　[picture 56.05](#x056-05)　·　[pile 170.02](#x170-02)　·　[pin 235.07](#x235-07)

[pioneer 134.04](#x134-04)　·　[place 52.03](#x052-03)　·　[plan 187.01](#x187-01)　·　[plant 239.07](#x239-07)　·　[play 98.05](#x098-05)　·　[plead 75.05](#x075-05)　·　[please 177.07](#x177-07)

[pledge 224.10](#x224-10)　·　[plot 128.07](#x128-07)　·　[plug 73.07](#x073-07)　·　[plunge 169.08](#x169-08)　·　[point 200.09](#x200-09)　·　[poison 116.09](#x116-09)　·　[pop 85.03](#x085-03)

[portray 166.07](#x166-07)　·　[pose 236.03](#x236-03)　·　[position 99.06](#x099-06)　·　[possess 61.04](#x061-04)　·　[post 156.09](#x156-09)　·　[postpone 216.12](#x216-12)　·　[pour 115.04](#x115-04)

[power 74.01](#x074-01)　·　[practise 155.07](#x155-07)　·　[praise 208.08](#x208-08)　·　[pray 108.12](#x108-12)　·　[preach 75.08](#x075-08)　·　[precede 190.07](#x190-07)　·　[predict 213.10](#x213-10)

[prefer 115.09](#x115-09)　·　[prepare 79.05](#x079-05)　·　[prescribe 145.08](#x145-08)　·　[present 233.01](#x233-01)　·　[preserve 105.09](#x105-09)　·　[preside 76.03](#x076-03)　·　[press 148.01](#x148-01)

[presume 227.10](#x227-10)　·　[pretend 98.08](#x098-08)　·　[prevail 87.08](#x087-08)　·　[prevent 161.07](#x161-07)　·　[price 223.12](#x223-12)　·　[print 102.12](#x102-12)　·　[probe 67.07](#x067-07)

[proceed 144.08](#x144-08)　·　[process 218.07](#x218-07)　·　[proclaim 131.09](#x131-09)　·　[produce 59.02](#x059-02)　·　[program 172.01](#x172-01)　·　[progress 234.06](#x234-06)　·　[prohibit 103.03](#x103-03)

[project 71.08](#x071-08)　·　[promise 144.09](#x144-09)　·　[promote 234.03](#x234-03)　·　[prompt 110.01](#x110-01)　·　[pronounce 89.04](#x089-04)　·　[propose 186.01](#x186-01)　·　[prosecute 220.03](#x220-03)

[protect 113.12](#x113-12)　·　[protest 66.06](#x066-06)　·　[prove 140.10](#x140-10)　·　[provide 218.07](#x218-07)　·　[provoke 120.11](#x120-11)　·　[publish 67.10](#x067-10)　·　[pull 141.06](#x141-06)

[pump 216.05](#x216-05)　·　[punch 106.05](#x106-05)　·　[punish 86.04](#x086-04)　·　[purchase 162.02](#x162-02)　·　[pursue 238.10](#x238-10)　·　[push 132.06](#x132-06)　·　[put 83.03](#x083-03)

#### 動詞　Q

[qualify 182.03](#x182-03)　·　[quantify 228.08](#x228-08)　·　[question 130.09](#x130-09)　·　[queue 66.07](#x066-07)　·　[quit 163.07](#x163-07)　·　[quote 227.11](#x227-11)

#### 動詞　R

[race (competition) 92.05](#x092-05)　·　[raid 75.03](#x075-03)　·　[rain 180.05](#x180-05)　·　[raise 223.11](#x223-11)　·　[rally 120.08](#x120-08)　·　[randomize 78.04](#x078-04)　·　[range 189.08](#x189-08)

[rank 229.06](#x229-06)　·　[rape 105.05](#x105-05)　·　[rate 89.07](#x089-07)　·　[reach 169.08](#x169-08)　·　[react 236.05](#x236-05)　·　[read 105.10](#x105-10)　·　[realize 83.08](#x083-08)

[reassure 144.08](#x144-08)　·　[rebuild 214.07](#x214-07)　·　[recall 107.09](#x107-09)　·　[receive 86.10](#x086-10)　·　[reckon 163.08](#x163-08)　·　[recognize 199.07](#x199-07)　·　[recommend 124.08](#x124-08)

[reconstruct 50.03](#x050-03)　·　[record 153.07](#x153-07)　·　[recount¹ 220.02](#x220-02)　·　[recover 126.09](#x126-09)　·　[recruit 82.07](#x082-07)　·　[recycle 181.05](#x181-05)　·　[reduce 223.11](#x223-11)

[refer 131.08](#x131-08)　·　[reflect 78.05](#x078-05)　·　[reform 186.08](#x186-08)　·　[refuse¹ 208.11](#x208-11)　·　[regain 101.06](#x101-06)　·　[regard 83.10](#x083-10)　·　[register 173.04](#x173-04)

[regret 238.11](#x238-11)　·　[regulate 131.09](#x131-09)　·　[reign 89.01](#x089-01)　·　[reinforce 147.06](#x147-06)　·　[reject 224.08](#x224-08)　·　[relate 127.09](#x127-09)　·　[relax 76.02](#x076-02)

[release 162.06](#x162-06)　·　[relieve 222.08](#x222-08)　·　[rely 128.06](#x128-06)　·　[remain 58.05](#x058-05)　·　[remark 166.04](#x166-04)　·　[remember 209.03](#x209-03)　·　[remind 138.05](#x138-05)

[remove 52.05](#x052-05)　·　[render 157.09](#x157-09)　·　[renew 230.02](#x230-02)　·　[rent 121.04](#x121-04)　·　[repair 53.06](#x053-06)　·　[repeat 157.05](#x157-05)　·　[replace 204.07](#x204-07)

[reply 92.08](#x092-08)　·　[report 74.08](#x074-08)　·　[represent 156.05](#x156-05)　·　[reproduce 226.02](#x226-02)　·　[request 102.09](#x102-09)　·　[require 53.10](#x053-10)　·　[rescue 165.06](#x165-06)

[research 232.10](#x232-10)　·　[resemble 108.11](#x108-11)　·　[reserve 59.08](#x059-08)　·　[reside 166.05](#x166-05)　·　[resign 219.09](#x219-09)　·　[resist 117.09](#x117-09)　·　[resolve 87.06](#x087-06)

[respect 167.05](#x167-05)　·　[respond 222.05](#x222-05)　·　[rest (sleep/relax) 108.12](#x108-12)　·　[restore 73.02](#x073-02)　·　[restrict 161.06](#x161-06)　·　[result 220.09](#x220-09)　·　[resume 118.10](#x118-10)

[retain 52.05](#x052-05)　·　[retire 142.10](#x142-10)　·　[retreat 237.04](#x237-04)　·　[retrieve 100.07](#x100-07)　·　[return 70.09](#x070-09)　·　[reveal 147.09](#x147-09)　·　[reverse 225.09](#x225-09)

[review 110.12](#x110-12)　·　[revise 63.10](#x063-10)　·　[revive 187.02](#x187-02)　·　[reward 223.03](#x223-03)　·　[rid 134.09](#x134-09)　·　[ride 83.05](#x083-05)　·　[ring² 139.01](#x139-01)

[rip 210.08](#x210-08)　·　[rise 90.03](#x090-03)　·　[risk 89.06](#x089-06)　·　[rob 188.09](#x188-09)　·　[rock 206.06](#x206-06)　·　[roll 115.07](#x115-07)　·　[rotate 74.02](#x074-02)

[rub 148.08](#x148-08)　·　[ruin 213.12](#x213-12)　·　[rule 126.05](#x126-05)　·　[run 74.09](#x074-09)　·　[rush 180.09](#x180-09)

#### 動詞　S

[sack 240.01](#x240-01)　·　[sacrifice 119.08](#x119-08)　·　[sail 56.10](#x056-10)　·　[sample 175.01](#x175-01)　·　[satisfy 237.07](#x237-07)　·　[save 133.08](#x133-08)　·　[say 83.07](#x083-07)

[scale 181.03](#x181-03)　·　[scan 228.08](#x228-08)　·　[scare 130.06](#x130-06)　·　[schedule 80.07](#x080-07)　·　[score 192.07](#x192-07)　·　[scratch 231.05](#x231-05)　·　[scream 130.05](#x130-05)

[screen 79.07](#x079-07)　·　[screw 170.04](#x170-04)　·　[seal 210.03](#x210-03)　·　[search 112.02](#x112-02)　·　[seat 79.07](#x079-07)　·　[secure 143.07](#x143-07)　·　[see 202.06](#x202-06)

[seek 104.10](#x104-10)　·　[seem 85.05](#x085-05)　·　[seize 169.08](#x169-08)　·　[select 225.06](#x225-06)　·　[sell 102.07](#x102-07)　·　[send 73.09](#x073-09)　·　[sense 167.07](#x167-07)

[sentence 220.07](#x220-07)　·　[separate 113.09](#x113-09)　·　[serve 68.04](#x068-04)　·　[set 150.05](#x150-05)　·　[set (put) 225.05](#x225-05)　·　[settle 121.10](#x121-10)　·　[shake 84.04](#x084-04)

[shape 172.06](#x172-06)　·　[share 205.09](#x205-09)　·　[shatter 130.05](#x130-05)　·　[shed 81.09](#x081-09)　·　[shelter 168.04](#x168-04)　·　[shift 214.06](#x214-06)　·　[shine 124.13](#x124-13)

[ship 83.02](#x083-02)　·　[shock 195.08](#x195-08)　·　[shoot 219.06](#x219-06)　·　[shop 104.04](#x104-04)　·　[shout 69.06](#x069-06)　·　[show 140.01](#x140-01)　·　[shrink 226.04](#x226-04)

[shrug 94.05](#x094-05)　·　[shut 53.03](#x053-03)　·　[sigh 188.06](#x188-06)　·　[sign 212.11](#x212-11)　·　[signal 118.06](#x118-06)　·　[simplify 63.09](#x063-09)　·　[simulate 173.03](#x173-03)

[sing 215.04](#x215-04)　·　[sink 134.07](#x134-07)　·　[sit 55.04](#x055-04)　·　[ski 180.02](#x180-02)　·　[skip 236.03](#x236-03)　·　[slam 130.05](#x130-05)　·　[slap 85.02](#x085-02)

[slash 171.07](#x171-07)　·　[sleep 215.02](#x215-02)　·　[slice 115.04](#x115-04)　·　[slide 70.04](#x070-04)　·　[slip 169.07](#x169-07)　·　[slope 225.07](#x225-07)　·　[slow 118.06](#x118-06)

[smash 69.07](#x069-07)　·　[smell 142.08](#x142-08)　·　[smile 200.04](#x200-04)　·　[smoke 131.03](#x131-03)　·　[snap 54.05](#x054-05)　·　[snow 180.04](#x180-04)　·　[soak 239.04](#x239-04)

[soar 134.01](#x134-01)　·　[solve 81.06](#x081-06)　·　[sort 154.03](#x154-03)　·　[sound 236.12](#x236-12)　·　[span 114.03](#x114-03)　·　[spare 59.05](#x059-05)　·　[spark 183.07](#x183-07)

[speak 209.08](#x209-08)　·　[specialize 129.04](#x129-04)　·　[specify 71.09](#x071-09)　·　[speculate 153.05](#x153-05)　·　[speed 211.05](#x211-05)　·　[spell 138.04](#x138-04)　·　[spend 80.04](#x080-04)

[spill 181.07](#x181-07)　·　[spin 235.04](#x235-04)　·　[split 132.07](#x132-07)　·　[spoil 62.05](#x062-05)　·　[sponsor 152.07](#x152-07)　·　[spot 226.07](#x226-07)　·　[spread 125.12](#x125-12)

[spring 85.04](#x085-04)　·　[spy 186.07](#x186-07)　·　[squeeze 203.04](#x203-04)　·　[stab 98.08](#x098-08)　·　[stabilize 81.01](#x081-01)　·　[stage 178.02](#x178-02)　·　[stand 211.10](#x211-10)

[star 98.05](#x098-05)　·　[stare 69.06](#x069-06)　·　[start 163.02](#x163-02)　·　[starve 218.05](#x218-05)　·　[state 104.06](#x104-06)　·　[stay 76.10](#x076-10)　·　[steal 157.07](#x157-07)

[steer 206.09](#x206-09)　·　[stem 130.04](#x130-04)　·　[step 62.07](#x062-07)　·　[stick (push into/attach) 148.07](#x148-07)　·　[stimulate 236.04](#x236-04)　·　[stir 115.05](#x115-05)　·　[stop 68.05](#x068-05)

[store 147.03](#x147-03)　·　[strengthen 214.08](#x214-08)　·　[stress 120.10](#x120-10)　·　[stretch 70.07](#x070-07)　·　[strike 169.06](#x169-06)　·　[strip (remove clothes/a layer) 210.03](#x210-03)　·　[strive 101.06](#x101-06)

[structure 85.08](#x085-08)　·　[struggle 187.08](#x187-08)　·　[study 231.04](#x231-04)　·　[stuff 115.07](#x115-07)　·　[stumble 84.05](#x084-05)　·　[stun 188.02](#x188-02)　·　[subject 236.08](#x236-08)

[submit 113.03](#x113-03)　·　[substitute 84.06](#x084-06)　·　[succeed 196.11](#x196-11)　·　[suck 239.03](#x239-03)　·　[sue 131.10](#x131-10)　·　[suffer 79.06](#x079-06)　·　[suggest 166.08](#x166-08)

[suit 234.07](#x234-07)　·　[sum 128.12](#x128-12)　·　[summarize 78.06](#x078-06)　·　[supervise 163.04](#x163-04)　·　[supplement 218.10](#x218-10)　·　[supply 108.02](#x108-02)　·　[support 82.07](#x082-07)

[suppose 185.09](#x185-09)　·　[suppress 224.11](#x224-11)　·　[surge 134.08](#x134-08)　·　[surprise 72.02](#x072-02)　·　[surrender 155.09](#x155-09)　·　[surround 215.04](#x215-04)　·　[survey 113.02](#x113-02)

[survive 70.09](#x070-09)　·　[suspect 190.06](#x190-06)　·　[suspend 232.09](#x232-09)　·　[sustain 99.03](#x099-03)　·　[swallow 79.08](#x079-08)　·　[swear 190.09](#x190-09)　·　[sweep 235.04](#x235-04)

[swim 90.04](#x090-04)　·　[swing 69.05](#x069-05)　·　[switch 151.06](#x151-06)

#### 動詞　T

[tackle 242.08](#x242-08)　·　[tag 112.07](#x112-07)　·　[take 67.08](#x067-08)　·　[talk 188.03](#x188-03)　·　[tap 215.06](#x215-06)　·　[target 101.05](#x101-05)　·　[taste 59.07](#x059-07)

[tax 184.05](#x184-05)　·　[teach 227.03](#x227-03)　·　[tear¹ 124.11](#x124-11)　·　[telephone 66.08](#x066-08)　·　[tell 155.01](#x155-01)　·　[tempt 240.11](#x240-11)　·　[tend 136.07](#x136-07)

[term 87.09](#x087-09)　·　[terminate 171.07](#x171-07)　·　[terrify 209.04](#x209-04)　·　[test 95.10](#x095-10)　·　[testify 64.05](#x064-05)　·　[text 180.03](#x180-03)　·　[thank 221.11](#x221-11)

[think 135.06](#x135-06)　·　[threaten 70.04](#x070-04)　·　[thrive 160.09](#x160-09)　·　[throw 235.04](#x235-04)　·　[tidy 114.09](#x114-09)　·　[tie 83.02](#x083-02)　·　[tighten 143.04](#x143-04)

[time 213.05](#x213-05)　·　[tip 132.06](#x132-06)　·　[title 71.09](#x071-09)　·　[tolerate 169.09](#x169-09)　·　[top 212.04](#x212-04)　·　[torture 107.11](#x107-11)　·　[toss 85.03](#x085-03)

[total 171.04](#x171-04)　·　[touch 202.08](#x202-08)　·　[tour 110.06](#x110-06)　·　[trace 51.07](#x051-07)　·　[track 173.01](#x173-01)　·　[trade 212.06](#x212-06)　·　[trail 132.08](#x132-08)

[train 68.03](#x068-03)　·　[transfer 162.05](#x162-05)　·　[transform 233.04](#x233-04)　·　[translate 123.09](#x123-09)　·　[transmit 70.06](#x070-06)　·　[transport 170.03](#x170-03)　·　[trap 234.07](#x234-07)

[travel 99.07](#x099-07)　·　[treat 57.02](#x057-02)　·　[trick 174.05](#x174-05)　·　[trigger 216.04](#x216-04)　·　[trip 114.11](#x114-11)　·　[trouble 86.08](#x086-08)　·　[trust 174.09](#x174-09)

[try 210.09](#x210-09)　·　[turn 94.07](#x094-07)　·　[twist 84.04](#x084-04)　·　[type 172.02](#x172-02)

#### 動詞　U

[undergo 244.06](#x244-06)　·　[undermine 135.03](#x135-03)　·　[understand 77.08](#x077-08)　·　[undertake 189.06](#x189-06)　·　[unfold 227.09](#x227-09)　·　[unify 119.04](#x119-04)　·　[unite 82.04](#x082-04)

[unveil 196.09](#x196-09)　·　[update 228.10](#x228-10)　·　[upgrade 112.11](#x112-11)　·　[uphold 61.05](#x061-05)　·　[upset 167.03](#x167-03)　·　[urge 240.11](#x240-11)　·　[use 118.11](#x118-11)

[utilize 87.06](#x087-06)

#### 動詞　V

[validate 159.08](#x159-08)　·　[value 233.07](#x233-07)　·　[vanish 118.04](#x118-04)　·　[vary 55.06](#x055-06)　·　[venture 170.07](#x170-07)　·　[verify 220.05](#x220-05)　·　[view 95.06](#x095-06)

[violate 86.06](#x086-06)　·　[visit 160.07](#x160-07)　·　[volunteer 222.02](#x222-02)　·　[vote 103.09](#x103-09)　·　[vow 86.06](#x086-06)

#### 動詞　W

[wait 143.07](#x143-07)　·　[wake 222.09](#x222-09)　·　[walk 99.09](#x099-09)　·　[wander 76.01](#x076-01)　·　[want 139.09](#x139-09)　·　[warm 237.08](#x237-08)　·　[warn 118.06](#x118-06)

[warrant 64.08](#x064-08)　·　[wash 181.05](#x181-05)　·　[waste 237.08](#x237-08)　·　[watch 100.03](#x100-03)　·　[water 60.03](#x060-03)　·　[wave 149.09](#x149-09)　·　[weaken 203.10](#x203-10)

[wear 130.02](#x130-02)　·　[weave 85.02](#x085-02)　·　[weigh 162.09](#x162-09)　·　[welcome 199.02](#x199-02)　·　[whip 115.07](#x115-07)　·　[whisper 72.07](#x072-07)　·　[widen 147.06](#x147-06)

[win 213.03](#x213-03)　·　[wind² 94.09](#x094-09)　·　[wipe 59.09](#x059-09)　·　[wish 170.03](#x170-03)　·　[withdraw 224.11](#x224-11)　·　[witness 124.06](#x124-06)　·　[wonder 83.07](#x083-07)

[work 178.08](#x178-08)　·　[worry 209.11](#x209-11)　·　[worship 108.14](#x108-14)　·　[wound 75.04](#x075-04)　·　[wrap 139.06](#x139-06)　·　[write 227.11](#x227-11)

#### 動詞　Y

[yell 98.09](#x098-09)　·　[yield 78.09](#x078-09)

<a id="lex-adjective"></a>

### 形容詞　1,119項目

#### 形容詞　A

[able 225.05](#x225-05)　·　[abnormal 129.05](#x129-05)　·　[above 73.08](#x073-08)　·　[absent 163.05](#x163-05)　·　[absolute 232.07](#x232-07)　·　[abstract 128.08](#x128-08)　·　[absurd 85.05](#x085-05)

[academic 153.02](#x153-02)　·　[acceptable 240.08](#x240-08)　·　[accessible 105.02](#x105-02)　·　[accountable 67.08](#x067-08)　·　[accurate 153.07](#x153-07)　·　[acid 203.04](#x203-04)　·　[active 118.01](#x118-01)

[actual 63.05](#x063-05)　·　[acute 174.04](#x174-04)　·　[adaptive 234.06](#x234-06)　·　[additional 110.10](#x110-10)　·　[adequate 74.05](#x074-05)　·　[adjacent 147.07](#x147-07)　·　[administrative 232.04](#x232-04)

[adult 121.03](#x121-03)　·　[advance 80.03](#x080-03)　·　[advanced 172.02](#x172-02)　·　[adverse 232.10](#x232-10)　·　[aesthetic 114.06](#x114-06)　·　[affordable 80.02](#x080-02)　·　[afraid 187.09](#x187-09)

[aged 210.05](#x210-05)　·　[aggressive 107.10](#x107-10)　·　[agricultural 60.02](#x060-02)　·　[alcoholic 188.05](#x188-05)　·　[alert 210.09](#x210-09)　·　[alien 107.14](#x107-14)　·　[alike 77.03](#x077-03)

[alive 187.04](#x187-04)　·　[all right 211.06](#x211-06)　·　[alone 133.01](#x133-01)　·　[alternative 80.05](#x080-05)　·　[amateur 151.01](#x151-01)　·　[amazed 226.09](#x226-09)　·　[amazing 134.03](#x134-03)

[ambitious 61.02](#x061-02)　·　[amusing 151.09](#x151-09)　·　[analytical 236.09](#x236-09)　·　[ancient 98.03](#x098-03)　·　[angry 67.01](#x067-01)　·　[annoyed 152.09](#x152-09)　·　[annoying 228.03](#x228-03)

[annual 126.01](#x126-01)　·　[anonymous 67.03](#x067-03)　·　[anxious 174.05](#x174-05)　·　[apparent 236.06](#x236-06)　·　[appealing 126.02](#x126-02)　·　[applicable 74.06](#x074-06)　·　[appropriate 173.04](#x173-04)

[arbitrary 224.08](#x224-08)　·　[architectural 114.04](#x114-04)　·　[armed 61.07](#x061-07)　·　[artificial 150.02](#x150-02)　·　[artistic 236.12](#x236-12)　·　[ashamed 133.04](#x133-04)　·　[asleep 83.06](#x083-06)

[assistant 154.04](#x154-04)　·　[associated 218.09](#x218-09)　·　[astonishing 128.10](#x128-10)　·　[attractive 62.04](#x062-04)　·　[audio 151.02](#x151-02)　·　[authentic 220.01](#x220-01)　·　[automatic 90.10](#x090-10)

[available 57.06](#x057-06)　·　[average 159.06](#x159-06)　·　[aware 228.11](#x228-11)　·　[awful 138.09](#x138-09)　·　[awkward 89.03](#x089-03)

#### 形容詞　B

[back 139.05](#x139-05)　·　[bad 211.06](#x211-06)　·　[balanced 127.09](#x127-09)　·　[bare 51.01](#x051-01)　·　[based 192.01](#x192-01)　·　[basic 209.04](#x209-04)　·　[beautiful 117.10](#x117-10)

[beloved 61.04](#x061-04)　·　[beneficial 160.05](#x160-05)　·　[bent 201.09](#x201-09)　·　[best 101.05](#x101-05)　·　[better 80.10](#x080-10)　·　[big 191.08](#x191-08)　·　[biological 221.06](#x221-06)

[bitter 93.08](#x093-08)　·　[bizarre 72.04](#x072-04)　·　[black 170.08](#x170-08)　·　[blank 199.03](#x199-03)　·　[blind 99.10](#x099-10)　·　[blonde 62.02](#x062-02)　·　[blue 140.04](#x140-04)

[bold 224.02](#x224-02)　·　[bored 134.06](#x134-06)　·　[boring 71.06](#x071-06)　·　[bottom 148.06](#x148-06)　·　[bound 238.08](#x238-08)　·　[brave 107.11](#x107-11)　·　[brief 61.06](#x061-06)

[bright 162.08](#x162-08)　·　[brilliant 225.04](#x225-04)　·　[broad 98.02](#x098-02)　·　[broken 53.04](#x053-04)　·　[brown 139.06](#x139-06)　·　[brutal 208.05](#x208-05)　·　[busy 100.08](#x100-08)

#### 形容詞　C

[calm 58.08](#x058-08)　·　[capable 190.08](#x190-08)　·　[capital 235.11](#x235-11)　·　[capitalist 127.07](#x127-07)　·　[careful 70.05](#x070-05)　·　[careless 157.09](#x157-09)　·　[casual 213.10](#x213-10)

[causal 113.08](#x113-08)　·　[cautious 74.07](#x074-07)　·　[central 173.07](#x173-07)　·　[certain 199.09](#x199-09)　·　[challenging 128.03](#x128-03)　·　[characteristic 77.03](#x077-03)　·　[charming 187.09](#x187-09)

[cheap 214.03](#x214-03)　·　[cheerful 102.04](#x102-04)　·　[chemical 78.02](#x078-02)　·　[chief 186.03](#x186-03)　·　[chronic 221.01](#x221-01)　·　[civic 103.07](#x103-07)　·　[civil 66.03](#x066-03)

[civilian 155.06](#x155-06)　·　[classic 231.03](#x231-03)　·　[classical 99.03](#x099-03)　·　[clean 59.09](#x059-09)　·　[clear 145.03](#x145-03)　·　[clever 208.08](#x208-08)　·　[clinical 97.01](#x097-01)

[close² 79.10](#x079-10)　·　[closed 148.10](#x148-10)　·　[coastal 212.03](#x212-03)　·　[cognitive 129.01](#x129-01)　·　[cold 77.02](#x077-02)　·　[collective 158.08](#x158-08)　·　[colonial 217.01](#x217-01)

[coloured 114.12](#x114-12)　·　[colourful 65.07](#x065-07)　·　[comfortable 177.01](#x177-01)　·　[comic 208.08](#x208-08)　·　[commercial 102.08](#x102-08)　·　[common 73.05](#x073-05)　·　[communist 166.01](#x166-01)

[comparable 203.08](#x203-08)　·　[comparative 110.05](#x110-05)　·　[compelling 76.08](#x076-08)　·　[competent 169.03](#x169-03)　·　[competitive 213.12](#x213-12)　·　[complete 123.07](#x123-07)　·　[complex 81.03](#x081-03)

[complicated 172.03](#x172-03)　·　[comprehensive 222.03](#x222-03)　·　[compulsory 120.03](#x120-03)　·　[conceptual 82.06](#x082-06)　·　[concerned 168.02](#x168-02)　·　[concrete 205.07](#x205-07)　·　[conditional 110.11](#x110-11)

[confident 85.08](#x085-08)　·　[confused 182.05](#x182-05)　·　[confusing 209.07](#x209-07)　·　[congressional 119.04](#x119-04)　·　[connected 84.06](#x084-06)　·　[conscious 145.03](#x145-03)　·　[consecutive 213.09](#x213-09)

[conservative 103.03](#x103-03)　·　[considerable 64.09](#x064-09)　·　[consistent 182.07](#x182-07)　·　[constant 216.02](#x216-02)　·　[constitutional 119.05](#x119-05)　·　[constructive 67.04](#x067-04)　·　[contemporary 164.06](#x164-06)

[content² 215.12](#x215-12)　·　[continuous 107.03](#x107-03)　·　[contrary 82.03](#x082-03)　·　[controversial 185.01](#x185-01)　·　[convenient 239.02](#x239-02)　·　[conventional 127.05](#x127-05)　·　[convinced 83.09](#x083-09)

[convincing 157.09](#x157-09)　·　[cool 201.03](#x201-03)　·　[cooperative 119.10](#x119-10)　·　[core 80.02](#x080-02)　·　[corporate 176.04](#x176-04)　·　[correct 209.10](#x209-10)　·　[corresponding 125.13](#x125-13)

[corrupt 61.04](#x061-04)　·　[costly 162.06](#x162-06)　·　[countless 227.02](#x227-02)　·　[covered 109.04](#x109-04)　·　[crazy 85.06](#x085-06)　·　[cream 148.03](#x148-03)　·　[creative 228.04](#x228-04)

[credible 104.09](#x104-09)　·　[criminal 64.07](#x064-07)　·　[critical 153.10](#x153-10)　·　[crowded 208.15](#x208-15)　·　[crucial 103.05](#x103-05)　·　[crude 63.03](#x063-03)　·　[cruel 165.03](#x165-03)

[cult 209.01](#x209-01)　·　[cultural 119.02](#x119-02)　·　[cumulative 78.03](#x078-03)　·　[curious 145.05](#x145-05)　·　[curly 200.08](#x200-08)　·　[current 127.10](#x127-10)　·　[curved 50.10](#x050-10)

[cute 178.03](#x178-03)　·　[cynical 240.02](#x240-02)

#### 形容詞　D

[daily 95.05](#x095-05)　·　[dairy 59.03](#x059-03)　·　[damaging 175.07](#x175-07)　·　[dangerous 236.09](#x236-09)　·　[dark 97.05](#x097-05)　·　[dead 53.05](#x053-05)　·　[deadly 174.07](#x174-07)

[dear 208.11](#x208-11)　·　[decent 121.05](#x121-05)　·　[decisive 61.09](#x061-09)　·　[dedicated 173.01](#x173-01)　·　[deep 210.11](#x210-11)　·　[defensive 126.04](#x126-04)　·　[definite 66.08](#x066-08)

[deliberate 178.02](#x178-02)　·　[delicate 210.08](#x210-08)　·　[delicious 93.12](#x093-12)　·　[delighted 62.08](#x062-08)　·　[democratic 156.03](#x156-03)　·　[dense 210.01](#x210-01)　·　[dependent 133.03](#x133-03)

[depressed 79.09](#x079-09)　·　[depressing 196.03](#x196-03)　·　[descriptive 215.07](#x215-07)　·　[desirable 127.11](#x127-11)　·　[desperate 63.07](#x063-07)　·　[destructive 183.07](#x183-07)　·　[detailed 203.11](#x203-11)

[determined 120.09](#x120-09)　·　[developed 82.05](#x082-05)　·　[different 140.07](#x140-07)　·　[difficult 222.09](#x222-09)　·　[digital 112.03](#x112-03)　·　[diplomatic 66.09](#x066-09)　·　[direct 146.09](#x146-09)

[dirty 201.06](#x201-06)　·　[disabled 101.10](#x101-10)　·　[disappointed 85.07](#x085-07)　·　[disappointing 194.08](#x194-08)　·　[disastrous 236.07](#x236-07)　·　[dishonest 102.06](#x102-06)　·　[distant 63.02](#x063-02)

[distinct 156.09](#x156-09)　·　[distinctive 207.06](#x207-06)　·　[disturbing 130.09](#x130-09)　·　[diverse 80.02](#x080-02)　·　[divine 187.07](#x187-07)　·　[divorced 215.02](#x215-02)　·　[domestic 125.09](#x125-09)

[dominant 63.02](#x063-02)　·　[double 150.03](#x150-03)　·　[downstairs 200.01](#x200-01)　·　[downtown 121.01](#x121-01)　·　[dramatic 62.07](#x062-07)　·　[dressed 151.05](#x151-05)　·　[driving 216.02](#x216-02)

[drunk 106.02](#x106-02)　·　[dry 57.04](#x057-04)　·　[dual 154.07](#x154-07)　·　[due 204.05](#x204-05)　·　[dull 134.06](#x134-06)　·　[dumb 89.05](#x089-05)　·　[dynamic 196.04](#x196-04)

#### 形容詞　E

[eager 205.03](#x205-03)　·　[early 127.04](#x127-04)　·　[east 60.04](#x060-04)　·　[eastern 149.01](#x149-01)　·　[easy 231.04](#x231-04)　·　[ecological 134.05](#x134-05)　·　[economic 82.01](#x082-01)

[editorial 158.01](#x158-01)　·　[educated 217.10](#x217-10)　·　[educational 120.01](#x120-01)　·　[effective 67.08](#x067-08)　·　[efficient 181.06](#x181-06)　·　[elaborate 217.05](#x217-05)　·　[elderly 96.03](#x096-03)

[electoral 66.05](#x066-05)　·　[electric 162.02](#x162-02)　·　[electrical 210.03](#x210-03)　·　[electronic 112.04](#x112-04)　·　[elegant 62.01](#x062-01)　·　[elementary 153.03](#x153-03)　·　[eligible 204.04](#x204-04)

[embarrassed 121.08](#x121-08)　·　[embarrassing 89.02](#x089-02)　·　[emotional 188.05](#x188-05)　·　[empirical 228.09](#x228-09)　·　[empty 121.03](#x121-03)　·　[encouraging 87.10](#x087-10)　·　[endless 188.06](#x188-06)

[engaged 239.01](#x239-01)　·　[engaging 124.04](#x124-04)　·　[enjoyable 72.04](#x072-04)　·　[enormous 181.04](#x181-04)　·　[entertaining 240.04](#x240-04)　·　[enthusiastic 120.06](#x120-06)　·　[entire 53.01](#x053-01)

[environmental 176.09](#x176-09)　·　[equal 224.02](#x224-02)　·　[equivalent 128.05](#x128-05)　·　[essential 82.09](#x082-09)　·　[eternal 187.07](#x187-07)　·　[ethical 240.01](#x240-01)　·　[ethnic 130.03](#x130-03)

[even 81.05](#x081-05)　·　[everyday 194.03](#x194-03)　·　[evident 240.09](#x240-09)　·　[evil 106.10](#x106-10)　·　[evolutionary 77.01](#x077-01)　·　[exact 150.05](#x150-05)　·　[excellent 215.09](#x215-09)

[exceptional 100.11](#x100-11)　·　[excess 78.08](#x078-08)　·　[excessive 191.05](#x191-05)　·　[excited 215.02](#x215-02)　·　[exciting 134.11](#x134-11)　·　[exclusive 53.08](#x053-08)　·　[executive 171.07](#x171-07)

[exotic 223.05](#x223-05)　·　[expected 128.10](#x128-10)　·　[expensive 83.03](#x083-03)　·　[experienced 154.03](#x154-03)　·　[experimental 214.09](#x214-09)　·　[expert 117.11](#x117-11)　·　[explanatory 67.10](#x067-10)

[explicit 158.06](#x158-06)　·　[explosive 237.04](#x237-04)　·　[extensive 128.01](#x128-01)　·　[external 73.09](#x073-09)　·　[extra 150.04](#x150-04)　·　[extraordinary 217.01](#x217-01)　·　[extreme 117.03](#x117-03)

#### 形容詞　F

[fabulous 85.09](#x085-09)　·　[failed 161.02](#x161-02)　·　[fair 220.09](#x220-09)　·　[fake 124.11](#x124-11)　·　[FALSE 72.10](#x072-10)　·　[familiar 149.02](#x149-02)　·　[family 230.01](#x230-01)

[famous 98.10](#x098-10)　·　[fancy 62.03](#x062-03)　·　[fantastic 174.03](#x174-03)　·　[far 224.02](#x224-02)　·　[fascinating 136.10](#x136-10)　·　[fashionable 62.02](#x062-02)　·　[fast 176.04](#x176-04)

[fat 231.02](#x231-02)　·　[fatal 107.07](#x107-07)　·　[favourable 65.05](#x065-05)　·　[favourite 180.02](#x180-02)　·　[federal 224.09](#x224-09)　·　[fellow 120.08](#x120-08)　·　[female 68.08](#x068-08)

[feminist 183.03](#x183-03)　·　[few 229.04](#x229-04)　·　[fierce 98.08](#x098-08)　·　[final 61.03](#x061-03)　·　[financial 184.06](#x184-06)　·　[fine 210.09](#x210-09)　·　[firm 105.07](#x105-07)

[fit 68.03](#x068-03)　·　[fixed 152.02](#x152-02)　·　[flat 207.05](#x207-05)　·　[flawed 125.12](#x125-12)　·　[flexible 73.04](#x073-04)　·　[flying 174.02](#x174-02)　·　[folding 201.04](#x201-04)

[folk 99.02](#x099-02)　·　[following 69.04](#x069-04)　·　[fond 187.08](#x187-08)　·　[foreign 217.03](#x217-03)　·　[formal 103.07](#x103-07)　·　[former 52.07](#x052-07)　·　[forthcoming 171.01](#x171-01)

[fortunate 237.07](#x237-07)　·　[forward 122.06](#x122-06)　·　[fragile 61.10](#x061-10)　·　[free 177.05](#x177-05)　·　[frequent 232.03](#x232-03)　·　[fresh 115.04](#x115-04)　·　[friendly 80.05](#x080-05)

[frightened 168.06](#x168-06)　·　[frightening 209.03](#x209-03)　·　[front 128.11](#x128-11)　·　[frozen 60.08](#x060-08)　·　[frustrated 179.07](#x179-07)　·　[frustrating 242.07](#x242-07)　·　[full 109.04](#x109-04)

[full-time 71.02](#x071-02)　·　[fun 192.05](#x192-05)　·　[functional 231.04](#x231-04)　·　[fundamental 120.12](#x120-12)　·　[funny 72.03](#x072-03)　·　[furious 195.04](#x195-04)　·　[further 204.10](#x204-10)

[future 112.07](#x112-07)

#### 形容詞　G

[gay 86.05](#x086-05)　·　[general 184.05](#x184-05)　·　[generic 221.05](#x221-05)　·　[generous 91.13](#x091-13)　·　[genetic 77.04](#x077-04)　·　[gentle 144.03](#x144-03)　·　[genuine 204.09](#x204-09)

[geographical 116.05](#x116-05)　·　[giant 56.05](#x056-05)　·　[given 171.09](#x171-09)　·　[glad 222.10](#x222-10)　·　[global 131.09](#x131-09)　·　[glorious 84.01](#x084-01)　·　[gold 164.02](#x164-02)

[golden 208.04](#x208-04)　·　[good 123.08](#x123-08)　·　[gorgeous 71.03](#x071-03)　·　[governmental 171.06](#x171-06)　·　[grand 208.13](#x208-13)　·　[graphic 128.07](#x128-07)　·　[grateful 72.08](#x072-08)

[grave (serious) 190.03](#x190-03)　·　[great 213.08](#x213-08)　·　[green 91.06](#x091-06)　·　[grey 50.01](#x050-01)　·　[gross 191.03](#x191-03)　·　[guilty 220.08](#x220-08)

#### 形容詞　H

[handy 112.03](#x112-03)　·　[happy 84.09](#x084-09)　·　[hard 148.02](#x148-02)　·　[harmful 221.03](#x221-03)　·　[harsh 131.01](#x131-01)　·　[healthy 58.05](#x058-05)　·　[heavy 139.02](#x139-02)

[helpful 222.07](#x222-07)　·　[hidden 99.01](#x099-01)　·　[hierarchical 82.03](#x082-03)　·　[high 152.02](#x152-02)　·　[high-profile 220.03](#x220-03)　·　[hilarious 98.11](#x098-11)　·　[historic 71.01](#x071-01)

[historical 154.05](#x154-05)　·　[hollow 212.09](#x212-09)　·　[holy 108.09](#x108-09)　·　[home 68.07](#x068-07)　·　[homeless 182.01](#x182-01)　·　[honest 220.12](#x220-12)　·　[hopeful 135.11](#x135-11)

[horizontal 52.01](#x052-01)　·　[horrible 195.01](#x195-01)　·　[hostile 224.05](#x224-05)　·　[hot 95.03](#x095-03)　·　[huge 65.06](#x065-06)　·　[human 174.08](#x174-08)　·　[humanitarian 237.01](#x237-01)

[humble 117.07](#x117-07)　·　[humorous 72.02](#x072-02)　·　[hungry 182.09](#x182-09)　·　[hurt 208.06](#x208-06)　·　[hypothetical 129.02](#x129-02)

#### 形容詞　I

[ideal 89.06](#x089-06)　·　[identical 166.04](#x166-04)　·　[ideological 242.02](#x242-02)　·　[ill 121.05](#x121-05)　·　[illegal 64.05](#x064-05)　·　[imaginary 151.05](#x151-05)　·　[immediate 215.11](#x215-11)

[immense 99.08](#x099-08)　·　[imminent 66.02](#x066-02)　·　[immune 160.06](#x160-06)　·　[impatient 213.04](#x213-04)　·　[implicit 103.08](#x103-08)　·　[important 71.07](#x071-07)　·　[impossible 192.04](#x192-04)

[impressed 228.11](#x228-11)　·　[impressive 124.09](#x124-09)　·　[inadequate 64.08](#x064-08)　·　[inappropriate 185.06](#x185-06)　·　[inclined 233.07](#x233-07)　·　[included 138.08](#x138-08)　·　[inconsistent 87.07](#x087-07)

[incorrect 158.07](#x158-07)　·　[incredible 242.09](#x242-09)　·　[independent 111.05](#x111-05)　·　[indigenous 63.05](#x063-05)　·　[indirect 158.06](#x158-06)　·　[individual 224.09](#x224-09)　·　[indoor 100.03](#x100-03)

[industrial 65.01](#x065-01)　·　[inevitable 185.02](#x185-02)　·　[infamous 220.01](#x220-01)　·　[influential 99.12](#x099-12)　·　[informal 72.01](#x072-01)　·　[informed 153.07](#x153-07)　·　[inherent 232.04](#x232-04)

[initial 110.09](#x110-09)　·　[injured 64.06](#x064-06)　·　[inner 167.04](#x167-04)　·　[innocent 220.08](#x220-08)　·　[innovative 112.01](#x112-01)　·　[inside 74.03](#x074-03)　·　[instant 178.05](#x178-05)

[institutional 224.10](#x224-10)　·　[instrumental 135.09](#x135-09)　·　[insufficient 74.06](#x074-06)　·　[intact 148.06](#x148-06)　·　[integral 217.09](#x217-09)　·　[integrated 119.08](#x119-08)　·　[intellectual 76.07](#x076-07)

[intelligent 172.07](#x172-07)　·　[intended 229.03](#x229-03)　·　[intense 122.02](#x122-02)　·　[intensive 79.02](#x079-02)　·　[interactive 172.05](#x172-05)　·　[interested 242.04](#x242-04)　·　[interesting 123.13](#x123-13)

[interim 66.10](#x066-10)　·　[interior 180.07](#x180-07)　·　[intermediate 231.06](#x231-06)　·　[internal 129.06](#x129-06)　·　[international 63.08](#x063-08)　·　[intimate 167.02](#x167-02)　·　[intriguing 227.01](#x227-01)

[intrinsic 129.07](#x129-07)　·　[invisible 71.07](#x071-07)　·　[involved 190.02](#x190-02)　·　[ironic 240.03](#x240-03)　·　[irrelevant 133.06](#x133-06)　·　[isolated 63.07](#x063-07)

#### 形容詞　J

[joint 176.06](#x176-06)　·　[judicial 220.09](#x220-09)　·　[junior 96.06](#x096-06)　·　[just 87.08](#x087-08)

#### 形容詞　K

[keen 160.01](#x160-01)　·　[key 234.10](#x234-10)　·　[kind (caring) 91.02](#x091-02)

#### 形容詞　L

[large 67.09](#x067-09)　·　[large-scale 176.01](#x176-01)　·　[late 235.01](#x235-01)　·　[later 108.05](#x108-05)　·　[latest 73.07](#x073-07)　·　[latter 183.10](#x183-10)　·　[lazy 242.08](#x242-08)

[leading 127.08](#x127-08)　·　[left 69.05](#x069-05)　·　[legal 156.08](#x156-08)　·　[legendary 217.04](#x217-04)　·　[legislative 131.08](#x131-08)　·　[legitimate 87.04](#x087-04)　·　[lengthy 149.02](#x149-02)

[lesbian 209.08](#x209-08)　·　[lesser 131.07](#x131-07)　·　[lethal 77.07](#x077-07)　·　[level 150.02](#x150-02)　·　[liable 242.07](#x242-07)　·　[liberal 103.04](#x103-04)　·　[lifelong 67.02](#x067-02)

[light (from the sun/a lamp) 175.08](#x175-08)　·　[light (not heavy) 206.04](#x206-04)　·　[likely 101.08](#x101-08)　·　[limited 78.10](#x078-10)　·　[linear 150.08](#x150-08)　·　[liquid 226.03](#x226-03)　·　[literary 135.03](#x135-03)

[little 50.06](#x050-06)　·　[live² 151.07](#x151-07)　·　[lively 213.07](#x213-07)　·　[living 126.09](#x126-09)　·　[local 53.07](#x053-07)　·　[localized 160.05](#x160-05)　·　[located 232.05](#x232-05)

[logical 128.03](#x128-03)　·　[lonely 60.01](#x060-01)　·　[long-standing 187.06](#x187-06)　·　[long-term 217.07](#x217-07)　·　[long-time 122.02](#x122-02)　·　[long¹ 55.04](#x055-04)　·　[loose 143.01](#x143-01)

[lost 235.09](#x235-09)　·　[loud 99.05](#x099-05)　·　[lovely 83.10](#x083-10)　·　[low 177.08](#x177-08)　·　[lower 232.05](#x232-05)　·　[loyal 130.04](#x130-04)　·　[lucky 87.05](#x087-05)

#### 形容詞　M

[mad 192.05](#x192-05)　·　[magic 235.01](#x235-01)　·　[magical 128.11](#x128-11)　·　[magnetic 53.05](#x053-05)　·　[magnificent 164.06](#x164-06)　·　[main 204.01](#x204-01)　·　[mainstream 120.09](#x120-09)

[major 78.07](#x078-07)　·　[male 163.02](#x163-02)　·　[mandatory 232.02](#x232-02)　·　[marginal 99.08](#x099-08)　·　[marine 56.06](#x056-06)　·　[married 141.01](#x141-01)　·　[martial 219.04](#x219-04)

[mass 124.05](#x124-05)　·　[massive 70.04](#x070-04)　·　[matching 181.09](#x181-09)　·　[material 226.10](#x226-10)　·　[mathematical 128.01](#x128-01)　·　[mature 84.01](#x084-01)　·　[maximum 173.05](#x173-05)

[meaningful 232.06](#x232-06)　·　[mechanical 94.02](#x094-02)　·　[medical 57.09](#x057-09)　·　[medieval 164.03](#x164-03)　·　[medium 235.02](#x235-02)　·　[memorable 122.05](#x122-05)　·　[mental 58.05](#x058-05)

[mere 181.07](#x181-07)　·　[methodological 203.12](#x203-12)　·　[middle 113.06](#x113-06)　·　[mild 57.03](#x057-03)　·　[militant 165.04](#x165-04)　·　[military 219.12](#x219-12)　·　[minimal 134.11](#x134-11)

[minimum 62.04](#x062-04)　·　[minor 157.04](#x157-04)　·　[minute² 210.10](#x210-10)　·　[miserable 133.04](#x133-04)　·　[misleading 65.10](#x065-10)　·　[missing 146.07](#x146-07)　·　[mixed 229.04](#x229-04)

[mobile 110.06](#x110-06)　·　[moderate 65.11](#x065-11)　·　[modern 171.02](#x171-02)　·　[modest 204.03](#x204-03)　·　[monthly 101.10](#x101-10)　·　[moral 76.03](#x076-03)　·　[motor 149.03](#x149-03)

[moving 215.01](#x215-01)　·　[multiple 125.07](#x125-07)　·　[municipal 59.01](#x059-01)　·　[musical 179.01](#x179-01)　·　[mutual 217.10](#x217-10)　·　[mysterious 116.08](#x116-08)

#### 形容詞　N

[naked 63.03](#x063-03)　·　[narrative 179.02](#x179-02)　·　[narrow 202.07](#x202-07)　·　[nasty 125.10](#x125-10)　·　[national 66.02](#x066-02)　·　[nationwide 158.02](#x158-02)　·　[native 209.07](#x209-07)

[natural 93.12](#x093-12)　·　[naval 56.02](#x056-02)　·　[near 192.09](#x192-09)　·　[nearby 207.02](#x207-02)　·　[neat 109.05](#x109-05)　·　[necessary 86.09](#x086-09)　·　[negative 191.05](#x191-05)

[neighbouring 205.06](#x205-06)　·　[nervous 107.06](#x107-06)　·　[net 65.02](#x065-02)　·　[neutral 166.08](#x166-08)　·　[new 226.04](#x226-04)　·　[next 132.01](#x132-01)　·　[nice 84.05](#x084-05)

[noble 164.05](#x164-05)　·　[noisy 213.01](#x213-01)　·　[non-profit 126.01](#x126-01)　·　[normal 78.04](#x078-04)　·　[north 147.02](#x147-02)　·　[northern 205.02](#x205-02)　·　[notable 126.02](#x126-02)

[notorious 69.01](#x069-01)　·　[novel 172.09](#x172-09)　·　[nuclear 237.02](#x237-02)　·　[numerous 135.10](#x135-10)　·　[nursing 79.01](#x079-01)

#### 形容詞　O

[objective 157.04](#x157-04)　·　[obvious 230.11](#x230-11)　·　[occasional 116.07](#x116-07)　·　[odd 69.11](#x069-11)　·　[offensive 183.01](#x183-01)　·　[official 205.01](#x205-01)　·　[OK 134.06](#x134-06)

[old 55.05](#x055-05)　·　[old-fashioned 177.06](#x177-06)　·　[ongoing 228.03](#x228-03)　·　[online 112.06](#x112-06)　·　[only 53.02](#x053-02)　·　[open 191.01](#x191-01)　·　[operational 216.05](#x216-05)

[opposed 103.04](#x103-04)　·　[opposite 51.01](#x051-01)　·　[optical 150.03](#x150-03)　·　[optimal 214.10](#x214-10)　·　[optimistic 111.08](#x111-08)　·　[oral 58.01](#x058-01)　·　[orange 148.03](#x148-03)

[ordinary 209.03](#x209-03)　·　[organic 134.04](#x134-04)　·　[organizational 83.01](#x083-01)　·　[organized 171.06](#x171-06)　·　[original 219.02](#x219-02)　·　[other 92.04](#x092-04)　·　[outdoor 68.01](#x068-01)

[outer 169.07](#x169-07)　·　[outside 210.11](#x210-11)　·　[outstanding 123.02](#x123-02)　·　[overall 81.10](#x081-10)　·　[overseas 184.02](#x184-02)　·　[overwhelming 228.09](#x228-09)　·　[own 93.14](#x093-14)

#### 形容詞　P

[painful 57.04](#x057-04)　·　[pale 160.07](#x160-07)　·　[parallel 210.01](#x210-01)　·　[parental 103.06](#x103-06)　·　[parliamentary 66.04](#x066-04)　·　[part-time 171.07](#x171-07)　·　[partial 234.05](#x234-05)

[particular 97.09](#x097-09)　·　[passionate 82.09](#x082-09)　·　[passive 169.04](#x169-04)　·　[past 221.02](#x221-02)　·　[patient 93.13](#x093-13)　·　[peaceful 67.03](#x067-03)　·　[peculiar 139.10](#x139-10)

[per cent 240.05](#x240-05)　·　[perfect 98.07](#x098-07)　·　[permanent 58.03](#x058-03)　·　[persistent 161.06](#x161-06)　·　[personal 229.05](#x229-05)　·　[philosophical 129.05](#x129-05)　·　[physical 58.05](#x058-05)

[pink 140.02](#x140-02)　·　[plain 207.08](#x207-08)　·　[plastic 100.05](#x100-05)　·　[pleasant 76.02](#x076-02)　·　[pleased 192.07](#x192-07)　·　[plus¹ 231.12](#x231-12)　·　[pointed 98.04](#x098-04)

[poisonous 60.05](#x060-05)　·　[polite 146.01](#x146-01)　·　[political 219.06](#x219-06)　·　[poor 108.02](#x108-02)　·　[pop 72.03](#x072-03)　·　[popular 192.09](#x192-09)　·　[positive 203.10](#x203-10)

[possible 110.05](#x110-05)　·　[post-war 75.08](#x075-08)　·　[potential 191.09](#x191-09)　·　[powerful 233.08](#x233-08)　·　[practical 114.13](#x114-13)　·　[precious 62.05](#x062-05)　·　[precise 147.09](#x147-09)

[predictable 234.07](#x234-07)　·　[pregnant 121.06](#x121-06)　·　[preliminary 71.03](#x071-03)　·　[prepared 191.08](#x191-08)　·　[present 216.11](#x216-11)　·　[presidential 135.01](#x135-01)　·　[prestigious 61.02](#x061-02)

[pretty 177.06](#x177-06)　·　[previous 209.09](#x209-09)　·　[primary 113.05](#x113-05)　·　[prime 75.01](#x075-01)　·　[principal 154.02](#x154-02)　·　[prior 204.04](#x204-04)　·　[private 105.03](#x105-03)

[probable 57.08](#x057-08)　·　[problematic 195.10](#x195-10)　·　[procedural 220.09](#x220-09)　·　[productive 127.11](#x127-11)　·　[professional 68.02](#x068-02)　·　[profitable 152.01](#x152-01)　·　[profound 242.10](#x242-10)

[progressive 127.08](#x127-08)　·　[prominent 65.08](#x065-08)　·　[promising 188.01](#x188-01)　·　[pronounced 228.09](#x228-09)　·　[proper 116.12](#x116-12)　·　[proportional 78.06](#x078-06)　·　[prospective 154.06](#x154-06)

[protective 206.02](#x206-02)　·　[proud 125.02](#x125-02)　·　[provincial 72.02](#x072-02)　·　[psychiatric 145.02](#x145-02)　·　[psychological 222.04](#x222-04)　·　[public 103.01](#x103-01)　·　[pure 62.04](#x062-04)

[purple 151.05](#x151-05)

#### 形容詞　Q

[qualified 221.03](#x221-03)　·　[qualitative 113.03](#x113-03)　·　[quantitative 65.04](#x065-04)　·　[quick 163.08](#x163-08)　·　[quiet 208.10](#x208-10)

#### 形容詞　R

[racial 125.06](#x125-06)　·　[racist 63.04](#x063-04)　·　[radical 171.02](#x171-02)　·　[random 225.08](#x225-08)　·　[rapid 93.11](#x093-11)　·　[rare 72.06](#x072-06)　·　[rational 185.07](#x185-07)

[raw 226.01](#x226-01)　·　[ready 121.09](#x121-09)　·　[real 61.10](#x061-10)　·　[realistic 173.02](#x173-02)　·　[rear 200.09](#x200-09)　·　[reasonable 108.05](#x108-05)　·　[recent 85.10](#x085-10)

[red 139.03](#x139-03)　·　[regional 212.01](#x212-01)　·　[regular 95.04](#x095-04)　·　[regulatory 74.05](#x074-05)　·　[related 179.03](#x179-03)　·　[relative 237.04](#x237-04)　·　[relaxed 120.09](#x120-09)

[relaxing 68.04](#x068-04)　·　[relevant 186.05](#x186-05)　·　[reliable 203.06](#x203-06)　·　[relieved 133.07](#x133-07)　·　[religious 75.02](#x075-02)　·　[reluctant 182.05](#x182-05)　·　[remarkable 214.06](#x214-06)

[remote 92.01](#x092-01)　·　[renowned 61.01](#x061-01)　·　[repeated 158.05](#x158-05)　·　[representative 232.06](#x232-06)　·　[resident 92.08](#x092-08)　·　[residential 69.02](#x069-02)　·　[resistant 160.06](#x160-06)

[respective 234.06](#x234-06)　·　[responsible 130.08](#x130-08)　·　[restrictive 53.09](#x053-09)　·　[retired 139.02](#x139-02)　·　[reverse 239.04](#x239-04)　·　[revolutionary 126.03](#x126-03)　·　[rich 59.06](#x059-06)

[ridiculous 178.01](#x178-01)　·　[right 199.09](#x199-09)　·　[risky 132.11](#x132-11)　·　[rival 66.06](#x066-06)　·　[robust 184.07](#x184-07)　·　[romantic 208.10](#x208-10)　·　[rough 92.03](#x092-03)

[round 51.07](#x051-07)　·　[routine 175.03](#x175-03)　·　[royal 208.02](#x208-02)　·　[rubber 91.05](#x091-05)　·　[rude 67.06](#x067-06)　·　[rural 161.02](#x161-02)

#### 形容詞　S

[sacred 217.02](#x217-02)　·　[sad 122.05](#x122-05)　·　[safe 53.01](#x053-01)　·　[same 158.03](#x158-03)　·　[satisfied 238.12](#x238-12)　·　[scared 96.11](#x096-11)　·　[scary 76.09](#x076-09)

[scattered 148.04](#x148-04)　·　[sceptical 228.10](#x228-10)　·　[scientific 113.01](#x113-01)　·　[secondary 63.01](#x063-01)　·　[secret 157.02](#x157-02)　·　[secular 217.07](#x217-07)　·　[secure 112.06](#x112-06)

[selective 74.04](#x074-04)　·　[senior 144.01](#x144-01)　·　[sensible 239.06](#x239-06)　·　[sensitive 105.11](#x105-11)　·　[sensory 77.09](#x077-09)　·　[separate 147.09](#x147-09)　·　[serial 229.07](#x229-07)

[serious 106.01](#x106-01)　·　[severe 51.08](#x051-08)　·　[sexual 183.02](#x183-02)　·　[sexy 229.02](#x229-02)　·　[shallow 92.02](#x092-02)　·　[shaped 71.08](#x071-08)　·　[sharp 147.05](#x147-05)

[sheer 244.01](#x244-01)　·　[shiny 90.02](#x090-02)　·　[shocked 89.01](#x089-01)　·　[shocking 195.07](#x195-07)　·　[short 202.01](#x202-01)　·　[short-term 110.12](#x110-12)　·　[shut 60.05](#x060-05)

[shy 172.08](#x172-08)　·　[sick 218.04](#x218-04)　·　[significant 113.04](#x113-04)　·　[silent 55.04](#x055-04)　·　[silly 141.06](#x141-06)　·　[silver 199.06](#x199-06)　·　[similar 95.07](#x095-07)

[simple 62.02](#x062-02)　·　[simultaneous 186.03](#x186-03)　·　[sincere 217.08](#x217-08)　·　[single 93.05](#x093-05)　·　[situated 70.02](#x070-02)　·　[ski 180.01](#x180-01)　·　[skilled 213.06](#x213-06)

[slight 94.08](#x094-08)　·　[slow 84.03](#x084-03)　·　[small 165.09](#x165-09)　·　[smart 225.06](#x225-06)　·　[smooth 100.04](#x100-04)　·　[so-called 89.04](#x089-04)　·　[social 196.04](#x196-04)

[socialist 224.01](#x224-01)　·　[societal 127.09](#x127-09)　·　[soft 51.05](#x051-05)　·　[solar 162.03](#x162-03)　·　[sole 208.13](#x208-13)　·　[solid 92.04](#x092-04)　·　[solo 55.01](#x055-01)

[sophisticated 171.03](#x171-03)　·　[sorry 220.06](#x220-06)　·　[sound 107.09](#x107-09)　·　[south 56.09](#x056-09)　·　[southern 147.02](#x147-02)　·　[spare 205.03](#x205-03)　·　[spatial 128.03](#x128-03)

[special 78.09](#x078-09)　·　[specialist 175.03](#x175-03)　·　[specialized 226.02](#x226-02)　·　[specific 103.10](#x103-10)　·　[spectacular 71.04](#x071-04)　·　[spicy 142.02](#x142-02)　·　[spiritual 227.07](#x227-07)

[spoken 130.10](#x130-10)　·　[sporting 68.09](#x068-09)　·　[square 178.04](#x178-04)　·　[stable 214.07](#x214-07)　·　[standard 135.05](#x135-05)　·　[standing 85.10](#x085-10)　·　[stark 194.06](#x194-06)

[state 219.05](#x219-05)　·　[statistical 109.10](#x109-10)　·　[steady 65.02](#x065-02)　·　[steep 169.06](#x169-06)　·　[sticky 219.02](#x219-02)　·　[stiff 94.05](#x094-05)　·　[still 52.08](#x052-08)

[straight 173.06](#x173-06)　·　[straightforward 202.05](#x202-05)　·　[strange 96.04](#x096-04)　·　[strategic 75.01](#x075-01)　·　[strict 146.02](#x146-02)　·　[striking 203.05](#x203-05)　·　[strong 92.10](#x092-10)

[structural 81.03](#x081-03)　·　[stunning 179.08](#x179-08)　·　[stupid 240.02](#x240-02)　·　[subject 131.05](#x131-05)　·　[subjective 82.10](#x082-10)　·　[subsequent 161.07](#x161-07)　·　[substantial 205.08](#x205-08)

[substantive 130.09](#x130-09)　·　[subtle 52.08](#x052-08)　·　[suburban 168.03](#x168-03)　·　[successful 223.03](#x223-03)　·　[successive 113.02](#x113-02)　·　[sudden 55.10](#x055-10)　·　[sufficient 147.04](#x147-04)

[suitable 221.09](#x221-09)　·　[super 134.10](#x134-10)　·　[superb 84.10](#x084-10)　·　[superior 192.07](#x192-07)　·　[supportive 222.01](#x222-01)　·　[supreme 138.10](#x138-10)　·　[sure 89.08](#x089-08)

[surgical 145.07](#x145-07)　·　[surprised 231.12](#x231-12)　·　[surprising 118.03](#x118-03)　·　[surrounding 70.02](#x070-02)　·　[suspicious 195.07](#x195-07)　·　[sustainable 218.11](#x218-11)　·　[sweet 93.07](#x093-07)

[symbolic 71.06](#x071-06)　·　[sympathetic 155.08](#x155-08)　·　[systematic 228.09](#x228-09)

#### 形容詞　T

[tactical 138.03](#x138-03)　·　[talented 68.08](#x068-08)　·　[tall 170.06](#x170-06)　·　[technical 214.10](#x214-10)　·　[technological 113.08](#x113-08)　·　[teenage 61.08](#x061-08)　·　[temporary 146.07](#x146-07)

[tender 221.08](#x221-08)　·　[terminal 133.05](#x133-05)　·　[terrible 69.02](#x069-02)　·　[terrific 150.07](#x150-07)　·　[theatrical 235.01](#x235-01)　·　[theoretical 113.09](#x113-09)　·　[thick 54.02](#x054-02)

[thin 144.05](#x144-05)　·　[thirsty 227.05](#x227-05)　·　[thorough 114.07](#x114-07)　·　[thought-provoking 76.08](#x076-08)　·　[thoughtful 158.09](#x158-09)　·　[thrilled 225.11](#x225-11)　·　[tidy 118.12](#x118-12)

[tight 51.03](#x051-03)　·　[timely 190.07](#x190-07)　·　[tiny 199.05](#x199-05)　·　[tired 118.12](#x118-12)　·　[top 81.07](#x081-07)　·　[total 191.01](#x191-01)　·　[tough 238.12](#x238-12)

[toxic 116.10](#x116-10)　·　[toy 80.08](#x080-08)　·　[traditional 151.06](#x151-06)　·　[tragic 240.06](#x240-06)　·　[transparent 114.05](#x114-05)　·　[tremendous 84.07](#x084-07)　·　[tribal 164.05](#x164-05)

[tropical 218.04](#x218-04)　·　[troubled 133.01](#x133-01)　·　[TRUE 70.10](#x070-10)　·　[twin 141.02](#x141-02)　·　[typical 234.07](#x234-07)

#### 形容詞　U

[ugly 130.02](#x130-02)　·　[ultimate 85.09](#x085-09)　·　[unable 143.08](#x143-08)　·　[unacceptable 242.03](#x242-03)　·　[unclear 135.11](#x135-11)　·　[uncomfortable 79.06](#x079-06)　·　[unconscious 145.04](#x145-04)

[underground 216.01](#x216-01)　·　[underlying 106.09](#x106-09)　·　[unemployed 71.02](#x071-02)　·　[unexpected 151.09](#x151-09)　·　[unfair 238.08](#x238-08)　·　[unfortunate 134.11](#x134-11)　·　[unhappy 79.07](#x079-07)

[unique 196.09](#x196-09)　·　[united 224.10](#x224-10)　·　[universal 120.04](#x120-04)　·　[unknown 78.02](#x078-02)　·　[unlikely 191.05](#x191-05)　·　[unnecessary 234.09](#x234-09)　·　[unpleasant 130.07](#x130-07)

[unprecedented 89.08](#x089-08)　·　[unrelated 194.09](#x194-09)　·　[unstable 214.02](#x214-02)　·　[unusual 93.05](#x093-05)　·　[upcoming 61.01](#x061-01)　·　[upper 147.03](#x147-03)　·　[upset 238.08](#x238-08)

[upstairs 105.01](#x105-01)　·　[urban 81.02](#x081-02)　·　[urgent 169.02](#x169-02)　·　[used 231.01](#x231-01)　·　[used¹ 109.12](#x109-12)　·　[used² 73.03](#x073-03)　·　[useful 175.08](#x175-08)

[useless 239.06](#x239-06)　·　[usual 92.08](#x092-08)

#### 形容詞　V

[vague 74.06](#x074-06)　·　[valid 181.08](#x181-08)　·　[valuable 230.11](#x230-11)　·　[variable 116.07](#x116-07)　·　[varied 87.05](#x087-05)　·　[various 196.10](#x196-10)　·　[vast 212.09](#x212-09)

[verbal 105.11](#x105-11)　·　[vertical 70.07](#x070-07)　·　[very 166.09](#x166-09)　·　[viable 218.09](#x218-09)　·　[vibrant 125.01](#x125-01)　·　[vicious 63.04](#x063-04)　·　[violent 155.02](#x155-02)

[virtual 214.01](#x214-01)　·　[visible 114.07](#x114-07)　·　[visual 71.04](#x071-04)　·　[vital 196.08](#x196-08)　·　[vocal 205.11](#x205-11)　·　[voluntary 113.04](#x113-04)　·　[vulnerable 75.05](#x075-05)

#### 形容詞　W

[warm 168.05](#x168-05)　·　[waste 232.01](#x232-01)　·　[weak 96.04](#x096-04)　·　[wealthy 63.02](#x063-02)　·　[weekly 140.01](#x140-01)　·　[weird 226.10](#x226-10)　·　[welcome 130.10](#x130-10)

[well 84.02](#x084-02)　·　[west 177.07](#x177-07)　·　[western 212.09](#x212-09)　·　[wet 90.02](#x090-02)　·　[white 52.04](#x052-04)　·　[whole 161.02](#x161-02)　·　[wide 226.05](#x226-05)

[widespread 116.03](#x116-03)　·　[wild 60.01](#x060-01)　·　[willing 184.04](#x184-04)　·　[wise 206.10](#x206-10)　·　[wonderful 125.04](#x125-04)　·　[wooden 50.06](#x050-06)　·　[working 149.09](#x149-09)

[worldwide 233.04](#x233-04)　·　[worried 110.10](#x110-10)　·　[worse 86.03](#x086-03)　·　[worst 180.09](#x180-09)　·　[worth 233.11](#x233-11)　·　[worthwhile 134.12](#x134-12)　·　[worthy 82.08](#x082-08)

[written 146.03](#x146-03)　·　[wrong 204.09](#x204-09)

#### 形容詞　Y

[yellow 92.12](#x092-12)　·　[young 50.10](#x050-10)

### 照合と語数

名詞3,018行・動詞1,275行・形容詞1,119行の全5,412行を、それぞれ本書中の用例に対応させた。語彙は全品詞をまとめた6,100行の許可リストに照合し、名詞の複数形・所有格、動詞の活用形、比較級・最上級を元の見出し語に対応させた。

物語2,099文は英語28,804語。語数は空白で区切る複語を複数語と数え、内部にハイフンまたはアポストロフィのある語形を一語と数えた。

失くし物をめぐる会話、条件や視点のずれ、日常の問いから考え直す進め方は、『赤い点のついた傘』の原篇および参考資料の『アリス』二作品、回答集と学習ノートを踏まえた。本書の出来事・登場人物・数値は練習用の創作。
