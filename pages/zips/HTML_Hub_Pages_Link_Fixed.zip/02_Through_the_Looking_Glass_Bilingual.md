# Through the Looking-Glass

## 鏡の国のアリス — 英日対訳

Lewis Carroll

添付版の全12章・936対訳ブロックを収録。英語の原段落・詩の連の直下に、日本語訳を引用形式で配置しています。HTML版と同じ章・段落IDを使用しています。

英語の語句・綴り・句読点は添付原文のままです。日本語訳は本版のための新訳で、説明が必要な言葉遊び等には別途「訳注」を付けています。詩は意味と改行を優先し、韻や頭文字の仕掛けをすべて再現する訳ではありません。

添付版に挿絵データは含まれていません。本文中の挿絵への言及と、原文にある版注は残しています。

<a id="book-top"></a>

## 章目次

- [第1章　鏡の向こうの家](#lg-chapter-01) — CHAPTER I. Looking-Glass House
- [第2章　生きた花たちの庭](#lg-chapter-02) — CHAPTER II. The Garden of Live Flowers
- [第3章　鏡の国の虫たち](#lg-chapter-03) — CHAPTER III. Looking-Glass Insects
- [第4章　トゥイードルダムとトゥイードルディー](#lg-chapter-04) — CHAPTER IV. Tweedledum And Tweedledee
- [第5章　羊毛と水](#lg-chapter-05) — CHAPTER V. Wool and Water
- [第6章　ハンプティ・ダンプティ](#lg-chapter-06) — CHAPTER VI. Humpty Dumpty
- [第7章　ライオンと一角獣](#lg-chapter-07) — CHAPTER VII. The Lion and the Unicorn
- [第8章　「これは私の発明だ」](#lg-chapter-08) — CHAPTER VIII. “It’s my own Invention”
- [第9章　アリス女王](#lg-chapter-09) — CHAPTER IX. Queen Alice
- [第10章　揺すぶる](#lg-chapter-10) — CHAPTER X. Shaking
- [第11章　目覚める](#lg-chapter-11) — CHAPTER XI. Waking
- [第12章　夢を見たのはどちら？](#lg-chapter-12) — CHAPTER XII. Which Dreamed it?

---

<a id="lg-chapter-01"></a>

## 第1章　鏡の向こうの家

### CHAPTER I. Looking-Glass House

<a id="LG-01-001"></a>

**LG-01-001**

<!-- EN:LG-01-001 -->
One thing was certain, that the *white* kitten had had nothing to do with it:—it was the black kitten’s fault entirely. For the white kitten had been having its face washed by the old cat for the last quarter of an hour (and bearing it pretty well, considering); so you see that it *couldn’t* have had any hand in the mischief.
<!-- /EN:LG-01-001 -->

> ひとつだけ、確かなことがあった。*白い*子猫は、この件には何の関わりもなかったのだ。悪いのは、すべて黒い子猫だった。というのも、白い子猫はこの十五分ばかり、母猫に顔を洗ってもらっていたからだ（事情を考えれば、なかなかよく我慢していた）。だから、いたずらに手を貸すことなど*できるはずがなかった*、というわけ。

<a id="LG-01-002"></a>

**LG-01-002**

<!-- EN:LG-01-002 -->
The way Dinah washed her children’s faces was this: first she held the poor thing down by its ear with one paw, and then with the other paw she rubbed its face all over, the wrong way, beginning at the nose: and just now, as I said, she was hard at work on the white kitten, which was lying quite still and trying to purr—no doubt feeling that it was all meant for its good.
<!-- /EN:LG-01-002 -->

> ダイナが子供たちの顔を洗うやり方は、こうだった。まず片方の前足で、かわいそうな子の耳を押さえつけ、それからもう片方の前足で、鼻を手始めに、毛並みに逆らって顔じゅうをこするのだ。そして今は、さっき言ったとおり、白い子猫をせっせと洗っていた。子猫はじっと横になり、喉を鳴らそうとしていた。きっと、何もかも自分のためにしてくれているのだと思っていたのだろう。

<a id="LG-01-003"></a>

**LG-01-003**

<!-- EN:LG-01-003 -->
But the black kitten had been finished with earlier in the afternoon, and so, while Alice was sitting curled up in a corner of the great arm-chair, half talking to herself and half asleep, the kitten had been having a grand game of romps with the ball of worsted Alice had been trying to wind up, and had been rolling it up and down till it had all come undone again; and there it was, spread over the hearth-rug, all knots and tangles, with the kitten running after its own tail in the middle.
<!-- /EN:LG-01-003 -->

> けれど黒い子猫のほうは、午後の早いうちに洗い終えていた。そこで、アリスが大きな肘掛け椅子の隅で丸くなり、半ば独り言を言い、半ば眠っているあいだ、子猫はアリスが巻こうとしていた毛糸玉を相手に、大はしゃぎで遊んでいた。あちらこちらへ転がして、すっかりほどいてしまったのだ。毛糸は結び目だらけのもつれたまま暖炉前の敷物いっぱいに広がり、その真ん中で、子猫が自分の尻尾を追いかけていた。

<a id="LG-01-004"></a>

**LG-01-004**

<!-- EN:LG-01-004 -->
“Oh, you wicked little thing!” cried Alice, catching up the kitten, and giving it a little kiss to make it understand that it was in disgrace. “Really, Dinah ought to have taught you better manners! You *ought*, Dinah, you know you ought!” she added, looking reproachfully at the old cat, and speaking in as cross a voice as she could manage—and then she scrambled back into the arm-chair, taking the kitten and the worsted with her, and began winding up the ball again. But she didn’t get on very fast, as she was talking all the time, sometimes to the kitten, and sometimes to herself. Kitty sat very demurely on her knee, pretending to watch the progress of the winding, and now and then putting out one paw and gently touching the ball, as if it would be glad to help, if it might.
<!-- /EN:LG-01-004 -->

> 「まあ、この悪い子！」とアリスは叫び、子猫を抱き上げて、叱られているのだとわからせるために、ちょっぴりキスをした。「まったく、ダイナはもっときちんとお行儀を教えておくべきだったわ！　そう*するべき*だったのよ、ダイナ。わかっているでしょう！」母猫をとがめるように見つめ、できるかぎり怒った声でそう付け加えると、アリスは子猫と毛糸を連れて肘掛け椅子によじ登り、また毛糸玉を巻きはじめた。けれど、ときには子猫に、ときには自分に、絶えず話しかけていたので、あまりはかどらなかった。子猫は膝の上でたいそうおすましして座り、毛糸が巻かれていくのを見守るふりをしていた。そして、ときおり片方の前足を伸ばして、そっと毛糸玉に触れた。許してもらえるなら、喜んでお手伝いするのに、とでも言いたげに。

<a id="LG-01-005"></a>

**LG-01-005**

<!-- EN:LG-01-005 -->
“Do you know what to-morrow is, Kitty?” Alice began. “You’d have guessed if you’d been up in the window with me—only Dinah was making you tidy, so you couldn’t. I was watching the boys getting in sticks for the bonfire—and it wants plenty of sticks, Kitty! Only it got so cold, and it snowed so, they had to leave off. Never mind, Kitty, we’ll go and see the bonfire to-morrow.” Here Alice wound two or three turns of the worsted round the kitten’s neck, just to see how it would look: this led to a scramble, in which the ball rolled down upon the floor, and yards and yards of it got unwound again.
<!-- /EN:LG-01-005 -->

> 「子猫ちゃん、明日が何の日か知ってる？」とアリスは話しはじめた。「わたしと一緒に窓辺にいたら、わかったはずよ。けれど、ダイナに身づくろいしてもらっていたから、来られなかったのね。男の子たちが、焚き火に使う木切れを運んでくるのを見ていたの。たくさんの木切れがいるのよ、子猫ちゃん！　でも、あんまり寒くなって、雪もひどく降ってきたから、やめなくちゃならなかったの。大丈夫よ、子猫ちゃん。明日、一緒に焚き火を見に行きましょうね」ここでアリスは、どんなふうに見えるか試すだけのつもりで、子猫の首に毛糸を二、三周巻きつけた。これがもとでひと騒ぎになり、そのあいだに毛糸玉は床へ転がり落ち、何ヤードも何ヤードも、またほどけてしまった。

<a id="LG-01-006"></a>

**LG-01-006**

<!-- EN:LG-01-006 -->
“Do you know, I was so angry, Kitty,” Alice went on as soon as they were comfortably settled again, “when I saw all the mischief you had been doing, I was very nearly opening the window, and putting you out into the snow! And you’d have deserved it, you little mischievous darling! What have you got to say for yourself? Now don’t interrupt me!” she went on, holding up one finger. “I’m going to tell you all your faults. Number one: you squeaked twice while Dinah was washing your face this morning. Now you can’t deny it, Kitty: I heard you! What’s that you say?” (pretending that the kitten was speaking.) “Her paw went into your eye? Well, that’s *your* fault, for keeping your eyes open—if you’d shut them tight up, it wouldn’t have happened. Now don’t make any more excuses, but listen! Number two: you pulled Snowdrop away by the tail just as I had put down the saucer of milk before her! What, you were thirsty, were you? How do you know she wasn’t thirsty too? Now for number three: you unwound every bit of the worsted while I wasn’t looking!
<!-- /EN:LG-01-006 -->

> 「あのね、子猫ちゃん。わたし、すごく腹が立ったのよ」と、ふたりともまた落ち着くと、アリスは続けた。「あなたのしたいたずらを見たとき、もう少しで窓を開けて、あなたを雪の中へ出してしまうところだったわ！　そうされても文句は言えなかったのよ、いたずらっ子のかわいい子！　何か言い訳はある？　さあ、口を挟まないで！」人差し指を一本立てて、アリスは続けた。「あなたの悪いところを、全部言ってあげる。第一、今朝ダイナに顔を洗ってもらっているとき、あなたは二度も鳴いたわね。違うなんて言わせないわよ、子猫ちゃん。わたし、聞いたんだから！　何ですって？」（子猫がしゃべったことにして。）「前足が目に入った？　それは目を開けていた*あなた*が悪いのよ。ぎゅっと閉じていれば、そんなことにはならなかったわ。もう言い訳しないで、お聞きなさい！　第二、スノードロップの前にわたしがミルクのお皿を置いた、そのとたんに、あなたは尻尾を引っ張ってあの子をどかしたわね！　え、喉が渇いていたの？　あの子だって喉が渇いていたかもしれないでしょう？　それでは第三、わたしが見ていないあいだに、毛糸を残らずほどいてしまったこと！

<a id="LG-01-007"></a>

**LG-01-007**

<!-- EN:LG-01-007 -->
“That’s three faults, Kitty, and you’ve not been punished for any of them yet. You know I’m saving up all your punishments for Wednesday week—Suppose they had saved up all *my* punishments!” she went on, talking more to herself than the kitten. “What *would* they do at the end of a year? I should be sent to prison, I suppose, when the day came. Or—let me see—suppose each punishment was to be going without a dinner: then, when the miserable day came, I should have to go without fifty dinners at once! Well, I shouldn’t mind *that* much! I’d far rather go without them than eat them!
<!-- /EN:LG-01-007 -->

> 「これで悪いことが三つよ、子猫ちゃん。でも、まだどれについても罰を受けていないわね。お仕置きは全部、今度の水曜日の一週間後までためておいてあげているんだから。もし*わたし*のお仕置きも全部ためておいたとしたら！」アリスは子猫にというより、自分に向かって話し続けた。「一年たったら、いったいどうするのかしら。その日が来たら、わたし、牢屋に入れられるのでしょうね。それとも、ええと、お仕置きが一回につき夕食抜き一回だとしたら。そうしたら、その悲惨な日には、一度に五十回分の夕食を抜かなくちゃいけないわ！　まあ、*それなら*大して気にならないけれど！　そんなに食べるくらいなら、抜いてもらったほうが、ずっといいもの！

<a id="LG-01-008"></a>

**LG-01-008**

<!-- EN:LG-01-008 -->
“Do you hear the snow against the window-panes, Kitty? How nice and soft it sounds! Just as if some one was kissing the window all over outside. I wonder if the snow *loves* the trees and fields, that it kisses them so gently? And then it covers them up snug, you know, with a white quilt; and perhaps it says, ‘Go to sleep, darlings, till the summer comes again.’ And when they wake up in the summer, Kitty, they dress themselves all in green, and dance about—whenever the wind blows—oh, that’s very pretty!” cried Alice, dropping the ball of worsted to clap her hands. “And I do so *wish* it was true! I’m sure the woods look sleepy in the autumn, when the leaves are getting brown.
<!-- /EN:LG-01-008 -->

> 「子猫ちゃん、窓ガラスに雪の当たる音が聞こえる？　なんて優しくて柔らかい音なのかしら！　まるで誰かが外から窓いっぱいにキスしているみたい。雪は木々や野原が*好き*だから、こんなに優しくキスするのかしら？　それからね、白い掛け布団であたたかく包んであげて、こう言うのかもしれないわ。『おやすみ、かわいい子たち。夏がまた来るまでね』。そして夏に目を覚ますとね、子猫ちゃん、みんな緑の服に着替えて、風が吹くたびに踊るのよ。ああ、なんてすてき！」とアリスは叫び、拍手しようと毛糸玉を落とした。「本当にそうだったら、どんなに*いいかしら*！　秋になって葉っぱが茶色になると、森は確かに眠そうに見えるもの。

<a id="LG-01-009"></a>

**LG-01-009**

<!-- EN:LG-01-009 -->
“Kitty, can you play chess? Now, don’t smile, my dear, I’m asking it seriously. Because, when we were playing just now, you watched just as if you understood it: and when I said ‘Check!’ you purred! Well, it *was* a nice check, Kitty, and really I might have won, if it hadn’t been for that nasty Knight, that came wiggling down among my pieces. Kitty, dear, let’s pretend—” And here I wish I could tell you half the things Alice used to say, beginning with her favourite phrase “Let’s pretend.” She had had quite a long argument with her sister only the day before—all because Alice had begun with “Let’s pretend we’re kings and queens;” and her sister, who liked being very exact, had argued that they couldn’t, because there were only two of them, and Alice had been reduced at last to say, “Well, *you* can be one of them then, and *I’ll* be all the rest.” And once she had really frightened her old nurse by shouting suddenly in her ear, “Nurse! Do let’s pretend that I’m a hungry hyaena, and you’re a bone.”
<!-- /EN:LG-01-009 -->

> 「子猫ちゃん、チェスはできる？　あら、笑わないで、かわいい子。真面目に聞いているのよ。だって、さっきわたしたちがやっていたとき、あなたはまるでわかっているみたいに見ていたでしょう。それに、わたしが『チェック！』って言ったら、喉を鳴らしたわ！　まあ、*いい*チェックだったものね、子猫ちゃん。わたしの駒のあいだへ、あの意地悪なナイトがくねくね入り込んでこなければ、わたし、本当に勝っていたかもしれないのよ。ねえ、子猫ちゃん、ごっこをしましょう——」さて、ここでアリスがお気に入りの「ごっこをしましょう」という言葉で、いつもどんなことを言い出したか、その半分でもお伝えできたらと思う。ほんの前日にも、お姉さんとずいぶん長い言い争いをしたばかりだった。すべては、アリスが「わたしたち、王様や女王様になったことにしましょう」と言い出したせいだった。何でもきちんと正確にしたいお姉さんが、ふたりしかいないのだから、それはできないと言い張ったので、しまいにアリスは「じゃあ、*お姉さん*がそのうちのひとりになって、残りは全部*わたし*がなるわ」と言うよりほかなかった。また一度などは、年老いた乳母の耳元で、突然こう叫んで、本当にびっくりさせたこともあった。「ばあや！　わたしがお腹をすかせたハイエナで、ばあやは骨っていうごっこをしましょうよ」

<a id="LG-01-010"></a>

**LG-01-010**

<!-- EN:LG-01-010 -->
But this is taking us away from Alice’s speech to the kitten. “Let’s pretend that you’re the Red Queen, Kitty! Do you know, I think if you sat up and folded your arms, you’d look exactly like her. Now do try, there’s a dear!” And Alice got the Red Queen off the table, and set it up before the kitten as a model for it to imitate: however, the thing didn’t succeed, principally, Alice said, because the kitten wouldn’t fold its arms properly. So, to punish it, she held it up to the Looking-glass, that it might see how sulky it was—“and if you’re not good directly,” she added, “I’ll put you through into Looking-glass House. How would you like *that*?”
<!-- /EN:LG-01-010 -->

> けれど、これではアリスが子猫にしていた話からそれてしまう。「子猫ちゃん、あなたが赤の女王になったことにしましょう！　ねえ、背筋を伸ばして座って、腕を組んだら、そっくりになると思うわ。さあ、やってみて。いい子だから！」アリスはテーブルから赤の女王の駒を取り、子猫がまねをするお手本にと、その前に立たせた。けれど、うまくはいかなかった。主な理由は、子猫がきちんと腕を組もうとしないからだ、とアリスは言った。そこでお仕置きとして、子猫を鏡の前に掲げ、自分がどれほどむくれた顔をしているか見せてやった。「それに、すぐにいい子にしなかったら」とアリスは付け加えた。「鏡を通して、鏡のおうちへ入れてしまうわよ。*そう*されたら、どう？」

<a id="LG-01-011"></a>

**LG-01-011**

<!-- EN:LG-01-011 -->
“Now, if you’ll only attend, Kitty, and not talk so much, I’ll tell you all my ideas about Looking-glass House. First, there’s the room you can see through the glass—that’s just the same as our drawing room, only the things go the other way. I can see all of it when I get upon a chair—all but the bit behind the fireplace. Oh! I do so wish I could see *that* bit! I want so much to know whether they’ve a fire in the winter: you never *can* tell, you know, unless our fire smokes, and then smoke comes up in that room too—but that may be only pretence, just to make it look as if they had a fire. Well then, the books are something like our books, only the words go the wrong way; I know that, because I’ve held up one of our books to the glass, and then they hold up one in the other room.
<!-- /EN:LG-01-011 -->

> 「さあ、子猫ちゃん。そんなにおしゃべりばかりしないで聞いてくれたら、鏡のおうちについて考えたことを全部教えてあげる。まず、鏡の向こうに見えるお部屋があるでしょう。あれは、わたしたちの居間とまったく同じで、ただ物の向きが逆になっているの。椅子に乗ると、隅々まで見えるわ。暖炉の後ろのところ以外はね。ああ、*あそこ*を見られたら、どんなにいいかしら！　冬には火をたくのか、とても知りたいの。こちらの暖炉が煙を出さないかぎり、どうしてもわからないのよ。煙が出ると、向こうのお部屋でも煙が上がるけれど、それだって、火をたいているように見せかけているだけかもしれないもの。そう、それから、本はわたしたちの本に少し似ているの。ただ、字が逆向きになっているけれど。これは確かなのよ。こちらの本を鏡の前に掲げたら、向こうのお部屋でも本を掲げていたんだから。

<a id="LG-01-012"></a>

**LG-01-012**

<!-- EN:LG-01-012 -->
“How would you like to live in Looking-glass House, Kitty? I wonder if they’d give you milk in there? Perhaps Looking-glass milk isn’t good to drink—But oh, Kitty! now we come to the passage. You can just see a little *peep* of the passage in Looking-glass House, if you leave the door of our drawing-room wide open: and it’s very like our passage as far as you can see, only you know it may be quite different on beyond. Oh, Kitty! how nice it would be if we could only get through into Looking-glass House! I’m sure it’s got, oh! such beautiful things in it! Let’s pretend there’s a way of getting through into it, somehow, Kitty. Let’s pretend the glass has got all soft like gauze, so that we can get through. Why, it’s turning into a sort of mist now, I declare! It’ll be easy enough to get through—” She was up on the chimney-piece while she said this, though she hardly knew how she had got there. And certainly the glass *was* beginning to melt away, just like a bright silvery mist.
<!-- /EN:LG-01-012 -->

> 「子猫ちゃん、鏡のおうちに住むっていうのは、どう？　あちらでもミルクをくれるかしら。鏡のミルクは、飲むのによくないかもしれないわね。でもね、子猫ちゃん、今度は廊下のお話よ。居間の戸を大きく開けておくと、鏡のおうちの廊下がほんの*ちょっぴり*のぞけるでしょう。見えるところまでは、こちらの廊下にとてもよく似ているわ。でも、その先はまるで違うかもしれないのよ。ああ、子猫ちゃん！　鏡を通って、鏡のおうちに入れたら、どんなにすてきかしら！　きっと、とびきりすばらしい物があるのよ！　何とかして、通り抜ける方法があることにしましょう、子猫ちゃん。ガラスがガーゼみたいにすっかり柔らかくなって、通り抜けられることにしましょう。あら、本当に、何だか霧みたいになってきたわ！　これなら簡単に通れるわね——」こう言っているあいだに、アリスは暖炉の上の棚に上がっていた。どうやってそこまで来たのかは、自分でもほとんどわからなかった。そして確かに、鏡のガラスは明るい銀色の霧のように、溶けはじめていた。

<a id="LG-01-013"></a>

**LG-01-013**

<!-- EN:LG-01-013 -->
In another moment Alice was through the glass, and had jumped lightly down into the Looking-glass room. The very first thing she did was to look whether there was a fire in the fireplace, and she was quite pleased to find that there was a real one, blazing away as brightly as the one she had left behind. “So I shall be as warm here as I was in the old room,” thought Alice: “warmer, in fact, because there’ll be no one here to scold me away from the fire. Oh, what fun it’ll be, when they see me through the glass in here, and can’t get at me!”
<!-- /EN:LG-01-013 -->

> 次の瞬間には、アリスは鏡を通り抜け、鏡の中の部屋へと軽やかに飛び降りていた。真っ先にしたのは、暖炉に火があるか確かめることだった。そして、もとの部屋に残してきた火と同じくらい明るく燃える、本物の火があるのを見つけて、とても満足した。「それなら、ここでも前のお部屋と同じくらい暖かくしていられるわ」とアリスは思った。「いいえ、むしろ、もっと暖かいわね。ここには、火から離れなさいって叱る人がいないんだから。ああ、みんなが鏡越しにここにいるわたしを見つけても、手を出せなかったら、どんなに面白いでしょう！」

<a id="LG-01-014"></a>

**LG-01-014**

<!-- EN:LG-01-014 -->
Then she began looking about, and noticed that what could be seen from the old room was quite common and uninteresting, but that all the rest was as different as possible. For instance, the pictures on the wall next the fire seemed to be all alive, and the very clock on the chimney-piece (you know you can only see the back of it in the Looking-glass) had got the face of a little old man, and grinned at her.
<!-- /EN:LG-01-014 -->

> それからあたりを見回しはじめ、もとの部屋から見えていた部分はごく普通でつまらないけれど、それ以外のところは、何から何まで違うのに気づいた。たとえば、暖炉のそばの壁に掛かった絵は、どれも生きているようだったし、暖炉の棚の時計まで（鏡では、その後ろ側しか見えないでしょう）、小さなおじいさんの顔をして、アリスににやりと笑いかけた。

<a id="LG-01-015"></a>

**LG-01-015**

<!-- EN:LG-01-015 -->
“They don’t keep this room so tidy as the other,” Alice thought to herself, as she noticed several of the chessmen down in the hearth among the cinders: but in another moment, with a little “Oh!” of surprise, she was down on her hands and knees watching them. The chessmen were walking about, two and two!
<!-- /EN:LG-01-015 -->

> 「ここのお部屋は、向こうほどきちんと片づけていないのね」とアリスは思った。チェスの駒がいくつも、暖炉の中の燃えがらに交じって落ちているのに気づいたからだ。けれど次の瞬間には、驚いて「あら！」と小さく声を上げ、四つんばいになって見つめていた。チェスの駒が、ふたつずつ連れ立って歩き回っていたのだ！

<a id="LG-01-016"></a>

**LG-01-016**

<!-- EN:LG-01-016 -->
“Here are the Red King and the Red Queen,” Alice said (in a whisper, for fear of frightening them), “and there are the White King and the White Queen sitting on the edge of the shovel—and here are two castles walking arm in arm—I don’t think they can hear me,” she went on, as she put her head closer down, “and I’m nearly sure they can’t see me. I feel somehow as if I were invisible—”
<!-- /EN:LG-01-016 -->

> 「ここにいるのは赤の王と赤の女王ね」とアリスは言った（びっくりさせないよう、小声で）。「あっちのシャベルの端に座っているのは、白の王と白の女王。それから、ここではふたつのお城が腕を組んで歩いているわ。わたしの声は聞こえないみたいね」と、顔をもっと近づけながら続けた。「それに、わたしの姿も、まず間違いなく見えていないわ。何だか自分が透明になったような気がする——」

> **訳注：** castles は城の形をしたチェスのルーク。ここでは駒を人物のように描いている。

<a id="LG-01-017"></a>

**LG-01-017**

<!-- EN:LG-01-017 -->
Here something began squeaking on the table behind Alice, and made her turn her head just in time to see one of the White Pawns roll over and begin kicking: she watched it with great curiosity to see what would happen next.
<!-- /EN:LG-01-017 -->

> そのとき、アリスの背後のテーブルで何かがきいきい鳴きはじめた。振り返ると、ちょうど白のポーンのひとつが転がって、足をばたつかせはじめたところだった。アリスは、このあとどうなるのかと、興味津々で見守った。

<a id="LG-01-018"></a>

**LG-01-018**

<!-- EN:LG-01-018 -->
“It is the voice of my child!” the White Queen cried out as she rushed past the King, so violently that she knocked him over among the cinders. “My precious Lily! My imperial kitten!” and she began scrambling wildly up the side of the fender.
<!-- /EN:LG-01-018 -->

> 「あれは、わたくしの子の声だわ！」と白の女王が叫び、王のそばを駆け抜けた。その勢いがあまりに激しかったので、王を燃えがらの中に突き倒してしまった。「かわいいリリー！　わたくしの、王家の子猫ちゃん！」そして女王は、暖炉の火よけ柵の側面を、むやみやたらによじ登りはじめた。

<a id="LG-01-019"></a>

**LG-01-019**

<!-- EN:LG-01-019 -->
“Imperial fiddlestick!” said the King, rubbing his nose, which had been hurt by the fall. He had a right to be a *little* annoyed with the Queen, for he was covered with ashes from head to foot.
<!-- /EN:LG-01-019 -->

> 「王家もへちまもあるものか！」と王は言い、転んで痛めた鼻をさすった。頭から足まで灰まみれになっていたのだから、王が女王に*少しくらい*腹を立てても、無理はなかった。

<a id="LG-01-020"></a>

**LG-01-020**

<!-- EN:LG-01-020 -->
Alice was very anxious to be of use, and, as the poor little Lily was nearly screaming herself into a fit, she hastily picked up the Queen and set her on the table by the side of her noisy little daughter.
<!-- /EN:LG-01-020 -->

> アリスは何とか役に立ちたくてたまらなかった。かわいそうな幼いリリーが、叫びすぎてひきつけでも起こしかねない様子だったので、急いで女王をつまみ上げ、テーブルの上の、やかましい小さな娘の隣へ置いてやった。

<a id="LG-01-021"></a>

**LG-01-021**

<!-- EN:LG-01-021 -->
The Queen gasped, and sat down: the rapid journey through the air had quite taken away her breath and for a minute or two she could do nothing but hug the little Lily in silence. As soon as she had recovered her breath a little, she called out to the White King, who was sitting sulkily among the ashes, “Mind the volcano!”
<!-- /EN:LG-01-021 -->

> 女王ははっと息をのみ、座り込んだ。空中を急に運ばれたので、すっかり息が詰まってしまい、一、二分のあいだは、黙って幼いリリーを抱き締めるほかなかった。少し息が戻ると、灰の中で不機嫌そうに座っている白の王へ向かって、こう呼びかけた。「火山にお気をつけて！」

<a id="LG-01-022"></a>

**LG-01-022**

<!-- EN:LG-01-022 -->
“What volcano?” said the King, looking up anxiously into the fire, as if he thought that was the most likely place to find one.
<!-- /EN:LG-01-022 -->

> 「何の火山だ？」と王は言い、心配そうに暖炉の火を見上げた。火山があるとすれば、そこがいちばんありそうだと考えたらしかった。

<a id="LG-01-023"></a>

**LG-01-023**

<!-- EN:LG-01-023 -->
“Blew—me—up,” panted the Queen, who was still a little out of breath. “Mind you come up—the regular way—don’t get blown up!”
<!-- /EN:LG-01-023 -->

> 「吹き——上げられたの」と、まだ少し息を切らしている女王は、あえぎながら言った。「上がるなら——ちゃんとした道で——吹き飛ばされないようにね！」

<a id="LG-01-024"></a>

**LG-01-024**

<!-- EN:LG-01-024 -->
Alice watched the White King as he slowly struggled up from bar to bar, till at last she said, “Why, you’ll be hours and hours getting to the table, at that rate. I’d far better help you, hadn’t I?” But the King took no notice of the question: it was quite clear that he could neither hear her nor see her.
<!-- /EN:LG-01-024 -->

> アリスは白の王が柵の一本一本を、ゆっくり苦労しながらよじ登るのを見ていたが、ついにこう言った。「まあ、その調子じゃ、テーブルまで何時間も何時間もかかってしまうわ。わたしがお手伝いしたほうが、ずっといいでしょう？」けれど、王はその問いかけにまるで気づかなかった。アリスの声も聞こえず、姿も見えていないことは、もう明らかだった。

<a id="LG-01-025"></a>

**LG-01-025**

<!-- EN:LG-01-025 -->
So Alice picked him up very gently, and lifted him across more slowly than she had lifted the Queen, that she mightn’t take his breath away: but, before she put him on the table, she thought she might as well dust him a little, he was so covered with ashes.
<!-- /EN:LG-01-025 -->

> そこでアリスは、王をとてもそっとつまみ上げ、息が詰まらないよう、女王のときよりもゆっくり運んでやった。けれど、テーブルに置く前に、あまりに灰まみれだったので、少しはたいてあげるのがよさそうだと思った。

<a id="LG-01-026"></a>

**LG-01-026**

<!-- EN:LG-01-026 -->
She said afterwards that she had never seen in all her life such a face as the King made, when he found himself held in the air by an invisible hand, and being dusted: he was far too much astonished to cry out, but his eyes and his mouth went on getting larger and larger, and rounder and rounder, till her hand shook so with laughing that she nearly let him drop upon the floor.
<!-- /EN:LG-01-026 -->

> 王が、見えない手で空中に持ち上げられ、ほこりをはたかれていると気づいたときの顔といったら、あんな顔は生まれてから一度も見たことがない、とアリスはあとで言った。王はあまりにびっくりして、声も出せなかった。けれど、目も口も、どんどん大きく、どんどん丸くなっていくので、アリスは笑いすぎて手が震え、危うく床に落としてしまうところだった。

<a id="LG-01-027"></a>

**LG-01-027**

<!-- EN:LG-01-027 -->
“Oh! *please* don’t make such faces, my dear!” she cried out, quite forgetting that the King couldn’t hear her. “You make me laugh so that I can hardly hold you! And don’t keep your mouth so wide open! All the ashes will get into it—there, now I think you’re tidy enough!” she added, as she smoothed his hair, and set him upon the table near the Queen.
<!-- /EN:LG-01-027 -->

> 「ああ、*お願い*だから、そんな顔をしないで！」とアリスは叫んだ。王には声が聞こえないことなど、すっかり忘れていた。「笑いすぎて、持っていられないじゃない！　それに、お口をそんなに大きく開けないで！　灰がみんな入ってしまうわ。さあ、これでもう、十分きれいになったわね！」そう付け加え、王の髪をなでつけて、テーブルの上の女王のそばへ置いた。

<a id="LG-01-028"></a>

**LG-01-028**

<!-- EN:LG-01-028 -->
The King immediately fell flat on his back, and lay perfectly still: and Alice was a little alarmed at what she had done, and went round the room to see if she could find any water to throw over him. However, she could find nothing but a bottle of ink, and when she got back with it she found he had recovered, and he and the Queen were talking together in a frightened whisper—so low, that Alice could hardly hear what they said.
<!-- /EN:LG-01-028 -->

> 王はすぐさま、ばったり仰向けに倒れ、ぴくりとも動かなくなった。アリスは自分のしたことが少し心配になり、王に掛ける水がどこかにないかと、部屋の中を探し回った。けれど、見つかったのはインクの瓶だけだった。それを持って戻ると、王はもう気を取り戻し、女王とふたり、怯えたような小声で話し合っていた。あまり小さい声なので、アリスには何を言っているのか、やっと聞き取れるくらいだった。

<a id="LG-01-029"></a>

**LG-01-029**

<!-- EN:LG-01-029 -->
The King was saying, “I assure you, my dear, I turned cold to the very ends of my whiskers!”
<!-- /EN:LG-01-029 -->

> 王はこう言っていた。「いや、そなた、本当なのだぞ。ひげの先の先まで冷たくなったわい！」

<a id="LG-01-030"></a>

**LG-01-030**

<!-- EN:LG-01-030 -->
To which the Queen replied, “You haven’t got any whiskers.”
<!-- /EN:LG-01-030 -->

> それに女王は、「あなたに、おひげなんかありませんわ」と答えた。

<a id="LG-01-031"></a>

**LG-01-031**

<!-- EN:LG-01-031 -->
“The horror of that moment,” the King went on, “I shall never, *never* forget!”
<!-- /EN:LG-01-031 -->

> 「あの瞬間の恐ろしさは」と王は続けた。「決して、*決して*忘れはせぬ！」

<a id="LG-01-032"></a>

**LG-01-032**

<!-- EN:LG-01-032 -->
“You will, though,” the Queen said, “if you don’t make a memorandum of it.”
<!-- /EN:LG-01-032 -->

> 「でも、忘れますわよ」と女王は言った。「覚え書きにしておかなければね」

<a id="LG-01-033"></a>

**LG-01-033**

<!-- EN:LG-01-033 -->
Alice looked on with great interest as the King took an enormous memorandum-book out of his pocket, and began writing. A sudden thought struck her, and she took hold of the end of the pencil, which came some way over his shoulder, and began writing for him.
<!-- /EN:LG-01-033 -->

> 王がポケットから途方もなく大きな手帳を取り出し、何か書きはじめると、アリスはたいそう面白がって見つめた。ふとあることを思いつき、王の肩からかなり突き出している鉛筆の先端をつかんで、代わりに書いてあげることにした。

<a id="LG-01-034"></a>

**LG-01-034**

<!-- EN:LG-01-034 -->
The poor King looked puzzled and unhappy, and struggled with the pencil for some time without saying anything; but Alice was too strong for him, and at last he panted out, “My dear! I really *must* get a thinner pencil. I can’t manage this one a bit; it writes all manner of things that I don’t intend—”
<!-- /EN:LG-01-034 -->

> かわいそうに、王は困り果てた、悲しげな顔になり、しばらくは黙って鉛筆と格闘した。けれど、アリスの力にはかなわなかったので、ついに息を切らしてこう言った。「そなた！　わしは本当に、もっと細い鉛筆を手に入れ*ねばならん*。これは少しも思うように動かせぬ。書く気もないことを、あれこれ勝手に書きよる——」

<a id="LG-01-035"></a>

**LG-01-035**

<!-- EN:LG-01-035 -->
“What manner of things?” said the Queen, looking over the book (in which Alice had put “*The White Knight is sliding down the poker. He balances very badly*”) “That’s not a memorandum of *your* feelings!”
<!-- /EN:LG-01-035 -->

> 「どんなことですの？」と女王は手帳をのぞいて言った（アリスが書いたのは、「*白の騎士が火かき棒を滑り降りている。ひどく釣り合いの取り方が悪い*」だった）。「これは、*あなた*のお気持ちの覚え書きではありませんね！」

<a id="LG-01-036"></a>

**LG-01-036**

<!-- EN:LG-01-036 -->
There was a book lying near Alice on the table, and while she sat watching the White King (for she was still a little anxious about him, and had the ink all ready to throw over him, in case he fainted again), she turned over the leaves, to find some part that she could read, “—for it’s all in some language I don’t know,” she said to herself.
<!-- /EN:LG-01-036 -->

> アリスの近くのテーブルに、一冊の本が置いてあった。白の王を座って見守りながら（まだ少し心配で、また気を失ったら掛けてあげようと、インクをすぐ使えるようにしていた）、アリスは、自分に読めるところを探して、そのページをめくった。「だって、全部知らない言葉で書いてあるんだもの」と独り言を言った。

<a id="LG-01-037"></a>

**LG-01-037**

<!-- EN:LG-01-037 -->
It was like this.
<!-- /EN:LG-01-037 -->

> こんなふうだった。

<a id="LG-01-038"></a>

**LG-01-038**

<!-- EN:LG-01-038 -->
.YKCOWREBBAJ  
<!-- /EN:LG-01-038 -->

> ジャバウォックの詩。

> **訳注：** 英語の見出しは、JABBERWOCKY. を逆順に並べた鏡文字。日本語訳は読みやすい向きで示す。

<a id="LG-01-039"></a>

**LG-01-039**

<!-- EN:LG-01-039 -->
sevot yhtils eht dna, gillirb sawT’  
ebaw eht ni elbmig dna eryg diD  
     ,sevogorob eht erew ysmim llA  
.ebargtuo shtar emom eht dnA
<!-- /EN:LG-01-039 -->

> ブリリグのころ、ぬるしなやかなトーヴたちが  
> 　　ウェイブでぐる回り、穴ぐりぐり。  
> ボロゴーヴは、みなみじめひ弱、  
> 　　迷子のラースがくしゃぼえた。

> **訳注：** 原文は、のちに鏡に映して読む第1連を、各行とも逆向きに記したもの。日本語訳は通常の向きで示す。

<a id="LG-01-040"></a>

**LG-01-040**

<!-- EN:LG-01-040 -->
She puzzled over this for some time, but at last a bright thought struck her. “Why, it’s a Looking-glass book, of course! And if I hold it up to a glass, the words will all go the right way again.”
<!-- /EN:LG-01-040 -->

> しばらく首をひねっていたが、やがて、すばらしい考えがひらめいた。「そうだ、もちろん、鏡の本なんだわ！　鏡に映してみれば、字は全部、正しい向きに戻るはずよ」

<a id="LG-01-041"></a>

**LG-01-041**

<!-- EN:LG-01-041 -->
This was the poem that Alice read.
<!-- /EN:LG-01-041 -->

> アリスが読んだのは、この詩だった。

<a id="LG-01-042"></a>

**LG-01-042**

<!-- EN:LG-01-042 -->
JABBERWOCKY.  
<!-- /EN:LG-01-042 -->

> ジャバウォックの詩。

<a id="LG-01-043"></a>

**LG-01-043**

<!-- EN:LG-01-043 -->
’Twas brillig, and the slithy toves  
    Did gyre and gimble in the wabe;  
All mimsy were the borogoves,  
    And the mome raths outgrabe.  
<!-- /EN:LG-01-043 -->

> ブリリグのころ、ぬるしなやかなトーヴたちが  
> 　　ウェイブでぐる回り、穴ぐりぐり。  
> ボロゴーヴは、みなみじめひ弱、  
> 　　迷子のラースがくしゃぼえた。

> **訳注：** 造語には、日本語でも音や語の混ざり合いを用いた。主な語は第VI章でハンプティ・ダンプティが説明する。

<a id="LG-01-044"></a>

**LG-01-044**

<!-- EN:LG-01-044 -->
“Beware the Jabberwock, my son!  
    The jaws that bite, the claws that catch!  
Beware the Jubjub bird, and shun  
    The frumious Bandersnatch!”  
<!-- /EN:LG-01-044 -->

> 「ジャバウォックに気をつけろ、わが息子！  
> 　　かみつくあご、つかまえる爪！  
> ジャブジャブ鳥にも気をつけて、避けるのだ、  
> 　　ふりふり猛るバンダースナッチを！」

> **訳注：** frumious は furious と fuming を思わせる造語。「ふりふり猛る」も、意味を固定しすぎず響きの奇妙さを残した訳。

<a id="LG-01-045"></a>

**LG-01-045**

<!-- EN:LG-01-045 -->
He took his vorpal sword in hand:  
    Long time the manxome foe he sought—  
So rested he by the Tumtum tree,  
    And stood awhile in thought.  
<!-- /EN:LG-01-045 -->

> 若者はヴォーパルの剣を手に取った。  
> 　　長いこと、マンキシャスな敵を捜した——  
> そこでタムタムの木のそばで休み、  
> 　　しばし立ったまま思いにふけった。

> **訳注：** vorpal、manxome は意味を一意に定めにくい造語。剣と敵を修飾する奇妙な語感を残すため、音を生かした。

<a id="LG-01-046"></a>

**LG-01-046**

<!-- EN:LG-01-046 -->
And as in uffish thought he stood,  
    The Jabberwock, with eyes of flame,  
Came whiffling through the tulgey wood,  
    And burbled as it came!  
<!-- /EN:LG-01-046 -->

> うっふと考え込み、そこに立っていると、  
> 　　炎の目をしたジャバウォックが、  
> 鬱蒼たるタルギーの森を、ひゅるひゅる抜けて、  
> 　　ぶくぶく吠えながらやって来た！

<a id="LG-01-047"></a>

**LG-01-047**

<!-- EN:LG-01-047 -->
One, two! One, two! And through and through  
    The vorpal blade went snicker-snack!  
He left it dead, and with its head  
    He went galumphing back.  
<!-- /EN:LG-01-047 -->

> 一、二！　一、二！　ずぶり、ざくりと  
> 　　ヴォーパルの刃が、スニッカー・スナック！  
> 死骸を残し、その首を持って、  
> 　　若者は、がるんと勇んで帰っていった。

<a id="LG-01-048"></a>

**LG-01-048**

<!-- EN:LG-01-048 -->
“And hast thou slain the Jabberwock?  
    Come to my arms, my beamish boy!  
O frabjous day! Callooh! Callay!”  
    He chortled in his joy.  
<!-- /EN:LG-01-048 -->

> 「おお、ジャバウォックを倒したか？  
> 　　この腕に来い、わが晴れやかな息子よ！  
> なんとすばらしきフラブジャスの日！　カロー！　カレイ！」  
> 　　喜びに、くすっと高らかに笑った。

<a id="LG-01-049"></a>

**LG-01-049**

<!-- EN:LG-01-049 -->
’Twas brillig, and the slithy toves  
    Did gyre and gimble in the wabe;  
All mimsy were the borogoves,  
    And the mome raths outgrabe.
<!-- /EN:LG-01-049 -->

> ブリリグのころ、ぬるしなやかなトーヴたちが  
> 　　ウェイブでぐる回り、穴ぐりぐり。  
> ボロゴーヴは、みなみじめひ弱、  
> 　　迷子のラースがくしゃぼえた。

<a id="LG-01-050"></a>

**LG-01-050**

<!-- EN:LG-01-050 -->
“It seems very pretty,” she said when she had finished it, “but it’s *rather* hard to understand!” (You see she didn’t like to confess, even to herself, that she couldn’t make it out at all.) “Somehow it seems to fill my head with ideas—only I don’t exactly know what they are! However, *somebody* killed *something*: that’s clear, at any rate—”
<!-- /EN:LG-01-050 -->

> 「とてもきれいみたい」と、読み終えてアリスは言った。「でも、意味が*ちょっと*わかりにくいわね！」（まったくわからなかった、とは、自分にさえ認めたくなかったのだ。）「何だか、頭がいろいろな考えでいっぱいになるみたい。でも、それがどんな考えなのか、はっきりとはわからないの！　けれど、*誰か*が*何か*を殺したのね。それだけは、どのみち確かだわ——」

<a id="LG-01-051"></a>

**LG-01-051**

<!-- EN:LG-01-051 -->
“But oh!” thought Alice, suddenly jumping up, “if I don’t make haste I shall have to go back through the Looking-glass, before I’ve seen what the rest of the house is like! Let’s have a look at the garden first!” She was out of the room in a moment, and ran down stairs—or, at least, it wasn’t exactly running, but a new invention of hers for getting down stairs quickly and easily, as Alice said to herself. She just kept the tips of her fingers on the hand-rail, and floated gently down without even touching the stairs with her feet; then she floated on through the hall, and would have gone straight out at the door in the same way, if she hadn’t caught hold of the door-post. She was getting a little giddy with so much floating in the air, and was rather glad to find herself walking again in the natural way.
<!-- /EN:LG-01-051 -->

> 「でも、大変！」とアリスは思い、急に立ち上がった。「急がないと、おうちのほかのところがどんなふうか見ないうちに、鏡を通って帰らなくちゃならなくなるわ！　まずお庭を見てみましょう！」たちまち部屋を飛び出して、階段を駆け下りた。というより、正確には駆け下りたのではなく、自分でそう言ったとおり、素早く楽に階段を下りるために、新しい方法を発明したのだった。ただ指先を手すりに添えているだけで、足を段に触れさせもしないまま、ふわりと下へ漂っていったのだ。それから玄関の広間も、そのままふわふわ通り抜け、戸口の柱をつかまなかったら、同じやり方でまっすぐ外まで出てしまうところだった。あまり空中を漂ったので少し目が回りかけていたから、また普通に歩けるようになって、かなりほっとした。

[章目次へ戻る](#book-top)

---

<a id="lg-chapter-02"></a>

## 第2章　生きた花たちの庭

### CHAPTER II. The Garden of Live Flowers

<a id="LG-02-001"></a>

**LG-02-001**

<!-- EN:LG-02-001 -->
“I should see the garden far better,” said Alice to herself, “if I could get to the top of that hill: and here’s a path that leads straight to it—at least, no, it doesn’t do that—” (after going a few yards along the path, and turning several sharp corners), “but I suppose it will at last. But how curiously it twists! It’s more like a corkscrew than a path! Well, *this* turn goes to the hill, I suppose—no, it doesn’t! This goes straight back to the house! Well then, I’ll try it the other way.”
<!-- /EN:LG-02-001 -->

> 「あの丘の上まで行けたら、お庭がずっとよく見えるのに」とアリスは独り言を言った。「ここに、まっすぐそこまで続く小道があるわ。少なくとも、いいえ、続いていないわね——」（数ヤード歩いて、何度も鋭い角を曲がってから）「でも、最後には着くのでしょう。けれど、何て変な曲がり方をするのかしら！　道というより、コルク抜きみたい！　ええと、*ここ*を曲がれば丘に行くのね、きっと——違うわ！　これじゃ、おうちへまっすぐ戻ってしまう！　それなら、反対向きに行ってみようっと」

<a id="LG-02-002"></a>

**LG-02-002**

<!-- EN:LG-02-002 -->
And so she did: wandering up and down, and trying turn after turn, but always coming back to the house, do what she would. Indeed, once, when she turned a corner rather more quickly than usual, she ran against it before she could stop herself.
<!-- /EN:LG-02-002 -->

> そこで、そのとおりにしてみた。あちこち歩き回り、角という角を曲がってみたけれど、どうやっても、いつもおうちへ戻ってしまうのだった。それどころか一度など、いつもより少し勢いよく角を曲がると、立ち止まる間もなく、おうちにぶつかってしまった。

<a id="LG-02-003"></a>

**LG-02-003**

<!-- EN:LG-02-003 -->
“It’s no use talking about it,” Alice said, looking up at the house and pretending it was arguing with her. “I’m *not* going in again yet. I know I should have to get through the Looking-glass again—back into the old room—and there’d be an end of all my adventures!”
<!-- /EN:LG-02-003 -->

> 「そんなことを言っても、だめよ」とアリスは家を見上げ、家が言い返しているつもりになって言った。「まだ中には戻ら*ない*わ。入れば、また鏡を通って、もとのお部屋へ戻らなければならなくなるに決まっているもの。そうしたら、冒険はみんなおしまいだわ！」

<a id="LG-02-004"></a>

**LG-02-004**

<!-- EN:LG-02-004 -->
So, resolutely turning her back upon the house, she set out once more down the path, determined to keep straight on till she got to the hill. For a few minutes all went on well, and she was just saying, “I really *shall* do it this time—” when the path gave a sudden twist and shook itself (as she described it afterwards), and the next moment she found herself actually walking in at the door.
<!-- /EN:LG-02-004 -->

> そこで、きっぱりと家に背を向け、丘に着くまでまっすぐ進み続けようと心に決めて、もう一度小道を歩き出した。数分のあいだはすべて順調で、「今度こそ、本当に*行ける*わ——」と言いかけたそのとき、小道が突然ぐにゃりと曲がって身震いをした（あとでアリスが説明したところによれば）。そして次の瞬間には、何と自分が戸口から家に入っていくところだった。

<a id="LG-02-005"></a>

**LG-02-005**

<!-- EN:LG-02-005 -->
“Oh, it’s too bad!” she cried. “I never saw such a house for getting in the way! Never!”
<!-- /EN:LG-02-005 -->

> 「ああ、あんまりだわ！」とアリスは叫んだ。「こんなに邪魔ばかりするおうちなんて、見たことがない！　一度も！」

<a id="LG-02-006"></a>

**LG-02-006**

<!-- EN:LG-02-006 -->
However, there was the hill full in sight, so there was nothing to be done but start again. This time she came upon a large flower-bed, with a border of daisies, and a willow-tree growing in the middle.
<!-- /EN:LG-02-006 -->

> けれど、丘は目の前にはっきり見えていたので、また出直すよりほかなかった。今度は、大きな花壇に出た。縁にはヒナギクが並び、真ん中に柳の木が一本生えていた。

<a id="LG-02-007"></a>

**LG-02-007**

<!-- EN:LG-02-007 -->
“O Tiger-lily,” said Alice, addressing herself to one that was waving gracefully about in the wind, “I *wish* you could talk!”
<!-- /EN:LG-02-007 -->

> 「ああ、オニユリさん」とアリスは、風に吹かれて優雅に揺れている花のひとつに話しかけた。「あなたとお話ができたら*いいのに*！」

<a id="LG-02-008"></a>

**LG-02-008**

<!-- EN:LG-02-008 -->
“We *can* talk,” said the Tiger-lily: “when there’s anybody worth talking to.”
<!-- /EN:LG-02-008 -->

> 「わたしたちは話せ*ます*よ」とオニユリは言った。「話すだけの値打ちがある相手さえいればね」

<a id="LG-02-009"></a>

**LG-02-009**

<!-- EN:LG-02-009 -->
Alice was so astonished that she could not speak for a minute: it quite seemed to take her breath away. At length, as the Tiger-lily only went on waving about, she spoke again, in a timid voice—almost in a whisper. “And can *all* the flowers talk?”
<!-- /EN:LG-02-009 -->

> アリスはあまりに驚いて、しばらく口も利けなかった。まるで息が止まったようだった。やがて、オニユリはただ揺れ続けているばかりなので、また、おずおずとした声で話しかけた。ほとんどささやき声だった。「じゃあ、お花は*みんな*お話ができるの？」

<a id="LG-02-010"></a>

**LG-02-010**

<!-- EN:LG-02-010 -->
“As well as *you* can,” said the Tiger-lily. “And a great deal louder.”
<!-- /EN:LG-02-010 -->

> 「*あなた*と同じくらいね」とオニユリは言った。「それに、ずっと大きな声で」

<a id="LG-02-011"></a>

**LG-02-011**

<!-- EN:LG-02-011 -->
“It isn’t manners for us to begin, you know,” said the Rose, “and I really was wondering when you’d speak! Said I to myself, ‘Her face has got *some* sense in it, though it’s not a clever one!’ Still, you’re the right colour, and that goes a long way.”
<!-- /EN:LG-02-011 -->

> 「こちらから話しかけるのは、お行儀に反するでしょう」とバラが言った。「だから、本当に、いつあなたがお話しになるのかしらと思っていましたの！　わたくし、心の中でこう言っていたんですよ。『賢そうなお顔ではないけれど、*多少は*物がわかりそうだわ！』。それでも、色はちゃんとしていらっしゃるし、それは大いにものを言いますからね」

<a id="LG-02-012"></a>

**LG-02-012**

<!-- EN:LG-02-012 -->
“I don’t care about the colour,” the Tiger-lily remarked. “If only her petals curled up a little more, she’d be all right.”
<!-- /EN:LG-02-012 -->

> 「わたしは、色はどうでもいいけれど」とオニユリが口を挟んだ。「花びらがもう少し巻いていさえすれば、この子も申し分ないのよ」

<a id="LG-02-013"></a>

**LG-02-013**

<!-- EN:LG-02-013 -->
Alice didn’t like being criticised, so she began asking questions. “Aren’t you sometimes frightened at being planted out here, with nobody to take care of you?”
<!-- /EN:LG-02-013 -->

> アリスは品定めをされるのが嫌だったので、質問をはじめた。「こんなところに植えられていて、お世話をしてくれる人もいなくて、怖くなることはないの？」

<a id="LG-02-014"></a>

**LG-02-014**

<!-- EN:LG-02-014 -->
“There’s the tree in the middle,” said the Rose: “what else is it good for?”
<!-- /EN:LG-02-014 -->

> 「真ん中に木があるでしょう」とバラは言った。「あれが、ほかに何の役に立つというの？」

<a id="LG-02-015"></a>

**LG-02-015**

<!-- EN:LG-02-015 -->
“But what could it do, if any danger came?” Alice asked.
<!-- /EN:LG-02-015 -->

> 「でも、何か危ないことが起こったら、木に何ができるの？」とアリスは聞いた。

<a id="LG-02-016"></a>

**LG-02-016**

<!-- EN:LG-02-016 -->
“It says ‘Bough-wough!’” cried a Daisy: “that’s why its branches are called boughs!”
<!-- /EN:LG-02-016 -->

> 「『バウ、ワウ！』って言うんだよ！」とヒナギクが叫んだ。「だから木の枝は、バウっていうんだ！」

> **訳注：** 犬の鳴き声 bow-wow の bow と、木の大枝を指す bough は、同じ /baʊ/ の音。

<a id="LG-02-017"></a>

**LG-02-017**

<!-- EN:LG-02-017 -->
“Didn’t you know *that*?” cried another Daisy, and here they all began shouting together, till the air seemed quite full of little shrill voices. “Silence, every one of you!” cried the Tiger-lily, waving itself passionately from side to side, and trembling with excitement. “They know I can’t get at them!” it panted, bending its quivering head towards Alice, “or they wouldn’t dare to do it!”
<!-- /EN:LG-02-017 -->

> 「*そんなこと*も知らなかったの？」と、別のヒナギクが叫んだ。すると、みんなが一斉にわめきはじめ、あたりは甲高い小さな声でいっぱいになった。「静かになさい、みんな！」オニユリは激しく左右に身を振り、興奮に震えながら叫んだ。「わたしが手を出せないのを、知っているのよ！」と、震える頭をアリスへかしげ、息を切らして言った。「そうでなければ、こんなことをする度胸なんて、ありはしないんだから！」

<a id="LG-02-018"></a>

**LG-02-018**

<!-- EN:LG-02-018 -->
“Never mind!” Alice said in a soothing tone, and stooping down to the daisies, who were just beginning again, she whispered, “If you don’t hold your tongues, I’ll pick you!”
<!-- /EN:LG-02-018 -->

> 「大丈夫よ！」とアリスはなだめるように言い、また騒ぎはじめようとしていたヒナギクたちへ身をかがめて、ささやいた。「お黙りにならないと、摘んでしまうわよ！」

<a id="LG-02-019"></a>

**LG-02-019**

<!-- EN:LG-02-019 -->
There was silence in a moment, and several of the pink daisies turned white.
<!-- /EN:LG-02-019 -->

> たちまち静まり返り、桃色のヒナギクのいくつかは、白くなってしまった。

<a id="LG-02-020"></a>

**LG-02-020**

<!-- EN:LG-02-020 -->
“That’s right!” said the Tiger-lily. “The daisies are worst of all. When one speaks, they all begin together, and it’s enough to make one wither to hear the way they go on!”
<!-- /EN:LG-02-020 -->

> 「そのとおりよ！」とオニユリは言った。「ヒナギクは、とりわけ始末が悪いわ。ひとつがしゃべれば、みんなが一斉にしゃべりだすの。その騒ぎようを聞いていると、しおれてしまいそうよ！」

<a id="LG-02-021"></a>

**LG-02-021**

<!-- EN:LG-02-021 -->
“How is it you can all talk so nicely?” Alice said, hoping to get it into a better temper by a compliment. “I’ve been in many gardens before, but none of the flowers could talk.”
<!-- /EN:LG-02-021 -->

> 「どうして、みなさんそんなに上手にお話ができるの？」とアリスは言った。褒めれば機嫌がよくなるのではないかと思ったのだ。「今までいろいろなお庭へ行ったけれど、お話のできるお花は、ひとつもなかったわ」

<a id="LG-02-022"></a>

**LG-02-022**

<!-- EN:LG-02-022 -->
“Put your hand down, and feel the ground,” said the Tiger-lily. “Then you’ll know why.”
<!-- /EN:LG-02-022 -->

> 「手を下ろして、地面に触れてごらんなさい」とオニユリは言った。「そうすれば理由がわかるわ」

<a id="LG-02-023"></a>

**LG-02-023**

<!-- EN:LG-02-023 -->
Alice did so. “It’s very hard,” she said, “but I don’t see what that has to do with it.”
<!-- /EN:LG-02-023 -->

> アリスはそうしてみた。「とても硬いわ」と言った。「でも、それと何の関係があるのか、わからないわ」

<a id="LG-02-024"></a>

**LG-02-024**

<!-- EN:LG-02-024 -->
“In most gardens,” the Tiger-lily said, “they make the beds too soft—so that the flowers are always asleep.”
<!-- /EN:LG-02-024 -->

> 「たいていのお庭では」とオニユリは言った。「花の寝床を柔らかくしすぎるのよ。だから、お花たちはいつも眠っているの」

> **訳注：** bed は「花壇」と「寝床」の両方を意味する。

<a id="LG-02-025"></a>

**LG-02-025**

<!-- EN:LG-02-025 -->
This sounded a very good reason, and Alice was quite pleased to know it. “I never thought of that before!” she said.
<!-- /EN:LG-02-025 -->

> これは、とてももっともな理由に思えたので、アリスはそれを知って大いに喜んだ。「今まで、そんなこと考えたこともなかったわ！」と言った。

<a id="LG-02-026"></a>

**LG-02-026**

<!-- EN:LG-02-026 -->
“It’s *my* opinion that you never think *at all*,” the Rose said in a rather severe tone.
<!-- /EN:LG-02-026 -->

> 「*わたくし*の考えでは、あなたは*まるで*物を考えないのね」とバラが、かなり厳しい調子で言った。

<a id="LG-02-027"></a>

**LG-02-027**

<!-- EN:LG-02-027 -->
“I never saw anybody that looked stupider,” a Violet said, so suddenly, that Alice quite jumped; for it hadn’t spoken before.
<!-- /EN:LG-02-027 -->

> 「これほど頭の悪そうな人、見たことないわ」と、スミレがあまりに突然言ったので、アリスは思わず飛び上がった。今までひと言もしゃべらなかった花だったからだ。

<a id="LG-02-028"></a>

**LG-02-028**

<!-- EN:LG-02-028 -->
“Hold *your* tongue!” cried the Tiger-lily. “As if *you* ever saw anybody! You keep your head under the leaves, and snore away there, till you know no more what’s going on in the world, than if you were a bud!”
<!-- /EN:LG-02-028 -->

> 「*あなた*こそ、お黙りなさい！」とオニユリは叫んだ。「まるで*あなた*が誰かを見たことでもあるみたいな言い方ね！　いつも葉っぱの下に頭を隠して、そこでぐうぐういびきをかいているくせに。世の中のことなんて、まだつぼみのままでいるのと同じくらい、何もわかっていないじゃない！」

<a id="LG-02-029"></a>

**LG-02-029**

<!-- EN:LG-02-029 -->
“Are there any more people in the garden besides me?” Alice said, not choosing to notice the Rose’s last remark.
<!-- /EN:LG-02-029 -->

> 「お庭には、わたし以外にも誰かいるの？」とアリスは言った。バラのさっきの言葉は、聞かなかったことにした。

<a id="LG-02-030"></a>

**LG-02-030**

<!-- EN:LG-02-030 -->
“There’s one other flower in the garden that can move about like you,” said the Rose. “I wonder how you do it—” (“You’re always wondering,” said the Tiger-lily), “but she’s more bushy than you are.”
<!-- /EN:LG-02-030 -->

> 「このお庭には、あなたのように歩き回れる花が、もうひとついるわ」とバラは言った。「どうやっているのかしらね——」（「あなたは、いつも何かを不思議がっているわね」とオニユリが言った。）「でも、あの方はあなたより、もっとこんもりしているわ」

<a id="LG-02-031"></a>

**LG-02-031**

<!-- EN:LG-02-031 -->
“Is she like me?” Alice asked eagerly, for the thought crossed her mind, “There’s another little girl in the garden, somewhere!”
<!-- /EN:LG-02-031 -->

> 「わたしに似ているの？」とアリスは熱心に聞いた。「お庭のどこかに、もうひとり女の子がいるんだわ！」という考えが、頭をよぎったからだ。

<a id="LG-02-032"></a>

**LG-02-032**

<!-- EN:LG-02-032 -->
“Well, she has the same awkward shape as you,” the Rose said, “but she’s redder—and her petals are shorter, I think.”
<!-- /EN:LG-02-032 -->

> 「そうね、あなたと同じ、不格好な形をしているわ」とバラは言った。「でも、もっと赤くて、花びらは短かったと思うわ」

<a id="LG-02-033"></a>

**LG-02-033**

<!-- EN:LG-02-033 -->
“Her petals are done up close, almost like a dahlia,” the Tiger-lily interrupted: “not tumbled about anyhow, like yours.”
<!-- /EN:LG-02-033 -->

> 「あの方の花びらは、ぴったりまとめてあるの。ほとんどダリアみたいに」とオニユリが口を挟んだ。「あなたのように、あちこち勝手にはねてはいないわ」

<a id="LG-02-034"></a>

**LG-02-034**

<!-- EN:LG-02-034 -->
“But that’s not *your* fault,” the Rose added kindly: “you’re beginning to fade, you know—and then one can’t help one’s petals getting a little untidy.”
<!-- /EN:LG-02-034 -->

> 「でも、それは*あなた*のせいではないのよ」とバラは優しく付け加えた。「あなた、しおれはじめているでしょう。そうなれば、花びらが少し乱れるのは、仕方のないことですもの」

<a id="LG-02-035"></a>

**LG-02-035**

<!-- EN:LG-02-035 -->
Alice didn’t like this idea at all: so, to change the subject, she asked “Does she ever come out here?”
<!-- /EN:LG-02-035 -->

> アリスは、そんな考えはちっとも気に入らなかったので、話を変えようとして聞いた。「その人、ここへ来ることはあるの？」

<a id="LG-02-036"></a>

**LG-02-036**

<!-- EN:LG-02-036 -->
“I daresay you’ll see her soon,” said the Rose. “She’s one of the thorny kind.”
<!-- /EN:LG-02-036 -->

> 「きっと、すぐに会えますよ」とバラは言った。「あの方は、とげのある種類ですから」

<a id="LG-02-037"></a>

**LG-02-037**

<!-- EN:LG-02-037 -->
“Where does she wear the thorns?” Alice asked with some curiosity.
<!-- /EN:LG-02-037 -->

> 「とげは、どこにつけているの？」とアリスは、少し興味をひかれて聞いた。

<a id="LG-02-038"></a>

**LG-02-038**

<!-- EN:LG-02-038 -->
“Why all round her head, of course,” the Rose replied. “I was wondering *you* hadn’t got some too. I thought it was the regular rule.”
<!-- /EN:LG-02-038 -->

> 「まあ、もちろん、頭の周りにぐるりとよ」とバラは答えた。「*あなた*にはどうしてついていないのか、不思議に思っていましたの。それが普通の決まりだと思っていたから」

<a id="LG-02-039"></a>

**LG-02-039**

<!-- EN:LG-02-039 -->
“She’s coming!” cried the Larkspur. “I hear her footstep, thump, thump, thump, along the gravel-walk!”
<!-- /EN:LG-02-039 -->

> 「おいでになったわ！」とヒエンソウが叫んだ。「砂利道を、どん、どん、どんと歩いてくる足音が聞こえる！」

<a id="LG-02-040"></a>

**LG-02-040**

<!-- EN:LG-02-040 -->
Alice looked round eagerly, and found that it was the Red Queen. “She’s grown a good deal!” was her first remark. She had indeed: when Alice first found her in the ashes, she had been only three inches high—and here she was, half a head taller than Alice herself!
<!-- /EN:LG-02-040 -->

> アリスが勢いよく振り返ると、それは赤の女王だった。「ずいぶん大きくなったわね！」それが最初の言葉だった。実際、大きくなっていた。アリスが最初に灰の中で見つけたときは、高さが三インチしかなかったのに、今では、アリスより頭半分ほど背が高かったのだ！

<a id="LG-02-041"></a>

**LG-02-041**

<!-- EN:LG-02-041 -->
“It’s the fresh air that does it,” said the Rose: “wonderfully fine air it is, out here.”
<!-- /EN:LG-02-041 -->

> 「新鮮な空気のおかげですよ」とバラは言った。「ここは外の空気が、驚くほどよろしいの」

<a id="LG-02-042"></a>

**LG-02-042**

<!-- EN:LG-02-042 -->
“I think I’ll go and meet her,” said Alice, for, though the flowers were interesting enough, she felt that it would be far grander to have a talk with a real Queen.
<!-- /EN:LG-02-042 -->

> 「行ってお会いしてくるわ」とアリスは言った。花たちも十分面白かったけれど、本物の女王と話すほうが、ずっとすばらしいことだと思ったのだ。

<a id="LG-02-043"></a>

**LG-02-043**

<!-- EN:LG-02-043 -->
“You can’t possibly do that,” said the Rose: “*I* should advise you to walk the other way.”
<!-- /EN:LG-02-043 -->

> 「そんなこと、できるはずがないわ」とバラは言った。「*わたくし*なら、反対向きに歩くことをお勧めしますけれど」

<a id="LG-02-044"></a>

**LG-02-044**

<!-- EN:LG-02-044 -->
This sounded nonsense to Alice, so she said nothing, but set off at once towards the Red Queen. To her surprise, she lost sight of her in a moment, and found herself walking in at the front-door again.
<!-- /EN:LG-02-044 -->

> アリスには、これはでたらめに聞こえたので、何も答えず、すぐに赤の女王へ向かって歩き出した。すると驚いたことに、たちまち女王の姿が見えなくなり、気づけばまた玄関の戸口を入っていた。

<a id="LG-02-045"></a>

**LG-02-045**

<!-- EN:LG-02-045 -->
A little provoked, she drew back, and after looking everywhere for the queen (whom she spied out at last, a long way off), she thought she would try the plan, this time, of walking in the opposite direction.
<!-- /EN:LG-02-045 -->

> 少し腹を立てて後戻りし、女王をあちこち捜した末に（ようやく遠くのほうに姿を見つけた）、今度は反対の方向へ歩いてみようと思った。

<a id="LG-02-046"></a>

**LG-02-046**

<!-- EN:LG-02-046 -->
It succeeded beautifully. She had not been walking a minute before she found herself face to face with the Red Queen, and full in sight of the hill she had been so long aiming at.
<!-- /EN:LG-02-046 -->

> それは、見事にうまくいった。一分も歩かないうちに、アリスは赤の女王と向き合っていて、ずっと目指していた丘も、目の前にはっきり見えていた。

<a id="LG-02-047"></a>

**LG-02-047**

<!-- EN:LG-02-047 -->
“Where do you come from?” said the Red Queen. “And where are you going? Look up, speak nicely, and don’t twiddle your fingers all the time.”
<!-- /EN:LG-02-047 -->

> 「どこから来たのです？」と赤の女王は言った。「それから、どこへ行くのです？　顔を上げて、きちんとお話しなさい。そして、いつまでも指をいじくり回さないこと」

<a id="LG-02-048"></a>

**LG-02-048**

<!-- EN:LG-02-048 -->
Alice attended to all these directions, and explained, as well as she could, that she had lost her way.
<!-- /EN:LG-02-048 -->

> アリスは言いつけを全部守り、自分が道に迷ったことを、できるかぎり上手に説明した。

<a id="LG-02-049"></a>

**LG-02-049**

<!-- EN:LG-02-049 -->
“I don’t know what you mean by *your* way,” said the Queen: “all the ways about here belong to *me*—but why did you come out here at all?” she added in a kinder tone. “Curtsey while you’re thinking what to say, it saves time.”
<!-- /EN:LG-02-049 -->

> 「*自分の*道を見失った、とはどういう意味かわかりませんね」と女王は言った。「このあたりの道は、全部*わたくし*のものです。でも、そもそも何のために外へ出てきたのです？」と、少し優しい調子で付け加えた。「何と言うか考えているあいだに、お辞儀をなさい。時間の節約になります」

> **訳注：** lose one’s way は「道に迷う」。女王は your way を「あなたの所有する道」と字義どおりに受け取っている。

<a id="LG-02-050"></a>

**LG-02-050**

<!-- EN:LG-02-050 -->
Alice wondered a little at this, but she was too much in awe of the Queen to disbelieve it. “I’ll try it when I go home,” she thought to herself, “the next time I’m a little late for dinner.”
<!-- /EN:LG-02-050 -->

> アリスは少し不思議に思ったけれど、女王をあまりに恐れ多く感じていたので、それは違うなどとは思えなかった。「家に帰ったらやってみよう」と心の中で思った。「今度、夕食に少し遅れたときに」

<a id="LG-02-051"></a>

**LG-02-051**

<!-- EN:LG-02-051 -->
“It’s time for you to answer now,” the Queen said, looking at her watch: “open your mouth a *little* wider when you speak, and always say ‘your Majesty.’”
<!-- /EN:LG-02-051 -->

> 「そろそろ答える時間ですよ」と女王は時計を見て言った。「お話しするときは、お口を*もう少し*大きく開けること。それから、必ず『陛下』と言いなさい」

<a id="LG-02-052"></a>

**LG-02-052**

<!-- EN:LG-02-052 -->
“I only wanted to see what the garden was like, your Majesty—”
<!-- /EN:LG-02-052 -->

> 「ただ、お庭がどんなふうか見てみたかったのです、陛下——」

<a id="LG-02-053"></a>

**LG-02-053**

<!-- EN:LG-02-053 -->
“That’s right,” said the Queen, patting her on the head, which Alice didn’t like at all, “though, when you say ‘garden,’—*I’ve* seen gardens, compared with which this would be a wilderness.”
<!-- /EN:LG-02-053 -->

> 「よろしい」と女王は言い、アリスの頭をぽんぽんとたたいた。アリスには、これはまるで気に入らなかった。「もっとも、『お庭』とおっしゃるけれど、*わたくし*の見たお庭の中には、それと比べたらここなど荒れ地に思えるものもありますよ」

<a id="LG-02-054"></a>

**LG-02-054**

<!-- EN:LG-02-054 -->
Alice didn’t dare to argue the point, but went on: “—and I thought I’d try and find my way to the top of that hill—”
<!-- /EN:LG-02-054 -->

> アリスは、そのことに反論する勇気はなかったので、そのまま続けた。「——それで、あの丘の上まで行く道を探してみようと思ったのです——」

<a id="LG-02-055"></a>

**LG-02-055**

<!-- EN:LG-02-055 -->
“When you say ‘hill,’” the Queen interrupted, “*I* could show you hills, in comparison with which you’d call that a valley.”
<!-- /EN:LG-02-055 -->

> 「『丘』とおっしゃるけれど」と女王は口を挟んだ。「*わたくし*なら、あれが谷に思えるほどの丘を、お見せできますよ」

<a id="LG-02-056"></a>

**LG-02-056**

<!-- EN:LG-02-056 -->
“No, I shouldn’t,” said Alice, surprised into contradicting her at last: “a hill *can’t* be a valley, you know. That would be nonsense—”
<!-- /EN:LG-02-056 -->

> 「いいえ、谷とは思いません」とアリスは言った。驚きのあまり、とうとう反論してしまったのだ。「丘が谷であるはずは*ない*でしょう。そんなの、でたらめです——」

<a id="LG-02-057"></a>

**LG-02-057**

<!-- EN:LG-02-057 -->
The Red Queen shook her head, “You may call it ‘nonsense’ if you like,” she said, “but *I’ve* heard nonsense, compared with which that would be as sensible as a dictionary!”
<!-- /EN:LG-02-057 -->

> 赤の女王は首を振った。「お望みなら、『でたらめ』と呼んでも結構」と言った。「けれど、*わたくし*は、それに比べれば今の話が辞書と同じくらい筋の通ったものに思える、そんなでたらめだって聞いたことがありますよ！」

<a id="LG-02-058"></a>

**LG-02-058**

<!-- EN:LG-02-058 -->
Alice curtseyed again, as she was afraid from the Queen’s tone that she was a *little* offended: and they walked on in silence till they got to the top of the little hill.
<!-- /EN:LG-02-058 -->

> 女王の口ぶりから、*少し*気を悪くされたのではないかと心配になったので、アリスはもう一度お辞儀をした。それから、ふたりは小さな丘の頂上に着くまで、黙って歩いた。

<a id="LG-02-059"></a>

**LG-02-059**

<!-- EN:LG-02-059 -->
For some minutes Alice stood without speaking, looking out in all directions over the country—and a most curious country it was. There were a number of tiny little brooks running straight across it from side to side, and the ground between was divided up into squares by a number of little green hedges, that reached from brook to brook.
<!-- /EN:LG-02-059 -->

> 数分のあいだ、アリスは何も言わずに立ち、四方に広がる国を見渡した。何とも奇妙な国だった。とても小さな小川が何本も、端から端までまっすぐ流れ、そのあいだの土地は、小川から小川へ伸びる緑の低い生け垣によって、いくつもの正方形に区切られていた。

<a id="LG-02-060"></a>

**LG-02-060**

<!-- EN:LG-02-060 -->
“I declare it’s marked out just like a large chessboard!” Alice said at last. “There ought to be some men moving about somewhere—and so there are!” She added in a tone of delight, and her heart began to beat quick with excitement as she went on. “It’s a great huge game of chess that’s being played—all over the world—if this *is* the world at all, you know. Oh, what fun it is! How I *wish* I was one of them! I wouldn’t mind being a Pawn, if only I might join—though of course I should *like* to be a Queen, best.”
<!-- /EN:LG-02-060 -->

> 「まあ、まるで大きなチェス盤みたいに区切ってあるわ！」とアリスは、ようやく言った。「どこかで駒が動いているはずね。あら、本当にいる！」そう嬉しそうな声で付け加えた。興奮で胸がどきどきしはじめ、続けた。「とてつもなく大きなチェスの勝負をしているんだわ。世界じゅうで。もっとも、これが本当に世界全体*なら*、だけどね。ああ、何て面白いの！　わたしも、そのひとりになれたら*いいのに*！　仲間に入れるなら、ポーンでもかまわないわ。もちろん、いちばん*なりたい*のは女王だけれど」

<a id="LG-02-061"></a>

**LG-02-061**

<!-- EN:LG-02-061 -->
She glanced rather shyly at the real Queen as she said this, but her companion only smiled pleasantly, and said, “That’s easily managed. You can be the White Queen’s Pawn, if you like, as Lily’s too young to play; and you’re in the Second Square to begin with: when you get to the Eighth Square you’ll be a Queen—” Just at this moment, somehow or other, they began to run.
<!-- /EN:LG-02-061 -->

> そう言いながら、本物の女王を少し恥ずかしそうにちらりと見た。けれど相手は、ただにこやかに笑ってこう言った。「それなら簡単なことです。リリーはまだ幼くて参加できないから、よろしければ、あなたが白の女王のポーンになればよいのです。最初は第二の升目にいます。第八の升目へ着けば、女王になれます——」ちょうどそのとき、どういうわけか、ふたりは走りはじめた。

<a id="LG-02-062"></a>

**LG-02-062**

<!-- EN:LG-02-062 -->
Alice never could quite make out, in thinking it over afterwards, how it was that they began: all she remembers is, that they were running hand in hand, and the Queen went so fast that it was all she could do to keep up with her: and still the Queen kept crying “Faster! Faster!” but Alice felt she *could not* go faster, though she had not breath left to say so.
<!-- /EN:LG-02-062 -->

> どうして走りはじめることになったのか、アリスはあとで考えても、どうしてもはっきり思い出せなかった。覚えているのは、ふたりが手をつないで走っていたこと、女王の足があまりに速くて、ついていくのが精いっぱいだったことだけだった。それでも女王は「もっと速く！　もっと速く！」と叫び続けた。けれどアリスには、それ以上速く走るなど*できない*と思えたし、そう言うだけの息さえ残っていなかった。

<a id="LG-02-063"></a>

**LG-02-063**

<!-- EN:LG-02-063 -->
The most curious part of the thing was, that the trees and the other things round them never changed their places at all: however fast they went, they never seemed to pass anything. “I wonder if all the things move along with us?” thought poor puzzled Alice. And the Queen seemed to guess her thoughts, for she cried, “Faster! Don’t try to talk!”
<!-- /EN:LG-02-063 -->

> いちばん奇妙なのは、周囲の木々や、ほかの物の位置が、少しも変わらないことだった。いくら速く走っても、何かを通り過ぎているようには見えない。「何もかも、わたしたちと一緒に動いているのかしら？」と、かわいそうに、すっかり困惑したアリスは思った。すると女王は、考えを読み取ったかのように叫んだ。「もっと速く！　しゃべろうとしないこと！」

<a id="LG-02-064"></a>

**LG-02-064**

<!-- EN:LG-02-064 -->
Not that Alice had any idea of doing *that*. She felt as if she would never be able to talk again, she was getting so much out of breath: and still the Queen cried “Faster! Faster!” and dragged her along. “Are we nearly there?” Alice managed to pant out at last.
<!-- /EN:LG-02-064 -->

> もっとも、アリスに*そんなこと*をするつもりはなかった。息があまりに切れていたので、もう二度と話せなくなるような気がした。それでも女王は「もっと速く！　もっと速く！」と叫びながら、アリスを引っ張っていった。「もうすぐ着きますか？」と、ようやくアリスは、あえぎあえぎ言った。

<a id="LG-02-065"></a>

**LG-02-065**

<!-- EN:LG-02-065 -->
“Nearly there!” the Queen repeated. “Why, we passed it ten minutes ago! Faster!” And they ran on for a time in silence, with the wind whistling in Alice’s ears, and almost blowing her hair off her head, she fancied.
<!-- /EN:LG-02-065 -->

> 「もうすぐ着く？」と女王は繰り返した。「まあ、十分前にそこは通り過ぎましたよ！　もっと速く！」しばらく、ふたりは黙って走り続けた。風がアリスの耳元でひゅうひゅう鳴り、髪の毛まで頭から吹き飛ばされそうな気がした。

<a id="LG-02-066"></a>

**LG-02-066**

<!-- EN:LG-02-066 -->
“Now! Now!” cried the Queen. “Faster! Faster!” And they went so fast that at last they seemed to skim through the air, hardly touching the ground with their feet, till suddenly, just as Alice was getting quite exhausted, they stopped, and she found herself sitting on the ground, breathless and giddy.
<!-- /EN:LG-02-066 -->

> 「さあ！　さあ！」と女王は叫んだ。「もっと速く！　もっと速く！」ふたりはあまりに速く進んだので、しまいには足もほとんど地面に触れず、空中をすれすれに飛んでいくようだった。そして、アリスがすっかり疲れ果てる、その寸前に、突然ぴたりと止まった。気がつくとアリスは、息を切らし、目を回しながら、地面に座っていた。

<a id="LG-02-067"></a>

**LG-02-067**

<!-- EN:LG-02-067 -->
The Queen propped her up against a tree, and said kindly, “You may rest a little now.”
<!-- /EN:LG-02-067 -->

> 女王はアリスを木にもたれさせ、優しく言った。「さあ、少し休んでよろしい」

<a id="LG-02-068"></a>

**LG-02-068**

<!-- EN:LG-02-068 -->
Alice looked round her in great surprise. “Why, I do believe we’ve been under this tree the whole time! Everything’s just as it was!”
<!-- /EN:LG-02-068 -->

> アリスは大層驚いて、あたりを見回した。「まあ、わたしたち、ずっとこの木の下にいたんだと思います！　何もかも、もとのままですもの！」

<a id="LG-02-069"></a>

**LG-02-069**

<!-- EN:LG-02-069 -->
“Of course it is,” said the Queen, “what would you have it?”
<!-- /EN:LG-02-069 -->

> 「もちろん、そうですよ」と女王は言った。「どうなっていてほしいというのです？」

<a id="LG-02-070"></a>

**LG-02-070**

<!-- EN:LG-02-070 -->
“Well, in *our* country,” said Alice, still panting a little, “you’d generally get to somewhere else—if you ran very fast for a long time, as we’ve been doing.”
<!-- /EN:LG-02-070 -->

> 「でも、*わたしたちの*国では」とアリスは、まだ少し息を切らしながら言った。「今したみたいに、長いあいだとても速く走れば、普通は、どこかほかの場所に着くんです」

<a id="LG-02-071"></a>

**LG-02-071**

<!-- EN:LG-02-071 -->
“A slow sort of country!” said the Queen. “Now, *here*, you see, it takes all the running *you* can do, to keep in the same place. If you want to get somewhere else, you must run at least twice as fast as that!”
<!-- /EN:LG-02-071 -->

> 「のろまな国ですね！」と女王は言った。「いいですか、*ここでは*、同じ場所にとどまるだけでも、*あなたが*走れるかぎり力いっぱい走らなくてはなりません。どこかほかの場所へ行きたければ、少なくとも、その二倍は速く走らなければならないのです！」

<a id="LG-02-072"></a>

**LG-02-072**

<!-- EN:LG-02-072 -->
“I’d rather not try, please!” said Alice. “I’m quite content to stay here—only I *am* so hot and thirsty!”
<!-- /EN:LG-02-072 -->

> 「お願いですから、それは遠慮しておきます！」とアリスは言った。「ここにいられれば、わたしは十分満足です。ただ、本当に、暑くて喉が渇いてしまって！」

<a id="LG-02-073"></a>

**LG-02-073**

<!-- EN:LG-02-073 -->
“I know what *you’d* like!” the Queen said good-naturedly, taking a little box out of her pocket. “Have a biscuit?”
<!-- /EN:LG-02-073 -->

> 「*あなたの*欲しいものは、わかっていますよ！」と女王は気さくに言い、ポケットから小さな箱を取り出した。「ビスケットはいかが？」

<a id="LG-02-074"></a>

**LG-02-074**

<!-- EN:LG-02-074 -->
Alice thought it would not be civil to say “No,” though it wasn’t at all what she wanted. So she took it, and ate it as well as she could: and it was *very* dry; and she thought she had never been so nearly choked in all her life.
<!-- /EN:LG-02-074 -->

> 欲しいものとはまるで違ったけれど、アリスは「いいえ」と言うのは失礼だと思った。そこで受け取り、何とか食べてみた。ところが、それは*ひどく*ぱさぱさしていた。生まれてから、これほど喉に詰まりかけたことはない、と思った。

<a id="LG-02-075"></a>

**LG-02-075**

<!-- EN:LG-02-075 -->
“While you’re refreshing yourself,” said the Queen, “I’ll just take the measurements.” And she took a ribbon out of her pocket, marked in inches, and began measuring the ground, and sticking little pegs in here and there.
<!-- /EN:LG-02-075 -->

> 「あなたが元気を取り戻しているあいだに」と女王は言った。「わたくしは、ちょっと寸法を測りましょう」そして、インチの目盛りがついたリボンをポケットから取り出し、地面を測りながら、あちこちに小さな杭を打ちはじめた。

<a id="LG-02-076"></a>

**LG-02-076**

<!-- EN:LG-02-076 -->
“At the end of two yards,” she said, putting in a peg to mark the distance, “I shall give you your directions—have another biscuit?”
<!-- /EN:LG-02-076 -->

> 「二ヤードのところで」と女王は言い、その距離を示す杭を打った。「進み方を教えてあげましょう。もう一枚、ビスケットはいかが？」

<a id="LG-02-077"></a>

**LG-02-077**

<!-- EN:LG-02-077 -->
“No, thank you,” said Alice: “one’s *quite* enough!”
<!-- /EN:LG-02-077 -->

> 「いいえ、ありがとうございます」とアリスは言った。「一枚で、*十分すぎるくらい*です！」

<a id="LG-02-078"></a>

**LG-02-078**

<!-- EN:LG-02-078 -->
“Thirst quenched, I hope?” said the Queen.
<!-- /EN:LG-02-078 -->

> 「喉の渇きは治まりましたね？」と女王は言った。

<a id="LG-02-079"></a>

**LG-02-079**

<!-- EN:LG-02-079 -->
Alice did not know what to say to this, but luckily the Queen did not wait for an answer, but went on. “At the end of *three* yards I shall repeat them—for fear of your forgetting them. At the end of *four*, I shall say good-bye. And at the end of *five*, I shall go!”
<!-- /EN:LG-02-079 -->

> アリスには何と答えてよいかわからなかった。けれど幸い、女王は返事を待たず、そのまま話を続けた。「*三*ヤードのところで、もう一度繰り返します。あなたが忘れてはいけませんから。*四*ヤードのところで、お別れの挨拶をします。そして、*五*ヤードのところで、わたくしは行ってしまいます！」

<a id="LG-02-080"></a>

**LG-02-080**

<!-- EN:LG-02-080 -->
She had got all the pegs put in by this time, and Alice looked on with great interest as she returned to the tree, and then began slowly walking down the row.
<!-- /EN:LG-02-080 -->

> このときには、女王は杭を全部打ち終えていた。女王が木のところへ戻り、それから杭の列に沿ってゆっくり歩きはじめるのを、アリスはたいそう興味深く見守った。

<a id="LG-02-081"></a>

**LG-02-081**

<!-- EN:LG-02-081 -->
At the two-yard peg she faced round, and said, “A pawn goes two squares in its first move, you know. So you’ll go *very* quickly through the Third Square—by railway, I should think—and you’ll find yourself in the Fourth Square in no time. Well, *that* square belongs to Tweedledum and Tweedledee—the Fifth is mostly water—the Sixth belongs to Humpty Dumpty—But you make no remark?”
<!-- /EN:LG-02-081 -->

> 二ヤードの杭で、女王は振り向いて言った。「ご存じのとおり、ポーンは最初の一手では二升進めます。ですから、第三の升目は*ごく*素早く通り抜けることになるでしょう。鉄道を使うのでしょうね。そして、あっという間に第四の升目に着きます。さて、*そこ*はトゥイードルダムとトゥイードルディーの場所です。第五はほとんど水、第六はハンプティ・ダンプティの場所です。でも、何もおっしゃらないのですか？」

<a id="LG-02-082"></a>

**LG-02-082**

<!-- EN:LG-02-082 -->
“I—I didn’t know I had to make one—just then,” Alice faltered out.
<!-- /EN:LG-02-082 -->

> 「わ、わたし、何か言わなくちゃいけないとは、今は思わなかったものですから——」とアリスは、口ごもりながら言った。

<a id="LG-02-083"></a>

**LG-02-083**

<!-- EN:LG-02-083 -->
“You *should* have said, ‘It’s extremely kind of you to tell me all this’—however, we’ll suppose it said—the Seventh Square is all forest—however, one of the Knights will show you the way—and in the Eighth Square we shall be Queens together, and it’s all feasting and fun!” Alice got up and curtseyed, and sat down again.
<!-- /EN:LG-02-083 -->

> 「『いろいろお教えくださって、まことにありがとうございます』と*言うべき*でした。まあ、言ったことにしておきましょう。第七の升目は、一面の森です。でも、騎士のどちらかが道案内をしてくれるでしょう。そして第八の升目では、わたしたちは一緒に女王となり、あとは、ごちそうと楽しいことばかりです！」アリスは立ち上がってお辞儀をし、また座った。

<a id="LG-02-084"></a>

**LG-02-084**

<!-- EN:LG-02-084 -->
At the next peg the Queen turned again, and this time she said, “Speak in French when you can’t think of the English for a thing—turn out your toes as you walk—and remember who you are!” She did not wait for Alice to curtsey this time, but walked on quickly to the next peg, where she turned for a moment to say “good-bye,” and then hurried on to the last.
<!-- /EN:LG-02-084 -->

> 次の杭で女王はまた振り向き、今度はこう言った。「英語が思い浮かばなければ、フランス語で話すこと。歩くときは、つま先を外へ向けること。そして、自分が誰なのかを忘れないこと！」今度はアリスがお辞儀をするのを待たず、さっさと次の杭まで歩いていった。そこでちょっとだけ振り向いて「さようなら」と言い、それから急いで最後の杭へ進んだ。

<a id="LG-02-085"></a>

**LG-02-085**

<!-- EN:LG-02-085 -->
How it happened, Alice never knew, but exactly as she came to the last peg, she was gone. Whether she vanished into the air, or whether she ran quickly into the wood (“and she *can* run very fast!” thought Alice), there was no way of guessing, but she was gone, and Alice began to remember that she was a Pawn, and that it would soon be time for her to move.
<!-- /EN:LG-02-085 -->

> どうやったのか、アリスにはついにわからなかったけれど、女王は最後の杭に着いた、ちょうどその瞬間に、いなくなった。空中へ消えたのか、すばやく森へ走り込んだのか（「*とても*速く走れる人だものね！」とアリスは思った）、見当のつけようもなかった。けれど、とにかく女王はもういなかった。そこでアリスは、自分がポーンであり、そろそろ動く番になるのだということを、思い出しはじめた。

[章目次へ戻る](#book-top)

---

<a id="lg-chapter-03"></a>

## 第3章　鏡の国の虫たち

### CHAPTER III. Looking-Glass Insects

<a id="LG-03-001"></a>

**LG-03-001**

<!-- EN:LG-03-001 -->
Of course the first thing to do was to make a grand survey of the country she was going to travel through. “It’s something very like learning geography,” thought Alice, as she stood on tiptoe in hopes of being able to see a little further. “Principal rivers—there *are* none. Principal mountains—I’m on the only one, but I don’t think it’s got any name. Principal towns—why, what *are* those creatures, making honey down there? They can’t be bees—nobody ever saw bees a mile off, you know—” and for some time she stood silent, watching one of them that was bustling about among the flowers, poking its proboscis into them, “just as if it was a regular bee,” thought Alice.
<!-- /EN:LG-03-001 -->

> もちろん、まずすべきことは、これから旅する国をぐるりと見渡しておくことだった。「地理を習うのと、よく似ているわね」とアリスは思い、少しでも遠くが見えないかと、つま先立ちをした。「主な河川——*なし*。主な山地——たったひとつの山の上にいるけれど、名前はないみたい。主な都市——あら、下のほうで蜜を作っている、あの生き物は*何*かしら？　ハチのはずはないわ。一マイルも先のハチなんて、誰も見たことがないものね——」そしてしばらく黙って立ち、その一匹が花のあいだを忙しそうに動き回り、長い鼻を花へ突っ込んでいるのを見ていた。「まるで、普通のハチみたい」とアリスは思った。

<a id="LG-03-002"></a>

**LG-03-002**

<!-- EN:LG-03-002 -->
However, this was anything but a regular bee: in fact it was an elephant—as Alice soon found out, though the idea quite took her breath away at first. “And what enormous flowers they must be!” was her next idea. “Something like cottages with the roofs taken off, and stalks put to them—and what quantities of honey they must make! I think I’ll go down and—no, I won’t *just* yet,” she went on, checking herself just as she was beginning to run down the hill, and trying to find some excuse for turning shy so suddenly. “It’ll never do to go down among them without a good long branch to brush them away—and what fun it’ll be when they ask me how I like my walk. I shall say—‘Oh, I like it well enough—’” (here came the favourite little toss of the head), “‘only it was so dusty and hot, and the elephants did tease so!’”
<!-- /EN:LG-03-002 -->

> けれど、それは普通のハチとは、まったく違うものだった。実はゾウだったのだ。アリスにも、すぐにそれがわかったが、最初はそう考えただけで、息をのんでしまった。「それなら、あのお花はどんなに大きいのかしら！」というのが、次に浮かんだ考えだった。「屋根を取り払って、茎をつけた小さなおうちみたいなものね。それに、どれほどたくさん蜜を作るのかしら！　下りていって——いいえ、まだ*今すぐには*行かないわ」と続け、丘を駆け下りかけたところで立ち止まった。そして、急に気後れしたことに、何か言い訳をつけようとした。「追い払うための、十分長い枝を持たずに、あの中へ下りていくわけにはいかないもの。それに、お散歩は楽しかったかって聞かれたら、何て面白いでしょうね。こう言うのよ。『ええ、なかなかよかったわ——』」（ここで、お得意の、ちょっとした首の振り方をした。）「『ただ、ひどくほこりっぽくて暑かったし、ゾウがやたらにまとわりついて、困ってしまったの！』」

<a id="LG-03-003"></a>

**LG-03-003**

<!-- EN:LG-03-003 -->
“I think I’ll go down the other way,” she said after a pause: “and perhaps I may visit the elephants later on. Besides, I do so want to get into the Third Square!”
<!-- /EN:LG-03-003 -->

> しばらくしてから、「反対側を下りていこうかな」とアリスは言った。「ゾウのところへは、あとで行ってもいいし。それに、第三の升目へ、とても行ってみたいんだもの！」

<a id="LG-03-004"></a>

**LG-03-004**

<!-- EN:LG-03-004 -->
So with this excuse she ran down the hill and jumped over the first of the six little brooks.
<!-- /EN:LG-03-004 -->

> こう言い訳をして、アリスは丘を駆け下り、六本の小川の、最初の一本を飛び越えた。

<a id="LG-03-005"></a>

<!-- EN:LG-03-005 -->
\*      \*      \*      \*      \*      \*      \*  
<!-- /EN:LG-03-005 -->

<a id="LG-03-006"></a>

<!-- EN:LG-03-006 -->
    \*      \*      \*      \*      \*      \*  
<!-- /EN:LG-03-006 -->

<a id="LG-03-007"></a>

<!-- EN:LG-03-007 -->
\*      \*      \*      \*      \*      \*      \*
<!-- /EN:LG-03-007 -->

<a id="LG-03-008"></a>

**LG-03-008**

<!-- EN:LG-03-008 -->
“Tickets, please!” said the Guard, putting his head in at the window. In a moment everybody was holding out a ticket: they were about the same size as the people, and quite seemed to fill the carriage.
<!-- /EN:LG-03-008 -->

> 「切符を拝見！」と車掌が窓から顔を入れて言った。たちまち、みんなが切符を差し出した。切符は持ち主と同じくらいの大きさで、客車がそれでいっぱいになったようだった。

<a id="LG-03-009"></a>

**LG-03-009**

<!-- EN:LG-03-009 -->
“Now then! Show your ticket, child!” the Guard went on, looking angrily at Alice. And a great many voices all said together (“like the chorus of a song,” thought Alice), “Don’t keep him waiting, child! Why, his time is worth a thousand pounds a minute!”
<!-- /EN:LG-03-009 -->

> 「さあ、さあ！　お嬢ちゃん、切符を見せなさい！」車掌はアリスを怒った顔で見ながら続けた。すると、たくさんの声が一斉にこう言った（「歌の合唱みたい」とアリスは思った）。「待たせてはいけないよ、お嬢ちゃん！　この人の時間は、一分で千ポンドの値打ちがあるんだからね！」

<a id="LG-03-010"></a>

**LG-03-010**

<!-- EN:LG-03-010 -->
“I’m afraid I haven’t got one,” Alice said in a frightened tone: “there wasn’t a ticket-office where I came from.” And again the chorus of voices went on. “There wasn’t room for one where she came from. The land there is worth a thousand pounds an inch!”
<!-- /EN:LG-03-010 -->

> 「すみません、持っていないんです」とアリスは怯えた声で言った。「わたしの来たところには、切符売り場がなかったんです」すると、また声の合唱が続いた。「この子の来たところには、建てる場所がなかったのさ。あそこの土地は、一インチが千ポンドもするんだから！」

<a id="LG-03-011"></a>

**LG-03-011**

<!-- EN:LG-03-011 -->
“Don’t make excuses,” said the Guard: “you should have bought one from the engine-driver.” And once more the chorus of voices went on with “The man that drives the engine. Why, the smoke alone is worth a thousand pounds a puff!”
<!-- /EN:LG-03-011 -->

> 「言い訳をしてはいけません」と車掌は言った。「機関士から買えばよかったのです」すると、またも声の合唱が続いた。「機関車を動かす男だよ。何しろ、煙だけでも、ひと吹き千ポンドの値打ちだからね！」

<a id="LG-03-012"></a>

**LG-03-012**

<!-- EN:LG-03-012 -->
Alice thought to herself, “Then there’s no use in speaking.” The voices didn’t join in this time, as she hadn’t spoken, but to her great surprise, they all *thought* in chorus (I hope you understand what *thinking in chorus* means—for I must confess that *I* don’t), “Better say nothing at all. Language is worth a thousand pounds a word!”
<!-- /EN:LG-03-012 -->

> アリスは心の中で、「それなら、話をするだけ無駄だわ」と思った。今度は口に出していなかったので、声は唱和しなかった。けれど、たいそう驚いたことに、みんなが一斉に*思った*のだった（*合唱して考える*というのが、どういうことか、あなたにはわかるといいのだけれど。正直に言うと、*私には*わからないのだ）。「何も言わないにかぎる。言葉は一語で千ポンドの値打ちがあるんだから！」

<a id="LG-03-013"></a>

**LG-03-013**

<!-- EN:LG-03-013 -->
“I shall dream about a thousand pounds tonight, I know I shall!” thought Alice.
<!-- /EN:LG-03-013 -->

> 「今夜はきっと、千ポンドの夢を見るわ。そうなるに決まっている！」とアリスは思った。

<a id="LG-03-014"></a>

**LG-03-014**

<!-- EN:LG-03-014 -->
All this time the Guard was looking at her, first through a telescope, then through a microscope, and then through an opera-glass. At last he said, “You’re travelling the wrong way,” and shut up the window and went away.
<!-- /EN:LG-03-014 -->

> そのあいだじゅう車掌は、最初は望遠鏡で、次には顕微鏡で、それからオペラグラスで、アリスを調べていた。しまいに「進む方向が違います」と言い、窓を閉めて行ってしまった。

<a id="LG-03-015"></a>

**LG-03-015**

<!-- EN:LG-03-015 -->
“So young a child,” said the gentleman sitting opposite to her (he was dressed in white paper), “ought to know which way she’s going, even if she doesn’t know her own name!”
<!-- /EN:LG-03-015 -->

> 「こんな小さな子供でも」と、向かいに座っていた紳士が言った（その人は、白い紙を着ていた）。「自分の名前はわからなくても、どっちへ進んでいるかくらいは、わかるべきだ！」

<a id="LG-03-016"></a>

**LG-03-016**

<!-- EN:LG-03-016 -->
A Goat, that was sitting next to the gentleman in white, shut his eyes and said in a loud voice, “She ought to know her way to the ticket-office, even if she doesn’t know her alphabet!”
<!-- /EN:LG-03-016 -->

> 白い服の紳士の隣に座っていたヤギが、目をつぶって大きな声で言った。「アルファベットは知らなくても、切符売り場への道くらいは知っているべきだ！」

<a id="LG-03-017"></a>

**LG-03-017**

<!-- EN:LG-03-017 -->
There was a Beetle sitting next to the Goat (it was a very queer carriage-full of passengers altogether), and, as the rule seemed to be that they should all speak in turn, *he* went on with “She’ll have to go back from here as luggage!”
<!-- /EN:LG-03-017 -->

> ヤギの隣には甲虫が座っていた（とにかく、この客車には、ひどく妙な乗客ばかりが乗っていた）。みんな順番に発言するのが決まりらしかったので、*甲虫*も続けた。「この子は、ここから荷物として送り返されなければならん！」

<a id="LG-03-018"></a>

**LG-03-018**

<!-- EN:LG-03-018 -->
Alice couldn’t see who was sitting beyond the Beetle, but a hoarse voice spoke next. “Change engines—” it said, and was obliged to leave off.
<!-- /EN:LG-03-018 -->

> 甲虫の向こうに誰が座っているのか、アリスには見えなかったが、次には、かすれた声が話した。「機関車を替えて——」と言って、そこで声が続かなくなった。

<a id="LG-03-019"></a>

**LG-03-019**

<!-- EN:LG-03-019 -->
“It sounds like a horse,” Alice thought to herself. And an extremely small voice, close to her ear, said, “You might make a joke on that—something about ‘horse’ and ‘hoarse,’ you know.”
<!-- /EN:LG-03-019 -->

> 「馬みたいな声ね」とアリスは心の中で思った。すると、耳のすぐそばで、ひどく小さな声が言った。「それで、しゃれが作れるよ。ほら、『馬の horse』と『声のかすれた hoarse』を使ってさ」

> **訳注：** horse と hoarse は同音。直前の hoarse voice「かすれた声」から、horse「馬」につないでいる。

<a id="LG-03-020"></a>

**LG-03-020**

<!-- EN:LG-03-020 -->
Then a very gentle voice in the distance said, “She must be labelled ‘Lass, with care,’ you know—”
<!-- /EN:LG-03-020 -->

> それから遠くのほうで、とても穏やかな声が言った。「『少女につき、取扱注意』という札をつけないといけませんね——」

> **訳注：** Lass, with care は、荷物の注意書き Glass, with care「ガラスにつき取扱注意」から G を取り、lass「少女」にしたしゃれ。

<a id="LG-03-021"></a>

**LG-03-021**

<!-- EN:LG-03-021 -->
And after that other voices went on (“What a number of people there are in the carriage!” thought Alice), saying, “She must go by post, as she’s got a head on her—” “She must be sent as a message by the telegraph—” “She must draw the train herself the rest of the way—” and so on.
<!-- /EN:LG-03-021 -->

> そのあとも、いろいろな声が続いた（「この客車、何てたくさん人がいるのかしら！」とアリスは思った）。「頭がついているんだから、郵便で送るべきだ——」「電報の伝言として送らないと——」「残りの道は、この子が自分で列車を引っ張らなければ——」などなど。

> **訳注：** 「頭がついているから郵便で」は、肖像のある切手を連想させる言葉遊び。

<a id="LG-03-022"></a>

**LG-03-022**

<!-- EN:LG-03-022 -->
But the gentleman dressed in white paper leaned forwards and whispered in her ear, “Never mind what they all say, my dear, but take a return-ticket every time the train stops.”
<!-- /EN:LG-03-022 -->

> けれど白い紙を着た紳士は、身を乗り出してアリスの耳にささやいた。「みんなの言うことは気にしなくていいよ、お嬢さん。ただ、汽車が止まるたびに、往復切符を買いなさい」

<a id="LG-03-023"></a>

**LG-03-023**

<!-- EN:LG-03-023 -->
“Indeed I shan’t!” Alice said rather impatiently. “I don’t belong to this railway journey at all—I was in a wood just now—and I wish I could get back there.”
<!-- /EN:LG-03-023 -->

> 「絶対に嫌です！」とアリスは、少しいらだった声で言った。「わたし、そもそもこの汽車の旅には関係ないんです。ついさっきまで森にいたのに。そこへ戻れたらいいのに」

<a id="LG-03-024"></a>

**LG-03-024**

<!-- EN:LG-03-024 -->
“You might make a joke on *that*,” said the little voice close to her ear: “something about ‘you *would* if you could,’ you know.”
<!-- /EN:LG-03-024 -->

> 「*それで*しゃれが作れるよ」と、耳元の小さな声が言った。「ほら、『できるものなら、そうしたい——would』とかさ」

> **訳注：** 直前の wood「森」と would の同音を使おうとしている。

<a id="LG-03-025"></a>

**LG-03-025**

<!-- EN:LG-03-025 -->
“Don’t tease so,” said Alice, looking about in vain to see where the voice came from; “if you’re so anxious to have a joke made, why don’t you make one yourself?”
<!-- /EN:LG-03-025 -->

> 「そんなにうるさくしないで」とアリスは言い、声がどこから来るのか、あたりを見回したが、見つからなかった。「そんなしゃれを作ってほしいなら、自分で作ったらどうなの？」

<a id="LG-03-026"></a>

**LG-03-026**

<!-- EN:LG-03-026 -->
The little voice sighed deeply: it was *very* unhappy, evidently, and Alice would have said something pitying to comfort it, “If it would only sigh like other people!” she thought. But this was such a wonderfully small sigh, that she wouldn’t have heard it at all, if it hadn’t come *quite* close to her ear. The consequence of this was that it tickled her ear very much, and quite took off her thoughts from the unhappiness of the poor little creature.
<!-- /EN:LG-03-026 -->

> 小さな声は、深いため息をついた。どうやら、*とても*悲しいらしかった。アリスも、いたわる言葉を何か言って、慰めてあげたいところだった。「ほかの人みたいに、ため息をついてくれさえすればね！」と思った。けれど、それは驚くほど小さなため息で、耳の*すぐ*そばでつかなければ、まったく聞こえなかったはずだった。その結果、耳がとてもくすぐったくなり、かわいそうな小さな生き物の悲しさなど、すっかり頭から追い出されてしまった。

<a id="LG-03-027"></a>

**LG-03-027**

<!-- EN:LG-03-027 -->
“I know you are a friend,” the little voice went on; “a dear friend, and an old friend. And you won’t hurt me, though I *am* an insect.”
<!-- /EN:LG-03-027 -->

> 「君は友達だって、わかっているよ」と小さな声は続けた。「大切な友達、昔からの友達だ。ぼくが虫*だからって*、ひどいことはしないよね」

<a id="LG-03-028"></a>

**LG-03-028**

<!-- EN:LG-03-028 -->
“What kind of insect?” Alice inquired a little anxiously. What she really wanted to know was, whether it could sting or not, but she thought this wouldn’t be quite a civil question to ask.
<!-- /EN:LG-03-028 -->

> 「どんな虫なの？」とアリスは少し心配そうに聞いた。本当に知りたいのは、刺すのかどうかということだったが、それを聞くのは、あまり礼儀正しい質問ではないと思ったのだ。

<a id="LG-03-029"></a>

**LG-03-029**

<!-- EN:LG-03-029 -->
“What, then you don’t—” the little voice began, when it was drowned by a shrill scream from the engine, and everybody jumped up in alarm, Alice among the rest.
<!-- /EN:LG-03-029 -->

> 「何だ、じゃあ、君は——」と小さな声が言いかけたが、そのとき、機関車の甲高い叫び声にかき消された。みんなびっくりして飛び上がり、アリスも一緒に飛び上がった。

<a id="LG-03-030"></a>

**LG-03-030**

<!-- EN:LG-03-030 -->
The Horse, who had put his head out of the window, quietly drew it in and said, “It’s only a brook we have to jump over.” Everybody seemed satisfied with this, though Alice felt a little nervous at the idea of trains jumping at all. “However, it’ll take us into the Fourth Square, that’s some comfort!” she said to herself. In another moment she felt the carriage rise straight up into the air, and in her fright she caught at the thing nearest to her hand, which happened to be the Goat’s beard.
<!-- /EN:LG-03-030 -->

> 窓の外へ頭を出していた馬が、静かに頭を引っ込めて言った。「ただ、小川を飛び越えなくちゃならないだけです」みんなは、これで納得したらしかった。けれどアリスは、汽車が跳ぶなどという考えだけで、少し不安になった。「でも、これで第四の升目へ行けるんだから、その点は救いだわ！」と心の中で言った。次の瞬間、客車が空中へまっすぐ上がるのを感じ、怖くなって、手のいちばん近くにあったものにつかまった。それが、たまたまヤギのひげだった。

<a id="LG-03-031"></a>

<!-- EN:LG-03-031 -->
\*      \*      \*      \*      \*      \*      \*  
<!-- /EN:LG-03-031 -->

<a id="LG-03-032"></a>

<!-- EN:LG-03-032 -->
    \*      \*      \*      \*      \*      \*  
<!-- /EN:LG-03-032 -->

<a id="LG-03-033"></a>

<!-- EN:LG-03-033 -->
\*      \*      \*      \*      \*      \*      \*
<!-- /EN:LG-03-033 -->

<a id="LG-03-034"></a>

**LG-03-034**

<!-- EN:LG-03-034 -->
But the beard seemed to melt away as she touched it, and she found herself sitting quietly under a tree—while the Gnat (for that was the insect she had been talking to) was balancing itself on a twig just over her head, and fanning her with its wings.
<!-- /EN:LG-03-034 -->

> ところが、触れるとひげは溶けてしまうようだった。そして気がつけば、アリスは木の下に静かに座っていた。頭のすぐ上の小枝では、ブヨが釣り合いを取りながらとまり、その羽でアリスをあおいでいた（話しかけていた虫は、ブヨだったのだ）。

<a id="LG-03-035"></a>

**LG-03-035**

<!-- EN:LG-03-035 -->
It certainly was a *very* large Gnat: “about the size of a chicken,” Alice thought. Still, she couldn’t feel nervous with it, after they had been talking together so long.
<!-- /EN:LG-03-035 -->

> 確かに、*とても*大きなブヨだった。「鶏くらいの大きさね」とアリスは思った。それでも、あれほど長く話し合ったあとだったから、もう怖がる気にはなれなかった。

<a id="LG-03-036"></a>

**LG-03-036**

<!-- EN:LG-03-036 -->
“—then you don’t like all insects?” the Gnat went on, as quietly as if nothing had happened.
<!-- /EN:LG-03-036 -->

> 「——じゃあ、どんな虫でも好きというわけではないんだね？」とブヨは、何事もなかったように静かに続けた。

<a id="LG-03-037"></a>

**LG-03-037**

<!-- EN:LG-03-037 -->
“I like them when they can talk,” Alice said. “None of them ever talk, where *I* come from.”
<!-- /EN:LG-03-037 -->

> 「お話ができるなら好きよ」とアリスは言った。「*わたしの*来たところでは、虫はちっともお話をしないの」

<a id="LG-03-038"></a>

**LG-03-038**

<!-- EN:LG-03-038 -->
“What sort of insects do you rejoice in, where *you* come from?” the Gnat inquired.
<!-- /EN:LG-03-038 -->

> 「*君の*来たところでは、どんな虫を見て喜ぶの？」とブヨは尋ねた。

<a id="LG-03-039"></a>

**LG-03-039**

<!-- EN:LG-03-039 -->
“I don’t *rejoice* in insects at all,” Alice explained, “because I’m rather afraid of them—at least the large kinds. But I can tell you the names of some of them.”
<!-- /EN:LG-03-039 -->

> 「虫を見ても、別に*喜びはしない*のよ」とアリスは説明した。「ちょっと怖いから。少なくとも、大きい種類はね。でも、いくつかなら名前を言えるわ」

<a id="LG-03-040"></a>

**LG-03-040**

<!-- EN:LG-03-040 -->
“Of course they answer to their names?” the Gnat remarked carelessly.
<!-- /EN:LG-03-040 -->

> 「もちろん、名前を呼べば返事をするんだね？」とブヨは何気なく言った。

<a id="LG-03-041"></a>

**LG-03-041**

<!-- EN:LG-03-041 -->
“I never knew them to do it.”
<!-- /EN:LG-03-041 -->

> 「返事をしたのは、聞いたことがないわ」

<a id="LG-03-042"></a>

**LG-03-042**

<!-- EN:LG-03-042 -->
“What’s the use of their having names,” the Gnat said, “if they won’t answer to them?”
<!-- /EN:LG-03-042 -->

> 「名前を呼んでも返事をしないなら」とブヨは言った。「名前があることに、何の役が立つの？」

<a id="LG-03-043"></a>

**LG-03-043**

<!-- EN:LG-03-043 -->
“No use to *them*,” said Alice; “but it’s useful to the people who name them, I suppose. If not, why do things have names at all?”
<!-- /EN:LG-03-043 -->

> 「*虫には*役立たないわね」とアリスは言った。「でも、名前をつける人には便利なんじゃないかしら。そうでなければ、そもそも物にどうして名前があるの？」

<a id="LG-03-044"></a>

**LG-03-044**

<!-- EN:LG-03-044 -->
“I can’t say,” the Gnat replied. “Further on, in the wood down there, they’ve got no names—however, go on with your list of insects: you’re wasting time.”
<!-- /EN:LG-03-044 -->

> 「それは、ぼくには言えないな」とブヨは答えた。「もっと先の、あそこの森の中では、名前はないよ。でも、虫の続きを言って。時間を無駄にしているよ」

<a id="LG-03-045"></a>

**LG-03-045**

<!-- EN:LG-03-045 -->
“Well, there’s the Horse-fly,” Alice began, counting off the names on her fingers.
<!-- /EN:LG-03-045 -->

> 「ええと、アブ——ホースフライがいるわね」とアリスは言いはじめ、指を折って名前を数えた。

<a id="LG-03-046"></a>

**LG-03-046**

<!-- EN:LG-03-046 -->
“All right,” said the Gnat: “half way up that bush, you’ll see a Rocking-horse-fly, if you look. It’s made entirely of wood, and gets about by swinging itself from branch to branch.”
<!-- /EN:LG-03-046 -->

> 「よろしい」とブヨは言った。「あの茂みの真ん中あたりを見れば、木馬アブ——ロッキングホースフライが見えるよ。全部木でできていて、枝から枝へ、体を揺らして移っていくんだ」

> **訳注：** horse-fly「アブ」の horse「馬」を rocking-horse「揺り木馬」に置き換えた虫。

<a id="LG-03-047"></a>

**LG-03-047**

<!-- EN:LG-03-047 -->
“What does it live on?” Alice asked, with great curiosity.
<!-- /EN:LG-03-047 -->

> 「何を食べて生きているの？」とアリスは、たいそう興味深そうに聞いた。

<a id="LG-03-048"></a>

**LG-03-048**

<!-- EN:LG-03-048 -->
“Sap and sawdust,” said the Gnat. “Go on with the list.”
<!-- /EN:LG-03-048 -->

> 「樹液と、おがくず」とブヨは言った。「続きをどうぞ」

<a id="LG-03-049"></a>

**LG-03-049**

<!-- EN:LG-03-049 -->
Alice looked up at the Rocking-horse-fly with great interest, and made up her mind that it must have been just repainted, it looked so bright and sticky; and then she went on.
<!-- /EN:LG-03-049 -->

> アリスは大いに興味をひかれ、木馬アブを見上げた。あまりにつやつやして、べたついていそうだったので、きっと塗り直したばかりなのだと思った。それから、話を続けた。

<a id="LG-03-050"></a>

**LG-03-050**

<!-- EN:LG-03-050 -->
“And there’s the Dragon-fly.”
<!-- /EN:LG-03-050 -->

> 「それから、トンボ——ドラゴンフライもいるわ」

<a id="LG-03-051"></a>

**LG-03-051**

<!-- EN:LG-03-051 -->
“Look on the branch above your head,” said the Gnat, “and there you’ll find a snap-dragon-fly. Its body is made of plum-pudding, its wings of holly-leaves, and its head is a raisin burning in brandy.”
<!-- /EN:LG-03-051 -->

> 「頭の上の枝を見てごらん」とブヨは言った。「そこにいるのは、スナップドラゴントンボ。胴体はプラムプディング、羽はヒイラギの葉っぱでできていて、頭はブランデーの中で燃えている干しブドウなんだ」

> **訳注：** dragon-fly「トンボ」を snap-dragon と組み合わせている。snap-dragon は、燃やしたブランデーから干しブドウを取るクリスマスの遊び。

<a id="LG-03-052"></a>

**LG-03-052**

<!-- EN:LG-03-052 -->
“And what does it live on?”
<!-- /EN:LG-03-052 -->

> 「それは、何を食べて生きているの？」

<a id="LG-03-053"></a>

**LG-03-053**

<!-- EN:LG-03-053 -->
“Frumenty and mince pie,” the Gnat replied; “and it makes its nest in a Christmas box.”
<!-- /EN:LG-03-053 -->

> 「小麦のミルク煮とミンスパイ」とブヨは答えた。「巣は、クリスマスの贈り物箱に作るんだよ」

<a id="LG-03-054"></a>

**LG-03-054**

<!-- EN:LG-03-054 -->
“And then there’s the Butterfly,” Alice went on, after she had taken a good look at the insect with its head on fire, and had thought to herself, “I wonder if that’s the reason insects are so fond of flying into candles—because they want to turn into Snap-dragon-flies!”
<!-- /EN:LG-03-054 -->

> 頭に火のついた虫をじっくり見て、「虫がろうそくの火へ飛び込むのが好きなのは、これが理由かしら。スナップドラゴントンボになりたいから！」と心の中で考えてから、アリスは続けた。「それから、チョウ——バタフライがいるわ」

<a id="LG-03-055"></a>

**LG-03-055**

<!-- EN:LG-03-055 -->
“Crawling at your feet,” said the Gnat (Alice drew her feet back in some alarm), “you may observe a Bread-and-Butterfly. Its wings are thin slices of Bread-and-butter, its body is a crust, and its head is a lump of sugar.”
<!-- /EN:LG-03-055 -->

> 「君の足元をはっているのが」とブヨは言った（アリスは少しぎょっとして、足を引っ込めた）。「バターつきパンチョウだよ。羽はバターを塗った薄切りパン、胴体はパンの耳、頭は砂糖の塊でできているんだ」

> **訳注：** butterfly「チョウ」を bread-and-butter「バターつきパン」と組み合わせた Bread-and-Butterfly。

<a id="LG-03-056"></a>

**LG-03-056**

<!-- EN:LG-03-056 -->
“And what does *it* live on?”
<!-- /EN:LG-03-056 -->

> 「それで、*その虫*は何を食べて生きているの？」

<a id="LG-03-057"></a>

**LG-03-057**

<!-- EN:LG-03-057 -->
“Weak tea with cream in it.”
<!-- /EN:LG-03-057 -->

> 「クリームを入れた、薄い紅茶」

<a id="LG-03-058"></a>

**LG-03-058**

<!-- EN:LG-03-058 -->
A new difficulty came into Alice’s head. “Supposing it couldn’t find any?” she suggested.
<!-- /EN:LG-03-058 -->

> アリスの頭に、新しい問題が浮かんだ。「もし、それを見つけられなかったら？」と問いかけた。

<a id="LG-03-059"></a>

**LG-03-059**

<!-- EN:LG-03-059 -->
“Then it would die, of course.”
<!-- /EN:LG-03-059 -->

> 「そのときは死ぬさ、もちろん」

<a id="LG-03-060"></a>

**LG-03-060**

<!-- EN:LG-03-060 -->
“But that must happen very often,” Alice remarked thoughtfully.
<!-- /EN:LG-03-060 -->

> 「でも、そんなことは、しょっちゅう起こるでしょうね」とアリスは考え込みながら言った。

<a id="LG-03-061"></a>

**LG-03-061**

<!-- EN:LG-03-061 -->
“It always happens,” said the Gnat.
<!-- /EN:LG-03-061 -->

> 「いつも起こるよ」とブヨは言った。

<a id="LG-03-062"></a>

**LG-03-062**

<!-- EN:LG-03-062 -->
After this, Alice was silent for a minute or two, pondering. The Gnat amused itself meanwhile by humming round and round her head: at last it settled again and remarked, “I suppose you don’t want to lose your name?”
<!-- /EN:LG-03-062 -->

> これを聞いて、アリスは一、二分、黙って考え込んだ。そのあいだブヨは、アリスの頭の周りをぶんぶん飛び回って楽しんでいたが、やがてまたとまって言った。「君は自分の名前をなくしたくはないだろうね？」

<a id="LG-03-063"></a>

**LG-03-063**

<!-- EN:LG-03-063 -->
“No, indeed,” Alice said, a little anxiously.
<!-- /EN:LG-03-063 -->

> 「ええ、もちろん」とアリスは少し心配そうに言った。

<a id="LG-03-064"></a>

**LG-03-064**

<!-- EN:LG-03-064 -->
“And yet I don’t know,” the Gnat went on in a careless tone: “only think how convenient it would be if you could manage to go home without it! For instance, if the governess wanted to call you to your lessons, she would call out ‘come here—,’ and there she would have to leave off, because there wouldn’t be any name for her to call, and of course you wouldn’t have to go, you know.”
<!-- /EN:LG-03-064 -->

> 「でも、どうかな」とブヨは何気ない調子で続けた。「名前を置いて家へ帰れたら、どれほど便利か考えてごらんよ！　たとえば家庭教師が、勉強に呼ぼうとしても、『こちらへいらっしゃい、——』と言ったところで止まってしまうだろう。呼ぶための名前がないんだからね。そうすれば、当然、君は行かなくていいんだよ」

<a id="LG-03-065"></a>

**LG-03-065**

<!-- EN:LG-03-065 -->
“That would never do, I’m sure,” said Alice: “the governess would never think of excusing me lessons for that. If she couldn’t remember my name, she’d call me ‘Miss!’ as the servants do.”
<!-- /EN:LG-03-065 -->

> 「それは、絶対にだめだと思うわ」とアリスは言った。「家庭教師の先生が、そんなことで勉強を免除してくれるはずはないもの。名前を思い出せなければ、召使いたちのように『お嬢様！』って呼ぶわよ」

<a id="LG-03-066"></a>

**LG-03-066**

<!-- EN:LG-03-066 -->
“Well, if she said ‘Miss,’ and didn’t say anything more,” the Gnat remarked, “of course you’d miss your lessons. That’s a joke. I wish *you* had made it.”
<!-- /EN:LG-03-066 -->

> 「そうか。『ミス』と言って、それ以上何も言わなければ」とブヨは言った。「もちろん、君は勉強をミスして、休めるじゃないか。これがしゃれだよ。*君が*言ってくれればよかったのに」

> **訳注：** Miss は女性への呼びかけ、miss one’s lessons は「授業に出ない・授業を逃す」。同じ音を使ったしゃれ。

<a id="LG-03-067"></a>

**LG-03-067**

<!-- EN:LG-03-067 -->
“Why do you wish *I* had made it?” Alice asked. “It’s a very bad one.”
<!-- /EN:LG-03-067 -->

> 「どうして、*わたしが*言ったほうがいいの？」とアリスは聞いた。「ひどくつまらないしゃれよ」

<a id="LG-03-068"></a>

**LG-03-068**

<!-- EN:LG-03-068 -->
But the Gnat only sighed deeply, while two large tears came rolling down its cheeks.
<!-- /EN:LG-03-068 -->

> けれどブヨは、ただ深いため息をつくだけだった。その頬を、大粒の涙がふたつ、ころころと流れ落ちた。

<a id="LG-03-069"></a>

**LG-03-069**

<!-- EN:LG-03-069 -->
“You shouldn’t make jokes,” Alice said, “if it makes you so unhappy.”
<!-- /EN:LG-03-069 -->

> 「そんなに悲しくなるなら」とアリスは言った。「しゃれなんか言わないほうがいいわ」

<a id="LG-03-070"></a>

**LG-03-070**

<!-- EN:LG-03-070 -->
Then came another of those melancholy little sighs, and this time the poor Gnat really seemed to have sighed itself away, for, when Alice looked up, there was nothing whatever to be seen on the twig, and, as she was getting quite chilly with sitting still so long, she got up and walked on.
<!-- /EN:LG-03-070 -->

> するとまた、あのもの悲しい小さなため息が聞こえた。今度は、かわいそうなブヨは本当に、ため息をついて、自分まで消してしまったようだった。アリスが見上げると、小枝には何もいなくなっていたからだ。長いことじっと座っていて、すっかり肌寒くなっていたので、アリスは立ち上がり、先へ歩き出した。

<a id="LG-03-071"></a>

**LG-03-071**

<!-- EN:LG-03-071 -->
She very soon came to an open field, with a wood on the other side of it: it looked much darker than the last wood, and Alice felt a *little* timid about going into it. However, on second thoughts, she made up her mind to go on: “for I certainly won’t go *back*,” she thought to herself, and this was the only way to the Eighth Square.
<!-- /EN:LG-03-071 -->

> すぐに開けた野原に出ると、その向こう側に森があった。さっきの森より、ずっと暗く見え、アリスは入るのが*少し*怖かった。けれど、考え直して、先へ進むことに決めた。「だって、絶対に*後戻り*はしないもの」と心の中で思ったし、第八の升目へ行くには、この道しかなかったのだ。

<a id="LG-03-072"></a>

**LG-03-072**

<!-- EN:LG-03-072 -->
“This must be the wood,” she said thoughtfully to herself, “where things have no names. I wonder what’ll become of *my* name when I go in? I shouldn’t like to lose it at all—because they’d have to give me another, and it would be almost certain to be an ugly one. But then the fun would be trying to find the creature that had got my old name! That’s just like the advertisements, you know, when people lose dogs—‘*answers to the name of “Dash:” had on a brass collar*’—just fancy calling everything you met ‘Alice,’ till one of them answered! Only they wouldn’t answer at all, if they were wise.”
<!-- /EN:LG-03-072 -->

> 「これが、きっと、物に名前のない森なのね」とアリスは、考えながら独り言を言った。「入ったら、*わたしの*名前はどうなるのかしら？　なくすのは、絶対に嫌だわ。別の名前をつけてもらわなくちゃならなくなるし、きっと、ほとんど間違いなく、変な名前になるもの。でも、わたしの前の名前を持っていった生き物を捜すのは、面白いでしょうね！　犬をなくした人の広告と、そっくりよ。『*「ダッシュ」と呼べば返事をします。真鍮の首輪をしていました*』っていう、あれね。出会うものを何でも『アリス』って呼んで、そのうちのひとつが返事をするまで続けるところを考えてみて！　もっとも、賢ければ、誰も返事なんかしないでしょうけれど」

<a id="LG-03-073"></a>

**LG-03-073**

<!-- EN:LG-03-073 -->
She was rambling on in this way when she reached the wood: it looked very cool and shady. “Well, at any rate it’s a great comfort,” she said as she stepped under the trees, “after being so hot, to get into the—into *what*?” she went on, rather surprised at not being able to think of the word. “I mean to get under the—under the—under *this*, you know!” putting her hand on the trunk of the tree. “What *does* it call itself, I wonder? I do believe it’s got no name—why, to be sure it hasn’t!”
<!-- /EN:LG-03-073 -->

> こんなふうに、とりとめもなく話しながら、森に着いた。そこは、ひどく涼しげな木陰だった。「まあ、とにかく、ありがたいことだわ」とアリスは、木々の下へ足を踏み入れて言った。「あんなに暑い思いをしたあとで、この——この*何*へ入れるなんて？」と続け、言葉が浮かばないことに、かなり驚いた。「つまり、この下へ——この下へ——*これ*の下へ入れるなんて、っていうことよ！」そう言って、木の幹に手を置いた。「いったい、*何て*名前なのかしら？　名前がないみたい。まあ、本当に、ないんだわ！」

<a id="LG-03-074"></a>

**LG-03-074**

<!-- EN:LG-03-074 -->
She stood silent for a minute, thinking: then she suddenly began again. “Then it really *has* happened, after all! And now, who am I? I *will* remember, if I can! I’m determined to do it!” But being determined didn’t help much, and all she could say, after a great deal of puzzling, was, “L, I *know* it begins with L!”
<!-- /EN:LG-03-074 -->

> しばらく黙って立ち、考えていたが、突然また話しはじめた。「それなら、本当にそうなって*しまった*のね！　じゃあ今、わたしは誰なの？　できるものなら、*絶対に*思い出すわ！　そうすると決めたんだから！」けれど、そう決めることは大して役に立たなかった。あれこれ頭をひねった末に、言えたのは、「Lよ。Lではじまることは*確か*なの！」だけだった。

<a id="LG-03-075"></a>

**LG-03-075**

<!-- EN:LG-03-075 -->
Just then a Fawn came wandering by: it looked at Alice with its large gentle eyes, but didn’t seem at all frightened. “Here then! Here then!” Alice said, as she held out her hand and tried to stroke it; but it only started back a little, and then stood looking at her again.
<!-- /EN:LG-03-075 -->

> ちょうどそのとき、一頭の子鹿が歩いてきた。大きな優しい目でアリスを見たが、少しも怖がってはいないようだった。「さあ、おいで！　おいで！」とアリスは言い、手を差し出してなでようとした。けれど子鹿は、ほんの少しびくっと後ずさりし、それからまた、立ったままアリスを見つめた。

<a id="LG-03-076"></a>

**LG-03-076**

<!-- EN:LG-03-076 -->
“What do you call yourself?” the Fawn said at last. Such a soft sweet voice it had!
<!-- /EN:LG-03-076 -->

> 「あなたは、自分を何て呼ぶの？」と子鹿が、ようやく言った。何て柔らかくて、優しい声だったことか！

<a id="LG-03-077"></a>

**LG-03-077**

<!-- EN:LG-03-077 -->
“I wish I knew!” thought poor Alice. She answered, rather sadly, “Nothing, just now.”
<!-- /EN:LG-03-077 -->

> 「わかればいいのに！」と、かわいそうにアリスは思った。そして、かなり悲しそうに答えた。「今のところは、何とも」

<a id="LG-03-078"></a>

**LG-03-078**

<!-- EN:LG-03-078 -->
“Think again,” it said: “that won’t do.”
<!-- /EN:LG-03-078 -->

> 「もう一度考えて」と子鹿は言った。「それじゃだめよ」

<a id="LG-03-079"></a>

**LG-03-079**

<!-- EN:LG-03-079 -->
Alice thought, but nothing came of it. “Please, would you tell me what *you* call yourself?” she said timidly. “I think that might help a little.”
<!-- /EN:LG-03-079 -->

> アリスは考えたけれど、何も浮かばなかった。「お願い、*あなた*は自分を何て呼ぶのか、教えてくださらない？」と、おずおずと言った。「そうすれば、少しは助けになる気がするの」

<a id="LG-03-080"></a>

**LG-03-080**

<!-- EN:LG-03-080 -->
“I’ll tell you, if you’ll move a little further on,” the Fawn said. “I can’t remember here.”
<!-- /EN:LG-03-080 -->

> 「もう少し先へ行ってくれれば、教えるわ」と子鹿は言った。「ここでは思い出せないの」

<a id="LG-03-081"></a>

**LG-03-081**

<!-- EN:LG-03-081 -->
So they walked on together though the wood, Alice with her arms clasped lovingly round the soft neck of the Fawn, till they came out into another open field, and here the Fawn gave a sudden bound into the air, and shook itself free from Alice’s arms. “I’m a Fawn!” it cried out in a voice of delight, “and, dear me! you’re a human child!” A sudden look of alarm came into its beautiful brown eyes, and in another moment it had darted away at full speed.
<!-- /EN:LG-03-081 -->

> そこで、ふたりは森の中を一緒に歩いていった。アリスは子鹿の柔らかな首に、いとおしそうに両腕を回していた。やがて別の開けた野原へ出ると、子鹿は突然、空中へ跳び上がり、アリスの腕を振りほどいた。「わたし、子鹿だわ！」と嬉しそうな声で叫んだ。「それに、まあ！　あなたは、人間の子供じゃない！」美しい茶色の目に、突然、怯えが浮かび、次の瞬間には、全速力で走り去ってしまった。

<a id="LG-03-082"></a>

**LG-03-082**

<!-- EN:LG-03-082 -->
Alice stood looking after it, almost ready to cry with vexation at having lost her dear little fellow-traveller so suddenly. “However, I know my name now.” she said, “that’s *some* comfort. Alice—Alice—I won’t forget it again. And now, which of these finger-posts ought I to follow, I wonder?”
<!-- /EN:LG-03-082 -->

> アリスは、そのあとを立ったまま見送った。かわいい小さな旅の仲間を、あまりに突然失ってしまい、悔しさに泣きだしそうになった。「でも、今は自分の名前がわかるわ」と言った。「それは*少しは*慰めになる。アリス、アリス。もう二度と忘れないわ。それで、今度は、この道しるべのどちらに従えばいいのかしら？」

<a id="LG-03-083"></a>

**LG-03-083**

<!-- EN:LG-03-083 -->
It was not a very difficult question to answer, as there was only one road through the wood, and the two finger-posts both pointed along it. “I’ll settle it,” Alice said to herself, “when the road divides and they point different ways.”
<!-- /EN:LG-03-083 -->

> これは、さほど答えにくい問いではなかった。森を通る道は一本しかなく、ふたつの道しるべは、両方ともその道を指していたからだ。「道が分かれて、それぞれが違う方向を指したら、そのとき決めましょう」とアリスは独り言を言った。

<a id="LG-03-084"></a>

**LG-03-084**

<!-- EN:LG-03-084 -->
But this did not seem likely to happen. She went on and on, a long way, but wherever the road divided there were sure to be two finger-posts pointing the same way, one marked “TO TWEEDLEDUM’S HOUSE” and the other “TO THE HOUSE OF TWEEDLEDEE.”
<!-- /EN:LG-03-084 -->

> けれど、そうなる様子はなかった。アリスは先へ先へ、ずいぶん遠くまで歩いたが、どこで道が分かれても、必ずふたつの道しるべが同じ方向を指していた。片方には「トゥイードルダムの家へ」、もう片方には「トゥイードルディーの家はこちら」と書いてあった。

<a id="LG-03-085"></a>

**LG-03-085**

<!-- EN:LG-03-085 -->
“I do believe,” said Alice at last, “that they live in the same house! I wonder I never thought of that before—But I can’t stay there long. I’ll just call and say ‘how d’you do?’ and ask them the way out of the wood. If I could only get to the Eighth Square before it gets dark!” So she wandered on, talking to herself as she went, till, on turning a sharp corner, she came upon two fat little men, so suddenly that she could not help starting back, but in another moment she recovered herself, feeling sure that they must be
<!-- /EN:LG-03-085 -->

> 「きっと、ふたりは同じ家に住んでいるんだわ！」とアリスは、ついに言った。「どうして、今まで思いつかなかったのかしら。でも、長居はできないわ。ちょっと寄って『ごきげんよう』って挨拶して、森から出る道を聞くだけにしましょう。暗くなる前に、第八の升目へ着けたらいいのに！」そうして、歩きながら独り言を言い、先へ進んでいった。鋭く曲がった角を曲がったとたん、小太りの小さな男がふたり、目の前に現れた。あまりに突然だったので、思わず後ずさりしたが、すぐに落ち着きを取り戻した。このふたりこそ、きっと——

> **訳注：** 原文の文はここで途切れ、次の章題「Tweedledum And Tweedledee」へ続く形になっている。

[章目次へ戻る](#book-top)

---

<a id="lg-chapter-04"></a>

## 第4章　トゥイードルダムとトゥイードルディー

### CHAPTER IV. Tweedledum And Tweedledee

<a id="LG-04-001"></a>

**LG-04-001**

<!-- EN:LG-04-001 -->
They were standing under a tree, each with an arm round the other’s neck, and Alice knew which was which in a moment, because one of them had “DUM” embroidered on his collar, and the other “DEE.” “I suppose they’ve each got ‘TWEEDLE’ round at the back of the collar,” she said to herself.
<!-- /EN:LG-04-001 -->

> ふたりは木の下で、お互いの首に片腕を回して立っていた。どちらがどちらか、アリスにはすぐわかった。片方の襟には「ダム」、もう片方の襟には「ディー」と刺繍してあったからだ。「きっと、襟の後ろ側に『トゥイードル』って書いてあるんだわ」とアリスは独り言を言った。

<a id="LG-04-002"></a>

**LG-04-002**

<!-- EN:LG-04-002 -->
They stood so still that she quite forgot they were alive, and she was just looking round to see if the word ‘TWEEDLE’ was written at the back of each collar, when she was startled by a voice coming from the one marked “DUM.”
<!-- /EN:LG-04-002 -->

> ふたりがあまりにじっとしているので、アリスは生きていることをすっかり忘れてしまった。それぞれの襟の後ろに「トゥイードル」と書いてあるか、回り込んで見ようとした、ちょうどそのとき、「ダム」と記されたほうから声がして、びっくりした。

<a id="LG-04-003"></a>

**LG-04-003**

<!-- EN:LG-04-003 -->
“If you think we’re wax-works,” he said, “you ought to pay, you know. Wax-works weren’t made to be looked at for nothing, nohow!”
<!-- /EN:LG-04-003 -->

> 「ぼくたちが、ろう人形だと思うなら」と彼は言った。「お金を払うべきだよ。ろう人形は、ただで見せるために作ったんじゃないんだから。どうあってもね！」

<a id="LG-04-004"></a>

**LG-04-004**

<!-- EN:LG-04-004 -->
“Contrariwise,” added the one marked “DEE,” “if you think we’re alive, you ought to speak.”
<!-- /EN:LG-04-004 -->

> 「それとは逆に」と「ディー」と記されたほうが付け加えた。「ぼくたちが生きていると思うなら、話しかけるべきだよ」

<a id="LG-04-005"></a>

**LG-04-005**

<!-- EN:LG-04-005 -->
“I’m sure I’m very sorry,” was all Alice could say; for the words of the old song kept ringing through her head like the ticking of a clock, and she could hardly help saying them out loud:—
<!-- /EN:LG-04-005 -->

> 「本当に、ごめんなさい」としか、アリスには言えなかった。頭の中では、古い歌の言葉が時計の刻む音のように、ずっと鳴り響いていて、声に出してしまうのを、どうにかこらえていたからだ。——

<a id="LG-04-006"></a>

**LG-04-006**

<!-- EN:LG-04-006 -->
“Tweedledum and Tweedledee  
    Agreed to have a battle;  
For Tweedledum said Tweedledee  
    Had spoiled his nice new rattle.  
<!-- /EN:LG-04-006 -->

> 「トゥイードルダムとトゥイードルディーは、  
> 　　ひと勝負することに決めました。  
> ダムが言うには、ディーのやつが、  
> 　　すてきな新品のガラガラを壊したから。

<a id="LG-04-007"></a>

**LG-04-007**

<!-- EN:LG-04-007 -->
Just then flew down a monstrous crow,  
    As black as a tar-barrel;  
Which frightened both the heroes so,  
    They quite forgot their quarrel.”
<!-- /EN:LG-04-007 -->

> ちょうどそのとき、大きな大きなカラスが降りてきた。  
> 　　タールの樽のように真っ黒なカラス。  
> ふたりの勇士は、あんまり怖くて、  
> 　　けんかのことなど、すっかり忘れてしまいました」

<a id="LG-04-008"></a>

**LG-04-008**

<!-- EN:LG-04-008 -->
“I know what you’re thinking about,” said Tweedledum: “but it isn’t so, nohow.”
<!-- /EN:LG-04-008 -->

> 「何を考えているか、わかっているよ」とトゥイードルダムは言った。「でも、そうじゃないんだ。どうあってもね」

<a id="LG-04-009"></a>

**LG-04-009**

<!-- EN:LG-04-009 -->
“Contrariwise,” continued Tweedledee, “if it was so, it might be; and if it were so, it would be; but as it isn’t, it ain’t. That’s logic.”
<!-- /EN:LG-04-009 -->

> 「それとは逆に」とトゥイードルディーは続けた。「そうだったのなら、そうかもしれないし、もしそうなのなら、そうだろう。けれど、そうじゃないんだから、そうじゃない。これが論理さ」

> **訳注：** if it was so / if it were so と might / would をずらしながら、最後は「そうではないから、そうではない」と結ぶ。原文の条件表現と反復を残した。

<a id="LG-04-010"></a>

**LG-04-010**

<!-- EN:LG-04-010 -->
“I was thinking,” Alice said very politely, “which is the best way out of this wood: it’s getting so dark. Would you tell me, please?”
<!-- /EN:LG-04-010 -->

> 「わたしが考えていたのは」とアリスは、とても丁寧に言った。「この森から出るには、どの道がいちばんいいか、ということです。ずいぶん暗くなってきたので。どうか、教えてくださらない？」

<a id="LG-04-011"></a>

**LG-04-011**

<!-- EN:LG-04-011 -->
But the little men only looked at each other and grinned.
<!-- /EN:LG-04-011 -->

> けれど、小さな男たちは、顔を見合わせてにやにやするばかりだった。

<a id="LG-04-012"></a>

**LG-04-012**

<!-- EN:LG-04-012 -->
They looked so exactly like a couple of great schoolboys, that Alice couldn’t help pointing her finger at Tweedledum, and saying “First Boy!”
<!-- /EN:LG-04-012 -->

> ふたりの様子が、体の大きな男子生徒ふたりに、あまりにそっくりだったので、アリスはついトゥイードルダムを指さして、「一番の生徒！」と言ってしまった。

<a id="LG-04-013"></a>

**LG-04-013**

<!-- EN:LG-04-013 -->
“Nohow!” Tweedledum cried out briskly, and shut his mouth up again with a snap.
<!-- /EN:LG-04-013 -->

> 「とんでもない、どうあっても！」とトゥイードルダムは元気よく叫ぶと、またぱちんと口を閉じた。

<a id="LG-04-014"></a>

**LG-04-014**

<!-- EN:LG-04-014 -->
“Next Boy!” said Alice, passing on to Tweedledee, though she felt quite certain he would only shout out “Contrariwise!” and so he did.
<!-- /EN:LG-04-014 -->

> 「次の生徒！」とアリスは言い、トゥイードルディーのほうへ移った。ただ「それとは逆に！」と叫ぶだけだろうと、ほとんど確信していたが、まさにそのとおりだった。

<a id="LG-04-015"></a>

**LG-04-015**

<!-- EN:LG-04-015 -->
“You’ve been wrong!” cried Tweedledum. “The first thing in a visit is to say ‘How d’ye do?’ and shake hands!” And here the two brothers gave each other a hug, and then they held out the two hands that were free, to shake hands with her.
<!-- /EN:LG-04-015 -->

> 「間違っているよ！」とトゥイードルダムは叫んだ。「お訪ねしたら、最初に『ごきげんよう』と言って、握手するものだよ！」そう言って、兄弟は互いにぎゅっと抱き合い、それから空いているほうの手をそれぞれ差し出して、アリスと握手しようとした。

<a id="LG-04-016"></a>

**LG-04-016**

<!-- EN:LG-04-016 -->
Alice did not like shaking hands with either of them first, for fear of hurting the other one’s feelings; so, as the best way out of the difficulty, she took hold of both hands at once: the next moment they were dancing round in a ring. This seemed quite natural (she remembered afterwards), and she was not even surprised to hear music playing: it seemed to come from the tree under which they were dancing, and it was done (as well as she could make it out) by the branches rubbing one across the other, like fiddles and fiddle-sticks.
<!-- /EN:LG-04-016 -->

> どちらかと先に握手をすると、もうひとりの気持ちを傷つけるかもしれないと思い、アリスはそれを避けたかった。そこで、この難問を解く最善の方法として、両方の手を同時につかんだ。次の瞬間には、三人は輪になって踊っていた。これは、とても自然なことに思えた（あとになって、アリスはそう思い出した）。音楽が鳴りはじめたのを聞いても、少しも驚かなかった。音は、三人が踊っている木から聞こえてくるようだった。アリスにわかったかぎりでは、枝と枝が、バイオリンと弓のように、互いにこすれ合って出している音らしかった。

<a id="LG-04-017"></a>

**LG-04-017**

<!-- EN:LG-04-017 -->
“But it certainly *was* funny,” (Alice said afterwards, when she was telling her sister the history of all this,) “to find myself singing ‘*Here we go round the mulberry bush*.’ I don’t know when I began it, but somehow I felt as if I’d been singing it a long long time!”
<!-- /EN:LG-04-017 -->

> 「でも、気がついたら自分が『*桑の木の周りを、ぐるぐる回ろう*』って歌っていたのは、確かにおかしな*ことだった*わ」と、アリスはあとで、お姉さんにこの一部始終を話したときに言った。「いつ歌いはじめたのかはわからないけれど、何だか、ずっとずっと前から歌っていたような気がしたの！」

<a id="LG-04-018"></a>

**LG-04-018**

<!-- EN:LG-04-018 -->
The other two dancers were fat, and very soon out of breath. “Four times round is enough for one dance,” Tweedledum panted out, and they left off dancing as suddenly as they had begun: the music stopped at the same moment.
<!-- /EN:LG-04-018 -->

> ほかのふたりの踊り手は太っていたので、たちまち息が切れた。「一度の踊りなら、四周で十分だ」とトゥイードルダムは、あえぎながら言った。すると、はじめたときと同じくらい唐突に、踊りが終わった。音楽も、ぴったり同じ瞬間に止まった。

<a id="LG-04-019"></a>

**LG-04-019**

<!-- EN:LG-04-019 -->
Then they let go of Alice’s hands, and stood looking at her for a minute: there was a rather awkward pause, as Alice didn’t know how to begin a conversation with people she had just been dancing with. “It would never do to say ‘How d’ye do?’ *now*,” she said to herself: “we seem to have got beyond that, somehow!”
<!-- /EN:LG-04-019 -->

> それからふたりはアリスの手を放し、しばらく立ったまま見つめた。かなり気まずい沈黙になった。たった今まで一緒に踊っていた人に、どう話を切り出せばいいのか、アリスにはわからなかったからだ。「*今さら*『ごきげんよう』って言うわけには、どうしてもいかないわ」と心の中で言った。「何だか、もうそれは通り越してしまったみたいだもの！」

<a id="LG-04-020"></a>

**LG-04-020**

<!-- EN:LG-04-020 -->
“I hope you’re not much tired?” she said at last.
<!-- /EN:LG-04-020 -->

> 「ずいぶんお疲れになっていませんか？」と、やっとアリスは言った。

<a id="LG-04-021"></a>

**LG-04-021**

<!-- EN:LG-04-021 -->
“Nohow. And thank you *very* much for asking,” said Tweedledum.
<!-- /EN:LG-04-021 -->

> 「とんでもない、どうあっても。それに、聞いてくれて、*どうも*ありがとう」とトゥイードルダムは言った。

<a id="LG-04-022"></a>

**LG-04-022**

<!-- EN:LG-04-022 -->
“So *much* obliged!” added Tweedledee. “You like poetry?”
<!-- /EN:LG-04-022 -->

> 「*大変*ありがたいね！」とトゥイードルディーも付け加えた。「詩は好き？」

<a id="LG-04-023"></a>

**LG-04-023**

<!-- EN:LG-04-023 -->
“Ye-es, pretty well—*some* poetry,” Alice said doubtfully. “Would you tell me which road leads out of the wood?”
<!-- /EN:LG-04-023 -->

> 「ええ、まあ、なかなか——*詩による*けれど」とアリスは、ためらいがちに言った。「森から出られるのはどの道か、教えてくださらない？」

<a id="LG-04-024"></a>

**LG-04-024**

<!-- EN:LG-04-024 -->
“What shall I repeat to her?” said Tweedledee, looking round at Tweedledum with great solemn eyes, and not noticing Alice’s question.
<!-- /EN:LG-04-024 -->

> 「何を聞かせてあげようか？」とトゥイードルディーは言い、大きな真面目くさった目でトゥイードルダムを振り返った。アリスの質問には気づかなかった。

<a id="LG-04-025"></a>

**LG-04-025**

<!-- EN:LG-04-025 -->
“‘*The Walrus and the Carpenter*’ is the longest,” Tweedledum replied, giving his brother an affectionate hug.
<!-- /EN:LG-04-025 -->

> 「『*セイウチと大工*』がいちばん長いよ」とトゥイードルダムは答え、兄弟をいとおしそうに抱き締めた。

<a id="LG-04-026"></a>

**LG-04-026**

<!-- EN:LG-04-026 -->
Tweedledee began instantly:
<!-- /EN:LG-04-026 -->

> トゥイードルディーは、たちまち語りはじめた。

<a id="LG-04-027"></a>

**LG-04-027**

<!-- EN:LG-04-027 -->
“The sun was shining—”
<!-- /EN:LG-04-027 -->

> 「お日様は照っていた——」

<a id="LG-04-028"></a>

**LG-04-028**

<!-- EN:LG-04-028 -->
Here Alice ventured to interrupt him. “If it’s *very* long,” she said, as politely as she could, “would you please tell me first which road—”
<!-- /EN:LG-04-028 -->

> ここでアリスは、思い切って口を挟んだ。「*とても*長いのでしたら」と、できるだけ丁寧に言った。「先に、どの道が——」

<a id="LG-04-029"></a>

**LG-04-029**

<!-- EN:LG-04-029 -->
Tweedledee smiled gently, and began again:
<!-- /EN:LG-04-029 -->

> トゥイードルディーは、優しくほほえんで、またはじめた。

<a id="LG-04-030"></a>

**LG-04-030**

<!-- EN:LG-04-030 -->
“The sun was shining on the sea,  
    Shining with all his might:  
He did his very best to make  
    The billows smooth and bright—  
And this was odd, because it was  
    The middle of the night.  
<!-- /EN:LG-04-030 -->

> 「お日様は海の上に照っていた、  
> 　　力のかぎり、明るく照っていた。  
> 波をなだらかに、きらめかせようと、  
> 　　精いっぱい頑張っていた——  
> けれど、これは妙なこと。なぜなら、  
> 　　真夜中だったのだから。

<a id="LG-04-031"></a>

**LG-04-031**

<!-- EN:LG-04-031 -->
The moon was shining sulkily,  
    Because she thought the sun  
Had got no business to be there  
    After the day was done—  
‘It’s very rude of him,’ she said,  
    ‘To come and spoil the fun!’  
<!-- /EN:LG-04-031 -->

> お月様は、むっつりと照っていた。  
> 　　お日様が、  
> 一日が終わったあとまでそこにいるのは、  
> 　　筋違いだと思ったから——  
> 『本当に、失礼な方ね』とお月様、  
> 　　『やって来て、楽しみを台無しにするなんて！』

<a id="LG-04-032"></a>

**LG-04-032**

<!-- EN:LG-04-032 -->
The sea was wet as wet could be,  
    The sands were dry as dry.  
You could not see a cloud, because  
    No cloud was in the sky:  
No birds were flying over head—  
    There were no birds to fly.  
<!-- /EN:LG-04-032 -->

> 海は濡れるだけ濡れていた、  
> 　　砂は乾くにも乾いていた。  
> 雲がひとつも見えなかったのは、  
> 　　空に雲がなかったから。  
> 頭の上を飛ぶ鳥もいなかった——  
> 　　飛ぶべき鳥がいなかったから。

<a id="LG-04-033"></a>

**LG-04-033**

<!-- EN:LG-04-033 -->
The Walrus and the Carpenter  
    Were walking close at hand;  
They wept like anything to see  
    Such quantities of sand:  
‘If this were only cleared away,’  
    They said, ‘it *would* be grand!’  
<!-- /EN:LG-04-033 -->

> セイウチと大工は、  
> 　　すぐそばを歩いていた。  
> こんなにたくさん砂があるのを見て、  
> 　　ふたりは、ひどく泣いた。  
> 『これを、きれいさっぱり片づけられたら』  
> 　　と言った。『どんなに*すばらしい*だろう！』

<a id="LG-04-034"></a>

**LG-04-034**

<!-- EN:LG-04-034 -->
‘If seven maids with seven mops  
    Swept it for half a year,  
Do you suppose,’ the Walrus said,  
    ‘That they could get it clear?’  
‘I doubt it,’ said the Carpenter,  
    And shed a bitter tear.  
<!-- /EN:LG-04-034 -->

> 『七人の娘が、七本のモップで、  
> 　　半年のあいだ掃いたら、  
> どう思う？』とセイウチは言った。  
> 　　『きれいに片づけられるかな？』  
> 『どうも怪しいね』と大工は言い、  
> 　　つらい涙を、ひと粒こぼした。

<a id="LG-04-035"></a>

**LG-04-035**

<!-- EN:LG-04-035 -->
‘O Oysters, come and walk with us!’  
    The Walrus did beseech.  
‘A pleasant walk, a pleasant talk,  
    Along the briny beach:  
We cannot do with more than four,  
    To give a hand to each.’  
<!-- /EN:LG-04-035 -->

> 『ああ、カキのみなさん、一緒に歩きませんか！』  
> 　　セイウチは、熱心に頼んだ。  
> 『楽しい散歩、楽しいおしゃべり、  
> 　　潮の浜辺に沿ってね。  
> ひとりずつ手をつないであげるには、  
> 　　四人を超えては困ります』

<a id="LG-04-036"></a>

**LG-04-036**

<!-- EN:LG-04-036 -->
The eldest Oyster looked at him.  
    But never a word he said:  
The eldest Oyster winked his eye,  
    And shook his heavy head—  
Meaning to say he did not choose  
    To leave the oyster-bed.  
<!-- /EN:LG-04-036 -->

> いちばん年上のカキは、セイウチを見た。  
> 　　けれど、ひと言も言わなかった。  
> いちばん年上のカキは、目をぱちり、  
> 　　重い頭を横に振った——  
> カキの寝床から出る気はない、と  
> 　　そう伝えるつもりだった。

<a id="LG-04-037"></a>

**LG-04-037**

<!-- EN:LG-04-037 -->
But four young oysters hurried up,  
    All eager for the treat:  
Their coats were brushed, their faces washed,  
    Their shoes were clean and neat—  
And this was odd, because, you know,  
    They hadn’t any feet.  
<!-- /EN:LG-04-037 -->

> けれど、四人の若いカキが駆け寄ってきた。  
> 　　みんな、お楽しみが待ちきれなくて。  
> 上着にはブラシを掛け、顔も洗って、  
> 　　靴はきれいに、こざっぱり——  
> けれど、これは妙なこと。だって、ほら、  
> 　　カキには足がなかったのだから。

<a id="LG-04-038"></a>

**LG-04-038**

<!-- EN:LG-04-038 -->
Four other Oysters followed them,  
    And yet another four;  
And thick and fast they came at last,  
    And more, and more, and more—  
All hopping through the frothy waves,  
    And scrambling to the shore.  
<!-- /EN:LG-04-038 -->

> 別の四人のカキが、そのあとに続いた。  
> 　　それからまた、四人。  
> しまいには、次から次へ、どっとやって来た。  
> 　　もっと、もっと、もっと——  
> みんな、泡立つ波をぴょんぴょん越えて、  
> 　　浜へと、よじ登ってきた。

<a id="LG-04-039"></a>

**LG-04-039**

<!-- EN:LG-04-039 -->
The Walrus and the Carpenter  
    Walked on a mile or so,  
And then they rested on a rock  
    Conveniently low:  
And all the little Oysters stood  
    And waited in a row.  
<!-- /EN:LG-04-039 -->

> セイウチと大工は、  
> 　　一マイルほど歩いた。  
> それから、座るのにちょうどよい、  
> 　　低い岩でひと休み。  
> 小さなカキたちはみんな立ったまま、  
> 　　一列に並んで待っていた。

<a id="LG-04-040"></a>

**LG-04-040**

<!-- EN:LG-04-040 -->
‘The time has come,’ the Walrus said,  
    ‘To talk of many things:  
Of shoes—and ships—and sealing-wax—  
    Of cabbages—and kings—  
And why the sea is boiling hot—  
    And whether pigs have wings.’  
<!-- /EN:LG-04-040 -->

> 『時が来た』とセイウチは言った。  
> 　　『いろいろなことを語る時が。  
> 靴について——船について——封蝋について——  
> 　　キャベツについて——王様について——  
> なぜ海が煮え立つほど熱いのか——  
> 　　そして、ブタに翼はあるのか』

<a id="LG-04-041"></a>

**LG-04-041**

<!-- EN:LG-04-041 -->
‘But wait a bit,’ the Oysters cried,  
    ‘Before we have our chat;  
For some of us are out of breath,  
    And all of us are fat!’  
‘No hurry!’ said the Carpenter.  
    They thanked him much for that.  
<!-- /EN:LG-04-041 -->

> 『でも、ちょっと待ってください』とカキたちは叫んだ。  
> 　　『お話をはじめる前に。  
> 息を切らした者もいますし、  
> 　　みんな太っていますから！』  
> 『急がなくていいよ！』と大工は言った。  
> 　　カキたちは、それに大いに感謝した。

<a id="LG-04-042"></a>

**LG-04-042**

<!-- EN:LG-04-042 -->
‘A loaf of bread,’ the Walrus said,  
    ‘Is what we chiefly need:  
Pepper and vinegar besides  
    Are very good indeed—  
Now if you’re ready Oysters dear,  
    We can begin to feed.’  
<!-- /EN:LG-04-042 -->

> 『ひと塊のパンこそ』とセイウチは言った。  
> 　　『いちばん必要なものだ。  
> そのうえ、コショウと酢があれば、  
> 　　実に結構——  
> さて、かわいいカキのみなさん、支度ができたら、  
> 　　食事をはじめられますよ』

<a id="LG-04-043"></a>

**LG-04-043**

<!-- EN:LG-04-043 -->
‘But not on us!’ the Oysters cried,  
    Turning a little blue,  
‘After such kindness, that would be  
    A dismal thing to do!’  
‘The night is fine,’ the Walrus said  
    ‘Do you admire the view?  
<!-- /EN:LG-04-043 -->

> 『でも、ぼくらを食べないで！』とカキたちは叫んだ。  
> 　　少し青ざめながら。  
> 『あんなに親切にしてくださったあとで、  
> 　　そんなことをするなんて、あんまりです！』  
> 『いい夜ですね』とセイウチは言った。  
> 　　『景色はお気に召しましたか？

<a id="LG-04-044"></a>

**LG-04-044**

<!-- EN:LG-04-044 -->
‘It was so kind of you to come!  
    And you are very nice!’  
The Carpenter said nothing but  
    ‘Cut us another slice:  
I wish you were not quite so deaf—  
    I’ve had to ask you twice!’  
<!-- /EN:LG-04-044 -->

> 『来てくださって、本当にありがとう！  
> 　　それに、あなたがたは、とても結構なお方たち！』  
> 大工は、ただ、こう言うだけだった。  
> 　　『もう一切れ、こっちにも切ってくれ。  
> そう耳が遠くなければ、いいんだが——  
> 　　二度も頼まなくちゃならなかったよ！』

<a id="LG-04-045"></a>

**LG-04-045**

<!-- EN:LG-04-045 -->
‘It seems a shame,’ the Walrus said,  
    ‘To play them such a trick,  
After we’ve brought them out so far,  
    And made them trot so quick!’  
The Carpenter said nothing but  
    ‘The butter’s spread too thick!’  
<!-- /EN:LG-04-045 -->

> 『悪いことのような気がするね』とセイウチは言った。  
> 　　『こんなふうに、だますなんて。  
> こんなに遠くまで連れ出して、  
> 　　あんなに急いで歩かせたあとに！』  
> 大工は、ただ、こう言うだけだった。  
> 　　『バターの塗り方が厚すぎる！』

<a id="LG-04-046"></a>

**LG-04-046**

<!-- EN:LG-04-046 -->
‘I weep for you,’ the Walrus said.  
    ‘I deeply sympathize.’  
With sobs and tears he sorted out  
    Those of the largest size.  
Holding his pocket handkerchief  
    Before his streaming eyes.  
<!-- /EN:LG-04-046 -->

> 『君たちのために泣いているのだよ』とセイウチは言った。  
> 　　『心の底から、お気の毒に思っている』  
> 泣いて、すすり上げながら、より分けたのは、  
> 　　いちばん大きなカキばかり。  
> ポケットのハンカチを掲げて、  
> 　　涙の流れる目を隠しながら。

<a id="LG-04-047"></a>

**LG-04-047**

<!-- EN:LG-04-047 -->
‘O Oysters,’ said the Carpenter.  
    ‘You’ve had a pleasant run!  
Shall we be trotting home again?’  
    But answer came there none—  
And that was scarcely odd, because  
    They’d eaten every one.”
<!-- /EN:LG-04-047 -->

> 『ああ、カキのみなさん』と大工は言った。  
> 　　『楽しいお散歩でしたね！  
> では、また、てくてく家へ帰りましょうか？』  
> 　　けれど、返事はひとつもなかった——  
> それも、大しておかしなことではない。だって、  
> 　　ふたりが残らず食べてしまったのだから」

<a id="LG-04-048"></a>

**LG-04-048**

<!-- EN:LG-04-048 -->
“I like the Walrus best,” said Alice: “because you see he was a *little* sorry for the poor oysters.”
<!-- /EN:LG-04-048 -->

> 「わたしは、セイウチのほうが好きだわ」とアリスは言った。「だって、かわいそうなカキたちを、*少しは*気の毒に思っていたでしょう」

<a id="LG-04-049"></a>

**LG-04-049**

<!-- EN:LG-04-049 -->
“He ate more than the Carpenter, though,” said Tweedledee. “You see he held his handkerchief in front, so that the Carpenter couldn’t count how many he took: contrariwise.”
<!-- /EN:LG-04-049 -->

> 「でも、大工よりたくさん食べたよ」とトゥイードルディーは言った。「ほら、前にハンカチを掲げていたから、大工には、いくつ取ったか数えられなかったんだ。それとは逆にね」

<a id="LG-04-050"></a>

**LG-04-050**

<!-- EN:LG-04-050 -->
“That was mean!” Alice said indignantly. “Then I like the Carpenter best—if he didn’t eat so many as the Walrus.”
<!-- /EN:LG-04-050 -->

> 「それは、ずるいわ！」とアリスは憤慨して言った。「じゃあ、大工のほうが好き。セイウチほどたくさん食べなかったなら」

<a id="LG-04-051"></a>

**LG-04-051**

<!-- EN:LG-04-051 -->
“But he ate as many as he could get,” said Tweedledum.
<!-- /EN:LG-04-051 -->

> 「でも、手に入るだけは食べたよ」とトゥイードルダムは言った。

<a id="LG-04-052"></a>

**LG-04-052**

<!-- EN:LG-04-052 -->
This was a puzzler. After a pause, Alice began, “Well! They were *both* very unpleasant characters—” Here she checked herself in some alarm, at hearing something that sounded to her like the puffing of a large steam-engine in the wood near them, though she feared it was more likely to be a wild beast. “Are there any lions or tigers about here?” she asked timidly.
<!-- /EN:LG-04-052 -->

> これは困った問題だった。しばらくしてアリスは言いはじめた。「まあ！　*ふたりとも*、とても嫌な人たちだったのね——」けれど、そこで少しぎょっとして言葉を止めた。すぐそばの森から、大きな蒸気機関車が息をついているような音が聞こえたからだ。ただ、たぶん野獣ではないかという気がして、怖くなった。「このあたりには、ライオンやトラがいるの？」と、おずおず聞いた。

<a id="LG-04-053"></a>

**LG-04-053**

<!-- EN:LG-04-053 -->
“It’s only the Red King snoring,” said Tweedledee.
<!-- /EN:LG-04-053 -->

> 「ただ、赤の王がいびきをかいているだけだよ」とトゥイードルディーは言った。

<a id="LG-04-054"></a>

**LG-04-054**

<!-- EN:LG-04-054 -->
“Come and look at him!” the brothers cried, and they each took one of Alice’s hands, and led her up to where the King was sleeping.
<!-- /EN:LG-04-054 -->

> 「見においでよ！」と兄弟は声をそろえ、アリスの手を片方ずつ取って、王の眠っているところへ連れていった。

<a id="LG-04-055"></a>

**LG-04-055**

<!-- EN:LG-04-055 -->
“Isn’t he a *lovely* sight?” said Tweedledum.
<!-- /EN:LG-04-055 -->

> 「*すてきな*眺めだろう？」とトゥイードルダムは言った。

<a id="LG-04-056"></a>

**LG-04-056**

<!-- EN:LG-04-056 -->
Alice couldn’t say honestly that he was. He had a tall red night-cap on, with a tassel, and he was lying crumpled up into a sort of untidy heap, and snoring loud—“fit to snore his head off!” as Tweedledum remarked.
<!-- /EN:LG-04-056 -->

> アリスには、正直にそうだとは言えなかった。王は、房のついた背の高い赤いナイトキャップをかぶり、だらしないひと塊のように、体をくしゃくしゃに丸めて寝ていた。そして、大きないびきをかいていた。「いびきで頭が取れそうだ！」と、トゥイードルダムが言ったとおりだった。

<a id="LG-04-057"></a>

**LG-04-057**

<!-- EN:LG-04-057 -->
“I’m afraid he’ll catch cold with lying on the damp grass,” said Alice, who was a very thoughtful little girl.
<!-- /EN:LG-04-057 -->

> 「湿った草の上に寝ていたら、風邪をひいてしまうんじゃないかしら」とアリスは言った。とても思いやりのある女の子だったのだ。

<a id="LG-04-058"></a>

**LG-04-058**

<!-- EN:LG-04-058 -->
“He’s dreaming now,” said Tweedledee: “and what do you think he’s dreaming about?”
<!-- /EN:LG-04-058 -->

> 「今、夢を見ているんだ」とトゥイードルディーは言った。「何の夢だと思う？」

<a id="LG-04-059"></a>

**LG-04-059**

<!-- EN:LG-04-059 -->
Alice said “Nobody can guess that.”
<!-- /EN:LG-04-059 -->

> アリスは、「それは、誰にも当てられないわ」と言った。

<a id="LG-04-060"></a>

**LG-04-060**

<!-- EN:LG-04-060 -->
“Why, about *you*!” Tweedledee exclaimed, clapping his hands triumphantly. “And if he left off dreaming about you, where do you suppose you’d be?”
<!-- /EN:LG-04-060 -->

> 「それが、*君の*夢さ！」とトゥイードルディーは叫び、得意そうに手をたたいた。「もし王様が、君の夢を見るのをやめたら、君はどこにいると思う？」

<a id="LG-04-061"></a>

**LG-04-061**

<!-- EN:LG-04-061 -->
“Where I am now, of course,” said Alice.
<!-- /EN:LG-04-061 -->

> 「もちろん、今いるところよ」とアリスは言った。

<a id="LG-04-062"></a>

**LG-04-062**

<!-- EN:LG-04-062 -->
“Not you!” Tweedledee retorted contemptuously. “You’d be nowhere. Why, you’re only a sort of thing in his dream!”
<!-- /EN:LG-04-062 -->

> 「君は、そうはいかないよ！」とトゥイードルディーは、見下すように言い返した。「どこにもいなくなるのさ。だって君は、王様の夢の中にある、何かみたいなものにすぎないんだから！」

<a id="LG-04-063"></a>

**LG-04-063**

<!-- EN:LG-04-063 -->
“If that there King was to wake,” added Tweedledum, “you’d go out—bang!—just like a candle!”
<!-- /EN:LG-04-063 -->

> 「あそこの王様が目を覚ましたら」とトゥイードルダムが付け加えた。「君は消えてしまうよ。ぱん！って、ろうそくみたいに！」

<a id="LG-04-064"></a>

**LG-04-064**

<!-- EN:LG-04-064 -->
“I shouldn’t!” Alice exclaimed indignantly. “Besides, if *I’m* only a sort of thing in his dream, what are *you*, I should like to know?”
<!-- /EN:LG-04-064 -->

> 「消えたりしないわ！」とアリスは憤然と叫んだ。「それに、*わたしが*王様の夢の中の何かにすぎないというなら、*あなたたち*は何なのか、聞かせてもらいたいわ！」

<a id="LG-04-065"></a>

**LG-04-065**

<!-- EN:LG-04-065 -->
“Ditto” said Tweedledum.
<!-- /EN:LG-04-065 -->

> 「同じく」とトゥイードルダムは言った。

<a id="LG-04-066"></a>

**LG-04-066**

<!-- EN:LG-04-066 -->
“Ditto, ditto” cried Tweedledee.
<!-- /EN:LG-04-066 -->

> 「同じく、同じく」とトゥイードルディーは叫んだ。

<a id="LG-04-067"></a>

**LG-04-067**

<!-- EN:LG-04-067 -->
He shouted this so loud that Alice couldn’t help saying, “Hush! You’ll be waking him, I’m afraid, if you make so much noise.”
<!-- /EN:LG-04-067 -->

> それがあまりに大きな声だったので、アリスは、ついこう言った。「しっ！　そんなに騒いだら、起こしてしまうんじゃないかしら」

<a id="LG-04-068"></a>

**LG-04-068**

<!-- EN:LG-04-068 -->
“Well, it no use *your* talking about waking him,” said Tweedledum, “when you’re only one of the things in his dream. You know very well you’re not real.”
<!-- /EN:LG-04-068 -->

> 「王様を起こすなんて話を*君が*しても、仕方がないよ」とトゥイードルダムは言った。「君は、夢の中のもののひとつにすぎないんだから。自分が本物じゃないことくらい、よくわかっているだろう」

<a id="LG-04-069"></a>

**LG-04-069**

<!-- EN:LG-04-069 -->
“I *am* real!” said Alice and began to cry.
<!-- /EN:LG-04-069 -->

> 「本物*だもの*！」とアリスは言い、泣きだした。

<a id="LG-04-070"></a>

**LG-04-070**

<!-- EN:LG-04-070 -->
“You won’t make yourself a bit realler by crying,” Tweedledee remarked: “there’s nothing to cry about.”
<!-- /EN:LG-04-070 -->

> 「泣いたって、少しも今より本物にはならないよ」とトゥイードルディーは言った。「泣くようなことじゃないさ」

<a id="LG-04-071"></a>

**LG-04-071**

<!-- EN:LG-04-071 -->
“If I wasn’t real,” Alice said—half-laughing through her tears, it all seemed so ridiculous—“I shouldn’t be able to cry.”
<!-- /EN:LG-04-071 -->

> 「本物じゃなかったら」とアリスは言った。何もかもあまりにばかばかしく思えたので、涙を流しながら、半ば笑っていた。「泣くことなんて、できないでしょう」

<a id="LG-04-072"></a>

**LG-04-072**

<!-- EN:LG-04-072 -->
“I hope you don’t suppose those are real tears?” Tweedledum interrupted in a tone of great contempt.
<!-- /EN:LG-04-072 -->

> 「まさか、それが本物の涙だなんて、思っていないよね？」とトゥイードルダムは、ひどく見下した口ぶりで口を挟んだ。

<a id="LG-04-073"></a>

**LG-04-073**

<!-- EN:LG-04-073 -->
“I know they’re talking nonsense,” Alice thought to herself: “and it’s foolish to cry about it.” So she brushed away her tears, and went on as cheerfully as she could. “At any rate I’d better be getting out of the wood, for really it’s coming on very dark. Do you think it’s going to rain?”
<!-- /EN:LG-04-073 -->

> 「この人たちが、でたらめを言っているのはわかっているわ」とアリスは心の中で思った。「それで泣くなんて、ばかみたい」そこで涙をぬぐい、できるだけ明るく続けた。「どのみち、そろそろ森を出たほうがいいわね。本当に、ずいぶん暗くなってきたもの。雨になると思う？」

<a id="LG-04-074"></a>

**LG-04-074**

<!-- EN:LG-04-074 -->
Tweedledum spread a large umbrella over himself and his brother, and looked up into it. “No, I don’t think it is,” he said: “at least—not under *here*. Nohow.”
<!-- /EN:LG-04-074 -->

> トゥイードルダムは、自分と兄弟の上に大きな傘を広げ、その内側を見上げた。「いや、降るとは思わないね」と言った。「少なくとも、*この下*ではね。どうあっても」

<a id="LG-04-075"></a>

**LG-04-075**

<!-- EN:LG-04-075 -->
“But it may rain *outside*?”
<!-- /EN:LG-04-075 -->

> 「でも、*外*では降るかもしれないでしょう？」

<a id="LG-04-076"></a>

**LG-04-076**

<!-- EN:LG-04-076 -->
“It may—if it chooses,” said Tweedledee: “we’ve no objection. Contrariwise.”
<!-- /EN:LG-04-076 -->

> 「降ってもいいよ。降りたければ」とトゥイードルディーは言った。「ぼくたちに異存はないよ。それとは逆にね」

<a id="LG-04-077"></a>

**LG-04-077**

<!-- EN:LG-04-077 -->
“Selfish things!” thought Alice, and she was just going to say “Good-night” and leave them, when Tweedledum sprang out from under the umbrella and seized her by the wrist.
<!-- /EN:LG-04-077 -->

> 「勝手な人たち！」とアリスは思った。そして「おやすみなさい」と言って立ち去ろうとした、そのとき、トゥイードルダムが傘の下から飛び出して、アリスの手首をつかんだ。

<a id="LG-04-078"></a>

**LG-04-078**

<!-- EN:LG-04-078 -->
“Do you see *that*?” he said, in a voice choking with passion, and his eyes grew large and yellow all in a moment, as he pointed with a trembling finger at a small white thing lying under the tree.
<!-- /EN:LG-04-078 -->

> 「*あれ*が見える？」と、激情に声を詰まらせながら言った。その目は一瞬で大きく、黄色くなり、震える指で、木の下に落ちている白い小さなものを指さした。

<a id="LG-04-079"></a>

**LG-04-079**

<!-- EN:LG-04-079 -->
“It’s only a rattle,” Alice said, after a careful examination of the little white thing. “Not a rattle-*snake*, you know,” she added hastily, thinking that he was frightened: “only an old rattle—quite old and broken.”
<!-- /EN:LG-04-079 -->

> 「ただのガラガラよ」と、白い小さなものを注意深く調べてから、アリスは言った。相手が怖がっていると思い、急いで付け加えた。「ガラガラ*ヘビ*じゃないわよ。ただの古いガラガラ。ずいぶん古くて、壊れているわ」

> **訳注：** rattle は赤ん坊のおもちゃ「ガラガラ」。rattlesnake は「ガラガラヘビ」。

<a id="LG-04-080"></a>

**LG-04-080**

<!-- EN:LG-04-080 -->
“I knew it was!” cried Tweedledum, beginning to stamp about wildly and tear his hair. “It’s spoilt, of course!” Here he looked at Tweedledee, who immediately sat down on the ground, and tried to hide himself under the umbrella.
<!-- /EN:LG-04-080 -->

> 「やっぱり、そうだと思った！」とトゥイードルダムは叫び、むやみに足を踏み鳴らして、髪をかきむしりはじめた。「もちろん、壊れているんだ！」そう言ってトゥイードルディーを見ると、ディーはすぐ地面に座り込み、傘の下へ隠れようとした。

<a id="LG-04-081"></a>

**LG-04-081**

<!-- EN:LG-04-081 -->
Alice laid her hand upon his arm, and said in a soothing tone, “You needn’t be so angry about an old rattle.”
<!-- /EN:LG-04-081 -->

> アリスはダムの腕に手を添え、なだめるような調子で言った。「古いガラガラくらいで、そんなに怒らなくてもいいでしょう」

<a id="LG-04-082"></a>

**LG-04-082**

<!-- EN:LG-04-082 -->
“But it isn’t old!” Tweedledum cried, in a greater fury than ever. “It’s new, I tell you—I bought it yesterday—my nice new RATTLE!” and his voice rose to a perfect scream.
<!-- /EN:LG-04-082 -->

> 「でも、古くなんかない！」とトゥイードルダムは、いっそう激しく怒って叫んだ。「新品なんだよ、いいかい！　昨日買ったんだ——ぼくの、すてきな新品の、ガラガラだ！」その声は、とうとう金切り声になった。

<a id="LG-04-083"></a>

**LG-04-083**

<!-- EN:LG-04-083 -->
All this time Tweedledee was trying his best to fold up the umbrella, with himself in it: which was such an extraordinary thing to do, that it quite took off Alice’s attention from the angry brother. But he couldn’t quite succeed, and it ended in his rolling over, bundled up in the umbrella, with only his head out: and there he lay, opening and shutting his mouth and his large eyes—“looking more like a fish than anything else,” Alice thought.
<!-- /EN:LG-04-083 -->

> そのあいだじゅうトゥイードルディーは、自分を中に入れたまま、何とか傘をたたもうとしていた。それはあまりに妙なやり方だったので、アリスの注意は、怒っている兄弟のほうから、すっかりそちらへ移ってしまった。けれど、どうしてもうまくはいかず、ついには傘にくるまったまま転がり、頭だけを出すことになった。そのまま横たわって、口と大きな目を開けたり閉じたりしていた。「何よりも、お魚にそっくりだわ」とアリスは思った。

<a id="LG-04-084"></a>

**LG-04-084**

<!-- EN:LG-04-084 -->
“Of course you agree to have a battle?” Tweedledum said in a calmer tone.
<!-- /EN:LG-04-084 -->

> 「もちろん、ひと勝負するのに異存はないね？」とトゥイードルダムは、少し落ち着いた声で言った。

<a id="LG-04-085"></a>

**LG-04-085**

<!-- EN:LG-04-085 -->
“I suppose so,” the other sulkily replied, as he crawled out of the umbrella: “only *she* must help us to dress up, you know.”
<!-- /EN:LG-04-085 -->

> 「そうだろうね」と、もうひとりは不機嫌そうに答え、傘からはい出した。「ただし、支度は*あの子*に手伝ってもらわないとね」

<a id="LG-04-086"></a>

**LG-04-086**

<!-- EN:LG-04-086 -->
So the two brothers went off hand-in-hand into the wood, and returned in a minute with their arms full of things—such as bolsters, blankets, hearth-rugs, table-cloths, dish-covers and coal-scuttles. “I hope you’re a good hand at pinning and tying strings?” Tweedledum remarked. “Every one of these things has got to go on, somehow or other.”
<!-- /EN:LG-04-086 -->

> そこで兄弟は、手をつないで森の中へ行き、一分もしないうちに、両腕いっぱいの品物を抱えて戻ってきた。長枕、毛布、暖炉前の敷物、テーブルクロス、料理の覆い、石炭入れなどだった。「ピン留めや、ひもを結ぶのは得意だろうね？」とトゥイードルダムは言った。「これをひとつ残らず、何とかして身につけなくちゃならないんだ」

<a id="LG-04-087"></a>

**LG-04-087**

<!-- EN:LG-04-087 -->
Alice said afterwards she had never seen such a fuss made about anything in all her life—the way those two bustled about—and the quantity of things they put on—and the trouble they gave her in tying strings and fastening buttons—“Really they’ll be more like bundles of old clothes than anything else, by the time they’re ready!” she said to herself, as she arranged a bolster round the neck of Tweedledee, “to keep his head from being cut off,” as he said.
<!-- /EN:LG-04-087 -->

> アリスはあとで、ひとつのことについて、あれほど大騒ぎするのは生まれてはじめて見た、と言った。ふたりのせわしなく動き回る様子といい、身につける品物の多さといい、ひもを結んだりボタンを留めたりするのに、アリスに掛ける手間といい——。「本当に、支度ができあがるころには、何よりも古着の包みにそっくりになってしまうわ！」とアリスは思った。そうしてトゥイードルディーの首の周りに、長枕を巻きつけてやった。彼の言うところでは、「頭を切り落とされないように」するためだった。

<a id="LG-04-088"></a>

**LG-04-088**

<!-- EN:LG-04-088 -->
“You know,” he added very gravely, “it’s one of the most serious things that can possibly happen to one in a battle—to get one’s head cut off.”
<!-- /EN:LG-04-088 -->

> 「いいかい」と彼は、ひどく重々しく付け加えた。「戦いで起こりうることの中で、いちばん重大なもののひとつなんだよ。頭を切り落とされるというのは」

<a id="LG-04-089"></a>

**LG-04-089**

<!-- EN:LG-04-089 -->
Alice laughed aloud: but she managed to turn it into a cough, for fear of hurting his feelings.
<!-- /EN:LG-04-089 -->

> アリスは声を立てて笑ったけれど、相手の気持ちを傷つけないように、どうにか咳に変えてごまかした。

<a id="LG-04-090"></a>

**LG-04-090**

<!-- EN:LG-04-090 -->
“Do I look very pale?” said Tweedledum, coming up to have his helmet tied on. (He *called* it a helmet, though it certainly looked much more like a saucepan.)
<!-- /EN:LG-04-090 -->

> 「ぼく、ひどく青ざめて見える？」とトゥイードルダムは、かぶとを結んでもらいに近づいてきて言った。（本人は、かぶとと*呼んで*いたけれど、確かに、どう見ても片手鍋に似ていた。）

<a id="LG-04-091"></a>

**LG-04-091**

<!-- EN:LG-04-091 -->
“Well—yes—a *little*,” Alice replied gently.
<!-- /EN:LG-04-091 -->

> 「ええと、ええ、*少し*ね」とアリスは優しく答えた。

<a id="LG-04-092"></a>

**LG-04-092**

<!-- EN:LG-04-092 -->
“I’m very brave generally,” he went on in a low voice: “only to-day I happen to have a headache.”
<!-- /EN:LG-04-092 -->

> 「普段は、とても勇敢なんだ」と彼は声を落として続けた。「ただ、今日は、たまたま頭が痛くてね」

<a id="LG-04-093"></a>

**LG-04-093**

<!-- EN:LG-04-093 -->
“And *I’ve* got a toothache!” said Tweedledee, who had overheard the remark. “I’m far worse off than you!”
<!-- /EN:LG-04-093 -->

> 「それなら、*ぼくは*歯が痛いよ！」と、それを聞きつけたトゥイードルディーが言った。「君より、ずっとひどい状態だ！」

<a id="LG-04-094"></a>

**LG-04-094**

<!-- EN:LG-04-094 -->
“Then you’d better not fight to-day,” said Alice, thinking it a good opportunity to make peace.
<!-- /EN:LG-04-094 -->

> 「それなら、今日は戦わないほうがいいわ」とアリスは言った。仲直りさせる、いい機会だと思ったのだ。

<a id="LG-04-095"></a>

**LG-04-095**

<!-- EN:LG-04-095 -->
“We *must* have a bit of a fight, but I don’t care about going on long,” said Tweedledum. “What’s the time now?”
<!-- /EN:LG-04-095 -->

> 「少しは戦わ*なくちゃ*いけないんだ。でも、長く続ける気はないよ」とトゥイードルダムは言った。「今、何時？」

<a id="LG-04-096"></a>

**LG-04-096**

<!-- EN:LG-04-096 -->
Tweedledee looked at his watch, and said “Half-past four.”
<!-- /EN:LG-04-096 -->

> トゥイードルディーは時計を見て、「四時半」と答えた。

<a id="LG-04-097"></a>

**LG-04-097**

<!-- EN:LG-04-097 -->
“Let’s fight till six, and then have dinner,” said Tweedledum.
<!-- /EN:LG-04-097 -->

> 「六時まで戦って、それから夕食にしよう」とトゥイードルダムは言った。

<a id="LG-04-098"></a>

**LG-04-098**

<!-- EN:LG-04-098 -->
“Very well,” the other said, rather sadly: “and *she* can watch us—only you’d better not come *very* close,” he added: “I generally hit everything I can see—when I get really excited.”
<!-- /EN:LG-04-098 -->

> 「よろしい」と、もうひとりは少し悲しそうに言った。「それで、*あの子*には見物してもらえばいい。ただし、*あんまり*近寄らないほうがいいよ」と付け加えた。「本当に興奮してくると、ぼくは、目に入るものを何でも殴るのが常だからね」

<a id="LG-04-099"></a>

**LG-04-099**

<!-- EN:LG-04-099 -->
“And *I* hit everything within reach,” cried Tweedledum, “whether I can see it or not!”
<!-- /EN:LG-04-099 -->

> 「それなら、*ぼくは*手の届くものなら何でも殴る！」とトゥイードルダムは叫んだ。「見えていても、見えていなくても！」

<a id="LG-04-100"></a>

**LG-04-100**

<!-- EN:LG-04-100 -->
Alice laughed. “You must hit the *trees* pretty often, I should think,” she said.
<!-- /EN:LG-04-100 -->

> アリスは笑った。「それなら、ずいぶんしょっちゅう、*木*を殴ることになるでしょうね」と言った。

<a id="LG-04-101"></a>

**LG-04-101**

<!-- EN:LG-04-101 -->
Tweedledum looked round him with a satisfied smile. “I don’t suppose,” he said, “there’ll be a tree left standing, for ever so far round, by the time we’ve finished!”
<!-- /EN:LG-04-101 -->

> トゥイードルダムは、満足そうな笑みを浮かべてあたりを見回した。「ぼくたちが戦い終わるころには」と言った。「あたり一帯、ずっと遠くまで、立っている木なんて一本も残っていないと思うよ！」

<a id="LG-04-102"></a>

**LG-04-102**

<!-- EN:LG-04-102 -->
“And all about a rattle!” said Alice, still hoping to make them a *little* ashamed of fighting for such a trifle.
<!-- /EN:LG-04-102 -->

> 「しかも、それが、ガラガラひとつのためなのね！」とアリスは言った。そんなささいなことで戦うのを、*少しでも*恥ずかしく思ってくれればと、まだ願っていたのだ。

<a id="LG-04-103"></a>

**LG-04-103**

<!-- EN:LG-04-103 -->
“I shouldn’t have minded it so much,” said Tweedledum, “if it hadn’t been a new one.”
<!-- /EN:LG-04-103 -->

> 「新品でなかったら、こんなに気にしなかったよ」とトゥイードルダムは言った。

<a id="LG-04-104"></a>

**LG-04-104**

<!-- EN:LG-04-104 -->
“I wish the monstrous crow would come!” thought Alice.
<!-- /EN:LG-04-104 -->

> 「大きなカラスが来てくれたらいいのに！」とアリスは思った。

<a id="LG-04-105"></a>

**LG-04-105**

<!-- EN:LG-04-105 -->
“There’s only one sword, you know,” Tweedledum said to his brother: “but you can have the umbrella—it’s quite as sharp. Only we must begin quick. It’s getting as dark as it can.”
<!-- /EN:LG-04-105 -->

> 「剣は一本しかないんだ」とトゥイードルダムは兄弟に言った。「でも、君は傘を使っていいよ。同じくらい鋭いから。ただ、早くはじめないと。これ以上ないくらい暗くなってきた」

<a id="LG-04-106"></a>

**LG-04-106**

<!-- EN:LG-04-106 -->
“And darker,” said Tweedledee.
<!-- /EN:LG-04-106 -->

> 「それ以上にもね」とトゥイードルディーは言った。

<a id="LG-04-107"></a>

**LG-04-107**

<!-- EN:LG-04-107 -->
It was getting dark so suddenly that Alice thought there must be a thunderstorm coming on. “What a thick black cloud that is!” she said. “And how fast it comes! Why, I do believe it’s got wings!”
<!-- /EN:LG-04-107 -->

> あまりに急に暗くなってきたので、アリスは、きっと雷雨が来るのだと思った。「何て厚い、黒い雲なの！」と言った。「それに、何て速く近づいてくるのかしら！　あら、あれには翼があるみたい！」

<a id="LG-04-108"></a>

**LG-04-108**

<!-- EN:LG-04-108 -->
“It’s the crow!” Tweedledum cried out in a shrill voice of alarm: and the two brothers took to their heels and were out of sight in a moment.
<!-- /EN:LG-04-108 -->

> 「カラスだ！」とトゥイードルダムは、怯えた甲高い声で叫んだ。兄弟は一目散に駆け出し、たちまち姿が見えなくなった。

<a id="LG-04-109"></a>

**LG-04-109**

<!-- EN:LG-04-109 -->
Alice ran a little way into the wood, and stopped under a large tree. “It can never get at me *here*,” she thought: “it’s far too large to squeeze itself in among the trees. But I wish it wouldn’t flap its wings so—it makes quite a hurricane in the wood—here’s somebody’s shawl being blown away!”
<!-- /EN:LG-04-109 -->

> アリスは少し森の中へ走り込み、大きな木の下で止まった。「*ここなら*、絶対に襲われないわ」と思った。「大きすぎて、木と木のあいだに体を押し込めないもの。でも、あんなに翼をばたばたさせないでほしいわね。森の中が、まるで暴風みたい。あら、誰かのショールが吹き飛ばされているわ！」

[章目次へ戻る](#book-top)

---

<a id="lg-chapter-05"></a>

## 第5章　羊毛と水

### CHAPTER V. Wool and Water

<a id="LG-05-001"></a>

**LG-05-001**

<!-- EN:LG-05-001 -->
She caught the shawl as she spoke, and looked about for the owner: in another moment the White Queen came running wildly through the wood, with both arms stretched out wide, as if she were flying, and Alice very civilly went to meet her with the shawl.
<!-- /EN:LG-05-001 -->

> アリスはそう言いながらショールをつかまえ、持ち主を探してあたりを見回した。次の瞬間、白の女王が、まるで飛んでいるように両腕を大きく広げて、森の中をむやみやたらに駆けてきた。アリスはショールを持って、とても礼儀正しく迎えに出た。

<a id="LG-05-002"></a>

**LG-05-002**

<!-- EN:LG-05-002 -->
“I’m very glad I happened to be in the way,” Alice said, as she helped her to put on her shawl again.
<!-- /EN:LG-05-002 -->

> 「ちょうど通り道にいて、よかったです」とアリスは言い、女王がもう一度ショールをまとえるよう、手伝ってあげた。

<a id="LG-05-003"></a>

**LG-05-003**

<!-- EN:LG-05-003 -->
The White Queen only looked at her in a helpless frightened sort of way, and kept repeating something in a whisper to herself that sounded like “bread-and-butter, bread-and-butter,” and Alice felt that if there was to be any conversation at all, she must manage it herself. So she began rather timidly: “Am I addressing the White Queen?”
<!-- /EN:LG-05-003 -->

> 白の女王は、頼りなさそうな、怯えたような顔でアリスを見るばかりだった。そして、「バターつきパン、バターつきパン」と聞こえるようなことを、小声で独り言のように繰り返していた。アリスは、会話をするには、自分でどうにかするしかないと思った。そこで、少しおずおずと切り出した。「わたしが今、お話しかけているのは、白の女王様でしょうか？」

<a id="LG-05-004"></a>

**LG-05-004**

<!-- EN:LG-05-004 -->
“Well, yes, if you call that a-dressing,” The Queen said. “It isn’t *my* notion of the thing, at all.”
<!-- /EN:LG-05-004 -->

> 「まあ、そうですよ。これを着付けと呼ぶならね」と女王は言った。「*わたくしの*考える着付けとは、まったく違いますけれど」

> **訳注：** addressing「話しかけている」を a-dressing「着付けしている」と聞き替えている。直前にアリスがショールを着せていることにも重なる。

<a id="LG-05-005"></a>

**LG-05-005**

<!-- EN:LG-05-005 -->
Alice thought it would never do to have an argument at the very beginning of their conversation, so she smiled and said, “If your Majesty will only tell me the right way to begin, I’ll do it as well as I can.”
<!-- /EN:LG-05-005 -->

> 会話のはじめから言い争うわけにはいかない、とアリスは思ったので、にっこりして言った。「陛下が、正しいはじめ方を教えてくだされば、できるだけ上手にいたします」

<a id="LG-05-006"></a>

**LG-05-006**

<!-- EN:LG-05-006 -->
“But I don’t want it done at all!” groaned the poor Queen. “I’ve been a-dressing myself for the last two hours.”
<!-- /EN:LG-05-006 -->

> 「でも、そんなこと、していただきたくないのよ！」と、かわいそうな女王はうめいた。「この二時間ずっと、自分で着付けをしていたんですから」

<a id="LG-05-007"></a>

**LG-05-007**

<!-- EN:LG-05-007 -->
It would have been all the better, as it seemed to Alice, if she had got some one else to dress her, she was so dreadfully untidy. “Every single thing’s crooked,” Alice thought to herself, “and she’s all over pins!—may I put your shawl straight for you?” she added aloud.
<!-- /EN:LG-05-007 -->

> あまりにひどい乱れようだったので、誰かほかの人に着せてもらったほうが、どれほどよかっただろうとアリスは思った。「何もかも曲がっているわ」と心の中で言った。「それに、全身ピンだらけ！——ショールをまっすぐにしてさしあげても、よろしいですか？」と、今度は声に出して付け加えた。

<a id="LG-05-008"></a>

**LG-05-008**

<!-- EN:LG-05-008 -->
“I don’t know what’s the matter with it!” the Queen said, in a melancholy voice. “It’s out of temper, I think. I’ve pinned it here, and I’ve pinned it there, but there’s no pleasing it!”
<!-- /EN:LG-05-008 -->

> 「これ、どこがおかしいのかしら！」と女王は、もの悲しい声で言った。「機嫌が悪いんだと思います。ここも留めて、あそこも留めたのに、ちっとも気に入ってくれないんですもの！」

<a id="LG-05-009"></a>

**LG-05-009**

<!-- EN:LG-05-009 -->
“It *can’t* go straight, you know, if you pin it all on one side,” Alice said, as she gently put it right for her; “and, dear me, what a state your hair is in!”
<!-- /EN:LG-05-009 -->

> 「片側ばかりピンで留めたら、まっすぐには*なりません*よ」とアリスは言い、そっと直してあげた。「それに、まあ、髪がすごいことになっていますね！」

<a id="LG-05-010"></a>

**LG-05-010**

<!-- EN:LG-05-010 -->
“The brush has got entangled in it!” the Queen said with a sigh. “And I lost the comb yesterday.”
<!-- /EN:LG-05-010 -->

> 「ブラシが絡まってしまったの！」と女王はため息をついて言った。「それに、昨日くしもなくしてしまって」

<a id="LG-05-011"></a>

**LG-05-011**

<!-- EN:LG-05-011 -->
Alice carefully released the brush, and did her best to get the hair into order. “Come, you look rather better now!” she said, after altering most of the pins. “But really you should have a lady’s maid!”
<!-- /EN:LG-05-011 -->

> アリスは気をつけてブラシを外し、できるだけ髪を整えてあげた。「さあ、ずいぶんよくなりましたよ！」と、ピンのほとんどを付け直してから言った。「でも、本当に、身の回りのお世話をする侍女をお雇いになったほうがいいです！」

<a id="LG-05-012"></a>

**LG-05-012**

<!-- EN:LG-05-012 -->
“I’m sure I’ll take you with pleasure!” the Queen said. “Twopence a week, and jam every other day.”
<!-- /EN:LG-05-012 -->

> 「もちろん、喜んであなたを雇いますよ！」と女王は言った。「一週間に二ペンス、それに一日おきにジャムを」

<a id="LG-05-013"></a>

**LG-05-013**

<!-- EN:LG-05-013 -->
Alice couldn’t help laughing, as she said, “I don’t want you to hire *me*—and I don’t care for jam.”
<!-- /EN:LG-05-013 -->

> アリスは思わず笑いながら言った。「*わたしを*雇っていただきたいのではないんです。それに、ジャムは欲しくありません」

<a id="LG-05-014"></a>

**LG-05-014**

<!-- EN:LG-05-014 -->
“It’s very good jam,” said the Queen.
<!-- /EN:LG-05-014 -->

> 「とてもおいしいジャムですよ」と女王は言った。

<a id="LG-05-015"></a>

**LG-05-015**

<!-- EN:LG-05-015 -->
“Well, I don’t want any *to-day*, at any rate.”
<!-- /EN:LG-05-015 -->

> 「でも、とにかく*今日は*、いただきたくありません」

<a id="LG-05-016"></a>

**LG-05-016**

<!-- EN:LG-05-016 -->
“You couldn’t have it if you *did* want it,” the Queen said. “The rule is, jam to-morrow and jam yesterday—but never jam to-day.”
<!-- /EN:LG-05-016 -->

> 「欲しいと*思っても*、もらえませんよ」と女王は言った。「決まりは、明日はジャム、昨日もジャム。でも、今日のジャムは絶対になし、ですから」

<a id="LG-05-017"></a>

**LG-05-017**

<!-- EN:LG-05-017 -->
“It *must* come sometimes to ‘jam to-day,’” Alice objected.
<!-- /EN:LG-05-017 -->

> 「それなら、ときには『今日はジャム』になる*はず*です」とアリスは反論した。

<a id="LG-05-018"></a>

**LG-05-018**

<!-- EN:LG-05-018 -->
“No, it can’t,” said the Queen. “It’s jam every *other* day: to-day isn’t any *other* day, you know.”
<!-- /EN:LG-05-018 -->

> 「いいえ、なりません」と女王は言った。「ジャムがあるのは、毎回*ほかの日*です。今日は、*ほかの日*ではないでしょう」

> **訳注：** every other day は普通「一日おき」。女王は other を「今日以外の、ほかの」と解釈し、今日のジャムをいつまでも排除する。

<a id="LG-05-019"></a>

**LG-05-019**

<!-- EN:LG-05-019 -->
“I don’t understand you,” said Alice. “It’s dreadfully confusing!”
<!-- /EN:LG-05-019 -->

> 「おっしゃることが、わかりません」とアリスは言った。「ひどく混乱してしまいます！」

<a id="LG-05-020"></a>

**LG-05-020**

<!-- EN:LG-05-020 -->
“That’s the effect of living backwards,” the Queen said kindly: “it always makes one a little giddy at first—”
<!-- /EN:LG-05-020 -->

> 「それは、後ろ向きに生きることの作用ですよ」と女王は優しく言った。「はじめは誰でも、少し目が回るものです——」

<a id="LG-05-021"></a>

**LG-05-021**

<!-- EN:LG-05-021 -->
“Living backwards!” Alice repeated in great astonishment. “I never heard of such a thing!”
<!-- /EN:LG-05-021 -->

> 「後ろ向きに生きる！」とアリスは、たいそう驚いて繰り返した。「そんなこと、聞いたこともありません！」

<a id="LG-05-022"></a>

**LG-05-022**

<!-- EN:LG-05-022 -->
“—but there’s one great advantage in it, that one’s memory works both ways.”
<!-- /EN:LG-05-022 -->

> 「——でも、ひとつ大きな利点があります。記憶が、どちらの向きにも働くのです」

<a id="LG-05-023"></a>

**LG-05-023**

<!-- EN:LG-05-023 -->
“I’m sure *mine* only works one way,” Alice remarked. “I can’t remember things before they happen.”
<!-- /EN:LG-05-023 -->

> 「*わたしの*記憶は、ひとつの向きにしか働きません」とアリスは言った。「まだ起きていないことは、思い出せませんもの」

<a id="LG-05-024"></a>

**LG-05-024**

<!-- EN:LG-05-024 -->
“It’s a poor sort of memory that only works backwards,” the Queen remarked.
<!-- /EN:LG-05-024 -->

> 「後ろ向きにしか働かないなんて、役に立たない記憶ですね」と女王は言った。

<a id="LG-05-025"></a>

**LG-05-025**

<!-- EN:LG-05-025 -->
“What sort of things do *you* remember best?” Alice ventured to ask.
<!-- /EN:LG-05-025 -->

> 「*陛下は*、どんなことをいちばんよく覚えていらっしゃるんですか？」とアリスは、思い切って聞いた。

<a id="LG-05-026"></a>

**LG-05-026**

<!-- EN:LG-05-026 -->
“Oh, things that happened the week after next,” the Queen replied in a careless tone. “For instance, now,” she went on, sticking a large piece of plaster on her finger as she spoke, “there’s the King’s Messenger. He’s in prison now, being punished: and the trial doesn’t even begin till next Wednesday: and of course the crime comes last of all.”
<!-- /EN:LG-05-026 -->

> 「そうね、再来週に起こったことかしら」と女王は何気なく答えた。「たとえば、今なら」と話を続けながら、指に大きな膏薬を貼った。「王様の使者がいるでしょう。今は牢屋に入って、罰を受けています。でも、裁判は今度の水曜日になるまで、はじまりもしません。そしてもちろん、犯罪は、いちばん最後に起こるのです」

<a id="LG-05-027"></a>

**LG-05-027**

<!-- EN:LG-05-027 -->
“Suppose he never commits the crime?” said Alice.
<!-- /EN:LG-05-027 -->

> 「もし、結局その人が犯罪を犯さなかったら？」とアリスは言った。

<a id="LG-05-028"></a>

**LG-05-028**

<!-- EN:LG-05-028 -->
“That would be all the better, wouldn’t it?” the Queen said, as she bound the plaster round her finger with a bit of ribbon.
<!-- /EN:LG-05-028 -->

> 「そのほうが、もっとよいことでしょう？」と女王は言い、リボンの切れ端で、指の膏薬を巻いて留めた。

<a id="LG-05-029"></a>

**LG-05-029**

<!-- EN:LG-05-029 -->
Alice felt there was no denying *that*. “Of course it would be all the better,” she said: “but it wouldn’t be all the better his being punished.”
<!-- /EN:LG-05-029 -->

> アリスは、*それ*は否定できないと思った。「もちろん、そのほうがよいことです」と言った。「でも、罰を受けていることまで、よくなるわけではありません」

<a id="LG-05-030"></a>

**LG-05-030**

<!-- EN:LG-05-030 -->
“You’re wrong *there*, at any rate,” said the Queen: “were *you* ever punished?”
<!-- /EN:LG-05-030 -->

> 「少なくとも、*そこは*間違っていますよ」と女王は言った。「*あなたは*、罰を受けたことがありますか？」

<a id="LG-05-031"></a>

**LG-05-031**

<!-- EN:LG-05-031 -->
“Only for faults,” said Alice.
<!-- /EN:LG-05-031 -->

> 「悪いことをしたときだけです」とアリスは言った。

<a id="LG-05-032"></a>

**LG-05-032**

<!-- EN:LG-05-032 -->
“And you were all the better for it, I know!” the Queen said triumphantly.
<!-- /EN:LG-05-032 -->

> 「そして、そのおかげで、もっとよい子になったに決まっていますね！」と女王は得意げに言った。

<a id="LG-05-033"></a>

**LG-05-033**

<!-- EN:LG-05-033 -->
“Yes, but then I *had* done the things I was punished for,” said Alice: “that makes all the difference.”
<!-- /EN:LG-05-033 -->

> 「はい、でも、そのときは、罰を受けることを本当に*していた*んです」とアリスは言った。「そこが、すっかり違います」

<a id="LG-05-034"></a>

**LG-05-034**

<!-- EN:LG-05-034 -->
“But if you *hadn’t* done them,” the Queen said, “that would have been better still; better, and better, and better!” Her voice went higher with each “better,” till it got quite to a squeak at last.
<!-- /EN:LG-05-034 -->

> 「でも、もし、して*いなかった*なら」と女王は言った。「それはもっとよかったでしょう。もっとよくて、もっとよくて、もっとよい！」声は「もっとよい」と言うたびに高くなり、最後には、すっかり金切り声になった。

<a id="LG-05-035"></a>

**LG-05-035**

<!-- EN:LG-05-035 -->
Alice was just beginning to say “There’s a mistake somewhere—,” when the Queen began screaming so loud that she had to leave the sentence unfinished. “Oh, oh, oh!” shouted the Queen, shaking her hand about as if she wanted to shake it off. “My finger’s bleeding! Oh, oh, oh, oh!”
<!-- /EN:LG-05-035 -->

> アリスが、「どこか間違っています——」と言いかけると、女王があまりに大きな声で悲鳴を上げはじめたので、最後まで言えなくなった。「ああ、ああ、ああ！」と女王は叫び、まるで手を振り落としてしまいたいかのように、振り回した。「指から血が出ている！　ああ、ああ、ああ、ああ！」

<a id="LG-05-036"></a>

**LG-05-036**

<!-- EN:LG-05-036 -->
Her screams were so exactly like the whistle of a steam-engine, that Alice had to hold both her hands over her ears.
<!-- /EN:LG-05-036 -->

> その悲鳴が、蒸気機関車の汽笛にそっくりだったので、アリスは両手で耳をふさがなければならなかった。

<a id="LG-05-037"></a>

**LG-05-037**

<!-- EN:LG-05-037 -->
“What *is* the matter?” she said, as soon as there was a chance of making herself heard. “Have you pricked your finger?”
<!-- /EN:LG-05-037 -->

> 自分の声が届きそうな隙間ができると、すぐに言った。「いったい、どうなさったんですか？　指を刺してしまったのですか？」

<a id="LG-05-038"></a>

**LG-05-038**

<!-- EN:LG-05-038 -->
“I haven’t pricked it *yet*,” the Queen said, “but I soon shall—oh, oh, oh!”
<!-- /EN:LG-05-038 -->

> 「*まだ*刺していません」と女王は言った。「でも、すぐ刺すのです。ああ、ああ、ああ！」

<a id="LG-05-039"></a>

**LG-05-039**

<!-- EN:LG-05-039 -->
“When do you expect to do it?” Alice asked, feeling very much inclined to laugh.
<!-- /EN:LG-05-039 -->

> 「いつ、お刺しになる予定なのですか？」とアリスは聞いた。とても笑いだしたくなっていた。

<a id="LG-05-040"></a>

**LG-05-040**

<!-- EN:LG-05-040 -->
“When I fasten my shawl again,” the poor Queen groaned out: “the brooch will come undone directly. Oh, oh!” As she said the words the brooch flew open, and the Queen clutched wildly at it, and tried to clasp it again.
<!-- /EN:LG-05-040 -->

> 「またショールを留めるときです」と、かわいそうな女王はうめいた。「じきにブローチが外れるのです。ああ、ああ！」そう言っているうちにブローチがぱっと開き、女王はむやみにそれをつかんで、もう一度留めようとした。

<a id="LG-05-041"></a>

**LG-05-041**

<!-- EN:LG-05-041 -->
“Take care!” cried Alice. “You’re holding it all crooked!” And she caught at the brooch; but it was too late: the pin had slipped, and the Queen had pricked her finger.
<!-- /EN:LG-05-041 -->

> 「お気をつけて！」とアリスは叫んだ。「すっかり曲がった持ち方をしています！」そしてブローチに手を伸ばしたけれど、もう遅かった。針が滑り、女王は指を刺してしまった。

<a id="LG-05-042"></a>

**LG-05-042**

<!-- EN:LG-05-042 -->
“That accounts for the bleeding, you see,” she said to Alice with a smile. “Now you understand the way things happen here.”
<!-- /EN:LG-05-042 -->

> 「ほら、これで、血が出た理由がわかりますね」と女王はほほえみながら言った。「これで、ここでは物事がどんなふうに起こるか、おわかりでしょう」

<a id="LG-05-043"></a>

**LG-05-043**

<!-- EN:LG-05-043 -->
“But why don’t you scream now?” Alice asked, holding her hands ready to put over her ears again.
<!-- /EN:LG-05-043 -->

> 「でも、どうして今は叫ばないのですか？」とアリスは聞いた。また耳をふさげるように、両手を構えていた。

<a id="LG-05-044"></a>

**LG-05-044**

<!-- EN:LG-05-044 -->
“Why, I’ve done all the screaming already,” said the Queen. “What would be the good of having it all over again?”
<!-- /EN:LG-05-044 -->

> 「まあ、悲鳴はもう、全部上げてしまいましたもの」と女王は言った。「最初からもう一度やって、何の役に立つというのです？」

<a id="LG-05-045"></a>

**LG-05-045**

<!-- EN:LG-05-045 -->
By this time it was getting light. “The crow must have flown away, I think,” said Alice: “I’m so glad it’s gone. I thought it was the night coming on.”
<!-- /EN:LG-05-045 -->

> このころには、あたりが明るくなりはじめていた。「カラスが飛んでいったんだと思います」とアリスは言った。「いなくなって、とても嬉しいです。夜になってきたのかと思っていました」

<a id="LG-05-046"></a>

**LG-05-046**

<!-- EN:LG-05-046 -->
“I wish *I* could manage to be glad!” the Queen said. “Only I never can remember the rule. You must be very happy, living in this wood, and being glad whenever you like!”
<!-- /EN:LG-05-046 -->

> 「*わたくしも*、何とか嬉しくなれればいいのですけれど！」と女王は言った。「ただ、どうしても、その決まりを覚えていられなくて。この森に住んで、好きなときに嬉しくなれるなんて、あなたはとても幸せに違いありませんね！」

<a id="LG-05-047"></a>

**LG-05-047**

<!-- EN:LG-05-047 -->
“Only it is so *very* lonely here!” Alice said in a melancholy voice; and at the thought of her loneliness two large tears came rolling down her cheeks.
<!-- /EN:LG-05-047 -->

> 「ただ、ここは、*本当に*寂しいんです！」とアリスは悲しげな声で言った。ひとりぼっちであることを考えると、大粒の涙がふたつ、頬を転がり落ちた。

<a id="LG-05-048"></a>

**LG-05-048**

<!-- EN:LG-05-048 -->
“Oh, don’t go on like that!” cried the poor Queen, wringing her hands in despair. “Consider what a great girl you are. Consider what a long way you’ve come to-day. Consider what o’clock it is. Consider anything, only don’t cry!”
<!-- /EN:LG-05-048 -->

> 「ああ、そんなふうにしないで！」と、かわいそうな女王は叫び、途方に暮れて両手をもみ合わせた。「自分がもうどんなに大きい子か、考えなさい。今日、どんなに遠くまで来たか、考えなさい。今、何時か、考えなさい。何でも考えていいから、ただ、泣かないで！」

<a id="LG-05-049"></a>

**LG-05-049**

<!-- EN:LG-05-049 -->
Alice could not help laughing at this, even in the midst of her tears. “Can *you* keep from crying by considering things?” she asked.
<!-- /EN:LG-05-049 -->

> これには、アリスも、泣いている最中なのに、笑わずにはいられなかった。「*陛下は*、何かを考えれば、泣かずにいられるのですか？」と聞いた。

<a id="LG-05-050"></a>

**LG-05-050**

<!-- EN:LG-05-050 -->
“That’s the way it’s done,” the Queen said with great decision: “nobody can do two things at once, you know. Let’s consider your age to begin with—how old are you?”
<!-- /EN:LG-05-050 -->

> 「そうやってするものです」と女王は、きっぱりと言った。「誰も一度にふたつのことはできませんからね。まず、あなたの年を考えましょう。いくつですか？」

<a id="LG-05-051"></a>

**LG-05-051**

<!-- EN:LG-05-051 -->
“I’m seven and a half exactly.”
<!-- /EN:LG-05-051 -->

> 「きっかり、七歳半です」

<a id="LG-05-052"></a>

**LG-05-052**

<!-- EN:LG-05-052 -->
“You needn’t say ‘exactually,’” the Queen remarked: “I can believe it without that. Now I’ll give *you* something to believe. I’m just one hundred and one, five months and a day.”
<!-- /EN:LG-05-052 -->

> 「『きっかり』と言わなくても結構ですよ」と女王は言った。「そう言われなくても、信じられますから。今度は、*あなたに*信じてもらうことをお話ししましょう。わたくしは、ちょうど百一歳と五か月と一日です」

> **訳注：** アリスは exactly と言うが、女王は exactually と、少し変えた形で繰り返している。

<a id="LG-05-053"></a>

**LG-05-053**

<!-- EN:LG-05-053 -->
“I can’t believe *that*!” said Alice.
<!-- /EN:LG-05-053 -->

> 「*それは*、信じられません！」とアリスは言った。

<a id="LG-05-054"></a>

**LG-05-054**

<!-- EN:LG-05-054 -->
“Can’t you?” the Queen said in a pitying tone. “Try again: draw a long breath, and shut your eyes.”
<!-- /EN:LG-05-054 -->

> 「できないの？」と女王は気の毒そうに言った。「もう一度やってごらんなさい。深く息を吸って、目を閉じて」

<a id="LG-05-055"></a>

**LG-05-055**

<!-- EN:LG-05-055 -->
Alice laughed. “There’s no use trying,” she said: “one *can’t* believe impossible things.”
<!-- /EN:LG-05-055 -->

> アリスは笑った。「やってみても無駄です」と言った。「ありえないことは、信じ*られない*ものです」

<a id="LG-05-056"></a>

**LG-05-056**

<!-- EN:LG-05-056 -->
“I daresay you haven’t had much practice,” said the Queen. “When I was your age, I always did it for half-an-hour a day. Why, sometimes I’ve believed as many as six impossible things before breakfast. There goes the shawl again!”
<!-- /EN:LG-05-056 -->

> 「きっと、あまり練習をしていないのですね」と女王は言った。「あなたの年のころ、わたくしは毎日、必ず三十分はやっていました。まあ、朝食前に、ありえないことを六つも信じた日さえありましたよ。またショールが飛んでしまう！」

<a id="LG-05-057"></a>

**LG-05-057**

<!-- EN:LG-05-057 -->
The brooch had come undone as she spoke, and a sudden gust of wind blew the Queen’s shawl across a little brook. The Queen spread out her arms again, and went flying after it, and this time she succeeded in catching it for herself. “I’ve got it!” she cried in a triumphant tone. “Now you shall see me pin it on again, all by myself!”
<!-- /EN:LG-05-057 -->

> そう言っているうちにブローチが外れ、不意の突風が、女王のショールを小川の向こうへ吹き飛ばした。女王はまた腕を広げ、そのあとを飛ぶように追いかけた。今度は自分でつかまえることができた。「取れました！」と勝ち誇った声で叫んだ。「今度は、わたくしが誰の手も借りずに、もう一度ピンで留めるところを見せてあげましょう！」

<a id="LG-05-058"></a>

**LG-05-058**

<!-- EN:LG-05-058 -->
“Then I hope your finger is better now?” Alice said very politely, as she crossed the little brook after the Queen.
<!-- /EN:LG-05-058 -->

> 「それでは、お指はもう、よくなったのですね？」とアリスは、女王のあとについて小川を渡りながら、とても丁寧に言った。

<a id="LG-05-059"></a>

<!-- EN:LG-05-059 -->
\*      \*      \*      \*      \*      \*      \*  
<!-- /EN:LG-05-059 -->

<a id="LG-05-060"></a>

<!-- EN:LG-05-060 -->
    \*      \*      \*      \*      \*      \*  
<!-- /EN:LG-05-060 -->

<a id="LG-05-061"></a>

<!-- EN:LG-05-061 -->
\*      \*      \*      \*      \*      \*      \*
<!-- /EN:LG-05-061 -->

<a id="LG-05-062"></a>

**LG-05-062**

<!-- EN:LG-05-062 -->
“Oh, much better!” cried the Queen, her voice rising to a squeak as she went on. “Much be-etter! Be-etter! Be-e-e-etter! Be-e-ehh!” The last word ended in a long bleat, so like a sheep that Alice quite started.
<!-- /EN:LG-05-062 -->

> 「ああ、ずっとよくなりました！」と女王は叫んだ。その声は、続けるうちに、きいきい高くなった。「ずっとベーター！　ベーター！　ベーエーター！　ベーエー！」最後の言葉は、長い鳴き声で終わった。それがあまりに羊に似ていたので、アリスはびっくりした。

> **訳注：** better が次第に引き伸ばされ、羊の bleat「メーという鳴き声」に変わっていく。ここでは英語の音の変化を残した。

<a id="LG-05-063"></a>

**LG-05-063**

<!-- EN:LG-05-063 -->
She looked at the Queen, who seemed to have suddenly wrapped herself up in wool. Alice rubbed her eyes, and looked again. She couldn’t make out what had happened at all. Was she in a shop? And was that really—was it really a *sheep* that was sitting on the other side of the counter? Rub as she could, she could make nothing more of it: she was in a little dark shop, leaning with her elbows on the counter, and opposite to her was an old Sheep, sitting in an arm-chair knitting, and every now and then leaving off to look at her through a great pair of spectacles.
<!-- /EN:LG-05-063 -->

> 女王を見ると、突然、毛糸で全身をくるんだように見えた。アリスは目をこすって、もう一度見た。何が起こったのか、まったくわからなかった。ここは、お店なの？　そして、カウンターの向こうに座っているのは、本当に——本当に、*羊*なの？　いくら目をこすっても、それ以上のことはわからなかった。小さな暗い店の中にいて、カウンターに両肘をついていた。そして向かいには、年を取った羊が肘掛け椅子に座って編み物をしており、ときどき手を休めて、大きな眼鏡越しにアリスを見ていた。

<a id="LG-05-064"></a>

**LG-05-064**

<!-- EN:LG-05-064 -->
“What is it you want to buy?” the Sheep said at last, looking up for a moment from her knitting.
<!-- /EN:LG-05-064 -->

> 「何を買いたいの？」と羊は、編み物からちょっと顔を上げて、ようやく言った。

<a id="LG-05-065"></a>

**LG-05-065**

<!-- EN:LG-05-065 -->
“I don’t *quite* know yet,” Alice said, very gently. “I should like to look all round me first, if I might.”
<!-- /EN:LG-05-065 -->

> 「まだ、*はっきりとは*わかりません」とアリスは、とても穏やかに言った。「よろしければ、まず周りをひととおり見たいのですけれど」

<a id="LG-05-066"></a>

**LG-05-066**

<!-- EN:LG-05-066 -->
“You may look in front of you, and on both sides, if you like,” said the Sheep: “but you can’t look *all* round you—unless you’ve got eyes at the back of your head.”
<!-- /EN:LG-05-066 -->

> 「見たければ、前と左右は見ていいわ」と羊は言った。「でも、周りを*全部*は見られないわよ。頭の後ろに目がついていないかぎりね」

<a id="LG-05-067"></a>

**LG-05-067**

<!-- EN:LG-05-067 -->
But these, as it happened, Alice had *not* got: so she contented herself with turning round, looking at the shelves as she came to them.
<!-- /EN:LG-05-067 -->

> しかし、たまたまアリスには、そんな目はついて*いなかった*。そこで、ぐるりと体を回し、向いた先の棚を順に眺めることで、満足することにした。

<a id="LG-05-068"></a>

**LG-05-068**

<!-- EN:LG-05-068 -->
The shop seemed to be full of all manner of curious things—but the oddest part of it all was, that whenever she looked hard at any shelf, to make out exactly what it had on it, that particular shelf was always quite empty: though the others round it were crowded as full as they could hold.
<!-- /EN:LG-05-068 -->

> 店には、ありとあらゆる奇妙な品物が詰まっているようだった。けれど、何よりおかしかったのは、棚に何が載っているのか、はっきり確かめようとじっと見るたび、その棚だけは、いつもまったく空っぽになることだった。その周りの棚は、これ以上ないほど物でいっぱいなのに。

<a id="LG-05-069"></a>

**LG-05-069**

<!-- EN:LG-05-069 -->
“Things flow about so here!” she said at last in a plaintive tone, after she had spent a minute or so in vainly pursuing a large bright thing, that looked sometimes like a doll and sometimes like a work-box, and was always in the shelf next above the one she was looking at. “And this one is the most provoking of all—but I’ll tell you what—” she added, as a sudden thought struck her, “I’ll follow it up to the very top shelf of all. It’ll puzzle it to go through the ceiling, I expect!”
<!-- /EN:LG-05-069 -->

> 「ここは、物があっちこっちへ流れてしまうのね！」とアリスは、とうとう嘆くように言った。大きくて明るい色をしたものを、一分ほど、むなしく追いかけていたのだ。それは人形に見えたり、裁縫箱に見えたりして、いつも、アリスが見ている棚のすぐ上の棚にあった。「それに、これがいちばん、じれったいわ。でも、いいことを思いついた——」と、突然ひらめいて付け加えた。「いちばん上の棚まで、追いかけてやるわ。天井を通り抜けるとなったら、きっと困るでしょうね！」

<a id="LG-05-070"></a>

**LG-05-070**

<!-- EN:LG-05-070 -->
But even this plan failed: the “thing” went through the ceiling as quietly as possible, as if it were quite used to it.
<!-- /EN:LG-05-070 -->

> けれど、この計画さえ失敗した。その「もの」は、いかにも慣れているとでもいうように、何の苦もなく、すっと天井を通り抜けてしまったのだ。

<a id="LG-05-071"></a>

**LG-05-071**

<!-- EN:LG-05-071 -->
“Are you a child or a teetotum?” the Sheep said, as she took up another pair of needles. “You’ll make me giddy soon, if you go on turning round like that.” She was now working with fourteen pairs at once, and Alice couldn’t help looking at her in great astonishment.
<!-- /EN:LG-05-071 -->

> 「あんたは子供なの、それとも回しゴマなの？」と羊は言い、もう一組の編み針を取った。「そんなふうにぐるぐる回り続けたら、こっちがすぐに目を回すわよ」そのとき羊は、十四組の編み針を同時に動かしていたので、アリスは仰天して見つめずにはいられなかった。

<a id="LG-05-072"></a>

**LG-05-072**

<!-- EN:LG-05-072 -->
“How *can* she knit with so many?” the puzzled child thought to herself. “She gets more and more like a porcupine every minute!”
<!-- /EN:LG-05-072 -->

> 「どうすれば、あんなにたくさんの針で編めるのかしら？」と、困惑した女の子は心の中で思った。「刻々と、ますますヤマアラシみたいになっていくわ！」

<a id="LG-05-073"></a>

**LG-05-073**

<!-- EN:LG-05-073 -->
“Can you row?” the Sheep asked, handing her a pair of knitting-needles as she spoke.
<!-- /EN:LG-05-073 -->

> 「ボートはこげる？」と羊は聞き、そう言いながら、アリスに編み針を一組渡した。

<a id="LG-05-074"></a>

**LG-05-074**

<!-- EN:LG-05-074 -->
“Yes, a little—but not on land—and not with needles—” Alice was beginning to say, when suddenly the needles turned into oars in her hands, and she found they were in a little boat, gliding along between banks: so there was nothing for it but to do her best.
<!-- /EN:LG-05-074 -->

> 「はい、少しは。でも、陸の上ではできませんし、編み針でも——」とアリスが言いかけると、突然、手の中の編み針はオールに変わった。そしてふたりは、小舟に乗って、両岸のあいだを滑るように進んでいた。だから、できるかぎり頑張るほかなかった。

<a id="LG-05-075"></a>

**LG-05-075**

<!-- EN:LG-05-075 -->
“Feather!” cried the Sheep, as she took up another pair of needles.
<!-- /EN:LG-05-075 -->

> 「フェザー！」と羊は叫び、また別の編み針を一組取り上げた。

> **訳注：** feather は「羽」のほか、ボートでは、オールを水から出して戻すとき、ブレードを水平に返す動作を指す。

<a id="LG-05-076"></a>

**LG-05-076**

<!-- EN:LG-05-076 -->
This didn’t sound like a remark that needed any answer, so Alice said nothing, but pulled away. There was something very queer about the water, she thought, as every now and then the oars got fast in it, and would hardly come out again.
<!-- /EN:LG-05-076 -->

> 返事が必要な言葉には聞こえなかったので、アリスは何も言わずにこぎ続けた。水が何だかひどく変だ、と思った。ときどきオールが水に引っかかり、ほとんど抜けなくなるのだ。

<a id="LG-05-077"></a>

**LG-05-077**

<!-- EN:LG-05-077 -->
“Feather! Feather!” the Sheep cried again, taking more needles. “You’ll be catching a crab directly.”
<!-- /EN:LG-05-077 -->

> 「フェザー！　フェザー！」と羊は、さらに編み針を取りながら、また叫んだ。「じきにカニをつかまえてしまうわよ」

> **訳注：** catch a crab はボートの用語で、オールを水に取られてこぎ損なうこと。アリスは、文字どおり「カニを捕る」と受け取る。

<a id="LG-05-078"></a>

**LG-05-078**

<!-- EN:LG-05-078 -->
“A dear little crab!” thought Alice. “I should like that.”
<!-- /EN:LG-05-078 -->

> 「かわいい小さなカニ！」とアリスは思った。「それなら、嬉しいわ」

<a id="LG-05-079"></a>

**LG-05-079**

<!-- EN:LG-05-079 -->
“Didn’t you hear me say ‘Feather’?” the Sheep cried angrily, taking up quite a bunch of needles.
<!-- /EN:LG-05-079 -->

> 「『フェザー』と言うのが聞こえなかったの？」と羊は怒って叫び、編み針をひと束ほども取り上げた。

<a id="LG-05-080"></a>

**LG-05-080**

<!-- EN:LG-05-080 -->
“Indeed I did,” said Alice: “you’ve said it very often—and very loud. Please, where *are* the crabs?”
<!-- /EN:LG-05-080 -->

> 「ちゃんと聞こえました」とアリスは言った。「何度もおっしゃっていますし、とても大きな声ですから。あの、カニは*どこに*いるのですか？」

<a id="LG-05-081"></a>

**LG-05-081**

<!-- EN:LG-05-081 -->
“In the water, of course!” said the Sheep, sticking some of the needles into her hair, as her hands were full. “Feather, I say!”
<!-- /EN:LG-05-081 -->

> 「もちろん、水の中よ！」と羊は言った。両手がいっぱいだったので、編み針を何本か髪に差した。「フェザー、と言っているの！」

<a id="LG-05-082"></a>

**LG-05-082**

<!-- EN:LG-05-082 -->
“*Why* do you say ‘feather’ so often?” Alice asked at last, rather vexed. “I’m not a bird!”
<!-- /EN:LG-05-082 -->

> 「どうして、そんなに何度も『フェザー』って言うのですか？」と、とうとうアリスは、少しいらいらして聞いた。「わたしは鳥ではありません！」

<a id="LG-05-083"></a>

**LG-05-083**

<!-- EN:LG-05-083 -->
“You are,” said the Sheep: “you’re a little goose.”
<!-- /EN:LG-05-083 -->

> 「鳥よ」と羊は言った。「あんたは、小さなガチョウだわ」

> **訳注：** goose は「ガチョウ」だけでなく、人を「ばか・おまぬけ」と呼ぶ言葉にもなる。

<a id="LG-05-084"></a>

**LG-05-084**

<!-- EN:LG-05-084 -->
This offended Alice a little, so there was no more conversation for a minute or two, while the boat glided gently on, sometimes among beds of weeds (which made the oars stick fast in the water, worse then ever), and sometimes under trees, but always with the same tall river-banks frowning over their heads.
<!-- /EN:LG-05-084 -->

> これにはアリスも少し気を悪くしたので、一、二分のあいだ、会話は途切れた。そのあいだにも、小舟は穏やかに滑っていった。ときには水草の茂みの中を（そのせいでオールは、これまで以上に水から抜けなくなった）、ときには木の下を通ったけれど、いつも同じ高い川岸が、ふたりの頭上に険しくそびえていた。

<a id="LG-05-085"></a>

**LG-05-085**

<!-- EN:LG-05-085 -->
“Oh, please! There are some scented rushes!” Alice cried in a sudden transport of delight. “There really are—and *such* beauties!”
<!-- /EN:LG-05-085 -->

> 「ああ、お願い！　香りのよいイグサがあるわ！」とアリスは、急に喜びに夢中になって叫んだ。「本当にあるの。それも、*とびきり*きれいなのが！」

<a id="LG-05-086"></a>

**LG-05-086**

<!-- EN:LG-05-086 -->
“You needn’t say ‘please’ to *me* about ’em,” the Sheep said, without looking up from her knitting: “I didn’t put ’em there, and I’m not going to take ’em away.”
<!-- /EN:LG-05-086 -->

> 「あれのことで、*あたしに*『お願い』なんて言わなくていいわ」と羊は、編み物から顔を上げずに言った。「あたしが植えたんじゃないし、持っていくつもりもないんだから」

<a id="LG-05-087"></a>

**LG-05-087**

<!-- EN:LG-05-087 -->
“No, but I meant—please, may we wait and pick some?” Alice pleaded. “If you don’t mind stopping the boat for a minute.”
<!-- /EN:LG-05-087 -->

> 「いいえ、でも、わたしが言いたいのは、お願いですから、止まって、少し摘んでもいいでしょうかということです」とアリスは頼んだ。「ちょっと舟を止めてくださるなら」

<a id="LG-05-088"></a>

**LG-05-088**

<!-- EN:LG-05-088 -->
“How am *I* to stop it?” said the Sheep. “If you leave off rowing, it’ll stop of itself.”
<!-- /EN:LG-05-088 -->

> 「*あたしが*どうやって止めるの？」と羊は言った。「あんたがこぐのをやめれば、ひとりでに止まるわ」

<a id="LG-05-089"></a>

**LG-05-089**

<!-- EN:LG-05-089 -->
So the boat was left to drift down the stream as it would, till it glided gently in among the waving rushes. And then the little sleeves were carefully rolled up, and the little arms were plunged in elbow-deep to get the rushes a good long way down before breaking them off—and for a while Alice forgot all about the Sheep and the knitting, as she bent over the side of the boat, with just the ends of her tangled hair dipping into the water—while with bright eager eyes she caught at one bunch after another of the darling scented rushes.
<!-- /EN:LG-05-089 -->

> そこで舟は、流れに任せて下るままにされ、やがて、揺れるイグサのあいだへ静かに滑り込んだ。小さな袖が丁寧にまくり上げられ、小さな腕が肘まで水に差し込まれた。なるべく下のほうをつかんで、長く折り取るためだった。しばらくのあいだアリスは、羊も編み物も、何もかも忘れた。舟べりから身を乗り出し、もつれた髪の先だけを水に浸しながら、きらきらした熱心な目で、かわいい、香りのよいイグサの束を、次から次へとつかんだ。

<a id="LG-05-090"></a>

**LG-05-090**

<!-- EN:LG-05-090 -->
“I only hope the boat won’t tipple over!” she said to herself. “Oh, *what* a lovely one! Only I couldn’t quite reach it.” And it certainly *did* seem a little provoking (“almost as if it happened on purpose,” she thought) that, though she managed to pick plenty of beautiful rushes as the boat glided by, there was always a more lovely one that she couldn’t reach.
<!-- /EN:LG-05-090 -->

> 「舟がひっくり返らなければいいのだけれど！」と独り言を言った。「ああ、*何て*きれいなの！　でも、あと少しのところで届かなかったわ」そして実際、少しじれったい*ことだった*（「わざとそうなっているみたい」とアリスは思った）。舟が進むにつれて、きれいなイグサをたくさん摘めたのに、それよりもっときれいな一本が、いつも手の届かないところにあったのだから。

<a id="LG-05-091"></a>

**LG-05-091**

<!-- EN:LG-05-091 -->
“The prettiest are always further!” she said at last, with a sigh at the obstinacy of the rushes in growing so far off, as, with flushed cheeks and dripping hair and hands, she scrambled back into her place, and began to arrange her new-found treasures.
<!-- /EN:LG-05-091 -->

> 「いちばんきれいなのは、いつも、もっと遠くなのね！」と、ついに言った。そう遠くにばかり生えたがるイグサの頑固さに、ため息をついた。そして、頬を赤くし、髪と手から水を滴らせながら、自分の席へよじ戻り、新しく手に入れた宝物を並べはじめた。

<a id="LG-05-092"></a>

**LG-05-092**

<!-- EN:LG-05-092 -->
What mattered it to her just then that the rushes had begun to fade, and to lose all their scent and beauty, from the very moment that she picked them? Even real scented rushes, you know, last only a very little while—and these, being dream-rushes, melted away almost like snow, as they lay in heaps at her feet—but Alice hardly noticed this, there were so many other curious things to think about.
<!-- /EN:LG-05-092 -->

> 摘んだその瞬間から、イグサがしおれはじめ、香りも美しさもみんな失いはじめていたからといって、そのときのアリスに、何の関わりがあっただろう？　本物の香りのよいイグサでさえ、ほんのわずかなあいだしか、もちはしない。まして、これは夢のイグサだったので、アリスの足元に山となって横たわりながら、ほとんど雪のように溶けていった。けれどアリスは、それにほとんど気づかなかった。ほかにも考えるべき奇妙なことが、あまりにたくさんあったからだ。

<a id="LG-05-093"></a>

**LG-05-093**

<!-- EN:LG-05-093 -->
They hadn’t gone much farther before the blade of one of the oars got fast in the water and *wouldn’t* come out again (so Alice explained it afterwards), and the consequence was that the handle of it caught her under the chin, and, in spite of a series of little shrieks of “Oh, oh, oh!” from poor Alice, it swept her straight off the seat, and down among the heap of rushes.
<!-- /EN:LG-05-093 -->

> そこから大して進まないうちに、片方のオールの先が水に引っかかり、どうしても抜けようと*しなくなった*（アリスは、あとでそう説明した）。そのために柄が顎の下に引っかかり、かわいそうなアリスが「ああ、ああ、ああ！」と何度も小さな悲鳴を上げたのもかまわず、座席からすくい上げ、そのままイグサの山の中へ落としてしまった。

<a id="LG-05-094"></a>

**LG-05-094**

<!-- EN:LG-05-094 -->
However, she wasn’t hurt, and was soon up again: the Sheep went on with her knitting all the while, just as if nothing had happened. “That was a nice crab you caught!” she remarked, as Alice got back into her place, very much relieved to find herself still in the boat.
<!-- /EN:LG-05-094 -->

> けれど、けがはなく、すぐに起き上がれた。羊はそのあいだじゅう、何事もなかったように編み物を続けていた。「立派なカニをつかまえたものね！」と羊は言った。アリスは、まだ舟の中にいるとわかって、心からほっとしながら、自分の席へ戻った。

<a id="LG-05-095"></a>

**LG-05-095**

<!-- EN:LG-05-095 -->
“Was it? I didn’t see it,” Said Alice, peeping cautiously over the side of the boat into the dark water. “I wish it hadn’t let go—I should so like to see a little crab to take home with me!” But the Sheep only laughed scornfully, and went on with her knitting.
<!-- /EN:LG-05-095 -->

> 「そうでしたか？　見えませんでした」とアリスは言い、舟べりから暗い水を用心深くのぞいた。「離さずにつかまえていてくれればよかったのに。家に連れて帰れる、小さなカニを見てみたかったわ！」けれど羊は、ただ馬鹿にしたように笑い、編み物を続けた。

<a id="LG-05-096"></a>

**LG-05-096**

<!-- EN:LG-05-096 -->
“Are there many crabs here?” said Alice.
<!-- /EN:LG-05-096 -->

> 「ここには、カニがたくさんいるのですか？」とアリスは聞いた。

<a id="LG-05-097"></a>

**LG-05-097**

<!-- EN:LG-05-097 -->
“Crabs, and all sorts of things,” said the Sheep: “plenty of choice, only make up your mind. Now, what *do* you want to buy?”
<!-- /EN:LG-05-097 -->

> 「カニも、何もかも、いろいろあるわよ」と羊は言った。「選ぶものはいくらでもあるから、とにかく決めなさい。それで、*何を*買いたいの？」

<a id="LG-05-098"></a>

**LG-05-098**

<!-- EN:LG-05-098 -->
“To buy!” Alice echoed in a tone that was half astonished and half frightened—for the oars, and the boat, and the river, had vanished all in a moment, and she was back again in the little dark shop.
<!-- /EN:LG-05-098 -->

> 「買うですって！」とアリスは、半分驚き、半分怯えた声で繰り返した。オールも舟も川も、すべて一瞬で消え失せ、またあの小さな暗い店に戻っていたからだ。

<a id="LG-05-099"></a>

**LG-05-099**

<!-- EN:LG-05-099 -->
“I should like to buy an egg, please,” she said timidly. “How do you sell them?”
<!-- /EN:LG-05-099 -->

> 「卵をひとつ、買いたいのですけれど」と、おずおず言った。「おいくらですか？」

<a id="LG-05-100"></a>

**LG-05-100**

<!-- EN:LG-05-100 -->
“Fivepence farthing for one—Twopence for two,” the Sheep replied.
<!-- /EN:LG-05-100 -->

> 「ひとつなら、五ペンスと一ファージング。ふたつなら、二ペンス」と羊は答えた。

> **訳注：** farthing は当時の一ペニーの四分の一。ふたつのほうがひとつより安いという、不思議な値付けになっている。

<a id="LG-05-101"></a>

**LG-05-101**

<!-- EN:LG-05-101 -->
“Then two are cheaper than one?” Alice said in a surprised tone, taking out her purse.
<!-- /EN:LG-05-101 -->

> 「それなら、ふたつのほうが、ひとつより安いのですか？」とアリスは驚いた声で言い、財布を取り出した。

<a id="LG-05-102"></a>

**LG-05-102**

<!-- EN:LG-05-102 -->
“Only you *must* eat them both, if you buy two,” said the Sheep.
<!-- /EN:LG-05-102 -->

> 「ただし、ふたつ買ったら、両方とも食べ*なくちゃ*いけないわよ」と羊は言った。

<a id="LG-05-103"></a>

**LG-05-103**

<!-- EN:LG-05-103 -->
“Then I’ll have *one*, please,” said Alice, as she put the money down on the counter. For she thought to herself, “They mightn’t be at all nice, you know.”
<!-- /EN:LG-05-103 -->

> 「それなら、*ひとつ*ください」とアリスは言い、カウンターにお金を置いた。心の中で、「ちっともおいしくないかもしれないものね」と思ったからだ。

<a id="LG-05-104"></a>

**LG-05-104**

<!-- EN:LG-05-104 -->
The Sheep took the money, and put it away in a box: then she said “I never put things into people’s hands—that would never do—you must get it for yourself.” And so saying, she went off to the other end of the shop, and set the egg upright on a shelf.
<!-- /EN:LG-05-104 -->

> 羊はお金を取り、箱へしまった。それから言った。「あたしは、人の手に直接物を渡したりはしないわ。それは絶対にいけないの。自分で取りなさい」そう言うと、店の反対の端へ行き、卵を棚の上に立てて置いた。

<a id="LG-05-105"></a>

**LG-05-105**

<!-- EN:LG-05-105 -->
“I wonder *why* it wouldn’t do?” thought Alice, as she groped her way among the tables and chairs, for the shop was very dark towards the end. “The egg seems to get further away the more I walk towards it. Let me see, is this a chair? Why, it’s got branches, I declare! How very odd to find trees growing here! And actually here’s a little brook! Well, this is the very queerest shop I ever saw!”
<!-- /EN:LG-05-105 -->

> 「*どうして*いけないのかしら？」とアリスは思い、テーブルや椅子のあいだを、手探りで進んだ。店の奥のほうは、ひどく暗かったのだ。「あの卵、近づけば近づくほど、遠ざかるみたい。ええと、これは椅子かしら？　あら、枝がついているじゃない！　こんなところに木が生えているなんて、何て変なの！　それに、本当に、小川まであるわ！　まあ、今まで見た中で、いちばんおかしなお店だわ！」

<a id="LG-05-106"></a>

<!-- EN:LG-05-106 -->
\*      \*      \*      \*      \*      \*      \*  
<!-- /EN:LG-05-106 -->

<a id="LG-05-107"></a>

<!-- EN:LG-05-107 -->
    \*      \*      \*      \*      \*      \*  
<!-- /EN:LG-05-107 -->

<a id="LG-05-108"></a>

<!-- EN:LG-05-108 -->
\*      \*      \*      \*      \*      \*      \*
<!-- /EN:LG-05-108 -->

<a id="LG-05-109"></a>

**LG-05-109**

<!-- EN:LG-05-109 -->
So she went on, wondering more and more at every step, as everything turned into a tree the moment she came up to it, and she quite expected the egg to do the same.
<!-- /EN:LG-05-109 -->

> こうしてアリスは、一歩ごとにますます不思議に思いながら、進んでいった。どんなものも、近づくと、そのとたんに木になってしまうので、卵もきっと同じようになるのだろうと、すっかり思い込んでいた。

[章目次へ戻る](#book-top)

---

<a id="lg-chapter-06"></a>

## 第6章　ハンプティ・ダンプティ

### CHAPTER VI. Humpty Dumpty

<a id="LG-06-001"></a>

**LG-06-001**

<!-- EN:LG-06-001 -->
However, the egg only got larger and larger, and more and more human: when she had come within a few yards of it, she saw that it had eyes and a nose and mouth; and when she had come close to it, she saw clearly that it was HUMPTY DUMPTY himself. “It can’t be anybody else!” she said to herself. “I’m as certain of it, as if his name were written all over his face.”
<!-- /EN:LG-06-001 -->

> けれど卵は、ただ大きくなるばかりで、ますます人間らしくなっていった。あと数ヤードというところまで来ると、目も鼻も口もあるのが分かった。そしてすぐそばまで近づくと、それがハンプティ・ダンプティその人だとはっきり分かった。「ほかのだれかであるはずがないわ！」アリスは独り言を言った。「顔じゅうに名前が書いてあるのと同じくらい、確かだもの」

<a id="LG-06-002"></a>

**LG-06-002**

<!-- EN:LG-06-002 -->
It might have been written a hundred times, easily, on that enormous face. Humpty Dumpty was sitting with his legs crossed, like a Turk, on the top of a high wall—such a narrow one that Alice quite wondered how he could keep his balance—and, as his eyes were steadily fixed in the opposite direction, and he didn’t take the least notice of her, she thought he must be a stuffed figure after all.
<!-- /EN:LG-06-002 -->

> あの大きな顔なら、名前を百回だって楽に書けただろう。ハンプティ・ダンプティは高い塀のてっぺんに、トルコ人のように足を組んで座っていた。その塀はとても細くて、よく釣り合いを保てるものだと、アリスは感心してしまった。彼は反対の方角に目をじっと向けたまま、アリスをまるで気に留めなかったので、やっぱり中身を詰めた人形に違いない、と彼女は思った。

<a id="LG-06-003"></a>

**LG-06-003**

<!-- EN:LG-06-003 -->
“And how exactly like an egg he is!” she said aloud, standing with her hands ready to catch him, for she was every moment expecting him to fall.
<!-- /EN:LG-06-003 -->

> 「それに、卵にそっくりだこと！」アリスは声に出して言った。今にも落ちるのではないかと、ずっと思っていたので、いつでも受け止められるよう手を構えて立っていた。

<a id="LG-06-004"></a>

**LG-06-004**

<!-- EN:LG-06-004 -->
“It’s *very* provoking,” Humpty Dumpty said after a long silence, looking away from Alice as he spoke, “to be called an egg—*Very!*”
<!-- /EN:LG-06-004 -->

> 「*まったく*腹が立つな」と、長い沈黙のあと、ハンプティ・ダンプティはアリスから目をそらしたまま言った。「卵呼ばわりされるとは――*まったく！*」

<a id="LG-06-005"></a>

**LG-06-005**

<!-- EN:LG-06-005 -->
“I said you *looked* like an egg, Sir,” Alice gently explained. “And some eggs are very pretty, you know” she added, hoping to turn her remark into a sort of a compliment.
<!-- /EN:LG-06-005 -->

> 「卵みたいに*見える*と言ったのです」とアリスはやんわり説明した。「それに、とてもきれいな卵だってあるでしょう」と付け加えた。何とか褒め言葉のようにしたかったのだ。

<a id="LG-06-006"></a>

**LG-06-006**

<!-- EN:LG-06-006 -->
“Some people,” said Humpty Dumpty, looking away from her as usual, “have no more sense than a baby!”
<!-- /EN:LG-06-006 -->

> 「世の中には」とハンプティ・ダンプティは、相変わらず目をそらして言った。「赤ん坊並みの分別しかない者がいる！」

<a id="LG-06-007"></a>

**LG-06-007**

<!-- EN:LG-06-007 -->
Alice didn’t know what to say to this: it wasn’t at all like conversation, she thought, as he never said anything to *her*; in fact, his last remark was evidently addressed to a tree—so she stood and softly repeated to herself:—
<!-- /EN:LG-06-007 -->

> アリスは、これに何と答えればよいのか分からなかった。少しも会話らしくない、と思った。相手は何一つ、*自分に向かって*言わないのだ。実際、最後の言葉は明らかに一本の木へ向けられていた。そこでアリスは立ったまま、小声でそっと唱えた。

<a id="LG-06-008"></a>

**LG-06-008**

<!-- EN:LG-06-008 -->
“Humpty Dumpty sat on a wall:  
Humpty Dumpty had a great fall.  
All the King’s horses and all the King’s men  
Couldn’t put Humpty Dumpty in his place again.”
<!-- /EN:LG-06-008 -->

> 「ハンプティ・ダンプティ、塀の上に座っていた。  
> ハンプティ・ダンプティ、どしんと落っこちた。  
> 王様の馬も、王様の家来も、みんな集まったけれど、  
> ハンプティ・ダンプティを、もとの場所へは戻せなかった」

<a id="LG-06-009"></a>

**LG-06-009**

<!-- EN:LG-06-009 -->
“That last line is much too long for the poetry,” she added, almost out loud, forgetting that Humpty Dumpty would hear her.
<!-- /EN:LG-06-009 -->

> 「最後の行は、詩にしては長すぎるわね」と付け加えた。ハンプティ・ダンプティに聞こえることを忘れて、ほとんど普通の声になっていた。

<a id="LG-06-010"></a>

**LG-06-010**

<!-- EN:LG-06-010 -->
“Don’t stand there chattering to yourself like that,” Humpty Dumpty said, looking at her for the first time, “but tell me your name and your business.”
<!-- /EN:LG-06-010 -->

> 「そこでそんなふうに、一人でぺちゃくちゃしゃべっていないで」とハンプティ・ダンプティは、初めてアリスを見て言った。「名前と用件を言いなさい」

<a id="LG-06-011"></a>

**LG-06-011**

<!-- EN:LG-06-011 -->
“My *name* is Alice, but—”
<!-- /EN:LG-06-011 -->

> 「*名前は*アリスですけれど……」

<a id="LG-06-012"></a>

**LG-06-012**

<!-- EN:LG-06-012 -->
“It’s a stupid enough name!” Humpty Dumpty interrupted impatiently. “What does it mean?”
<!-- /EN:LG-06-012 -->

> 「十分ばかげた名前だ！」ハンプティ・ダンプティはいらいらして遮った。「どういう意味だね？」

<a id="LG-06-013"></a>

**LG-06-013**

<!-- EN:LG-06-013 -->
“*Must* a name mean something?” Alice asked doubtfully.
<!-- /EN:LG-06-013 -->

> 「名前には何か意味が*なくちゃいけない*の？」アリスは心もとなげに尋ねた。

<a id="LG-06-014"></a>

**LG-06-014**

<!-- EN:LG-06-014 -->
“Of course it must,” Humpty Dumpty said with a short laugh: “*my* name means the shape I am—and a good handsome shape it is, too. With a name like yours, you might be any shape, almost.”
<!-- /EN:LG-06-014 -->

> 「もちろん、なくちゃいけない」とハンプティ・ダンプティは短く笑った。「*私の*名前は、この姿を意味している。しかも、なかなか見事な姿だ。おまえのような名前では、ほとんどどんな姿でもよいことになる」

<a id="LG-06-015"></a>

**LG-06-015**

<!-- EN:LG-06-015 -->
“Why do you sit out here all alone?” said Alice, not wishing to begin an argument.
<!-- /EN:LG-06-015 -->

> 「どうして、こんな外に一人きりで座っているの？」議論を始めたくなかったので、アリスはそう尋ねた。

<a id="LG-06-016"></a>

**LG-06-016**

<!-- EN:LG-06-016 -->
“Why, because there’s nobody with me!” cried Humpty Dumpty. “Did you think I didn’t know the answer to *that*? Ask another.”
<!-- /EN:LG-06-016 -->

> 「そりゃ、一緒にいる者がだれもいないからだ！」ハンプティ・ダンプティは叫んだ。「*そんなことの*答えも知らないと思ったのか？　別のを聞きなさい」

<a id="LG-06-017"></a>

**LG-06-017**

<!-- EN:LG-06-017 -->
“Don’t you think you’d be safer down on the ground?” Alice went on, not with any idea of making another riddle, but simply in her good-natured anxiety for the queer creature. “That wall is so *very* narrow!”
<!-- /EN:LG-06-017 -->

> 「地面へ下りたほうが安全だと思わない？」アリスは続けた。別のなぞなぞを出そうとしたのではなく、ただ親切心から、この奇妙な生き物を心配したのだった。「その塀、とても*細い*んだもの！」

<a id="LG-06-018"></a>

**LG-06-018**

<!-- EN:LG-06-018 -->
“What tremendously easy riddles you ask!” Humpty Dumpty growled out. “Of course I don’t think so! Why, if ever I *did* fall off—which there’s no chance of—but *if* I did—” Here he pursed his lips and looked so solemn and grand that Alice could hardly help laughing. “*If* I did fall,” he went on, “*The King has promised me—with his very own mouth*—to—to—”
<!-- /EN:LG-06-018 -->

> 「なんとまあ、途方もなく簡単ななぞなぞを出すのだ！」ハンプティ・ダンプティはうなるように言った。「もちろん、そんなことは思わん！　そもそも、仮に落ちた*としても*――そんなことはありえないが――それでも*もし*落ちたら……」そこで唇をきゅっと結び、いかにも重々しく偉そうな顔をしたので、アリスは笑いをこらえるのに苦労した。「*もし*私が落ちたら」と彼は続けた。「*王様は約束してくださったのだ、ご自身の口で*……その……その……」

<a id="LG-06-019"></a>

**LG-06-019**

<!-- EN:LG-06-019 -->
“To send all his horses and all his men,” Alice interrupted, rather unwisely.
<!-- /EN:LG-06-019 -->

> 「馬も家来も、全部送ってくださると」とアリスは、あまり賢くないことに、口を挟んだ。

<a id="LG-06-020"></a>

**LG-06-020**

<!-- EN:LG-06-020 -->
“Now I declare that’s too bad!” Humpty Dumpty cried, breaking into a sudden passion. “You’ve been listening at doors—and behind trees—and down chimneys—or you couldn’t have known it!”
<!-- /EN:LG-06-020 -->

> 「まったく、これはひどすぎる！」ハンプティ・ダンプティは、突然かっとなって叫んだ。「扉のところで盗み聞きをしていたな！　木の陰でも！　煙突の中からも！　そうでなければ知っているはずがない！」

<a id="LG-06-021"></a>

**LG-06-021**

<!-- EN:LG-06-021 -->
“I haven’t, indeed!” Alice said very gently. “It’s in a book.”
<!-- /EN:LG-06-021 -->

> 「ほんとうに、そんなことしていません」とアリスは、とても穏やかに言った。「本に載っているのです」

<a id="LG-06-022"></a>

**LG-06-022**

<!-- EN:LG-06-022 -->
“Ah, well! They may write such things in a *book*,” Humpty Dumpty said in a calmer tone. “That’s what you call a History of England, that is. Now, take a good look at me! I’m one that has spoken to a King, *I* am: mayhap you’ll never see such another: and to show you I’m not proud, you may shake hands with me!” And he grinned almost from ear to ear, as he leant forwards (and as nearly as possible fell off the wall in doing so) and offered Alice his hand. She watched him a little anxiously as she took it. “If he smiled much more, the ends of his mouth might meet behind,” she thought: “and then I don’t know what would happen to his head! I’m afraid it would come off!”
<!-- /EN:LG-06-022 -->

> 「ああ、それなら！　*本*にそういうことが書いてあるのは、ありうるな」とハンプティ・ダンプティは、いくらか落ち着いた声で言った。「それは、いわゆるイングランド史というものだ。さあ、よく私を見なさい！　*私は*王様と話をした者なのだ。こんな者には、もう二度と会えんかもしれんぞ。それから、私が高慢ではない証拠に、握手をさせてやろう！」そう言って、ほとんど耳から耳までにやりと笑い、前へ身を乗り出して――そのために、あやうく塀から落ちそうになりながら――アリスへ手を差し出した。アリスは少しはらはらしながら、その手を取った。「これ以上笑ったら、口の端が後ろでくっつくかもしれないわ」と思った。「そうしたら頭がどうなるか、分からない！　外れてしまうんじゃないかしら！」

<a id="LG-06-023"></a>

**LG-06-023**

<!-- EN:LG-06-023 -->
“Yes, all his horses and all his men,” Humpty Dumpty went on. “They’d pick me up again in a minute, *they* would! However, this conversation is going on a little too fast: let’s go back to the last remark but one.”
<!-- /EN:LG-06-023 -->

> 「そう、馬も家来も全部だ」とハンプティ・ダンプティは続けた。「*あの者たちなら*、たちまち私を起こしてくれる！　しかし、会話が少し速く進みすぎているな。さっきの一つ前の発言に戻ろう」

<a id="LG-06-024"></a>

**LG-06-024**

<!-- EN:LG-06-024 -->
“I’m afraid I can’t quite remember it,” Alice said very politely.
<!-- /EN:LG-06-024 -->

> 「はっきり覚えていなくて、すみません」とアリスは、とても丁寧に言った。

<a id="LG-06-025"></a>

**LG-06-025**

<!-- EN:LG-06-025 -->
“In that case we start fresh,” said Humpty Dumpty, “and it’s my turn to choose a subject—” (“He talks about it just as if it was a game!” thought Alice.) “So here’s a question for you. How old did you say you were?”
<!-- /EN:LG-06-025 -->

> 「それなら、初めからやり直しだ」とハンプティ・ダンプティ。「そして今度は、私が話題を選ぶ番だ――」（「まるでゲームみたいに話すのね！」とアリスは思った。）「では質問しよう。いくつだと言ったかね？」

<a id="LG-06-026"></a>

**LG-06-026**

<!-- EN:LG-06-026 -->
Alice made a short calculation, and said “Seven years and six months.”
<!-- /EN:LG-06-026 -->

> アリスはちょっと計算して、「七歳六か月」と答えた。

<a id="LG-06-027"></a>

**LG-06-027**

<!-- EN:LG-06-027 -->
“Wrong!” Humpty Dumpty exclaimed triumphantly. “You never said a word like it!”
<!-- /EN:LG-06-027 -->

> 「違う！」ハンプティ・ダンプティは勝ち誇って叫んだ。「そんなことは、一言も言っていない！」

<a id="LG-06-028"></a>

**LG-06-028**

<!-- EN:LG-06-028 -->
“I though you meant ‘How old *are* you?’” Alice explained.
<!-- /EN:LG-06-028 -->

> 「『今いくつ*なのか*』という意味だと思ったの」とアリスは説明した。

<a id="LG-06-029"></a>

**LG-06-029**

<!-- EN:LG-06-029 -->
“If I’d meant that, I’d have said it,” said Humpty Dumpty.
<!-- /EN:LG-06-029 -->

> 「その意味なら、そう言ったはずだ」とハンプティ・ダンプティ。

<a id="LG-06-030"></a>

**LG-06-030**

<!-- EN:LG-06-030 -->
Alice didn’t want to begin another argument, so she said nothing.
<!-- /EN:LG-06-030 -->

> また議論を始めたくなかったので、アリスは何も言わなかった。

<a id="LG-06-031"></a>

**LG-06-031**

<!-- EN:LG-06-031 -->
“Seven years and six months!” Humpty Dumpty repeated thoughtfully. “An uncomfortable sort of age. Now if you’d asked *my* advice, I’d have said ‘Leave off at seven’—but it’s too late now.”
<!-- /EN:LG-06-031 -->

> 「七歳六か月か！」ハンプティ・ダンプティは考え深げに繰り返した。「どうにも落ち着かん年齢だ。*私に*相談していれば、『七歳でやめておけ』と言ってやったのに。だが、もう遅い」

<a id="LG-06-032"></a>

**LG-06-032**

<!-- EN:LG-06-032 -->
“I never ask advice about growing,” Alice said indignantly.
<!-- /EN:LG-06-032 -->

> 「大きくなることを、人に相談したりしないわ」とアリスは憤慨して言った。

<a id="LG-06-033"></a>

**LG-06-033**

<!-- EN:LG-06-033 -->
“Too proud?” the other inquired.
<!-- /EN:LG-06-033 -->

> 「高慢すぎるのかね？」と相手は尋ねた。

<a id="LG-06-034"></a>

**LG-06-034**

<!-- EN:LG-06-034 -->
Alice felt even more indignant at this suggestion. “I mean,” she said, “that one can’t help growing older.”
<!-- /EN:LG-06-034 -->

> そう言われると、アリスはますます腹を立てた。「つまり」と言った。「人は、年を取るのをやめられないということよ」

<a id="LG-06-035"></a>

**LG-06-035**

<!-- EN:LG-06-035 -->
“*One* can’t, perhaps,” said Humpty Dumpty, “but *two* can. With proper assistance, you might have left off at seven.”
<!-- /EN:LG-06-035 -->

> 「*一人*では、やめられんかもしれん」とハンプティ・ダンプティ。「しかし、*二人*ならできる。適切な助けがあれば、おまえも七歳でやめられたかもしれん」

> **訳注：** Alice の one は人一般を表すが、Humpty Dumpty はそれを数の「一」と受け取り、two と対比する。

<a id="LG-06-036"></a>

**LG-06-036**

<!-- EN:LG-06-036 -->
“What a beautiful belt you’ve got on!” Alice suddenly remarked.
<!-- /EN:LG-06-036 -->

> 「なんてすてきなベルトをしているの！」アリスは突然そう言った。

<a id="LG-06-037"></a>

**LG-06-037**

<!-- EN:LG-06-037 -->
(They had had quite enough of the subject of age, she thought: and if they really were to take turns in choosing subjects, it was her turn now.) “At least,” she corrected herself on second thoughts, “a beautiful cravat, I should have said—no, a belt, I mean—I beg your pardon!” she added in dismay, for Humpty Dumpty looked thoroughly offended, and she began to wish she hadn’t chosen that subject. “If I only knew,” she thought to herself, “which was neck and which was waist!”
<!-- /EN:LG-06-037 -->

> （年齢の話はもう十分だ、とアリスは思った。本当に順番に話題を選ぶのなら、今度は自分の番だった。）「いえ」と考え直して訂正した。「すてきなクラバット、と言うべきだったわ。違う、ベルトのことよ。ごめんなさい！」アリスはうろたえて付け加えた。ハンプティ・ダンプティがすっかり気を悪くした顔をしたので、この話題にしなければよかったと思い始めた。「どこが首で、どこが腰なのか、分かりさえすれば！」と心の中で思った。

> **訳注：** cravat は首に巻く布。ハンプティ・ダンプティの体形では、首と腰の区別がつきにくい。

<a id="LG-06-038"></a>

**LG-06-038**

<!-- EN:LG-06-038 -->
Evidently Humpty Dumpty was very angry, though he said nothing for a minute or two. When he *did* speak again, it was in a deep growl.
<!-- /EN:LG-06-038 -->

> ハンプティ・ダンプティは明らかに、ひどく怒っていたが、一、二分は何も言わなかった。やがて口を*開いた*とき、その声は低いうなり声になっていた。

<a id="LG-06-039"></a>

**LG-06-039**

<!-- EN:LG-06-039 -->
“It is a—*most—provoking*—thing,” he said at last, “when a person doesn’t know a cravat from a belt!”
<!-- /EN:LG-06-039 -->

> 「まったく――*ひどく――腹立たしい*――ことだ」と、とうとう言った。「クラバットとベルトの見分けもつかない者がいるとは！」

<a id="LG-06-040"></a>

**LG-06-040**

<!-- EN:LG-06-040 -->
“I know it’s very ignorant of me,” Alice said, in so humble a tone that Humpty Dumpty relented.
<!-- /EN:LG-06-040 -->

> 「わたしが、とても物知らずなのね」とアリスは言った。その口調があまりにへりくだっていたので、ハンプティ・ダンプティも機嫌を直した。

<a id="LG-06-041"></a>

**LG-06-041**

<!-- EN:LG-06-041 -->
“It’s a cravat, child, and a beautiful one, as you say. It’s a present from the White King and Queen. There now!”
<!-- /EN:LG-06-041 -->

> 「クラバットだ、お嬢さん。おまえの言うとおり、すてきなものだ。白の王様と女王様からの贈り物なのだぞ。どうだ！」

<a id="LG-06-042"></a>

**LG-06-042**

<!-- EN:LG-06-042 -->
“Is it really?” said Alice, quite pleased to find that she *had* chosen a good subject, after all.
<!-- /EN:LG-06-042 -->

> 「ほんとうに？」とアリスは言った。結局、自分はよい話題を選んで*いた*のだと分かって、とてもうれしかった。

<a id="LG-06-043"></a>

**LG-06-043**

<!-- EN:LG-06-043 -->
“They gave it me,” Humpty Dumpty continued thoughtfully, as he crossed one knee over the other and clasped his hands round it, “they gave it me—for an un-birthday present.”
<!-- /EN:LG-06-043 -->

> 「これをくださったのは」とハンプティ・ダンプティは、片膝をもう一方の膝に重ね、そのまわりで両手を組んで、考え深げに続けた。「これをくださったのは、非誕生日の贈り物としてだ」

<a id="LG-06-044"></a>

**LG-06-044**

<!-- EN:LG-06-044 -->
“I beg your pardon?” Alice said with a puzzled air.
<!-- /EN:LG-06-044 -->

> 「失礼ですが？」アリスは不思議そうな顔で言った。

<a id="LG-06-045"></a>

**LG-06-045**

<!-- EN:LG-06-045 -->
“I’m not offended,” said Humpty Dumpty.
<!-- /EN:LG-06-045 -->

> 「怒ってはいないぞ」とハンプティ・ダンプティ。

> **訳注：** I beg your pardon? という聞き返しを、ここでは謝罪として受け取っている。

<a id="LG-06-046"></a>

**LG-06-046**

<!-- EN:LG-06-046 -->
“I mean, what *is* an un-birthday present?”
<!-- /EN:LG-06-046 -->

> 「つまり、非誕生日の贈り物って、*何なの*？」

<a id="LG-06-047"></a>

**LG-06-047**

<!-- EN:LG-06-047 -->
“A present given when it isn’t your birthday, of course.”
<!-- /EN:LG-06-047 -->

> 「もちろん、誕生日ではないときにもらう贈り物だ」

<a id="LG-06-048"></a>

**LG-06-048**

<!-- EN:LG-06-048 -->
Alice considered a little. “I like birthday presents best,” she said at last.
<!-- /EN:LG-06-048 -->

> アリスは少し考えた。「わたしは誕生日の贈り物がいちばん好き」と、ようやく言った。

<a id="LG-06-049"></a>

**LG-06-049**

<!-- EN:LG-06-049 -->
“You don’t know what you’re talking about!” cried Humpty Dumpty. “How many days are there in a year?”
<!-- /EN:LG-06-049 -->

> 「自分が何を言っているか、分かっていないな！」ハンプティ・ダンプティは叫んだ。「一年は何日だ？」

<a id="LG-06-050"></a>

**LG-06-050**

<!-- EN:LG-06-050 -->
“Three hundred and sixty-five,” said Alice.
<!-- /EN:LG-06-050 -->

> 「三百六十五日」とアリス。

<a id="LG-06-051"></a>

**LG-06-051**

<!-- EN:LG-06-051 -->
“And how many birthdays have you?”
<!-- /EN:LG-06-051 -->

> 「では、おまえの誕生日は何日ある？」

<a id="LG-06-052"></a>

**LG-06-052**

<!-- EN:LG-06-052 -->
“One.”
<!-- /EN:LG-06-052 -->

> 「一日」

<a id="LG-06-053"></a>

**LG-06-053**

<!-- EN:LG-06-053 -->
“And if you take one from three hundred and sixty-five, what remains?”
<!-- /EN:LG-06-053 -->

> 「では、三百六十五から一を引くと、いくつ残る？」

<a id="LG-06-054"></a>

**LG-06-054**

<!-- EN:LG-06-054 -->
“Three hundred and sixty-four, of course.”
<!-- /EN:LG-06-054 -->

> 「もちろん、三百六十四」

<a id="LG-06-055"></a>

**LG-06-055**

<!-- EN:LG-06-055 -->
Humpty Dumpty looked doubtful. “I’d rather see that done on paper,” he said.
<!-- /EN:LG-06-055 -->

> ハンプティ・ダンプティは疑わしそうな顔をした。「紙で計算したところを見たいものだ」と言った。

<a id="LG-06-056"></a>

**LG-06-056**

<!-- EN:LG-06-056 -->
Alice couldn’t help smiling as she took out her memorandum-book, and worked the sum for him:
<!-- /EN:LG-06-056 -->

> アリスは思わずほほえみながら手帳を取り出し、計算して見せた。

<a id="LG-06-057"></a>

**LG-06-057**

<!-- EN:LG-06-057 -->
<pre>
365
    1
____
364
___
</pre>
<!-- /EN:LG-06-057 -->

> <pre>
> 365
>   1
> ____
> 364
> ___
> </pre>

<a id="LG-06-058"></a>

**LG-06-058**

<!-- EN:LG-06-058 -->
Humpty Dumpty took the book, and looked at it carefully. “That seems to be done right—” he began.
<!-- /EN:LG-06-058 -->

> ハンプティ・ダンプティは手帳を受け取り、注意深く眺めた。「正しくできているようだな……」と言い始めた。

<a id="LG-06-059"></a>

**LG-06-059**

<!-- EN:LG-06-059 -->
“You’re holding it upside down!” Alice interrupted.
<!-- /EN:LG-06-059 -->

> 「上下逆さまに持っているわ！」アリスが口を挟んだ。

<a id="LG-06-060"></a>

**LG-06-060**

<!-- EN:LG-06-060 -->
“To be sure I was!” Humpty Dumpty said gaily, as she turned it round for him. “I thought it looked a little queer. As I was saying, that *seems* to be done right—though I haven’t time to look it over thoroughly just now—and that shows that there are three hundred and sixty-four days when you might get un-birthday presents—”
<!-- /EN:LG-06-060 -->

> 「なるほど、そうだった！」アリスが向きを直してやると、ハンプティ・ダンプティは陽気に言った。「少し妙に見えると思ったのだ。さっきも言ったように、正しくできている*ようだ*。もっとも今は、じっくり調べる時間はないが。これで分かるとおり、非誕生日の贈り物をもらえる日は、三百六十四日ある……」

<a id="LG-06-061"></a>

**LG-06-061**

<!-- EN:LG-06-061 -->
“Certainly,” said Alice.
<!-- /EN:LG-06-061 -->

> 「そうね」とアリス。

<a id="LG-06-062"></a>

**LG-06-062**

<!-- EN:LG-06-062 -->
“And only *one* for birthday presents, you know. There’s glory for you!”
<!-- /EN:LG-06-062 -->

> 「そして誕生日の贈り物をもらえるのは、たった*一日*だ。どうだ、これが栄光だ！」

<a id="LG-06-063"></a>

**LG-06-063**

<!-- EN:LG-06-063 -->
“I don’t know what you mean by ‘glory,’” Alice said.
<!-- /EN:LG-06-063 -->

> 「『栄光』を、どういう意味で言っているのか分からないわ」とアリス。

<a id="LG-06-064"></a>

**LG-06-064**

<!-- EN:LG-06-064 -->
Humpty Dumpty smiled contemptuously. “Of course you don’t—till I tell you. I meant ‘there’s a nice knock-down argument for you!’”
<!-- /EN:LG-06-064 -->

> ハンプティ・ダンプティは、ばかにしたように笑った。「もちろん、私が教えてやるまでは分からんだろう。『どうだ、見事に相手を打ち負かす議論だろう！』という意味で言ったのだ」

<a id="LG-06-065"></a>

**LG-06-065**

<!-- EN:LG-06-065 -->
“But ‘glory’ doesn’t mean ‘a nice knock-down argument,’” Alice objected.
<!-- /EN:LG-06-065 -->

> 「でも、『栄光』は『見事に相手を打ち負かす議論』という意味じゃないわ」とアリスは異議を唱えた。

<a id="LG-06-066"></a>

**LG-06-066**

<!-- EN:LG-06-066 -->
“When *I* use a word,” Humpty Dumpty said in rather a scornful tone, “it means just what I choose it to mean—neither more nor less.”
<!-- /EN:LG-06-066 -->

> 「*私が*ある言葉を使うときは」とハンプティ・ダンプティは、いくらかさげすむような調子で言った。「その言葉は、私が意味させようと決めたことを、きっかり意味するのだ。それ以上でも、それ以下でもない」

<a id="LG-06-067"></a>

**LG-06-067**

<!-- EN:LG-06-067 -->
“The question is,” said Alice, “whether you *can* make words mean so many different things.”
<!-- /EN:LG-06-067 -->

> 「問題なのは」とアリス。「言葉に、そんなにいろいろ違った意味を持たせることが*できるか*、ということよ」

<a id="LG-06-068"></a>

**LG-06-068**

<!-- EN:LG-06-068 -->
“The question is,” said Humpty Dumpty, “which is to be master—that’s all.”
<!-- /EN:LG-06-068 -->

> 「問題なのは」とハンプティ・ダンプティ。「どちらが主人になるかだ。それだけのことだ」

<a id="LG-06-069"></a>

**LG-06-069**

<!-- EN:LG-06-069 -->
Alice was too much puzzled to say anything, so after a minute Humpty Dumpty began again. “They’ve a temper, some of them—particularly verbs, they’re the proudest—adjectives you can do anything with, but not verbs—however, *I* can manage the whole lot of them! Impenetrability! That’s what *I* say!”
<!-- /EN:LG-06-069 -->

> アリスはあまりに戸惑って、何も言えなかった。そこで、しばらくしてハンプティ・ダンプティがまた話し始めた。「なかなか気難しいのもいる。とくに動詞だ。あれがいちばん高慢だ。形容詞なら、どうとでもできるが、動詞はそうはいかない。もっとも、*私なら*、全部まとめて扱える！　不可解性！　*私は*そう言うのだ！」

<a id="LG-06-070"></a>

**LG-06-070**

<!-- EN:LG-06-070 -->
“Would you tell me, please,” said Alice “what that means?”
<!-- /EN:LG-06-070 -->

> 「お願いだから」とアリス。「それがどういう意味か、教えてくださる？」

<a id="LG-06-071"></a>

**LG-06-071**

<!-- EN:LG-06-071 -->
“Now you talk like a reasonable child,” said Humpty Dumpty, looking very much pleased. “I meant by ‘impenetrability’ that we’ve had enough of that subject, and it would be just as well if you’d mention what you mean to do next, as I suppose you don’t mean to stop here all the rest of your life.”
<!-- /EN:LG-06-071 -->

> 「やっと分別のある子供らしい話し方になったな」とハンプティ・ダンプティは、とても満足そうな顔をした。「『不可解性』で私が意味したのは、この話題はもう十分だということ、それから、おまえは今後の人生をずっとここで過ごすつもりではあるまいから、次に何をするつもりか言ってくれてもよさそうだ、ということだ」

> **訳注：** impenetrability は「通り抜けられなさ・理解しにくさ」などを表す語。ここでは彼が長い発言全体に相当する独自の意味を与えている。

<a id="LG-06-072"></a>

**LG-06-072**

<!-- EN:LG-06-072 -->
“That’s a great deal to make one word mean,” Alice said in a thoughtful tone.
<!-- /EN:LG-06-072 -->

> 「一つの言葉に、ずいぶんたくさんの意味を持たせるのね」とアリスは考えこむように言った。

<a id="LG-06-073"></a>

**LG-06-073**

<!-- EN:LG-06-073 -->
“When I make a word do a lot of work like that,” said Humpty Dumpty, “I always pay it extra.”
<!-- /EN:LG-06-073 -->

> 「言葉にそんなにたくさん働かせるときは」とハンプティ・ダンプティ。「いつも特別手当を払うのだ」

<a id="LG-06-074"></a>

**LG-06-074**

<!-- EN:LG-06-074 -->
“Oh!” said Alice. She was too much puzzled to make any other remark.
<!-- /EN:LG-06-074 -->

> 「まあ！」とアリス。それ以上は、訳が分からなくて何も言えなかった。

<a id="LG-06-075"></a>

**LG-06-075**

<!-- EN:LG-06-075 -->
“Ah, you should see ’em come round me of a Saturday night,” Humpty Dumpty went on, wagging his head gravely from side to side: “for to get their wages, you know.”
<!-- /EN:LG-06-075 -->

> 「ああ、土曜の晩に、あいつらが私のまわりへ集まってくるのを見せてやりたい」とハンプティ・ダンプティは、重々しく頭を左右に振りながら続けた。「給料をもらいに来るのだよ」

<a id="LG-06-076"></a>

**LG-06-076**

<!-- EN:LG-06-076 -->
(Alice didn’t venture to ask what he paid them with; and so you see I can’t tell *you*.)
<!-- /EN:LG-06-076 -->

> （何で支払うのか、アリスはあえて聞かなかった。だから、*あなたにも*教えられないというわけだ。）

<a id="LG-06-077"></a>

**LG-06-077**

<!-- EN:LG-06-077 -->
“You seem very clever at explaining words, Sir,” said Alice. “Would you kindly tell me the meaning of the poem called ‘Jabberwocky’?”
<!-- /EN:LG-06-077 -->

> 「言葉の説明が、とてもお上手なのね」とアリス。「『ジャバウォックの詩』の意味を、教えていただける？」

<a id="LG-06-078"></a>

**LG-06-078**

<!-- EN:LG-06-078 -->
“Let’s hear it,” said Humpty Dumpty. “I can explain all the poems that were ever invented—and a good many that haven’t been invented just yet.”
<!-- /EN:LG-06-078 -->

> 「聞かせてもらおう」とハンプティ・ダンプティ。「これまでに作られた詩なら、全部説明できる。それに、まだ作られていない詩も、かなりたくさん説明できる」

<a id="LG-06-079"></a>

**LG-06-079**

<!-- EN:LG-06-079 -->
This sounded very hopeful, so Alice repeated the first verse:
<!-- /EN:LG-06-079 -->

> とても期待が持てそうだったので、アリスは最初の連を唱えた。

<a id="LG-06-080"></a>

**LG-06-080**

<!-- EN:LG-06-080 -->
’Twas brillig, and the slithy toves  
    Did gyre and gimble in the wabe;  
All mimsy were the borogoves,  
    And the mome raths outgrabe.
<!-- /EN:LG-06-080 -->

> ブリリグのころ、ぬるしなやかなトーヴたちが  
> 　　ウェイブでぐる回り、穴ぐりぐり。  
> ボロゴーヴは、みなみじめひ弱、  
> 　　迷子のラースがくしゃぼえた。

<a id="LG-06-081"></a>

**LG-06-081**

<!-- EN:LG-06-081 -->
“That’s enough to begin with,” Humpty Dumpty interrupted: “there are plenty of hard words there. ‘*Brillig*’ means four o’clock in the afternoon—the time when you begin *broiling* things for dinner.”
<!-- /EN:LG-06-081 -->

> 「手始めには、それで十分だ」とハンプティ・ダンプティは遮った。「難しい言葉がたくさんある。『*ブリリグ*』は午後四時のことだ。夕食にする物を*あぶり始める*時間だよ」

> **訳注：** brillig と broiling（直火で焼くこと）の音のつながりが、説明の中に示される。

<a id="LG-06-082"></a>

**LG-06-082**

<!-- EN:LG-06-082 -->
“That’ll do very well,” said Alice: “and ‘*slithy*’?”
<!-- /EN:LG-06-082 -->

> 「それなら、よく分かるわ」とアリス。「では、『*ぬるしなやかな*』は？」

<a id="LG-06-083"></a>

**LG-06-083**

<!-- EN:LG-06-083 -->
“Well, ‘*slithy*’ means ‘lithe and slimy.’ ‘Lithe’ is the same as ‘active.’ You see it’s like a portmanteau—there are two meanings packed up into one word.”
<!-- /EN:LG-06-083 -->

> 「そう、『*ぬるしなやかな*』は、『しなやかで、ぬるぬるした』という意味だ。『しなやか』は『活発』と同じ意味だよ。ほら、旅行かばんのようなものだ。一つの言葉に、二つの意味が詰めこまれている」

> **訳注：** slithy を lithe（しなやかな）＋slimy（ぬるぬるした）と説明している。portmanteau は二つに開く旅行かばん。訳語も「ぬるぬる」＋「しなやか」を合わせた。

<a id="LG-06-084"></a>

**LG-06-084**

<!-- EN:LG-06-084 -->
“I see it now,” Alice remarked thoughtfully: “and what are ‘*toves*’?”
<!-- /EN:LG-06-084 -->

> 「なるほど、分かったわ」とアリスは考え深げに言った。「では、『*トーヴ*』は何なの？」

<a id="LG-06-085"></a>

**LG-06-085**

<!-- EN:LG-06-085 -->
“Well, ‘*toves*’ are something like badgers—they’re something like lizards—and they’re something like corkscrews.”
<!-- /EN:LG-06-085 -->

> 「そうだな、『*トーヴ*』はアナグマに少し似ていて、トカゲにも少し似ていて、ねじ式のコルク抜きにも少し似ている」

<a id="LG-06-086"></a>

**LG-06-086**

<!-- EN:LG-06-086 -->
“They must be very curious looking creatures.”
<!-- /EN:LG-06-086 -->

> 「きっと、とても変わった姿の生き物なのね」

<a id="LG-06-087"></a>

**LG-06-087**

<!-- EN:LG-06-087 -->
“They are that,” said Humpty Dumpty: “also they make their nests under sun-dials—also they live on cheese.”
<!-- /EN:LG-06-087 -->

> 「そのとおりだ」とハンプティ・ダンプティ。「それから、日時計の下に巣を作る。それから、チーズを食べて暮らす」

<a id="LG-06-088"></a>

**LG-06-088**

<!-- EN:LG-06-088 -->
“And what’s the ‘*gyre*’ and to ‘*gimble*’?”
<!-- /EN:LG-06-088 -->

> 「それで、『*ぐる回る*』とか『*穴ぐりぐりする*』って、どういうこと？」

<a id="LG-06-089"></a>

**LG-06-089**

<!-- EN:LG-06-089 -->
“To ‘*gyre*’ is to go round and round like a gyroscope. To ‘*gimble*’ is to make holes like a gimlet.”
<!-- /EN:LG-06-089 -->

> 「『*ぐる回る*』は、ジャイロスコープのようにくるくる回ることだ。『*穴ぐりぐりする*』は、錐のように穴を開けることだ」

> **訳注：** gyre と gyroscope、gimble と gimlet（錐）の音や形の関係を、ハンプティ・ダンプティが説明する。

<a id="LG-06-090"></a>

**LG-06-090**

<!-- EN:LG-06-090 -->
“And ‘*the wabe*’ is the grass-plot round a sun-dial, I suppose?” said Alice, surprised at her own ingenuity.
<!-- /EN:LG-06-090 -->

> 「それなら『*ウェイブ*』は、日時計のまわりの芝生でしょう？」とアリスは言った。自分の気の利いた思いつきに、自分で驚いた。

<a id="LG-06-091"></a>

**LG-06-091**

<!-- EN:LG-06-091 -->
“Of course it is. It’s called ‘*wabe*,’ you know, because it goes a long way before it, and a long way behind it—”
<!-- /EN:LG-06-091 -->

> 「もちろん、そうだ。『*ウェイブ*』と呼ぶのは、日時計のずっと前にも、ずっと後ろにも続いているからだ――」

<a id="LG-06-092"></a>

**LG-06-092**

<!-- EN:LG-06-092 -->
“And a long way beyond it on each side,” Alice added.
<!-- /EN:LG-06-092 -->

> 「それから、左右の向こうにも、ずっと続いているからね」とアリスは付け加えた。

> **訳注：** wabe はここで way before、way behind、way beyond という表現に結びつけて説明される。

<a id="LG-06-093"></a>

**LG-06-093**

<!-- EN:LG-06-093 -->
“Exactly so. Well, then, ‘*mimsy*’ is ‘flimsy and miserable’ (there’s another portmanteau for you). And a ‘*borogove*’ is a thin shabby-looking bird with its feathers sticking out all round—something like a live mop.”
<!-- /EN:LG-06-093 -->

> 「まさにそのとおり。さて次に、『*みじめひ弱*』は『ひ弱で、みじめ』ということだ。これも旅行かばんだね。それから『*ボロゴーヴ*』は、やせてみすぼらしい鳥で、羽が四方八方に突き出ている。生きたモップのようなものだ」

> **訳注：** mimsy を flimsy（ひ弱な）＋miserable（みじめな）と説明している。訳語も二語を合わせた。

<a id="LG-06-094"></a>

**LG-06-094**

<!-- EN:LG-06-094 -->
“And then ‘*mome raths*’?” said Alice. “I’m afraid I’m giving you a great deal of trouble.”
<!-- /EN:LG-06-094 -->

> 「では、そのあとの『*迷子のラース*』は？」とアリス。「ずいぶんお手間を取らせてしまっているわね」

<a id="LG-06-095"></a>

**LG-06-095**

<!-- EN:LG-06-095 -->
“Well, a ‘*rath*’ is a sort of green pig: but ‘*mome*’ I’m not certain about. I think it’s short for ‘from home’—meaning that they’d lost their way, you know.”
<!-- /EN:LG-06-095 -->

> 「そうだな、『*ラース*』は緑色の豚の一種だ。だが『*迷子*』に当たる mome は、はっきりしない。from home、家を離れた、の略だと思う。つまり道に迷ったという意味だね」

<a id="LG-06-096"></a>

**LG-06-096**

<!-- EN:LG-06-096 -->
“And what does ‘*outgrabe*’ mean?”
<!-- /EN:LG-06-096 -->

> 「では、『*くしゃぼえた*』は、どういう意味？」

<a id="LG-06-097"></a>

**LG-06-097**

<!-- EN:LG-06-097 -->
“Well, ‘*outgrabing*’ is something between bellowing and whistling, with a kind of sneeze in the middle: however, you’ll hear it done, maybe—down in the wood yonder—and when you’ve once heard it you’ll be *quite* content. Who’s been repeating all that hard stuff to you?”
<!-- /EN:LG-06-097 -->

> 「そうだな、『*くしゃぼえる*』のは、ほえるのと口笛を吹くのとの中間で、途中にくしゃみのようなものが挟まるんだ。もっとも、そのうち聞くことがあるかもしれん。あっちの森の中あたりでね。一度聞けば、*すっかり*満足するだろう。そんな難しいものを、だれが聞かせたのだ？」

<a id="LG-06-098"></a>

**LG-06-098**

<!-- EN:LG-06-098 -->
“I read it in a book,” said Alice. “But I had some poetry repeated to me, much easier than that, by—Tweedledee, I think it was.”
<!-- /EN:LG-06-098 -->

> 「本で読んだの」とアリス。「でも、それよりずっと易しい詩なら、聞かせてもらったわ。ええと、トゥイードルディーだったと思う」

<a id="LG-06-099"></a>

**LG-06-099**

<!-- EN:LG-06-099 -->
“As to poetry, you know,” said Humpty Dumpty, stretching out one of his great hands, “*I* can repeat poetry as well as other folk, if it comes to that—”
<!-- /EN:LG-06-099 -->

> 「詩といえばだね」とハンプティ・ダンプティは、大きな手を片方突き出して言った。「*私だって*、そういうことになれば、人並みに詩をそらで言えるのだが――」

<a id="LG-06-100"></a>

**LG-06-100**

<!-- EN:LG-06-100 -->
“Oh, it needn’t come to that!” Alice hastily said, hoping to keep him from beginning.
<!-- /EN:LG-06-100 -->

> 「あら、そういうことには、ならなくてもいいわ！」とアリスはあわてて言った。始めるのをやめさせたかったのだ。

<a id="LG-06-101"></a>

**LG-06-101**

<!-- EN:LG-06-101 -->
“The piece I’m going to repeat,” he went on without noticing her remark, “was written entirely for your amusement.”
<!-- /EN:LG-06-101 -->

> 「これから聞かせる作品は」と、彼はアリスの言葉に気づかず続けた。「ただひたすら、おまえを楽しませるために書かれたものだ」

<a id="LG-06-102"></a>

**LG-06-102**

<!-- EN:LG-06-102 -->
Alice felt that in that case she really *ought* to listen to it, so she sat down, and said “Thank you” rather sadly.
<!-- /EN:LG-06-102 -->

> それなら、ほんとうに聞かなくては*いけない*とアリスは思った。そこで座り、「ありがとう」と、いくらか悲しげに言った。

<a id="LG-06-103"></a>

**LG-06-103**

<!-- EN:LG-06-103 -->
“In winter, when the fields are white,  
I sing this song for your delight—
<!-- /EN:LG-06-103 -->

> 「冬、野原が白くなるころ、  
> あなたを喜ばせようと、この歌を歌う――

<a id="LG-06-104"></a>

**LG-06-104**

<!-- EN:LG-06-104 -->
only I don’t sing it,” he added, as an explanation.
<!-- /EN:LG-06-104 -->

> ただし、歌うわけではない」と、説明を付け加えた。

<a id="LG-06-105"></a>

**LG-06-105**

<!-- EN:LG-06-105 -->
“I see you don’t,” said Alice.
<!-- /EN:LG-06-105 -->

> 「歌っていないのは分かるわ」とアリス。

<a id="LG-06-106"></a>

**LG-06-106**

<!-- EN:LG-06-106 -->
“If you can *see* whether I’m singing or not, you’ve sharper eyes than most.” Humpty Dumpty remarked severely. Alice was silent.
<!-- /EN:LG-06-106 -->

> 「歌っているかどうかが*見て分かる*なら、大抵の者より目がよいのだな」とハンプティ・ダンプティは厳しく言った。アリスは黙っていた。

> **訳注：** I see … の see は「分かる」の意味だが、彼は視覚で「見る」の意味に限定して受け取る。

<a id="LG-06-107"></a>

**LG-06-107**

<!-- EN:LG-06-107 -->
“In spring, when woods are getting green,  
I’ll try and tell you what I mean.”
<!-- /EN:LG-06-107 -->

> 「春、森が緑になるころ、  
> どんな意味なのか、話してみよう」

<a id="LG-06-108"></a>

**LG-06-108**

<!-- EN:LG-06-108 -->
“Thank you very much,” said Alice.
<!-- /EN:LG-06-108 -->

> 「どうもありがとう」とアリス。

<a id="LG-06-109"></a>

**LG-06-109**

<!-- EN:LG-06-109 -->
“In summer, when the days are long,  
Perhaps you’ll understand the song:  
<!-- /EN:LG-06-109 -->

> 「夏、日が長くなるころ、  
> あなたにも歌が分かるかもしれない。

<a id="LG-06-110"></a>

**LG-06-110**

<!-- EN:LG-06-110 -->
In autumn, when the leaves are brown,  
Take pen and ink, and write it down.”
<!-- /EN:LG-06-110 -->

> 秋、葉が茶色になるころ、  
> ペンとインクを取って、書き留めなさい」

<a id="LG-06-111"></a>

**LG-06-111**

<!-- EN:LG-06-111 -->
“I will, if I can remember it so long,” said Alice.
<!-- /EN:LG-06-111 -->

> 「そんな先まで覚えていられたら、そうするわ」とアリス。

<a id="LG-06-112"></a>

**LG-06-112**

<!-- EN:LG-06-112 -->
“You needn’t go on making remarks like that,” Humpty Dumpty said: “they’re not sensible, and they put me out.”
<!-- /EN:LG-06-112 -->

> 「そんな口出しを、いちいち続けなくてよい」とハンプティ・ダンプティ。「分別のある言葉ではないし、調子が狂う」

<a id="LG-06-113"></a>

**LG-06-113**

<!-- EN:LG-06-113 -->
“I sent a message to the fish:  
I told them ‘This is what I wish.’  
<!-- /EN:LG-06-113 -->

> 「魚たちに伝言を送った。  
> 『これが私の望みだ』と伝えた。

<a id="LG-06-114"></a>

**LG-06-114**

<!-- EN:LG-06-114 -->
The little fishes of the sea,  
They sent an answer back to me.  
<!-- /EN:LG-06-114 -->

> 海の小さな魚たちは、  
> 私に返事をよこした。

<a id="LG-06-115"></a>

**LG-06-115**

<!-- EN:LG-06-115 -->
The little fishes’ answer was  
‘We cannot do it, Sir, because—’”
<!-- /EN:LG-06-115 -->

> 小さな魚たちの返事は、  
> 『できません、旦那様。なぜなら――』」

<a id="LG-06-116"></a>

**LG-06-116**

<!-- EN:LG-06-116 -->
“I’m afraid I don’t quite understand,” said Alice.
<!-- /EN:LG-06-116 -->

> 「よく分からないのだけれど」とアリス。

<a id="LG-06-117"></a>

**LG-06-117**

<!-- EN:LG-06-117 -->
“It gets easier further on,” Humpty Dumpty replied.
<!-- /EN:LG-06-117 -->

> 「先へ行くほど易しくなる」とハンプティ・ダンプティは答えた。

<a id="LG-06-118"></a>

**LG-06-118**

<!-- EN:LG-06-118 -->
“I sent to them again to say  
‘It will be better to obey.’  
<!-- /EN:LG-06-118 -->

> 「私はもう一度伝言を送った、  
> 『従ったほうが身のためだ』と。

<a id="LG-06-119"></a>

**LG-06-119**

<!-- EN:LG-06-119 -->
The fishes answered with a grin,  
‘Why, what a temper you are in!’  
<!-- /EN:LG-06-119 -->

> 魚たちは、にやりと笑って答えた。  
> 『まあ、ずいぶんご機嫌が悪いのですね！』

<a id="LG-06-120"></a>

**LG-06-120**

<!-- EN:LG-06-120 -->
I told them once, I told them twice:  
They would not listen to advice.  
<!-- /EN:LG-06-120 -->

> 一度言った、二度言った。  
> 魚たちは忠告に耳を貸さなかった。

<a id="LG-06-121"></a>

**LG-06-121**

<!-- EN:LG-06-121 -->
I took a kettle large and new,  
Fit for the deed I had to do.  
<!-- /EN:LG-06-121 -->

> 新しくて大きなやかんを手に取った。  
> これからやらねばならないことに、うってつけのやかんを。

<a id="LG-06-122"></a>

**LG-06-122**

<!-- EN:LG-06-122 -->
My heart went hop, my heart went thump;  
I filled the kettle at the pump.  
<!-- /EN:LG-06-122 -->

> 心臓はぴょんとはね、どんと鳴った。  
> ポンプのところで、やかんに水を満たした。

<a id="LG-06-123"></a>

**LG-06-123**

<!-- EN:LG-06-123 -->
Then some one came to me and said,  
‘The little fishes are in bed.’  
<!-- /EN:LG-06-123 -->

> すると、だれかが来て言った。  
> 『小さな魚たちは、もう寝ています』

<a id="LG-06-124"></a>

**LG-06-124**

<!-- EN:LG-06-124 -->
I said to him, I said it plain,  
‘Then you must wake them up again.’  
<!-- /EN:LG-06-124 -->

> その者に言った、はっきり言った。  
> 『それなら、おまえがまた起こさなければいけない』

<a id="LG-06-125"></a>

**LG-06-125**

<!-- EN:LG-06-125 -->
I said it very loud and clear;  
I went and shouted in his ear.”
<!-- /EN:LG-06-125 -->

> たいそう大きく、はっきりと言った。  
> そばへ行って、その耳へどなってやった」

<a id="LG-06-126"></a>

**LG-06-126**

<!-- EN:LG-06-126 -->
Humpty Dumpty raised his voice almost to a scream as he repeated this verse, and Alice thought with a shudder, “I wouldn’t have been the messenger for *anything*!”
<!-- /EN:LG-06-126 -->

> ハンプティ・ダンプティはこの連を唱えるとき、ほとんど叫ぶほどに声を張り上げた。アリスは身震いして思った。「*何をもらっても*、その使いの役にはなりたくないわ！」

<a id="LG-06-127"></a>

**LG-06-127**

<!-- EN:LG-06-127 -->
“But he was very stiff and proud;  
He said ‘You needn’t shout so loud!’  
<!-- /EN:LG-06-127 -->

> 「けれど、その者はひどく頑固で高慢だった。  
> 『そんな大声でどなる必要はありません！』と言った。

<a id="LG-06-128"></a>

**LG-06-128**

<!-- EN:LG-06-128 -->
And he was very proud and stiff;  
He said ‘I’d go and wake them, if—’  
<!-- /EN:LG-06-128 -->

> そして、ひどく高慢で頑固だった。  
> 『起こしに行ってもよいのですが、もし――』と言った。

<a id="LG-06-129"></a>

**LG-06-129**

<!-- EN:LG-06-129 -->
I took a corkscrew from the shelf:  
I went to wake them up myself.  
<!-- /EN:LG-06-129 -->

> 私は棚からコルク抜きを取った。  
> 自分で魚たちを起こしに行った。

<a id="LG-06-130"></a>

**LG-06-130**

<!-- EN:LG-06-130 -->
And when I found the door was locked,  
I pulled and pushed and kicked and knocked.  
<!-- /EN:LG-06-130 -->

> 扉に鍵がかかっていると分かると、  
> 引いて、押して、蹴って、たたいた。

<a id="LG-06-131"></a>

**LG-06-131**

<!-- EN:LG-06-131 -->
And when I found the door was shut,  
I tried to turn the handle, but—”
<!-- /EN:LG-06-131 -->

> 扉が閉まっていると分かると、  
> 取っ手を回そうとした、けれど――」

<a id="LG-06-132"></a>

**LG-06-132**

<!-- EN:LG-06-132 -->
There was a long pause.
<!-- /EN:LG-06-132 -->

> 長い間があった。

<a id="LG-06-133"></a>

**LG-06-133**

<!-- EN:LG-06-133 -->
“Is that all?” Alice timidly asked.
<!-- /EN:LG-06-133 -->

> 「それでおしまい？」アリスはおずおずと尋ねた。

<a id="LG-06-134"></a>

**LG-06-134**

<!-- EN:LG-06-134 -->
“That’s all,” said Humpty Dumpty. “Good-bye.”
<!-- /EN:LG-06-134 -->

> 「それでおしまいだ」とハンプティ・ダンプティ。「さようなら」

<a id="LG-06-135"></a>

**LG-06-135**

<!-- EN:LG-06-135 -->
This was rather sudden, Alice thought: but, after such a *very* strong hint that she ought to be going, she felt that it would hardly be civil to stay. So she got up, and held out her hand. “Good-bye, till we meet again!” she said as cheerfully as she could.
<!-- /EN:LG-06-135 -->

> ずいぶん唐突だ、とアリスは思った。けれど、もう行ったほうがよいと、これほど*はっきり*ほのめかされたのだから、居続けるのは礼儀に反しそうだった。そこで立ち上がり、手を差し出した。「さようなら、またお会いするまで！」できるだけ明るく言った。

<a id="LG-06-136"></a>

**LG-06-136**

<!-- EN:LG-06-136 -->
“I shouldn’t know you again if we *did* meet,” Humpty Dumpty replied in a discontented tone, giving her one of his fingers to shake; “you’re so exactly like other people.”
<!-- /EN:LG-06-136 -->

> 「また会った*ところで*、おまえだとは分からんだろう」とハンプティ・ダンプティは不満そうに答え、握手するように指を一本差し出した。「ほかの人間と、まったく同じ姿をしているからな」

<a id="LG-06-137"></a>

**LG-06-137**

<!-- EN:LG-06-137 -->
“The face is what one goes by, generally,” Alice remarked in a thoughtful tone.
<!-- /EN:LG-06-137 -->

> 「普通は顔で見分けるものよ」とアリスは考え深げに言った。

<a id="LG-06-138"></a>

**LG-06-138**

<!-- EN:LG-06-138 -->
“That’s just what I complain of,” said Humpty Dumpty. “Your face is the same as everybody has—the two eyes, so—” (marking their places in the air with this thumb) “nose in the middle, mouth under. It’s always the same. Now if you had the two eyes on the same side of the nose, for instance—or the mouth at the top—that would be *some* help.”
<!-- /EN:LG-06-138 -->

> 「まさに、それが気に入らんのだ」とハンプティ・ダンプティ。「おまえの顔は、みんなの顔と同じだ。目が二つ、こう――」（親指で空中に、その位置を示した。）「真ん中に鼻、その下に口。いつも同じだ。たとえば、目が二つとも鼻の同じ側にあれば、あるいは口がいちばん上にあれば、*少しは*役に立つのだが」

<a id="LG-06-139"></a>

**LG-06-139**

<!-- EN:LG-06-139 -->
“It wouldn’t look nice,” Alice objected. But Humpty Dumpty only shut his eyes and said “Wait till you’ve tried.”
<!-- /EN:LG-06-139 -->

> 「そんなの、見た目がよくないわ」とアリスは反対した。けれどハンプティ・ダンプティは目を閉じ、「試してから言いなさい」と言っただけだった。

<a id="LG-06-140"></a>

**LG-06-140**

<!-- EN:LG-06-140 -->
Alice waited a minute to see if he would speak again, but as he never opened his eyes or took any further notice of her, she said “Good-bye!” once more, and, getting no answer to this, she quietly walked away: but she couldn’t help saying to herself as she went, “Of all the unsatisfactory—” (she repeated this aloud, as it was a great comfort to have such a long word to say) “of all the unsatisfactory people I *ever* met—” She never finished the sentence, for at this moment a heavy crash shook the forest from end to end.
<!-- /EN:LG-06-140 -->

> アリスは、また何か話すかと思って少し待った。けれど相手は目を開けず、それ以上こちらを気にする様子もなかったので、もう一度「さようなら！」と言った。それにも返事がなかったので、静かに歩き去った。けれど歩きながら、つい独り言を言ってしまった。「これまでに会った、話のかみ合わない……」（こんな長い言葉を口にすると、とても気が晴れるので、声に出して繰り返した。）「*これまでに*会った、話のかみ合わない人たちの中でも……」その文を終えることはなかった。その瞬間、ものすごい崩れる音がして、森が端から端まで震えたからだ。

[章目次へ戻る](#book-top)

---

<a id="lg-chapter-07"></a>

## 第7章　ライオンと一角獣

### CHAPTER VII. The Lion and the Unicorn

<a id="LG-07-001"></a>

**LG-07-001**

<!-- EN:LG-07-001 -->
The next moment soldiers came running through the wood, at first in twos and threes, then ten or twenty together, and at last in such crowds that they seemed to fill the whole forest. Alice got behind a tree, for fear of being run over, and watched them go by.
<!-- /EN:LG-07-001 -->

> その次の瞬間、兵隊たちが森の中を駆けてきた。はじめは二、三人ずつ、やがて十人、二十人と固まりになり、しまいには森じゅうが埋まってしまいそうな大群になった。アリスは踏み倒されないよう木の陰に隠れて、兵隊たちが通り過ぎるのを見ていた。

<a id="LG-07-002"></a>

**LG-07-002**

<!-- EN:LG-07-002 -->
She thought that in all her life she had never seen soldiers so uncertain on their feet: they were always tripping over something or other, and whenever one went down, several more always fell over him, so that the ground was soon covered with little heaps of men.
<!-- /EN:LG-07-002 -->

> 生まれてこのかた、こんなに足もとのおぼつかない兵隊を見たことはない、とアリスは思った。みんな何かしらにつまずいてばかりで、一人が倒れると、きまってその上に何人もつまずいて倒れる。たちまち地面には、人間の小さな山がいくつもできた。

<a id="LG-07-003"></a>

**LG-07-003**

<!-- EN:LG-07-003 -->
Then came the horses. Having four feet, these managed rather better than the foot-soldiers: but even *they* stumbled now and then; and it seemed to be a regular rule that, whenever a horse stumbled the rider fell off instantly. The confusion got worse every moment, and Alice was very glad to get out of the wood into an open place, where she found the White King seated on the ground, busily writing in his memorandum-book.
<!-- /EN:LG-07-003 -->

> 続いて馬たちがやってきた。足が四本あるだけに、歩兵よりは少しましだったけれど、*馬でさえ*ときどきつまずいた。そして馬がつまずくと、乗り手は即座に落馬するというのが、きちんとした決まりになっているらしかった。混乱は刻一刻とひどくなったので、アリスは森を抜けて開けたところに出られて、ほんとうにほっとした。そこには白の王が地面に座って、せっせと手帳に書きこんでいた。

<a id="LG-07-004"></a>

**LG-07-004**

<!-- EN:LG-07-004 -->
“I’ve sent them all!” the King cried in a tone of delight, on seeing Alice. “Did you happen to meet any soldiers, my dear, as you came through the wood?”
<!-- /EN:LG-07-004 -->

> 「全部送り出したぞ！」王はアリスを見ると、うれしそうな声を上げた。「お嬢さん、森を通ってくる途中、兵隊に会わなかったかね？」

<a id="LG-07-005"></a>

**LG-07-005**

<!-- EN:LG-07-005 -->
“Yes, I did,” said Alice: “several thousand, I should think.”
<!-- /EN:LG-07-005 -->

> 「ええ、会ったわ」とアリス。「何千人かいたと思うけれど」

<a id="LG-07-006"></a>

**LG-07-006**

<!-- EN:LG-07-006 -->
“Four thousand two hundred and seven, that’s the exact number,” the King said, referring to his book. “I couldn’t send all the horses, you know, because two of them are wanted in the game. And I haven’t sent the two Messengers, either. They’re both gone to the town. Just look along the road, and tell me if you can see either of them.”
<!-- /EN:LG-07-006 -->

> 「四千二百七人。それが正確な数じゃ」と王は手帳を確かめて言った。「馬は全部というわけにはいかんかった。二頭は勝負に必要でな。それから使者の二人も送り出しておらん。二人とも町へ行っている。道の向こうを見て、どちらか見えるか教えておくれ」

> **訳注：** 二頭の馬は、チェスのナイト二枚を指す。

<a id="LG-07-007"></a>

**LG-07-007**

<!-- EN:LG-07-007 -->
“I see nobody on the road,” said Alice.
<!-- /EN:LG-07-007 -->

> 「道には、だれも見えないわ」とアリスは言った。

<a id="LG-07-008"></a>

**LG-07-008**

<!-- EN:LG-07-008 -->
“I only wish *I* had such eyes,” the King remarked in a fretful tone. “To be able to see Nobody! And at that distance, too! Why, it’s as much as *I* can do to see real people, by this light!”
<!-- /EN:LG-07-008 -->

> 「*わしにも*そんな目があればなあ」と王は不満そうに言った。「『だれもいない』が見えるとは！　しかもあんな遠くに！　この明るさでは、*わしなど*実在する人間を見るだけで精いっぱいじゃ！」

> **訳注：** アリスの nobody（だれも〜ない）を、王は Nobody という人物の名のように受け取る。この取り違えが後の会話にも続く。

<a id="LG-07-009"></a>

**LG-07-009**

<!-- EN:LG-07-009 -->
All this was lost on Alice, who was still looking intently along the road, shading her eyes with one hand. “I see somebody now!” she exclaimed at last. “But he’s coming very slowly—and what curious attitudes he goes into!” (For the messenger kept skipping up and down, and wriggling like an eel, as he came along, with his great hands spread out like fans on each side.)
<!-- /EN:LG-07-009 -->

> アリスにはその話はまるで耳に入らなかった。片手を目の上にかざして、まだ道の向こうをじっと見ていたからだ。「今、だれか見えたわ！」とうとうアリスは叫んだ。「でも、とてもゆっくり来るのね。それに、なんておかしな格好をするのかしら！」（使者は大きな両手を扇のように左右へ広げ、ぴょんぴょん跳ねたり、ウナギのように身をくねらせたりしながらやってきたのだ。）

<a id="LG-07-010"></a>

**LG-07-010**

<!-- EN:LG-07-010 -->
“Not at all,” said the King. “He’s an Anglo-Saxon Messenger—and those are Anglo-Saxon attitudes. He only does them when he’s happy. His name is Haigha.” (He pronounced it so as to rhyme with “mayor.”)
<!-- /EN:LG-07-010 -->

> 「ちっともおかしくはない」と王。「あれはアングロサクソンの使者じゃから、身ぶりもアングロサクソン式なのじゃ。うれしいときだけああする。名はヘイヤという」（王はその名を、英語の mayor と韻を踏むように発音した。）

> **訳注：** Haigha はここでは mayor と韻を踏む発音。綴りどおりの「ハイガ」ではない。

<a id="LG-07-011"></a>

**LG-07-011**

<!-- EN:LG-07-011 -->
“I love my love with an H,” Alice couldn’t help beginning, “because he is Happy. I hate him with an H, because he is Hideous. I fed him with—with—with Ham-sandwiches and Hay. His name is Haigha, and he lives—”
<!-- /EN:LG-07-011 -->

> 「Hで、あの人が好き。Happy、幸せだから」と、アリスはつい言い始めた。「Hで、あの人が嫌い。Hideous、見るもおぞましいから。あの人に食べさせたのは……ええと……Ham-sandwiches、ハムサンドイッチと、Hay、干し草。名前はHaigha、ヘイヤ。住んでいるのは……」

> **訳注：** 同じ頭文字の語を続ける言葉遊び。原文のHのつながりが分かるよう、対応する英語を添えた。

<a id="LG-07-012"></a>

**LG-07-012**

<!-- EN:LG-07-012 -->
“He lives on the Hill,” the King remarked simply, without the least idea that he was joining in the game, while Alice was still hesitating for the name of a town beginning with H. “The other Messenger’s called Hatta. I must have *two*, you know—to come and go. One to come, and one to go.”
<!-- /EN:LG-07-012 -->

> 「Hill、丘の上に住んでいる」と王は、アリスがまだHで始まる町の名を思いつけずにいるうちに、あっさり言った。自分まで言葉遊びに加わったとは少しも思っていなかった。「もう一人の使者はハッタという。来たり行ったりしてもらうためには、*二人*必要じゃからな。来るのに一人、行くのに一人じゃ」

<a id="LG-07-013"></a>

**LG-07-013**

<!-- EN:LG-07-013 -->
“I beg your pardon?” said Alice.
<!-- /EN:LG-07-013 -->

> 「失礼ですが、もう一度お願いできます？」とアリス。

<a id="LG-07-014"></a>

**LG-07-014**

<!-- EN:LG-07-014 -->
“It isn’t respectable to beg,” said the King.
<!-- /EN:LG-07-014 -->

> 「物乞いなど、品のあることではないぞ」と王は言った。

> **訳注：** I beg your pardon? は聞き返す表現だが、王は beg を「物乞いする」の意味に取る。

<a id="LG-07-015"></a>

**LG-07-015**

<!-- EN:LG-07-015 -->
“I only meant that I didn’t understand,” said Alice. “Why one to come and one to go?”
<!-- /EN:LG-07-015 -->

> 「ただ、意味が分からなかったと言っただけよ」とアリス。「どうして来るのに一人、行くのに一人なの？」

<a id="LG-07-016"></a>

**LG-07-016**

<!-- EN:LG-07-016 -->
“Didn’t I tell you?” the King repeated impatiently. “I must have *two*—to fetch and carry. One to fetch, and one to carry.”
<!-- /EN:LG-07-016 -->

> 「今、言わなかったか？」王はいらいらして繰り返した。「取りに行って運んでもらうには、*二人*必要なのじゃ。取りに行くのに一人、運ぶのに一人じゃ」

> **訳注：** come and go、fetch and carry という一人でも行える一組の動作を、王は別々の担当者が必要な仕事として扱っている。

<a id="LG-07-017"></a>

**LG-07-017**

<!-- EN:LG-07-017 -->
At this moment the Messenger arrived: he was far too much out of breath to say a word, and could only wave his hands about, and make the most fearful faces at the poor King.
<!-- /EN:LG-07-017 -->

> そのとき、使者が到着した。あまりに息が切れて、一言も口をきけない。手を振り回して、気の毒な王に向かって、この上なく恐ろしい顔をするばかりだった。

<a id="LG-07-018"></a>

**LG-07-018**

<!-- EN:LG-07-018 -->
“This young lady loves you with an H,” the King said, introducing Alice in the hope of turning off the Messenger’s attention from himself—but it was no use—the Anglo-Saxon attitudes only got more extraordinary every moment, while the great eyes rolled wildly from side to side.
<!-- /EN:LG-07-018 -->

> 「このお嬢さんは、Hでおまえが好きだそうじゃ」と王はアリスを紹介した。使者の注意を自分からそらそうとしたのだが、効き目はなかった。大きな目が左右にぐるぐる動くにつれて、アングロサクソン式の身ぶりはますます奇怪になった。

<a id="LG-07-019"></a>

**LG-07-019**

<!-- EN:LG-07-019 -->
“You alarm me!” said the King. “I feel faint—Give me a ham sandwich!”
<!-- /EN:LG-07-019 -->

> 「怖いではないか！」と王。「気が遠くなる。ハムサンドイッチをおくれ！」

<a id="LG-07-020"></a>

**LG-07-020**

<!-- EN:LG-07-020 -->
On which the Messenger, to Alice’s great amusement, opened a bag that hung round his neck, and handed a sandwich to the King, who devoured it greedily.
<!-- /EN:LG-07-020 -->

> すると使者は、アリスがすっかり面白がって見ているなか、首から下げた袋を開けて、王にサンドイッチを渡した。王はがつがつとそれを平らげた。

<a id="LG-07-021"></a>

**LG-07-021**

<!-- EN:LG-07-021 -->
“Another sandwich!” said the King.
<!-- /EN:LG-07-021 -->

> 「サンドイッチをもう一つ！」と王。

<a id="LG-07-022"></a>

**LG-07-022**

<!-- EN:LG-07-022 -->
“There’s nothing but hay left now,” the Messenger said, peeping into the bag.
<!-- /EN:LG-07-022 -->

> 「もう干し草しか残っていません」と使者は袋の中をのぞいて言った。

<a id="LG-07-023"></a>

**LG-07-023**

<!-- EN:LG-07-023 -->
“Hay, then,” the King murmured in a faint whisper.
<!-- /EN:LG-07-023 -->

> 「では、干し草を」と王はかすかな声でつぶやいた。

<a id="LG-07-024"></a>

**LG-07-024**

<!-- EN:LG-07-024 -->
Alice was glad to see that it revived him a good deal. “There’s nothing like eating hay when you’re faint,” he remarked to her, as he munched away.
<!-- /EN:LG-07-024 -->

> それで王がずいぶん元気を取り戻したので、アリスはうれしくなった。「気が遠くなったときは、干し草を食べるようなものはほかにないな」と、王はむしゃむしゃかみながらアリスに言った。

<a id="LG-07-025"></a>

**LG-07-025**

<!-- EN:LG-07-025 -->
“I should think throwing cold water over you would be better,” Alice suggested: “or some sal-volatile.”
<!-- /EN:LG-07-025 -->

> 「冷たい水をかけたほうがいいと思うけれど」とアリスは言ってみた。「それか、気付け薬とか」

<a id="LG-07-026"></a>

**LG-07-026**

<!-- EN:LG-07-026 -->
“I didn’t say there was nothing *better*,” the King replied. “I said there was nothing *like* it.” Which Alice did not venture to deny.
<!-- /EN:LG-07-026 -->

> 「これより*よい*ものがないとは言っておらん」と王は答えた。「これと*同じような*ものがないと言ったのじゃ」それを否定する勇気は、アリスにはなかった。

> **訳注：** There’s nothing like … は普通「〜にまさるものはない」だが、王は like を文字どおり「似ている」の意味に限定している。

<a id="LG-07-027"></a>

**LG-07-027**

<!-- EN:LG-07-027 -->
“Who did you pass on the road?” the King went on, holding out his hand to the Messenger for some more hay.
<!-- /EN:LG-07-027 -->

> 「道でだれを追い越した？」王はそう続けながら、もう少し干し草をもらおうと使者に手を伸ばした。

<a id="LG-07-028"></a>

**LG-07-028**

<!-- EN:LG-07-028 -->
“Nobody,” said the Messenger.
<!-- /EN:LG-07-028 -->

> 「だれも」と使者。

<a id="LG-07-029"></a>

**LG-07-029**

<!-- EN:LG-07-029 -->
“Quite right,” said the King: “this young lady saw him too. So of course Nobody walks slower than you.”
<!-- /EN:LG-07-029 -->

> 「そのとおり」と王。「このお嬢さんもそいつを見た。ということは、もちろん『だれもいない』はおまえより歩くのが遅いわけじゃ」

<a id="LG-07-030"></a>

**LG-07-030**

<!-- EN:LG-07-030 -->
“I do my best,” the Messenger said in a sulky tone. “I’m sure nobody walks much faster than I do!”
<!-- /EN:LG-07-030 -->

> 「私は精いっぱいやっています」と使者はすねた声で言った。「私よりずっと速く歩く者など、だれもいませんよ！」

<a id="LG-07-031"></a>

**LG-07-031**

<!-- EN:LG-07-031 -->
“He can’t do that,” said the King, “or else he’d have been here first. However, now you’ve got your breath, you may tell us what’s happened in the town.”
<!-- /EN:LG-07-031 -->

> 「そいつにそんなことはできまい」と王。「もしできたら、おまえより先にここへ着いているはずじゃ。まあ、息が整ったなら、町で何があったか話しておくれ」

<a id="LG-07-032"></a>

**LG-07-032**

<!-- EN:LG-07-032 -->
“I’ll whisper it,” said the Messenger, putting his hands to his mouth in the shape of a trumpet, and stooping so as to get close to the King’s ear. Alice was sorry for this, as she wanted to hear the news too. However, instead of whispering, he simply shouted at the top of his voice “They’re at it again!”
<!-- /EN:LG-07-032 -->

> 「ひそひそお話ししましょう」と使者は言って、両手を口に当ててラッパの形にし、王の耳に近づこうとかがみこんだ。自分もその知らせを聞きたかったアリスは、残念に思った。ところが使者はささやくどころか、声の限りに「また始めました！」とどなっただけだった。

<a id="LG-07-033"></a>

**LG-07-033**

<!-- EN:LG-07-033 -->
“Do you call *that* a whisper?” cried the poor King, jumping up and shaking himself. “If you do such a thing again, I’ll have you buttered! It went through and through my head like an earthquake!”
<!-- /EN:LG-07-033 -->

> 「*これが*ひそひそ話か！」気の毒な王は飛び上がり、身を震わせて叫んだ。「もう一度そんなことをしたら、バターを塗りたくってやるぞ！　地震のように、頭のすみずみまで響き渡ったわ！」

<a id="LG-07-034"></a>

**LG-07-034**

<!-- EN:LG-07-034 -->
“It would have to be a very tiny earthquake!” thought Alice. “Who are at it again?” she ventured to ask.
<!-- /EN:LG-07-034 -->

> 「よほど小さな地震じゃなくちゃね！」とアリスは思った。「また始めたって、だれが？」と、思いきって尋ねた。

<a id="LG-07-035"></a>

**LG-07-035**

<!-- EN:LG-07-035 -->
“Why the Lion and the Unicorn, of course,” said the King.
<!-- /EN:LG-07-035 -->

> 「もちろん、ライオンと一角獣じゃよ」と王。

<a id="LG-07-036"></a>

**LG-07-036**

<!-- EN:LG-07-036 -->
“Fighting for the crown?”
<!-- /EN:LG-07-036 -->

> 「王冠を取り合ってけんかしているの？」

<a id="LG-07-037"></a>

**LG-07-037**

<!-- EN:LG-07-037 -->
“Yes, to be sure,” said the King: “and the best of the joke is, that it’s *my* crown all the while! Let’s run and see them.” And they trotted off, Alice repeating to herself, as she ran, the words of the old song:—
<!-- /EN:LG-07-037 -->

> 「いかにも」と王。「いちばんおかしいのは、その王冠はずうっと*わしの*物だということじゃ！　走って見に行こう」三人は小走りに出発した。アリスは走りながら、昔からの歌を口の中で繰り返した。

<a id="LG-07-038"></a>

**LG-07-038**

<!-- EN:LG-07-038 -->
“The Lion and the Unicorn were fighting for the crown:  
The Lion beat the Unicorn all round the town.  
Some gave them white bread, some gave them brown;  
Some gave them plum-cake and drummed them out of town.”
<!-- /EN:LG-07-038 -->

> 「ライオンと一角獣が王冠を取り合った。  
> ライオンは町じゅうで一角獣を打ち負かした。  
> 白いパンをやる人、茶色のパンをやる人、  
> プラムケーキをやって、太鼓で町から追い出す人」

<a id="LG-07-039"></a>

**LG-07-039**

<!-- EN:LG-07-039 -->
“Does—the one—that wins—get the crown?” she asked, as well as she could, for the run was putting her quite out of breath.
<!-- /EN:LG-07-039 -->

> 「勝った……ほうが……王冠を……もらえるの？」走ってすっかり息が切れたアリスは、どうにかそう尋ねた。

<a id="LG-07-040"></a>

**LG-07-040**

<!-- EN:LG-07-040 -->
“Dear me, no!” said the King. “What an idea!”
<!-- /EN:LG-07-040 -->

> 「とんでもない！」と王。「何を考えておる！」

<a id="LG-07-041"></a>

**LG-07-041**

<!-- EN:LG-07-041 -->
“Would you—be good enough,” Alice panted out, after running a little further, “to stop a minute—just to get—one’s breath again?”
<!-- /EN:LG-07-041 -->

> 「お願い……できるかしら」とアリスはもう少し走ってから、息を切らして言った。「一分……止まって……息を……整えさせて？」

<a id="LG-07-042"></a>

**LG-07-042**

<!-- EN:LG-07-042 -->
“I’m *good* enough,” the King said, “only I’m not strong enough. You see, a minute goes by so fearfully quick. You might as well try to stop a Bandersnatch!”
<!-- /EN:LG-07-042 -->

> 「親切心なら十分にあるが」と王は言った。「力が足りん。一分というのは、恐ろしい速さで過ぎていくからな。バンダースナッチを止めようとするのと同じじゃ！」

> **訳注：** stop a minute（ちょっと立ち止まる）を、王は「一分という時間を停止させる」と解釈する。good enough と strong enough も対照をなす。

<a id="LG-07-043"></a>

**LG-07-043**

<!-- EN:LG-07-043 -->
Alice had no more breath for talking, so they trotted on in silence, till they came in sight of a great crowd, in the middle of which the Lion and Unicorn were fighting. They were in such a cloud of dust, that at first Alice could not make out which was which: but she soon managed to distinguish the Unicorn by his horn.
<!-- /EN:LG-07-043 -->

> アリスはもう話す息も残っていなかったので、三人は黙って小走りを続けた。やがて大勢の人だかりが見え、その真ん中でライオンと一角獣が戦っていた。二匹はもうもうとした砂ぼこりの中にいたので、はじめアリスにはどちらがどちらか分からなかったが、やがて角を目印に、一角獣を見分けることができた。

<a id="LG-07-044"></a>

**LG-07-044**

<!-- EN:LG-07-044 -->
They placed themselves close to where Hatta, the other messenger, was standing watching the fight, with a cup of tea in one hand and a piece of bread-and-butter in the other.
<!-- /EN:LG-07-044 -->

> 三人は、もう一人の使者ハッタが立っているすぐそばへ行った。ハッタは片手に紅茶のカップ、もう片手にバター付きパンを持って、戦いを見物していた。

<a id="LG-07-045"></a>

**LG-07-045**

<!-- EN:LG-07-045 -->
“He’s only just out of prison, and he hadn’t finished his tea when he was sent in,” Haigha whispered to Alice: “and they only give them oyster-shells in there—so you see he’s very hungry and thirsty. How are you, dear child?” he went on, putting his arm affectionately round Hatta’s neck.
<!-- /EN:LG-07-045 -->

> 「刑務所を出たばかりでね。お茶を済ませないうちに放りこまれてしまったのさ」とヘイヤはアリスにささやいた。「あそこじゃカキの殻しかもらえない。だから、とてもおなかをすかせて、のども渇かせているんだ。元気かい、かわいい子？」そう言って、愛情をこめてハッタの首に腕を回した。

<a id="LG-07-046"></a>

**LG-07-046**

<!-- EN:LG-07-046 -->
Hatta looked round and nodded, and went on with his bread and butter.
<!-- /EN:LG-07-046 -->

> ハッタは振り向いてうなずき、またバター付きパンを食べ続けた。

<a id="LG-07-047"></a>

**LG-07-047**

<!-- EN:LG-07-047 -->
“Were you happy in prison, dear child?” said Haigha.
<!-- /EN:LG-07-047 -->

> 「刑務所では幸せだったかい、かわいい子？」とヘイヤ。

<a id="LG-07-048"></a>

**LG-07-048**

<!-- EN:LG-07-048 -->
Hatta looked round once more, and this time a tear or two trickled down his cheek: but not a word would he say.
<!-- /EN:LG-07-048 -->

> ハッタはもう一度振り向いた。今度は一粒か二粒、涙が頰を伝った。それでも一言も口をきこうとしなかった。

<a id="LG-07-049"></a>

**LG-07-049**

<!-- EN:LG-07-049 -->
“Speak, can’t you!” Haigha cried impatiently. But Hatta only munched away, and drank some more tea.
<!-- /EN:LG-07-049 -->

> 「しゃべれないのかい！」とヘイヤはいらだって叫んだ。けれどハッタはもぐもぐ食べて、また紅茶を飲むばかりだった。

<a id="LG-07-050"></a>

**LG-07-050**

<!-- EN:LG-07-050 -->
“Speak, won’t you!” cried the King. “How are they getting on with the fight?”
<!-- /EN:LG-07-050 -->

> 「しゃべってくれんか！」と王も叫んだ。「戦いはどうなっておる？」

<a id="LG-07-051"></a>

**LG-07-051**

<!-- EN:LG-07-051 -->
Hatta made a desperate effort, and swallowed a large piece of bread-and-butter. “They’re getting on very well,” he said in a choking voice: “each of them has been down about eighty-seven times.”
<!-- /EN:LG-07-051 -->

> ハッタは必死に力を入れて、バター付きパンの大きな塊をのみこんだ。「たいへん順調です」と、のどを詰まらせながら答えた。「どちらも八十七回ほど倒れています」

<a id="LG-07-052"></a>

**LG-07-052**

<!-- EN:LG-07-052 -->
“Then I suppose they’ll soon bring the white bread and the brown?” Alice ventured to remark.
<!-- /EN:LG-07-052 -->

> 「じゃあ、そろそろ白いパンと茶色いパンが出てくるのね？」とアリスは思いきって口を挟んだ。

<a id="LG-07-053"></a>

**LG-07-053**

<!-- EN:LG-07-053 -->
“It’s waiting for ’em now,” said Hatta: “this is a bit of it as I’m eating.”
<!-- /EN:LG-07-053 -->

> 「もう用意して待ってるよ」とハッタ。「おれが食ってるのも、その一切れさ」

<a id="LG-07-054"></a>

**LG-07-054**

<!-- EN:LG-07-054 -->
There was a pause in the fight just then, and the Lion and the Unicorn sat down, panting, while the King called out “Ten minutes allowed for refreshments!” Haigha and Hatta set to work at once, carrying rough trays of white and brown bread. Alice took a piece to taste, but it was *very* dry.
<!-- /EN:LG-07-054 -->

> ちょうどそのとき戦いがひと休みになり、ライオンと一角獣が息を切らして座りこんだ。王は「飲食のため、十分間の休憩を認める！」と声を上げた。ヘイヤとハッタはすぐさま仕事にかかり、白いパンと茶色いパンを粗末な盆に載せて運んだ。アリスも一切れ取って味見してみたが、*とても*ぱさぱさしていた。

<a id="LG-07-055"></a>

**LG-07-055**

<!-- EN:LG-07-055 -->
“I don’t think they’ll fight any more to-day,” the King said to Hatta: “go and order the drums to begin.” And Hatta went bounding away like a grasshopper.
<!-- /EN:LG-07-055 -->

> 「今日はもう戦うまい」と王はハッタに言った。「太鼓を始めるよう命じてきなさい」ハッタはバッタのように跳ねながら去っていった。

<a id="LG-07-056"></a>

**LG-07-056**

<!-- EN:LG-07-056 -->
For a minute or two Alice stood silent, watching him. Suddenly she brightened up. “Look, look!” she cried, pointing eagerly. “There’s the White Queen running across the country! She came flying out of the wood over yonder—How fast those Queens *can* run!”
<!-- /EN:LG-07-056 -->

> アリスは一、二分、黙って立ったままその姿を見ていた。ふいに顔を輝かせた。「見て、見て！」と、勢いよく指をさして叫んだ。「白の女王が野原を走っていくわ！　あっちの森から飛び出してきたの。女王様たちって、*ほんとうに*足が速いのね！」

<a id="LG-07-057"></a>

**LG-07-057**

<!-- EN:LG-07-057 -->
“There’s some enemy after her, no doubt,” the King said, without even looking round. “That wood’s full of them.”
<!-- /EN:LG-07-057 -->

> 「きっと敵に追われているのじゃろう」と王は振り向きもしないで言った。「あの森は敵だらけじゃ」

<a id="LG-07-058"></a>

**LG-07-058**

<!-- EN:LG-07-058 -->
“But aren’t you going to run and help her?” Alice asked, very much surprised at his taking it so quietly.
<!-- /EN:LG-07-058 -->

> 「でも、走って助けに行かないの？」とアリスは尋ねた。王があまりに落ち着き払っているので、ひどく驚いたのだ。

<a id="LG-07-059"></a>

**LG-07-059**

<!-- EN:LG-07-059 -->
“No use, no use!” said the King. “She runs so fearfully quick. You might as well try to catch a Bandersnatch! But I’ll make a memorandum about her, if you like—She’s a dear good creature,” he repeated softly to himself, as he opened his memorandum-book. “Do you spell ‘creature’ with a double ‘e’?”
<!-- /EN:LG-07-059 -->

> 「無駄じゃ、無駄じゃ！」と王。「恐ろしいほど速く走るからのう。バンダースナッチを捕まえようとするようなものじゃ！　だが、望むならあれのことを手帳に書いておこう。愛しい、よい子じゃ」と、手帳を開きながら、やさしい声で独り言を繰り返した。「creature は、eを二つ続けて綴るのだったかな？」

> **訳注：** 原文の dear good creature は愛情をこめた呼び方。creature の綴りには e が二つあるが、連続してはいない。

<a id="LG-07-060"></a>

**LG-07-060**

<!-- EN:LG-07-060 -->
At this moment the Unicorn sauntered by them, with his hands in his pockets. “I had the best of it this time?” he said to the King, just glancing at him as he passed.
<!-- /EN:LG-07-060 -->

> そのとき一角獣が、両手をポケットに入れてのんびり通りかかった。「今度はおれのほうが優勢だっただろう？」通り過ぎざま、王をちらりと見て言った。

<a id="LG-07-061"></a>

**LG-07-061**

<!-- EN:LG-07-061 -->
“A little—a little,” the King replied, rather nervously. “You shouldn’t have run him through with your horn, you know.”
<!-- /EN:LG-07-061 -->

> 「少しな、少し」と王は、いくらかおどおどして答えた。「角であいつを突き通してはいかんぞ」

<a id="LG-07-062"></a>

**LG-07-062**

<!-- EN:LG-07-062 -->
“It didn’t hurt him,” the Unicorn said carelessly, and he was going on, when his eye happened to fall upon Alice: he turned round rather instantly, and stood for some time looking at her with an air of the deepest disgust.
<!-- /EN:LG-07-062 -->

> 「けがはしなかったさ」と一角獣は無頓着に言って、行きかけた。ところが偶然アリスが目に入り、さっと振り向くと、ひどく不愉快そうな顔で、しばらく彼女を眺めた。

<a id="LG-07-063"></a>

**LG-07-063**

<!-- EN:LG-07-063 -->
“What—is—this?” he said at last.
<!-- /EN:LG-07-063 -->

> 「これ……は……何だ？」と、ようやく言った。

<a id="LG-07-064"></a>

**LG-07-064**

<!-- EN:LG-07-064 -->
“This is a child!” Haigha replied eagerly, coming in front of Alice to introduce her, and spreading out both his hands towards her in an Anglo-Saxon attitude. “We only found it to-day. It’s as large as life, and twice as natural!”
<!-- /EN:LG-07-064 -->

> 「子供ですよ！」ヘイヤは張り切って答え、紹介しようとアリスの前に出ると、アングロサクソン式の身ぶりで両手を彼女に向けて広げた。「今日見つけたばかりです。本物と同じ大きさで、本物の二倍も自然なんですよ！」

<a id="LG-07-065"></a>

**LG-07-065**

<!-- EN:LG-07-065 -->
“I always thought they were fabulous monsters!” said the Unicorn. “Is it alive?”
<!-- /EN:LG-07-065 -->

> 「子供なんて、ずっと伝説の怪物だと思っていた！」と一角獣。「生きているのか？」

<a id="LG-07-066"></a>

**LG-07-066**

<!-- EN:LG-07-066 -->
“It can talk,” said Haigha, solemnly.
<!-- /EN:LG-07-066 -->

> 「口もきけます」とヘイヤはおごそかに言った。

<a id="LG-07-067"></a>

**LG-07-067**

<!-- EN:LG-07-067 -->
The Unicorn looked dreamily at Alice, and said “Talk, child.”
<!-- /EN:LG-07-067 -->

> 一角獣は夢見るような目でアリスを眺め、「しゃべれ、子供」と言った。

<a id="LG-07-068"></a>

**LG-07-068**

<!-- EN:LG-07-068 -->
Alice could not help her lips curling up into a smile as she began: “Do you know, I always thought Unicorns were fabulous monsters, too! I never saw one alive before!”
<!-- /EN:LG-07-068 -->

> アリスは、思わず口もとがほころぶのを抑えられないまま話し始めた。「あのね、わたしも一角獣はずっと伝説の怪物だと思っていたの！　生きているのを見るのは初めてよ！」

<a id="LG-07-069"></a>

**LG-07-069**

<!-- EN:LG-07-069 -->
“Well, now that we *have* seen each other,” said the Unicorn, “if you’ll believe in me, I’ll believe in you. Is that a bargain?”
<!-- /EN:LG-07-069 -->

> 「さて、こうしてお互いに*会えた*ことだし」と一角獣。「おまえがおれを信じてくれるなら、おれもおまえを信じよう。それで取引成立か？」

<a id="LG-07-070"></a>

**LG-07-070**

<!-- EN:LG-07-070 -->
“Yes, if you like,” said Alice.
<!-- /EN:LG-07-070 -->

> 「ええ、それでよければ」とアリスは答えた。

<a id="LG-07-071"></a>

**LG-07-071**

<!-- EN:LG-07-071 -->
“Come, fetch out the plum-cake, old man!” the Unicorn went on, turning from her to the King. “None of your brown bread for me!”
<!-- /EN:LG-07-071 -->

> 「さあ、プラムケーキを出してくれよ、おっさん！」一角獣はアリスから王へ向き直って続けた。「おれに茶色いパンなんか出すなよ！」

> **訳注：** plum-cake はここでは干しぶどうなどの入ったフルーツケーキ。plum は菓子の語では干しぶどうを指すことがある。

<a id="LG-07-072"></a>

**LG-07-072**

<!-- EN:LG-07-072 -->
“Certainly—certainly!” the King muttered, and beckoned to Haigha. “Open the bag!” he whispered. “Quick! Not that one—that’s full of hay!”
<!-- /EN:LG-07-072 -->

> 「もちろん、もちろん！」王はつぶやき、ヘイヤを手招きした。「袋を開けろ！」とささやいた。「早く！　そっちではない。それは干し草ばかりじゃ！」

<a id="LG-07-073"></a>

**LG-07-073**

<!-- EN:LG-07-073 -->
Haigha took a large cake out of the bag, and gave it to Alice to hold, while he got out a dish and carving-knife. How they all came out of it Alice couldn’t guess. It was just like a conjuring-trick, she thought.
<!-- /EN:LG-07-073 -->

> ヘイヤは袋から大きなケーキを出して、アリスに持たせ、そのあいだに大皿と切り分け用のナイフを取り出した。どうしてこんなにいろいろ袋から出てくるのか、アリスには見当もつかなかった。まるで手品みたい、と彼女は思った。

<a id="LG-07-074"></a>

**LG-07-074**

<!-- EN:LG-07-074 -->
The Lion had joined them while this was going on: he looked very tired and sleepy, and his eyes were half shut. “What’s this!” he said, blinking lazily at Alice, and speaking in a deep hollow tone that sounded like the tolling of a great bell.
<!-- /EN:LG-07-074 -->

> そうしているうちに、ライオンも仲間に加わった。とても疲れて眠そうで、目も半ば閉じていた。「これは何だ！」気だるげにアリスへ目をしばたたかせながら言った。その深くうつろな声は、大きな鐘が鳴り響くようだった。

<a id="LG-07-075"></a>

**LG-07-075**

<!-- EN:LG-07-075 -->
“Ah, what *is* it, now?” the Unicorn cried eagerly. “You’ll never guess! *I* couldn’t.”
<!-- /EN:LG-07-075 -->

> 「さて、いったい*何*だろうな？」一角獣は勢いこんで叫んだ。「絶対に当てられないぞ！　*おれにも*分からなかった」

<a id="LG-07-076"></a>

**LG-07-076**

<!-- EN:LG-07-076 -->
The Lion looked at Alice wearily. “Are you animal—vegetable—or mineral?” he said, yawning at every other word.
<!-- /EN:LG-07-076 -->

> ライオンは疲れた目でアリスを見た。「おまえは動物か……植物か……それとも鉱物か？」一言おきにあくびをしながら尋ねた。

<a id="LG-07-077"></a>

**LG-07-077**

<!-- EN:LG-07-077 -->
“It’s a fabulous monster!” the Unicorn cried out, before Alice could reply.
<!-- /EN:LG-07-077 -->

> 「伝説の怪物だ！」アリスが答えるより先に、一角獣が叫んだ。

<a id="LG-07-078"></a>

**LG-07-078**

<!-- EN:LG-07-078 -->
“Then hand round the plum-cake, Monster,” the Lion said, lying down and putting his chin on his paws. “And sit down, both of you,” (to the King and the Unicorn): “fair play with the cake, you know!”
<!-- /EN:LG-07-078 -->

> 「それならプラムケーキを配ってくれ、怪物」とライオンは言って、横になり、前足の上にあごを載せた。「それから、二人とも座れ」（これは王と一角獣に向けて言った。）「ケーキは公平にな！」

<a id="LG-07-079"></a>

**LG-07-079**

<!-- EN:LG-07-079 -->
The King was evidently very uncomfortable at having to sit down between the two great creatures; but there was no other place for him.
<!-- /EN:LG-07-079 -->

> 王は、この大きな二匹のあいだに座らなければならず、見るからに居心地が悪そうだった。けれど、ほかに座る場所はなかった。

<a id="LG-07-080"></a>

**LG-07-080**

<!-- EN:LG-07-080 -->
“What a fight we might have for the crown, *now*!” the Unicorn said, looking slyly up at the crown, which the poor King was nearly shaking off his head, he trembled so much.
<!-- /EN:LG-07-080 -->

> 「*今なら*、王冠をかけてすごい戦いができそうだな！」一角獣は王冠を横目で見上げて言った。気の毒な王はあまりに震えていたので、王冠が頭から振り落とされそうになっていた。

<a id="LG-07-081"></a>

**LG-07-081**

<!-- EN:LG-07-081 -->
“I should win easy,” said the Lion.
<!-- /EN:LG-07-081 -->

> 「おれがたやすく勝つさ」とライオン。

<a id="LG-07-082"></a>

**LG-07-082**

<!-- EN:LG-07-082 -->
“I’m not so sure of that,” said the Unicorn.
<!-- /EN:LG-07-082 -->

> 「そうとも限らんだろう」と一角獣。

<a id="LG-07-083"></a>

**LG-07-083**

<!-- EN:LG-07-083 -->
“Why, I beat you all round the town, you chicken!” the Lion replied angrily, half getting up as he spoke.
<!-- /EN:LG-07-083 -->

> 「おい、おれは町じゅうでおまえを打ち負かしてやったんだぞ、この腰抜け！」ライオンは怒って言い返し、半ば立ち上がった。

<a id="LG-07-084"></a>

**LG-07-084**

<!-- EN:LG-07-084 -->
Here the King interrupted, to prevent the quarrel going on: he was very nervous, and his voice quite quivered. “All round the town?” he said. “That’s a good long way. Did you go by the old bridge, or the market-place? You get the best view by the old bridge.”
<!-- /EN:LG-07-084 -->

> そこで王は、口論が続かないよう割って入った。ひどく気をもんでいて、声がすっかり震えていた。「町じゅうだと？」と言った。「それはずいぶんな距離じゃ。古い橋を通ったのか、それとも市場の広場か？　古い橋のあたりが、いちばん眺めがよいぞ」

<a id="LG-07-085"></a>

**LG-07-085**

<!-- EN:LG-07-085 -->
“I’m sure I don’t know,” the Lion growled out as he lay down again. “There was too much dust to see anything. What a time the Monster is, cutting up that cake!”
<!-- /EN:LG-07-085 -->

> 「そんなこと知るものか」とライオンはうなって、また横になった。「ほこりがひどくて何も見えなかった。あの怪物、ケーキを切るのにいつまでかかっているんだ！」

<a id="LG-07-086"></a>

**LG-07-086**

<!-- EN:LG-07-086 -->
Alice had seated herself on the bank of a little brook, with the great dish on her knees, and was sawing away diligently with the knife. “It’s very provoking!” she said, in reply to the Lion (she was getting quite used to being called “the Monster”). “I’ve cut several slices already, but they always join on again!”
<!-- /EN:LG-07-086 -->

> アリスは小川の岸辺に座り、大皿を膝に載せて、ナイフをせっせとのこぎりのように動かしていた。「もう、ほんとうにいやになっちゃう！」とライオンに答えた（「怪物」と呼ばれるのにも、もうすっかり慣れていた）。「何切れも切ったのに、いつもまたくっついてしまうんだもの！」

<a id="LG-07-087"></a>

**LG-07-087**

<!-- EN:LG-07-087 -->
“You don’t know how to manage Looking-glass cakes,” the Unicorn remarked. “Hand it round first, and cut it afterwards.”
<!-- /EN:LG-07-087 -->

> 「鏡の国のケーキの扱い方を知らないんだな」と一角獣。「先に配って、あとから切るんだ」

<a id="LG-07-088"></a>

**LG-07-088**

<!-- EN:LG-07-088 -->
This sounded nonsense, but Alice very obediently got up, and carried the dish round, and the cake divided itself into three pieces as she did so. “*Now* cut it up,” said the Lion, as she returned to her place with the empty dish.
<!-- /EN:LG-07-088 -->

> でたらめに聞こえたけれど、アリスはとても素直に立ち上がって、大皿を持ってみんなのところを回った。するとそのあいだに、ケーキはひとりでに三切れに分かれた。「さあ、*これで*切ってくれ」とライオンは、空の皿を持って席に戻ったアリスに言った。

<a id="LG-07-089"></a>

**LG-07-089**

<!-- EN:LG-07-089 -->
“I say, this isn’t fair!” cried the Unicorn, as Alice sat with the knife in her hand, very much puzzled how to begin. “The Monster has given the Lion twice as much as me!”
<!-- /EN:LG-07-089 -->

> 「おい、これは不公平だぞ！」と一角獣が叫んだ。アリスはナイフを手に座り、どこから手をつけたらよいのか、ほとほと困っていた。「怪物は、ライオンにおれの倍もやったじゃないか！」

<a id="LG-07-090"></a>

**LG-07-090**

<!-- EN:LG-07-090 -->
“She’s kept none for herself, anyhow,” said the Lion. “Do you like plum-cake, Monster?”
<!-- /EN:LG-07-090 -->

> 「ともかく、自分の分は少しも取っていないぞ」とライオン。「プラムケーキは好きか、怪物？」

<a id="LG-07-091"></a>

**LG-07-091**

<!-- EN:LG-07-091 -->
But before Alice could answer him, the drums began.
<!-- /EN:LG-07-091 -->

> けれど、アリスが答えないうちに、太鼓が鳴り始めた。

<a id="LG-07-092"></a>

**LG-07-092**

<!-- EN:LG-07-092 -->
Where the noise came from, she couldn’t make out: the air seemed full of it, and it rang through and through her head till she felt quite deafened. She started to her feet and sprang across the little brook in her terror,
<!-- /EN:LG-07-092 -->

> どこから音がしてくるのか、アリスには分からなかった。空気ぜんぶがその音で満たされているようで、頭のすみずみまで響き渡り、すっかり耳が聞こえなくなりそうだった。アリスは飛び起き、恐ろしさのあまり小川を跳び越えた。

<a id="LG-07-093"></a>

<!-- EN:LG-07-093 -->
\*      \*      \*      \*      \*      \*      \*  
<!-- /EN:LG-07-093 -->

<a id="LG-07-094"></a>

<!-- EN:LG-07-094 -->
    \*      \*      \*      \*      \*      \*  
<!-- /EN:LG-07-094 -->

<a id="LG-07-095"></a>

<!-- EN:LG-07-095 -->
\*      \*      \*      \*      \*      \*      \*
<!-- /EN:LG-07-095 -->

<a id="LG-07-096"></a>

**LG-07-096**

<!-- EN:LG-07-096 -->
and had just time to see the Lion and the Unicorn rise to their feet, with angry looks at being interrupted in their feast, before she dropped to her knees, and put her hands over her ears, vainly trying to shut out the dreadful uproar.
<!-- /EN:LG-07-096 -->

> そして、ライオンと一角獣が、ごちそうの邪魔をされて腹を立てた顔で立ち上がるのを、かろうじて見届けると、膝をつき、両手で耳をふさいだ。恐ろしい大音響を締め出そうとしたけれど、無駄だった。

<a id="LG-07-097"></a>

**LG-07-097**

<!-- EN:LG-07-097 -->
“If *that* doesn’t ‘drum them out of town,’” she thought to herself, “nothing ever will!”
<!-- /EN:LG-07-097 -->

> 「*これで*『太鼓で町から追い出せない』なら」とアリスは思った。「何をしたって追い出せないわ！」

[章目次へ戻る](#book-top)

---

<a id="lg-chapter-08"></a>

## 第8章　「これは私の発明だ」

### CHAPTER VIII. “It’s my own Invention”

<a id="LG-08-001"></a>

**LG-08-001**

<!-- EN:LG-08-001 -->
After a while the noise seemed gradually to die away, till all was dead silence, and Alice lifted up her head in some alarm. There was no one to be seen, and her first thought was that she must have been dreaming about the Lion and the Unicorn and those queer Anglo-Saxon Messengers. However, there was the great dish still lying at her feet, on which she had tried to cut the plum-cake, “So I wasn’t dreaming, after all,” she said to herself, “unless—unless we’re all part of the same dream. Only I do hope it’s *my* dream, and not the Red King’s! I don’t like belonging to another person’s dream,” she went on in a rather complaining tone: “I’ve a great mind to go and wake him, and see what happens!”
<!-- /EN:LG-08-001 -->

> しばらくすると、物音はだんだん遠のいていくように聞こえ、とうとうあたりはしんと静まり返った。アリスは少し不安になって顔を上げた。だれ一人見当たらなかったので、まず、ライオンも一角獣も、あの妙なアングロサクソンの使者たちも、夢だったに違いないと思った。けれど足もとには、プラムケーキを切ろうとしたあの大皿が、まだ転がっていた。「やっぱり夢じゃなかったのね」と独り言を言った。「もしも……もしも、みんなが同じ夢の一部だというのでなければ。でもどうか、赤の王様のじゃなく、*わたしの*夢でありますように！　ほかの人の夢に属しているなんて、いやだもの」と、少し不満そうな声で続けた。「いっそ王様を起こしに行って、どうなるか確かめたいくらいだわ！」

<a id="LG-08-002"></a>

**LG-08-002**

<!-- EN:LG-08-002 -->
At this moment her thoughts were interrupted by a loud shouting of “Ahoy! Ahoy! Check!” and a Knight dressed in crimson armour came galloping down upon her, brandishing a great club. Just as he reached her, the horse stopped suddenly: “You’re my prisoner!” the Knight cried, as he tumbled off his horse.
<!-- /EN:LG-08-002 -->

> そのとき、「おおい！　おおい！　王手！」という大声がして、アリスの考えは中断された。深紅のよろいを着た騎士が、大きなこん棒を振り回して、馬を駆って襲いかかってきた。アリスのところへ着いたとたん、馬が急に止まった。「おまえはおれの捕虜だ！」騎士はそう叫びながら、馬から転げ落ちた。

<a id="LG-08-003"></a>

**LG-08-003**

<!-- EN:LG-08-003 -->
Startled as she was, Alice was more frightened for him than for herself at the moment, and watched him with some anxiety as he mounted again. As soon as he was comfortably in the saddle, he began once more “You’re my—” but here another voice broke in “Ahoy! Ahoy! Check!” and Alice looked round in some surprise for the new enemy.
<!-- /EN:LG-08-003 -->

> びっくりしたアリスだったが、このときは自分のことより騎士のほうが心配で、騎士がまた馬に乗るのを、はらはらして見守った。騎士は鞍に無事に収まるとすぐ、また「おまえはおれの……」と言いかけた。けれどそこへ、「おおい！　おおい！　王手！」と別の声が割りこんだ。アリスは少し驚いて、新しい敵を探して振り向いた。

<a id="LG-08-004"></a>

**LG-08-004**

<!-- EN:LG-08-004 -->
This time it was a White Knight. He drew up at Alice’s side, and tumbled off his horse just as the Red Knight had done: then he got on again, and the two Knights sat and looked at each other for some time without speaking. Alice looked from one to the other in some bewilderment.
<!-- /EN:LG-08-004 -->

> 今度は白の騎士だった。騎士はアリスのそばで馬を止めると、赤の騎士とまったく同じように転げ落ちた。それからまた馬に乗り、二人の騎士はしばらく黙ったまま、馬上で見つめ合っていた。アリスは当惑して、二人を交互に見た。

<a id="LG-08-005"></a>

**LG-08-005**

<!-- EN:LG-08-005 -->
“She’s *my* prisoner, you know!” the Red Knight said at last.
<!-- /EN:LG-08-005 -->

> 「その子は*おれの*捕虜だぞ！」ようやく赤の騎士が言った。

<a id="LG-08-006"></a>

**LG-08-006**

<!-- EN:LG-08-006 -->
“Yes, but then *I* came and rescued her!” the White Knight replied.
<!-- /EN:LG-08-006 -->

> 「そうだが、そのあとで*私が*来て、助け出したのだ！」と白の騎士は答えた。

<a id="LG-08-007"></a>

**LG-08-007**

<!-- EN:LG-08-007 -->
“Well, we must fight for her, then,” said the Red Knight, as he took up his helmet (which hung from the saddle, and was something the shape of a horse’s head), and put it on.
<!-- /EN:LG-08-007 -->

> 「それなら、その子をかけて戦わねばなるまい」と赤の騎士は言い、鞍に下げてあった兜を取り上げてかぶった。それはどことなく馬の頭の形をしていた。

<a id="LG-08-008"></a>

**LG-08-008**

<!-- EN:LG-08-008 -->
“You will observe the Rules of Battle, of course?” the White Knight remarked, putting on his helmet too.
<!-- /EN:LG-08-008 -->

> 「もちろん、戦いの規則は守るのだろうね？」白の騎士も兜をかぶりながら言った。

<a id="LG-08-009"></a>

**LG-08-009**

<!-- EN:LG-08-009 -->
“I always do,” said the Red Knight, and they began banging away at each other with such fury that Alice got behind a tree to be out of the way of the blows.
<!-- /EN:LG-08-009 -->

> 「いつも守っている」と赤の騎士。二人はものすごい勢いで互いをたたき始めたので、アリスはこん棒が当たらないよう木の陰に隠れた。

<a id="LG-08-010"></a>

**LG-08-010**

<!-- EN:LG-08-010 -->
“I wonder, now, what the Rules of Battle are,” she said to herself, as she watched the fight, timidly peeping out from her hiding-place: “one Rule seems to be, that if one Knight hits the other, he knocks him off his horse, and if he misses, he tumbles off himself—and another Rule seems to be that they hold their clubs with their arms, as if they were Punch and Judy—What a noise they make when they tumble! Just like a whole set of fire-irons falling into the fender! And how quiet the horses are! They let them get on and off them just as if they were tables!”
<!-- /EN:LG-08-010 -->

> 「さて、戦いの規則って、どんなものかしら」とアリスは、隠れたところからおずおずとのぞいて戦いを見ながら、独り言を言った。「一つの決まりは、一方が相手をたたくと、相手が馬から落ちることみたいね。外れると、自分が転げ落ちる。それから、パンチとジュディみたいに、こん棒を腕で抱えるのも決まりらしいわ。落ちるとき、なんてすごい音がするの！　暖炉道具を一式、囲いの中に落としたみたい！　それに馬たちのおとなしいこと！　まるでテーブルみたいに、乗ったり降りたりされるがままなのね！」

> **訳注：** Punch and Judy はイギリスの人形芝居の登場人物。ここではその棒を振るう身ぶりになぞらえている。

<a id="LG-08-011"></a>

**LG-08-011**

<!-- EN:LG-08-011 -->
Another Rule of Battle, that Alice had not noticed, seemed to be that they always fell on their heads, and the battle ended with their both falling off in this way, side by side: when they got up again, they shook hands, and then the Red Knight mounted and galloped off.
<!-- /EN:LG-08-011 -->

> アリスが気づかなかった規則が、もう一つあるらしかった。それは、いつも頭から落ちるというものだった。戦いは、二人が並んでそのとおりに落馬したところで終わった。起き上がると二人は握手し、赤の騎士は馬に乗って駆け去った。

<a id="LG-08-012"></a>

**LG-08-012**

<!-- EN:LG-08-012 -->
“It was a glorious victory, wasn’t it?” said the White Knight, as he came up panting.
<!-- /EN:LG-08-012 -->

> 「見事な勝利だったねえ？」白の騎士は息を切らして近づきながら言った。

<a id="LG-08-013"></a>

**LG-08-013**

<!-- EN:LG-08-013 -->
“I don’t know,” Alice said doubtfully. “I don’t want to be anybody’s prisoner. I want to be a Queen.”
<!-- /EN:LG-08-013 -->

> 「分からないわ」とアリスは心もとなげに答えた。「だれの捕虜にもなりたくないの。女王になりたいのよ」

<a id="LG-08-014"></a>

**LG-08-014**

<!-- EN:LG-08-014 -->
“So you will, when you’ve crossed the next brook,” said the White Knight. “I’ll see you safe to the end of the wood—and then I must go back, you know. That’s the end of my move.”
<!-- /EN:LG-08-014 -->

> 「なれるとも。次の小川を渡ればね」と白の騎士。「森の端まで、無事に送り届けてあげよう。そしたら私は戻らなければならない。それで私の一手はおしまいだからね」

<a id="LG-08-015"></a>

**LG-08-015**

<!-- EN:LG-08-015 -->
“Thank you very much,” said Alice. “May I help you off with your helmet?” It was evidently more than he could manage by himself; however, she managed to shake him out of it at last.
<!-- /EN:LG-08-015 -->

> 「どうもありがとう」とアリス。「兜を脱ぐのを手伝いましょうか？」どう見ても騎士一人の手には負えないことだったが、アリスが揺すってやると、ようやく中から出すことができた。

<a id="LG-08-016"></a>

**LG-08-016**

<!-- EN:LG-08-016 -->
“Now one can breathe more easily,” said the Knight, putting back his shaggy hair with both hands, and turning his gentle face and large mild eyes to Alice. She thought she had never seen such a strange-looking soldier in all her life.
<!-- /EN:LG-08-016 -->

> 「これで少し息が楽になる」と騎士は言った。両手でぼさぼさの髪を後ろへ払い、やさしい顔と大きなおだやかな目をアリスに向けた。こんな変わった姿の兵隊は、生まれて初めて見る、とアリスは思った。

<a id="LG-08-017"></a>

**LG-08-017**

<!-- EN:LG-08-017 -->
He was dressed in tin armour, which seemed to fit him very badly, and he had a queer-shaped little deal box fastened across his shoulder, upside-down, and with the lid hanging open. Alice looked at it with great curiosity.
<!-- /EN:LG-08-017 -->

> 騎士はブリキのよろいを着ていたが、まるで体に合っていないようだった。肩からは妙な形の小さな白木の箱を下げていた。箱は上下逆さまで、ふたが開いたままぶら下がっていた。アリスはたいそう興味を引かれて、それを眺めた。

<a id="LG-08-018"></a>

**LG-08-018**

<!-- EN:LG-08-018 -->
“I see you’re admiring my little box.” the Knight said in a friendly tone. “It’s my own invention—to keep clothes and sandwiches in. You see I carry it upside-down, so that the rain can’t get in.”
<!-- /EN:LG-08-018 -->

> 「私の小箱に感心しているのだね」と騎士は親しげに言った。「これは私の発明で、服やサンドイッチを入れておくのさ。ほら、雨が入らないように、逆さにして運んでいるんだ」

<a id="LG-08-019"></a>

**LG-08-019**

<!-- EN:LG-08-019 -->
“But the things can get *out*,” Alice gently remarked. “Do you know the lid’s open?”
<!-- /EN:LG-08-019 -->

> 「でも、中の物が*出て*しまうわ」とアリスはやんわり言った。「ふたが開いているの、ご存じ？」

<a id="LG-08-020"></a>

**LG-08-020**

<!-- EN:LG-08-020 -->
“I didn’t know it,” the Knight said, a shade of vexation passing over his face. “Then all the things must have fallen out! And the box is no use without them.” He unfastened it as he spoke, and was just going to throw it into the bushes, when a sudden thought seemed to strike him, and he hung it carefully on a tree. “Can you guess why I did that?” he said to Alice.
<!-- /EN:LG-08-020 -->

> 「知らなかった」と騎士は言い、少し困った表情を浮かべた。「じゃあ、全部落ちてしまったに違いない！　中の物がなければ、箱なんて役に立たない」そう言って箱を外し、茂みに投げ捨てようとしたとき、急に何か思いついたらしく、丁寧に木に掛けた。「どうしてこうしたか、分かるかい？」とアリスに尋ねた。

<a id="LG-08-021"></a>

**LG-08-021**

<!-- EN:LG-08-021 -->
Alice shook her head.
<!-- /EN:LG-08-021 -->

> アリスは首を横に振った。

<a id="LG-08-022"></a>

**LG-08-022**

<!-- EN:LG-08-022 -->
“In hopes some bees may make a nest in it—then I should get the honey.”
<!-- /EN:LG-08-022 -->

> 「ミツバチが巣を作ってくれないかと思ってね。そうしたら、蜂蜜が取れるだろう」

<a id="LG-08-023"></a>

**LG-08-023**

<!-- EN:LG-08-023 -->
“But you’ve got a bee-hive—or something like one—fastened to the saddle,” said Alice.
<!-- /EN:LG-08-023 -->

> 「でも、鞍に巣箱を……巣箱みたいなものを、取り付けてあるじゃない」とアリス。

<a id="LG-08-024"></a>

**LG-08-024**

<!-- EN:LG-08-024 -->
“Yes, it’s a very good bee-hive,” the Knight said in a discontented tone, “one of the best kind. But not a single bee has come near it yet. And the other thing is a mouse-trap. I suppose the mice keep the bees out—or the bees keep the mice out, I don’t know which.”
<!-- /EN:LG-08-024 -->

> 「そう、とてもよい巣箱なんだ」と騎士は不満そうに言った。「最高の部類に入る。ところが、まだ一匹も近寄ってこない。それから、もう一つのほうはネズミ捕りだ。たぶん、ネズミがハチを寄せつけないのか、ハチがネズミを寄せつけないのか、どちらかなんだろう。どっちかは分からないけれど」

<a id="LG-08-025"></a>

**LG-08-025**

<!-- EN:LG-08-025 -->
“I was wondering what the mouse-trap was for,” said Alice. “It isn’t very likely there would be any mice on the horse’s back.”
<!-- /EN:LG-08-025 -->

> 「ネズミ捕りを何に使うのか、不思議に思っていたの」とアリス。「馬の背中にネズミがいるとは、あまり思えないけれど」

<a id="LG-08-026"></a>

**LG-08-026**

<!-- EN:LG-08-026 -->
“Not very likely, perhaps,” said the Knight: “but if they *do* come, I don’t choose to have them running all about.”
<!-- /EN:LG-08-026 -->

> 「まあ、めったにないかもしれない」と騎士。「でも、*もし来たら*、そこらじゅう走り回らせたくはないからね」

<a id="LG-08-027"></a>

**LG-08-027**

<!-- EN:LG-08-027 -->
“You see,” he went on after a pause, “it’s as well to be provided for *everything*. That’s the reason the horse has all those anklets round his feet.”
<!-- /EN:LG-08-027 -->

> 「つまり」と、少し間を置いて続けた。「*何にでも*備えておくに越したことはないんだ。馬の足に、あんなに足輪をつけてあるのも、そのためさ」

<a id="LG-08-028"></a>

**LG-08-028**

<!-- EN:LG-08-028 -->
“But what are they for?” Alice asked in a tone of great curiosity.
<!-- /EN:LG-08-028 -->

> 「でも、あれは何に使うの？」アリスは興味津々で尋ねた。

<a id="LG-08-029"></a>

**LG-08-029**

<!-- EN:LG-08-029 -->
“To guard against the bites of sharks,” the Knight replied. “It’s an invention of my own. And now help me on. I’ll go with you to the end of the wood—What’s the dish for?”
<!-- /EN:LG-08-029 -->

> 「サメにかまれないようにするんだ」と騎士は答えた。「これも私の発明だよ。さて、馬に乗るのを手伝っておくれ。森の端まで一緒に行こう。その皿は何に使うんだい？」

<a id="LG-08-030"></a>

**LG-08-030**

<!-- EN:LG-08-030 -->
“It’s meant for plum-cake,” said Alice.
<!-- /EN:LG-08-030 -->

> 「プラムケーキを載せるためのものよ」とアリス。

<a id="LG-08-031"></a>

**LG-08-031**

<!-- EN:LG-08-031 -->
“We’d better take it with us,” the Knight said. “It’ll come in handy if we find any plum-cake. Help me to get it into this bag.”
<!-- /EN:LG-08-031 -->

> 「持っていったほうがよさそうだ」と騎士。「プラムケーキが見つかったら便利だろう。この袋に入れるのを手伝っておくれ」

<a id="LG-08-032"></a>

**LG-08-032**

<!-- EN:LG-08-032 -->
This took a very long time to manage, though Alice held the bag open very carefully, because the Knight was so *very* awkward in putting in the dish: the first two or three times that he tried he fell in himself instead. “It’s rather a tight fit, you see,” he said, as they got it in a last; “There are so many candlesticks in the bag.” And he hung it to the saddle, which was already loaded with bunches of carrots, and fire-irons, and many other things.
<!-- /EN:LG-08-032 -->

> これにはひどく時間がかかった。アリスはとても注意深く袋の口を開けていたのに、騎士が皿を入れるのは*ひどく*不器用で、最初の二、三回は、皿の代わりに自分が中へ転げこんでしまったからだ。「少し窮屈なんだね」と、やっと皿を入れてから騎士は言った。「袋には燭台がたくさん入っているから」そして、その袋を鞍に下げた。鞍にはすでに、束にしたニンジンや暖炉道具や、そのほかいろいろな物が満載だった。

<a id="LG-08-033"></a>

**LG-08-033**

<!-- EN:LG-08-033 -->
“I hope you’ve got your hair well fastened on?” he continued, as they set off.
<!-- /EN:LG-08-033 -->

> 「髪の毛はしっかり留めてあるかい？」歩き出すと、騎士は続けて尋ねた。

<a id="LG-08-034"></a>

**LG-08-034**

<!-- EN:LG-08-034 -->
“Only in the usual way,” Alice said, smiling.
<!-- /EN:LG-08-034 -->

> 「普通にしてあるだけよ」とアリスはほほえんだ。

<a id="LG-08-035"></a>

**LG-08-035**

<!-- EN:LG-08-035 -->
“That’s hardly enough,” he said, anxiously. “You see the wind is so *very* strong here. It’s as strong as soup.”
<!-- /EN:LG-08-035 -->

> 「それでは、ちょっと足りないな」と騎士は心配そうに言った。「ここは風が*たいへん*強いからね。スープくらい強いんだ」

> **訳注：** strong は風なら「強い」、スープなら「濃い」。異なる意味を同じ尺度として比較している。

<a id="LG-08-036"></a>

**LG-08-036**

<!-- EN:LG-08-036 -->
“Have you invented a plan for keeping the hair from being blown off?” Alice enquired.
<!-- /EN:LG-08-036 -->

> 「髪が吹き飛ばされない方法も発明したの？」とアリスは尋ねた。

<a id="LG-08-037"></a>

**LG-08-037**

<!-- EN:LG-08-037 -->
“Not yet,” said the Knight. “But I’ve got a plan for keeping it from *falling* off.”
<!-- /EN:LG-08-037 -->

> 「まだだ」と騎士。「けれど、髪が*抜け落ちない*方法ならある」

<a id="LG-08-038"></a>

**LG-08-038**

<!-- EN:LG-08-038 -->
“I should like to hear it, very much.”
<!-- /EN:LG-08-038 -->

> 「ぜひ聞きたいわ」

<a id="LG-08-039"></a>

**LG-08-039**

<!-- EN:LG-08-039 -->
“First you take an upright stick,” said the Knight. “Then you make your hair creep up it, like a fruit-tree. Now the reason hair falls off is because it hangs *down*—things never fall *upwards*, you know. It’s a plan of my own invention. You may try it if you like.”
<!-- /EN:LG-08-039 -->

> 「まず棒を一本、まっすぐ立てる」と騎士。「それから果樹のように、髪を棒づたいに上へはわせるんだ。さて、髪が落ちるわけは、*下に*垂れているからだよ。物が*上向きに*落ちることはないだろう。私が考え出した方法なんだ。よければ試してごらん」

<a id="LG-08-040"></a>

**LG-08-040**

<!-- EN:LG-08-040 -->
It didn’t sound a comfortable plan, Alice thought, and for a few minutes she walked on in silence, puzzling over the idea, and every now and then stopping to help the poor Knight, who certainly was *not* a good rider.
<!-- /EN:LG-08-040 -->

> あまり気持ちのよさそうな方法ではない、とアリスは思った。それから数分、黙って歩きながら、その考えをあれこれ思いめぐらせていた。ときどき立ち止まって、気の毒な騎士を助けてもやった。騎士はたしかに、乗馬が上手とは*いえなかった*。

<a id="LG-08-041"></a>

**LG-08-041**

<!-- EN:LG-08-041 -->
Whenever the horse stopped (which it did very often), he fell off in front; and whenever it went on again (which it generally did rather suddenly), he fell off behind. Otherwise he kept on pretty well, except that he had a habit of now and then falling off sideways; and as he generally did this on the side on which Alice was walking, she soon found that it was the best plan not to walk *quite* close to the horse.
<!-- /EN:LG-08-041 -->

> 馬が止まるたびに――それはしょっちゅうだった――騎士は前へ落ちた。そして馬がまた歩き出すたびに――たいてい、かなり突然歩き出した――今度は後ろへ落ちた。それ以外はまずまずだった。ただ、ときどき横へ落ちる癖もあり、たいていアリスの歩いている側へ落ちたので、馬に*あまりぴったり*寄らないほうがいい、とアリスはすぐに悟った。

<a id="LG-08-042"></a>

**LG-08-042**

<!-- EN:LG-08-042 -->
“I’m afraid you’ve not had much practice in riding,” she ventured to say, as she was helping him up from his fifth tumble.
<!-- /EN:LG-08-042 -->

> 「乗馬の練習をあまりなさっていないのかしら」と、五度目に転げ落ちた騎士を起こしながら、アリスは思いきって言った。

<a id="LG-08-043"></a>

**LG-08-043**

<!-- EN:LG-08-043 -->
The Knight looked very much surprised, and a little offended at the remark. “What makes you say that?” he asked, as he scrambled back into the saddle, keeping hold of Alice’s hair with one hand, to save himself from falling over on the other side.
<!-- /EN:LG-08-043 -->

> 騎士はその言葉にたいへん驚き、少し気を悪くしたようだった。「どうしてそう思うんだい？」と尋ねながら、鞍によじ登った。反対側へ落ちないよう、片手でアリスの髪をつかんでいた。

<a id="LG-08-044"></a>

**LG-08-044**

<!-- EN:LG-08-044 -->
“Because people don’t fall off quite so often, when they’ve had much practice.”
<!-- /EN:LG-08-044 -->

> 「だって、たくさん練習した人は、そう何度も落ちないでしょう」

<a id="LG-08-045"></a>

**LG-08-045**

<!-- EN:LG-08-045 -->
“I’ve had plenty of practice,” the Knight said very gravely: “plenty of practice!”
<!-- /EN:LG-08-045 -->

> 「たっぷり練習しているよ」と騎士は大まじめに言った。「たっぷり練習している！」

<a id="LG-08-046"></a>

**LG-08-046**

<!-- EN:LG-08-046 -->
Alice could think of nothing better to say than “Indeed?” but she said it as heartily as she could. They went on a little way in silence after this, the Knight with his eyes shut, muttering to himself, and Alice watching anxiously for the next tumble.
<!-- /EN:LG-08-046 -->

> アリスは「そうなんですか？」と言うほかに、うまい返事を思いつかなかった。でも、できるだけ心をこめて言った。それから二人は、しばらく黙って進んだ。騎士は目を閉じてぶつぶつ独り言を言い、アリスは次にいつ落ちるかと、はらはらして見守っていた。

<a id="LG-08-047"></a>

**LG-08-047**

<!-- EN:LG-08-047 -->
“The great art of riding,” the Knight suddenly began in a loud voice, waving his right arm as he spoke, “is to keep—” Here the sentence ended as suddenly as it had begun, as the Knight fell heavily on the top of his head exactly in the path where Alice was walking. She was quite frightened this time, and said in an anxious tone, as she picked him up, “I hope no bones are broken?”
<!-- /EN:LG-08-047 -->

> 「乗馬のいちばん大事なこつは」と、騎士は突然、右腕を振りながら大声で言い始めた。「保つことだ――」言葉は始まったときと同じくらい突然に途切れた。騎士が、ちょうどアリスの歩いていた道に、頭からどしんと落ちたからだった。今度こそアリスはすっかり怖くなり、騎士を起こしながら心配そうに言った。「骨は折れていない？」

<a id="LG-08-048"></a>

**LG-08-048**

<!-- EN:LG-08-048 -->
“None to speak of,” the Knight said, as if he didn’t mind breaking two or three of them. “The great art of riding, as I was saying, is—to keep your balance properly. Like this, you know—”
<!-- /EN:LG-08-048 -->

> 「取り立てて言うほどにはね」と騎士は答えた。二、三本折れたところで気にしない、とでも言うようだった。「さっきも言ったように、乗馬のいちばん大事なこつは、ちゃんと釣り合いを保つことなんだ。こういうふうにね――」

<a id="LG-08-049"></a>

**LG-08-049**

<!-- EN:LG-08-049 -->
He let go the bridle, and stretched out both his arms to show Alice what he meant, and this time he fell flat on his back, right under the horse’s feet.
<!-- /EN:LG-08-049 -->

> 騎士は手綱を放し、言ったとおりの姿勢をアリスに見せようと両腕を広げた。そして今度は、馬の足の真下へ、仰向けにまっすぐ落ちてしまった。

<a id="LG-08-050"></a>

**LG-08-050**

<!-- EN:LG-08-050 -->
“Plenty of practice!” he went on repeating, all the time that Alice was getting him on his feet again. “Plenty of practice!”
<!-- /EN:LG-08-050 -->

> 「たっぷり練習している！」アリスがまた立たせてやるあいだじゅう、騎士は繰り返した。「たっぷり練習している！」

<a id="LG-08-051"></a>

**LG-08-051**

<!-- EN:LG-08-051 -->
“It’s too ridiculous!” cried Alice, losing all her patience this time. “You ought to have a wooden horse on wheels, that you ought!”
<!-- /EN:LG-08-051 -->

> 「あんまりばかばかしいわ！」アリスはとうとう我慢ができなくなって叫んだ。「車輪のついた木馬に乗ればいいのに。ほんとうに、そのほうがいいわ！」

<a id="LG-08-052"></a>

**LG-08-052**

<!-- EN:LG-08-052 -->
“Does that kind go smoothly?” the Knight asked in a tone of great interest, clasping his arms round the horse’s neck as he spoke, just in time to save himself from tumbling off again.
<!-- /EN:LG-08-052 -->

> 「そういうのは、滑らかに進むかね？」騎士はたいへん興味を引かれた様子で尋ねた。そう言いながら馬の首を両腕で抱え、また転げ落ちるところを、間一髪で食い止めた。

<a id="LG-08-053"></a>

**LG-08-053**

<!-- EN:LG-08-053 -->
“Much more smoothly than a live horse,” Alice said, with a little scream of laughter, in spite of all she could do to prevent it.
<!-- /EN:LG-08-053 -->

> 「生きた馬より、ずっと滑らかよ」とアリスは言った。こらえようにもこらえきれず、小さく声を上げて笑ってしまった。

<a id="LG-08-054"></a>

**LG-08-054**

<!-- EN:LG-08-054 -->
“I’ll get one,” the Knight said thoughtfully to himself. “One or two—several.”
<!-- /EN:LG-08-054 -->

> 「一頭、手に入れよう」と騎士は考えこむように独り言を言った。「一頭か二頭……何頭か」

<a id="LG-08-055"></a>

**LG-08-055**

<!-- EN:LG-08-055 -->
There was a short silence after this, and then the Knight went on again. “I’m a great hand at inventing things. Now, I daresay you noticed, that last time you picked me up, that I was looking rather thoughtful?”
<!-- /EN:LG-08-055 -->

> しばらく沈黙が続いたあと、騎士はまた話し始めた。「私は物を発明するのがたいへん得意なんだ。さっき起こしてくれたとき、私がいくらか考え深げな顔をしていたのに気づいたんじゃないかね？」

<a id="LG-08-056"></a>

**LG-08-056**

<!-- EN:LG-08-056 -->
“You *were* a little grave,” said Alice.
<!-- /EN:LG-08-056 -->

> 「少し真剣なお顔を*していた*わ」とアリス。

<a id="LG-08-057"></a>

**LG-08-057**

<!-- EN:LG-08-057 -->
“Well, just then I was inventing a new way of getting over a gate—would you like to hear it?”
<!-- /EN:LG-08-057 -->

> 「ちょうどそのとき、門を乗り越える新しい方法を考えついていたんだ。聞きたいかね？」

<a id="LG-08-058"></a>

**LG-08-058**

<!-- EN:LG-08-058 -->
“Very much indeed,” Alice said politely.
<!-- /EN:LG-08-058 -->

> 「ええ、ぜひ」とアリスは礼儀正しく答えた。

<a id="LG-08-059"></a>

**LG-08-059**

<!-- EN:LG-08-059 -->
“I’ll tell you how I came to think of it,” said the Knight. “You see, I said to myself, ‘The only difficulty is with the feet: the *head* is high enough already.’ Now, first I put my head on the top of the gate—then I stand on my head—then the feet are high enough, you see—then I’m over, you see.”
<!-- /EN:LG-08-059 -->

> 「どう思いついたかを話そう」と騎士。「私はこう考えたんだ。『問題なのは足だけだ。*頭*はもう十分高いところにある』とね。そこで、まず頭を門のてっぺんに載せる。次に頭で逆立ちする。すると、ほら、足も十分高くなる。そうすれば、ほら、もう向こう側だ」

<a id="LG-08-060"></a>

**LG-08-060**

<!-- EN:LG-08-060 -->
“Yes, I suppose you’d be over when that was done,” Alice said thoughtfully: “but don’t you think it would be rather hard?”
<!-- /EN:LG-08-060 -->

> 「ええ、それができれば向こうへ行けるでしょうね」とアリスは考えながら言った。「でも、ずいぶん難しいと思わない？」

<a id="LG-08-061"></a>

**LG-08-061**

<!-- EN:LG-08-061 -->
“I haven’t tried it yet,” the Knight said, gravely: “so I can’t tell for certain—but I’m afraid it *would* be a little hard.”
<!-- /EN:LG-08-061 -->

> 「まだ試していないので」と騎士はまじめに言った。「はっきりとは言えないけれど、たしかに少し難しい*かもしれない*ね」

<a id="LG-08-062"></a>

**LG-08-062**

<!-- EN:LG-08-062 -->
He looked so vexed at the idea, that Alice changed the subject hastily. “What a curious helmet you’ve got!” she said cheerfully. “Is that your invention too?”
<!-- /EN:LG-08-062 -->

> 騎士があまりに困り切った顔をしたので、アリスはあわてて話題を変えた。「なんて変わった兜を持っているの！」と明るく言った。「それもあなたの発明？」

<a id="LG-08-063"></a>

**LG-08-063**

<!-- EN:LG-08-063 -->
The Knight looked down proudly at his helmet, which hung from the saddle. “Yes,” he said, “but I’ve invented a better one than that—like a sugar loaf. When I used to wear it, if I fell off the horse, it always touched the ground directly. So I had a *very* little way to fall, you see—But there *was* the danger of falling *into* it, to be sure. That happened to me once—and the worst of it was, before I could get out again, the other White Knight came and put it on. He thought it was his own helmet.”
<!-- /EN:LG-08-063 -->

> 騎士は、鞍に下がっている兜を誇らしげに見下ろした。「そうだ」と言った。「でも、これよりよい物も発明した。砂糖の塊みたいな、先のとがった形なんだ。それをかぶっていたころは、馬から落ちると、すぐに兜が地面に着いた。だから落ちる距離が*ほんの少し*で済んだわけさ。ただ、兜の*中へ*落ちこむ危険は、たしかに*あった*。一度そうなったことがある。それでいちばん困ったのは、私が抜け出す前に、もう一人の白の騎士がやってきて、それをかぶってしまったことだ。自分の兜だと思ったのだね」

> **訳注：** sugar loaf は、かつて砂糖を固めて売った円錐形の塊。兜の背の高さと、とがった形を表している。

<a id="LG-08-064"></a>

**LG-08-064**

<!-- EN:LG-08-064 -->
The knight looked so solemn about it that Alice did not dare to laugh. “I’m afraid you must have hurt him,” she said in a trembling voice, “being on the top of his head.”
<!-- /EN:LG-08-064 -->

> 騎士があまりに深刻な顔をしていたので、アリスは笑うに笑えなかった。「その人、痛かったでしょうね」と震える声で言った。「あなたが頭のてっぺんにいたんだもの」

<a id="LG-08-065"></a>

**LG-08-065**

<!-- EN:LG-08-065 -->
“I had to kick him, of course,” the Knight said, very seriously. “And then he took the helmet off again—but it took hours and hours to get me out. I was as fast as—as lightning, you know.”
<!-- /EN:LG-08-065 -->

> 「もちろん、蹴らなければならなかった」と騎士は大まじめに言った。「それで向こうは兜を脱いだのだが、私を出すには何時間も何時間もかかった。私は、そう、稲妻のようにしっかりしていたからね」

> **訳注：** fast には「しっかり固定されて」と「速い」の意味がある。騎士は兜にはまりこんで動けない状態を、as fast as lightning（稲妻のように速い）で説明してしまう。

<a id="LG-08-066"></a>

**LG-08-066**

<!-- EN:LG-08-066 -->
“But that’s a different kind of fastness,” Alice objected.
<!-- /EN:LG-08-066 -->

> 「でも、それは別の意味の『fast』でしょう」とアリスは異議を唱えた。

<a id="LG-08-067"></a>

**LG-08-067**

<!-- EN:LG-08-067 -->
The Knight shook his head. “It was all kinds of fastness with me, I can assure you!” he said. He raised his hands in some excitement as he said this, and instantly rolled out of the saddle, and fell headlong into a deep ditch.
<!-- /EN:LG-08-067 -->

> 騎士は首を振った。「私の場合は、あらゆる意味で『fast』だった。これは請け合うよ！」そう言って、少し興奮して両手を上げたとたん、鞍から転がり落ち、深い溝へ頭から突っこんでしまった。

<a id="LG-08-068"></a>

**LG-08-068**

<!-- EN:LG-08-068 -->
Alice ran to the side of the ditch to look for him. She was rather startled by the fall, as for some time he had kept on very well, and she was afraid that he really *was* hurt this time. However, though she could see nothing but the soles of his feet, she was much relieved to hear that he was talking on in his usual tone. “All kinds of fastness,” he repeated: “but it was careless of him to put another man’s helmet on—with the man in it, too.”
<!-- /EN:LG-08-068 -->

> アリスは騎士を探して、溝の縁へ駆け寄った。しばらくはうまく乗っていたので、急に落ちたことにいくらか驚き、今度こそほんとうにけがを*した*のではないかと心配した。けれど足の裏しか見えないものの、いつもと同じ調子で話し続けているのが聞こえて、ずいぶん安心した。「あらゆる意味で『fast』だった」と騎士は繰り返した。「だが、ほかの人の兜をかぶるとは、不注意だったね。しかも、中にその人が入っているのに」

<a id="LG-08-069"></a>

**LG-08-069**

<!-- EN:LG-08-069 -->
“How *can* you go on talking so quietly, head downwards?” Alice asked, as she dragged him out by the feet, and laid him in a heap on the bank.
<!-- /EN:LG-08-069 -->

> 「逆さまなのに、どうしてそんなに平気で話し続けられるの？」アリスは、騎士の足を持って引きずり出し、土手の上にひとかたまりに置きながら尋ねた。

<a id="LG-08-070"></a>

**LG-08-070**

<!-- EN:LG-08-070 -->
The Knight looked surprised at the question. “What does it matter where my body happens to be?” he said. “My mind goes on working all the same. In fact, the more head downwards I am, the more I keep inventing new things.”
<!-- /EN:LG-08-070 -->

> 騎士はその質問に驚いたようだった。「体がたまたまどこにあるかなんて、何の関係があるんだい？」と言った。「頭の中は同じように働き続けるよ。実際、逆さまになればなるほど、新しい物を次々に発明するんだ」

<a id="LG-08-071"></a>

**LG-08-071**

<!-- EN:LG-08-071 -->
“Now the cleverest thing of the sort that I ever did,” he went on after a pause, “was inventing a new pudding during the meat-course.”
<!-- /EN:LG-08-071 -->

> 「さて、その種のことで私がした、いちばん気の利いた発明はね」と、ひと息置いて続けた。「肉料理を食べているあいだに、新しいプディングを考え出したことだ」

<a id="LG-08-072"></a>

**LG-08-072**

<!-- EN:LG-08-072 -->
“In time to have it cooked for the next course?” said Alice.
<!-- /EN:LG-08-072 -->

> 「次のお皿に間に合うように、作ってもらったの？」とアリス。

<a id="LG-08-073"></a>

**LG-08-073**

<!-- EN:LG-08-073 -->
“Well, not the *next* course,” the Knight said in a slow thoughtful tone: “no, certainly not the next *course*.”
<!-- /EN:LG-08-073 -->

> 「いや、*次の*お皿ではない」と騎士はゆっくり考えこむように言った。「うん、次の*お皿*では、たしかにないね」

<a id="LG-08-074"></a>

**LG-08-074**

<!-- EN:LG-08-074 -->
“Then it would have to be the next day. I suppose you wouldn’t have two pudding-courses in one dinner?”
<!-- /EN:LG-08-074 -->

> 「じゃあ、翌日ということになるわね。一度の夕食で、プディングを二回も出したりはしないでしょう？」

<a id="LG-08-075"></a>

**LG-08-075**

<!-- EN:LG-08-075 -->
“Well, not the *next* day,” the Knight repeated as before: “not the next *day*. In fact,” he went on, holding his head down, and his voice getting lower and lower, “I don’t believe that pudding ever *was* cooked! In fact, I don’t believe that pudding ever *will* be cooked! And yet it was a very clever pudding to invent.”
<!-- /EN:LG-08-075 -->

> 「いや、*翌*日でもない」と騎士は同じ調子で繰り返した。「次の*日*でもない。実は」と、頭を垂れ、だんだん声を小さくしながら続けた。「あのプディングは、一度も作られたことが*ない*と思う。実際、これからも作られることは*ない*と思う！　それでも、あれを発明したのは、とても気の利いた思いつきだったんだ」

<a id="LG-08-076"></a>

**LG-08-076**

<!-- EN:LG-08-076 -->
“What did you mean it to be made of?” Alice asked, hoping to cheer him up, for the poor Knight seemed quite low-spirited about it.
<!-- /EN:LG-08-076 -->

> 「何を材料にするつもりだったの？」とアリスは尋ねた。気の毒な騎士が、すっかりしょげ返っているようだったので、元気づけたかったのだ。

<a id="LG-08-077"></a>

**LG-08-077**

<!-- EN:LG-08-077 -->
“It began with blotting paper,” the Knight answered with a groan.
<!-- /EN:LG-08-077 -->

> 「まず、吸い取り紙から始めるんだ」と騎士はうめくように答えた。

<a id="LG-08-078"></a>

**LG-08-078**

<!-- EN:LG-08-078 -->
“That wouldn’t be very nice, I’m afraid—”
<!-- /EN:LG-08-078 -->

> 「それじゃ、あまりおいしくなさそうだけれど……」

<a id="LG-08-079"></a>

**LG-08-079**

<!-- EN:LG-08-079 -->
“Not very nice *alone*,” he interrupted, quite eagerly: “but you’ve no idea what a difference it makes mixing it with other things—such as gunpowder and sealing-wax. And here I must leave you.” They had just come to the end of the wood.
<!-- /EN:LG-08-079 -->

> 「*それだけ*なら、あまりおいしくない」と騎士は、すっかり勢いこんで遮った。「でも、ほかの物を混ぜるとどれほど違ってくるか、君には想像もつかないだろう。たとえば火薬とか、封蠟とかね。さて、ここでお別れしなければならない」ちょうど森の端に着いたのだった。

<a id="LG-08-080"></a>

**LG-08-080**

<!-- EN:LG-08-080 -->
Alice could only look puzzled: she was thinking of the pudding.
<!-- /EN:LG-08-080 -->

> アリスはただ、当惑した顔をするばかりだった。まだプディングのことを考えていたのだ。

<a id="LG-08-081"></a>

**LG-08-081**

<!-- EN:LG-08-081 -->
“You are sad,” the Knight said in an anxious tone: “let me sing you a song to comfort you.”
<!-- /EN:LG-08-081 -->

> 「悲しいのだね」と騎士は心配そうに言った。「慰めに、一曲歌ってあげよう」

<a id="LG-08-082"></a>

**LG-08-082**

<!-- EN:LG-08-082 -->
“Is it very long?” Alice asked, for she had heard a good deal of poetry that day.
<!-- /EN:LG-08-082 -->

> 「とても長いの？」とアリスは尋ねた。その日は、すでにずいぶんたくさんの詩を聞いていたからだ。

<a id="LG-08-083"></a>

**LG-08-083**

<!-- EN:LG-08-083 -->
“It’s long,” said the Knight, “but very, *very* beautiful. Everybody that hears me sing it—either it brings the *tears* into their eyes, or else—”
<!-- /EN:LG-08-083 -->

> 「長い」と騎士。「でも、とても、*とても*美しい歌なんだ。私が歌うのを聞いた人は、だれでも――目に*涙*を浮かべるか、それとも――」

<a id="LG-08-084"></a>

**LG-08-084**

<!-- EN:LG-08-084 -->
“Or else what?” said Alice, for the Knight had made a sudden pause.
<!-- /EN:LG-08-084 -->

> 「それとも、どうなるの？」とアリス。騎士が突然、口をつぐんだからだった。

<a id="LG-08-085"></a>

**LG-08-085**

<!-- EN:LG-08-085 -->
“Or else it doesn’t, you know. The name of the song is called ‘*Haddocks’ Eyes*.’”
<!-- /EN:LG-08-085 -->

> 「それとも、浮かべないかだよ。歌の名前は『*コダラの目*』と呼ばれている」

<a id="LG-08-086"></a>

**LG-08-086**

<!-- EN:LG-08-086 -->
“Oh, that’s the name of the song, is it?” Alice said, trying to feel interested.
<!-- /EN:LG-08-086 -->

> 「ああ、それが歌の名前なのね？」とアリスは、興味を持とうと努めながら言った。

<a id="LG-08-087"></a>

**LG-08-087**

<!-- EN:LG-08-087 -->
“No, you don’t understand,” the Knight said, looking a little vexed. “That’s what the name is *called*. The name really *is* ‘*The Aged Aged Man*.’”
<!-- /EN:LG-08-087 -->

> 「いや、分かっていないね」と騎士は、少し困った顔で言った。「それは名前が何と*呼ばれているか*だよ。名前そのものは『*年取った年取った男*』なんだ」

<a id="LG-08-088"></a>

**LG-08-088**

<!-- EN:LG-08-088 -->
“Then I ought to have said ‘That’s what the *song* is called’?” Alice corrected herself.
<!-- /EN:LG-08-088 -->

> 「じゃあ、『*歌*がそう呼ばれているのね』と言えばよかったの？」アリスは自分の言い方を訂正した。

<a id="LG-08-089"></a>

**LG-08-089**

<!-- EN:LG-08-089 -->
“No, you oughtn’t: that’s quite another thing! The *song* is called ‘*Ways and Means*’: but that’s only what it’s *called*, you know!”
<!-- /EN:LG-08-089 -->

> 「いや、それではいけない。それはまた、まったく別のことだ！　*歌*は『*手段と方法*』と呼ばれている。でも、それはただ、そう*呼ばれている*だけなのだよ！」

<a id="LG-08-090"></a>

**LG-08-090**

<!-- EN:LG-08-090 -->
“Well, what *is* the song, then?” said Alice, who was by this time completely bewildered.
<!-- /EN:LG-08-090 -->

> 「それなら、歌そのものは*何なの*？」とアリスは言った。もう完全に訳が分からなくなっていた。

<a id="LG-08-091"></a>

**LG-08-091**

<!-- EN:LG-08-091 -->
“I was coming to that,” the Knight said. “The song really *is* ‘*A-sitting On A Gate*’: and the tune’s my own invention.”
<!-- /EN:LG-08-091 -->

> 「ちょうど、それを話そうとしていた」と騎士。「歌そのものは『*門の上に腰かけて*』なんだ。曲は私の発明だよ」

> **訳注：** ここでは「歌」「歌の名前」「名前の呼び名」「歌の呼び名」が、わざと別々のものとして扱われている。四つの表現を一つの題名にまとめないように訳した。

<a id="LG-08-092"></a>

**LG-08-092**

<!-- EN:LG-08-092 -->
So saying, he stopped his horse and let the reins fall on its neck: then, slowly beating time with one hand, and with a faint smile lighting up his gentle foolish face, as if he enjoyed the music of his song, he began.
<!-- /EN:LG-08-092 -->

> そう言って騎士は馬を止め、手綱を首の上に垂らした。それから片手でゆっくり拍子を取り、自分の歌の調べを楽しむかのように、やさしく、お人よしな顔にかすかな笑みを浮かべて、歌い始めた。

<a id="LG-08-093"></a>

**LG-08-093**

<!-- EN:LG-08-093 -->
Of all the strange things that Alice saw in her journey Through The Looking-Glass, this was the one that she always remembered most clearly. Years afterwards she could bring the whole scene back again, as if it had been only yesterday—the mild blue eyes and kindly smile of the Knight—the setting sun gleaming through his hair, and shining on his armour in a blaze of light that quite dazzled her—the horse quietly moving about, with the reins hanging loose on his neck, cropping the grass at her feet—and the black shadows of the forest behind—all this she took in like a picture, as, with one hand shading her eyes, she leant against a tree, watching the strange pair, and listening, in a half dream, to the melancholy music of the song.
<!-- /EN:LG-08-093 -->

> 鏡の国の旅でアリスが見た、あらゆる不思議な出来事のうち、いちばんはっきり、いつまでも心に残ったのは、この場面だった。何年たっても、その光景をまるごと、まるで昨日のことのように思い浮かべられた。騎士のおだやかな青い目と、親切そうなほほえみ。髪のあいだからきらめく夕日が、よろいに反射してまぶしいほどの光を放つこと。首に手綱をゆるく垂らした馬が、静かに歩き回りながら、アリスの足もとの草をはむこと。そして背後に広がる森の黒い影。アリスは片手を目の上にかざし、木にもたれながら、この不思議な一組を眺め、半ば夢見る心地で、もの悲しい歌の調べに耳を傾けた。そのすべてを、一枚の絵のように心へ取りこんだのだった。

<a id="LG-08-094"></a>

**LG-08-094**

<!-- EN:LG-08-094 -->
“But the tune *isn’t* his own invention,” she said to herself: “it’s ‘*I give thee all, I can no more*.’” She stood and listened very attentively, but no tears came into her eyes.
<!-- /EN:LG-08-094 -->

> 「でも、曲はあの人の発明*じゃない*わ」とアリスは独り言を言った。「『*すべてを君に捧げよう、これ以上は何もできない*』だもの」立ったまま、とても熱心に聞いていたけれど、目に涙は浮かばなかった。

<a id="LG-08-095"></a>

**LG-08-095**

<!-- EN:LG-08-095 -->
“I’ll tell thee everything I can;  
    There’s little to relate.  
I saw an aged aged man,  
    A-sitting on a gate.  
‘Who are you, aged man?’ I said,  
    ‘and how is it you live?’  
And his answer trickled through my head  
    Like water through a sieve.  
<!-- /EN:LG-08-095 -->

> 「話せることは、みんな話そう。  
> 　話すほどのことは、あまりないが。  
> 年取った、年取った男を見た。  
> 　門の上に腰かけていた。  
> 『ご老人、あなたはどなたです』と私は言った。  
> 　『それに、どうやって暮らしているのです』  
> 答えは私の頭をすり抜けていった。  
> 　ざるを通る水のように。

<a id="LG-08-096"></a>

**LG-08-096**

<!-- EN:LG-08-096 -->
He said ‘I look for butterflies  
    That sleep among the wheat:  
I make them into mutton-pies,  
    And sell them in the street.  
I sell them unto men,’ he said,  
    ‘Who sail on stormy seas;  
And that’s the way I get my bread—  
    A trifle, if you please.’  
<!-- /EN:LG-08-096 -->

> 老人は言った。『私は蝶を探します、  
> 　麦のあいだで眠る蝶を。  
> それを羊肉のパイにして、  
> 　通りで売るのです。  
> 売る相手は男たち』と老人は言った、  
> 　『荒れた海を航海する男たちです。  
> そうやってパンを得ているのです――  
> 　よろしければ、お恵みを少々』

<a id="LG-08-097"></a>

**LG-08-097**

<!-- EN:LG-08-097 -->
But I was thinking of a plan  
    To dye one’s whiskers green,  
And always use so large a fan  
    That they could not be seen.  
So, having no reply to give  
    To what the old man said,  
I cried, ‘Come, tell me how you live!’  
    And thumped him on the head.  
<!-- /EN:LG-08-097 -->

> けれど私は、ある方法を考えていた。  
> 　ほおひげを緑色に染めて、  
> いつも大きな扇を使って、  
> 　ひげが見えないようにする方法を。  
> だから返す言葉もなかった、  
> 　老人が語ったことに。  
> 『さあ、どうやって暮らしているのか話しなさい！』と叫んで、  
> 　頭をどんと殴った。

<a id="LG-08-098"></a>

**LG-08-098**

<!-- EN:LG-08-098 -->
His accents mild took up the tale:  
    He said ‘I go my ways,  
And when I find a mountain-rill,  
    I set it in a blaze;  
And thence they make a stuff they call  
    Rolands’ Macassar Oil—  
Yet twopence-halfpenny is all  
    They give me for my toil.’  
<!-- /EN:LG-08-098 -->

> 老人はおだやかな口調で、話を続けた。  
> 　『私はあちこち出歩いて、  
> 山の小川を見つけると、  
> 　それに火をつけ、燃やすのです。  
> するとそこから、いわゆる  
> 　ローランズのマカッサル油が作られます。  
> でも、二ペンス半しか  
> 　働き賃はもらえません』

> **訳注：** Macassar Oil は髪につける油。原文の Rolands’ という綴りは、英語欄では添付版どおりに保持している。

<a id="LG-08-099"></a>

**LG-08-099**

<!-- EN:LG-08-099 -->
But I was thinking of a way  
    To feed oneself on batter,  
And so go on from day to day  
    Getting a little fatter.  
I shook him well from side to side,  
    Until his face was blue:  
‘Come, tell me how you live,’ I cried,  
    ‘And what it is you do!’  
<!-- /EN:LG-08-099 -->

> けれど私は、ある方法を考えていた。  
> 　溶いた小麦粉を食べて暮らし、  
> そうして毎日毎日、  
> 　少しずつ太っていく方法を。  
> 老人を左右へ激しく揺すぶり、  
> 　顔が真っ青になるまで揺すぶって、  
> 『さあ、どうやって暮らしているのか話しなさい』と叫んだ。  
> 　『それに、何をしているのかを！』

<a id="LG-08-100"></a>

**LG-08-100**

<!-- EN:LG-08-100 -->
He said ‘I hunt for haddocks’ eyes  
    Among the heather bright,  
And work them into waistcoat-buttons  
    In the silent night.  
And these I do not sell for gold  
    Or coin of silvery shine  
But for a copper halfpenny,  
    And that will purchase nine.  
<!-- /EN:LG-08-100 -->

> 老人は言った。『コダラの目を探します、  
> 　鮮やかなヒースのあいだで。  
> それをチョッキのボタンに加工します、  
> 　静まり返った夜に。  
> それらを売るのは金貨でもなく、  
> 　銀に輝く硬貨でもなく、  
> 銅の半ペニー一枚で、  
> 　九個も買えるのですよ。

<a id="LG-08-101"></a>

**LG-08-101**

<!-- EN:LG-08-101 -->
‘I sometimes dig for buttered rolls,  
    Or set limed twigs for crabs;  
I sometimes search the grassy knolls  
    For wheels of Hansom-cabs.  
And that’s the way’ (he gave a wink)  
    ‘By which I get my wealth—  
And very gladly will I drink  
    Your Honour’s noble health.’  
<!-- /EN:LG-08-101 -->

> 『ときにはバター付きロールパンを掘り当て、  
> 　ときにはカニ捕りの鳥もち枝を仕掛けます。  
> ときには草の茂った丘を探します、  
> 　二輪辻馬車の車輪を求めて。  
> そういう方法で』と片目をつぶり、  
> 　『私は財を得ているのです。  
> そして喜んで乾杯いたしましょう、  
> 　旦那様の尊いご健康を祝って』

<a id="LG-08-102"></a>

**LG-08-102**

<!-- EN:LG-08-102 -->
I heard him then, for I had just  
    Completed my design  
To keep the Menai bridge from rust  
    By boiling it in wine.  
I thanked him much for telling me  
    The way he got his wealth,  
But chiefly for his wish that he  
    Might drink my noble health.  
<!-- /EN:LG-08-102 -->

> そのとき私は、老人の話を聞いた。ちょうど、  
> 　考えがまとまったからだ。  
> メナイ橋がさびないように、  
> 　ワインで煮ようという考えが。  
> 老人には厚く礼を言った、教えてくれたことに、  
> 　財を得るその方法を。  
> けれど、何より感謝したのは、  
> 　私の尊い健康に乾杯したいという願いだった。

<a id="LG-08-103"></a>

**LG-08-103**

<!-- EN:LG-08-103 -->
And now, if e’er by chance I put  
    My fingers into glue  
Or madly squeeze a right-hand foot  
    Into a left-hand shoe,  
Or if I drop upon my toe  
    A very heavy weight,  
I weep, for it reminds me so,  
Of that old man I used to know—  
Whose look was mild, whose speech was slow,  
Whose hair was whiter than the snow,  
Whose face was very like a crow,  
With eyes, like cinders, all aglow,  
Who seemed distracted with his woe,  
Who rocked his body to and fro,  
And muttered mumblingly and low,  
As if his mouth were full of dough,  
Who snorted like a buffalo—  
That summer evening, long ago,  
    A-sitting on a gate.”
<!-- /EN:LG-08-103 -->

> それで今も、もしうっかり  
> 　指を糊に突っこんだり、  
> むちゃにも右足を押しこんだりすると、  
> 　左足の靴の中へ、  
> あるいは足の指に落としたりすると、  
> 　とても重いおもりを、  
> 私は泣く。あまりによく思い出させるからだ、  
> 昔、知り合ったあの老人を。  
> おだやかな目つきで、ゆっくり話し、  
> 髪は雪よりも白く、  
> 顔はカラスにそっくりで、  
> 目は燃えさしのように、かっと光り、  
> 悲しみで気もそぞろに見え、  
> 体を前後に揺らし、  
> 低い声でもぐもぐつぶやき、  
> まるで口いっぱいにパン生地を詰め、  
> 水牛のように鼻を鳴らしていた――  
> 遠い昔の、あの夏の夕べ、  
> 　門の上に腰かけて」

<a id="LG-08-104"></a>

**LG-08-104**

<!-- EN:LG-08-104 -->
As the Knight sang the last words of the ballad, he gathered up the reins, and turned his horse’s head along the road by which they had come. “You’ve only a few yards to go,” he said, “down the hill and over that little brook, and then you’ll be a Queen—But you’ll stay and see me off first?” he added as Alice turned with an eager look in the direction to which he pointed. “I shan’t be long. You’ll wait and wave your handkerchief when I get to that turn in the road? I think it’ll encourage me, you see.”
<!-- /EN:LG-08-104 -->

> 歌の最後の言葉を歌いながら、騎士は手綱を取り、来た道へ馬の頭を向けた。「あとほんの数ヤードだよ」と言った。「坂を下りて、あの小川を渡れば、君は女王だ。でも、その前にここで私を見送ってくれるね？」アリスが指された方角へ、わくわくした顔を向けると、騎士は言い添えた。「長くはかからない。私があの曲がり角へ着くまで待って、ハンカチを振ってくれるかい？　きっと励みになると思うんだ」

<a id="LG-08-105"></a>

**LG-08-105**

<!-- EN:LG-08-105 -->
“Of course I’ll wait,” said Alice: “and thank you very much for coming so far—and for the song—I liked it very much.”
<!-- /EN:LG-08-105 -->

> 「もちろん、待っているわ」とアリス。「こんなに遠くまで来てくれて、どうもありがとう。それから歌も。とてもすてきだったわ」

<a id="LG-08-106"></a>

**LG-08-106**

<!-- EN:LG-08-106 -->
“I hope so,” the Knight said doubtfully: “but you didn’t cry so much as I thought you would.”
<!-- /EN:LG-08-106 -->

> 「そうだといいのだが」と騎士は心もとなげに言った。「でも、思っていたほど泣いてくれなかったね」

<a id="LG-08-107"></a>

**LG-08-107**

<!-- EN:LG-08-107 -->
So they shook hands, and then the Knight rode slowly away into the forest. “It won’t take long to see him *off*, I expect,” Alice said to herself, as she stood watching him. “There he goes! Right on his head as usual! However, he gets on again pretty easily—that comes of having so many things hung round the horse—” So she went on talking to herself, as she watched the horse walking leisurely along the road, and the Knight tumbling off, first on one side and then on the other. After the fourth or fifth tumble he reached the turn, and then she waved her handkerchief to him, and waited till he was out of sight.
<!-- /EN:LG-08-107 -->

> 二人は握手を交わし、騎士は馬に乗って、ゆっくり森へ去っていった。「あの人が*落ちる*のを見届けるなら、長くはかからないでしょうね」とアリスは立って見送りながら、独り言を言った。「ほら、落ちた！　いつものように、まっすぐ頭から！　でも、また乗るのはずいぶん簡単そう。馬のまわりに、あんなにたくさん物をぶら下げているおかげね――」そうして独り言を続けながら、馬がゆっくり道を歩いていくのと、騎士が右へ左へ交互に転げ落ちるのを見ていた。四度目か五度目に落ちたあとで、騎士は曲がり角に着いた。そこでアリスはハンカチを振り、姿が見えなくなるまで待った。

> **訳注：** see him off は「彼を見送る」だが、off の強調によって「馬から落ちるのを見る」という読みも重ねられる。

<a id="LG-08-108"></a>

**LG-08-108**

<!-- EN:LG-08-108 -->
“I hope it encouraged him,” she said, as she turned to run down the hill: “and now for the last brook, and to be a Queen! How grand it sounds!” A very few steps brought her to the edge of the brook. “The Eighth Square at last!” she cried as she bounded across,
<!-- /EN:LG-08-108 -->

> 「励みになったならいいのだけれど」とアリスは言い、向きを変えて坂を駆け下りた。「さあ、最後の小川を渡って、女王になるのよ！　なんて立派な響きでしょう！」ほんの数歩で小川の縁に着いた。「とうとう八番目の升目だわ！」そう叫んで、アリスは向こう岸へ跳んだ。

<a id="LG-08-109"></a>

<!-- EN:LG-08-109 -->
\*      \*      \*      \*      \*      \*      \*  
<!-- /EN:LG-08-109 -->

<a id="LG-08-110"></a>

<!-- EN:LG-08-110 -->
    \*      \*      \*      \*      \*      \*  
<!-- /EN:LG-08-110 -->

<a id="LG-08-111"></a>

<!-- EN:LG-08-111 -->
\*      \*      \*      \*      \*      \*      \*
<!-- /EN:LG-08-111 -->

<a id="LG-08-112"></a>

**LG-08-112**

<!-- EN:LG-08-112 -->
and threw herself down to rest on a lawn as soft as moss, with little flower-beds dotted about it here and there. “Oh, how glad I am to get here! And what *is* this on my head?” she exclaimed in a tone of dismay, as she put her hands up to something very heavy, and fitted tight all round her head.
<!-- /EN:LG-08-112 -->

> そして、苔のように柔らかい芝生に、休もうと身を投げ出した。あたりには小さな花壇が、ところどころに点々とあった。「ああ、ここへ来られて、なんてうれしいの！　それに、頭の上のこれは*何*？」そう叫ぶ声には、うろたえた響きがあった。頭のまわりにぴったりはまった、とても重い何かに、手が触れたのだ。

<a id="LG-08-113"></a>

**LG-08-113**

<!-- EN:LG-08-113 -->
“But how *can* it have got there without my knowing it?” she said to herself, as she lifted it off, and set it on her lap to make out what it could possibly be.
<!-- /EN:LG-08-113 -->

> 「でも、わたしが気づかないうちに、どうしてこんな物が載ったのかしら？」と独り言を言いながら、それを外して膝に置き、いったい何なのか確かめようとした。

<a id="LG-08-114"></a>

**LG-08-114**

<!-- EN:LG-08-114 -->
It was a golden crown.
<!-- /EN:LG-08-114 -->

> それは金の王冠だった。

[章目次へ戻る](#book-top)

---

<a id="lg-chapter-09"></a>

## 第9章　アリス女王

### CHAPTER IX. Queen Alice

<a id="LG-09-001"></a>

**LG-09-001**

<!-- EN:LG-09-001 -->
“Well, this *is* grand!” said Alice. “I never expected I should be a Queen so soon—and I’ll tell you what it is, your majesty,” she went on in a severe tone (she was always rather fond of scolding herself), “it’ll never do for you to be lolling about on the grass like that! Queens have to be dignified, you know!”
<!-- /EN:LG-09-001 -->

> 「まあ、*ほんとうに*すばらしいわ！」とアリスは言った。「こんなに早く女王になれるなんて、思ってもみなかった。それから、よろしいですか、陛下」と、今度は厳しい口調で続けた（アリスはもともと、自分を叱るのがわりに好きだった）。「そんなふうに草の上でごろごろしていてはいけません！　女王には威厳が必要なのですから！」

<a id="LG-09-002"></a>

**LG-09-002**

<!-- EN:LG-09-002 -->
So she got up and walked about—rather stiffly just at first, as she was afraid that the crown might come off: but she comforted herself with the thought that there was nobody to see her, “and if I really am a Queen,” she said as she sat down again, “I shall be able to manage it quite well in time.”
<!-- /EN:LG-09-002 -->

> そこで立ち上がって、あたりを歩き回った。王冠が落ちるのが心配で、はじめのうちは少しぎこちなかったけれど、見ている人はだれもいないと思って、自分を慰めた。「それに、ほんとうに女王になったのなら」と、また腰を下ろしながら言った。「そのうち、ちゃんとできるようになるわ」

<a id="LG-09-003"></a>

**LG-09-003**

<!-- EN:LG-09-003 -->
Everything was happening so oddly that she didn’t feel a bit surprised at finding the Red Queen and the White Queen sitting close to her, one on each side: she would have liked very much to ask them how they came there, but she feared it would not be quite civil. However, there would be no harm, she thought, in asking if the game was over. “Please, would you tell me—” she began, looking timidly at the Red Queen.
<!-- /EN:LG-09-003 -->

> 何もかも、あまりにおかしなことばかり起きていたので、すぐそばの左右に赤の女王と白の女王が一人ずつ座っているのを見ても、アリスは少しも驚かなかった。どうやってそこへ来たのか、ぜひ聞きたかったけれど、あまり礼儀正しくないかもしれないと思った。ただ、勝負が終わったのかを尋ねるくらいなら、構わないだろう。「あの、教えていただけますか……」と、おずおず赤の女王を見て、話し始めた。

<a id="LG-09-004"></a>

**LG-09-004**

<!-- EN:LG-09-004 -->
“Speak when you’re spoken to!” The Queen sharply interrupted her.
<!-- /EN:LG-09-004 -->

> 「話しかけられたら、お話しなさい！」女王は鋭い声で遮った。

<a id="LG-09-005"></a>

**LG-09-005**

<!-- EN:LG-09-005 -->
“But if everybody obeyed that rule,” said Alice, who was always ready for a little argument, “and if you only spoke when you were spoken to, and the other person always waited for *you* to begin, you see nobody would ever say anything, so that—”
<!-- /EN:LG-09-005 -->

> 「でも、みんながその規則を守ったら」と、ちょっとした議論ならいつでも大歓迎のアリスは言った。「話しかけられるまで自分はしゃべらなくて、相手もいつも*こちらが*先に話すのを待っていたら、だれも何も言わなくなってしまうでしょう。だから……」

<a id="LG-09-006"></a>

**LG-09-006**

<!-- EN:LG-09-006 -->
“Ridiculous!” cried the Queen. “Why, don’t you see, child—” here she broke off with a frown, and, after thinking for a minute, suddenly changed the subject of the conversation. “What do you mean by ‘If you really are a Queen’? What right have you to call yourself so? You can’t be a Queen, you know, till you’ve passed the proper examination. And the sooner we begin it, the better.”
<!-- /EN:LG-09-006 -->

> 「ばかばかしい！」と女王は叫んだ。「いいこと、あなた、分からないの……」そこで眉をひそめて口をつぐみ、一分ほど考えてから、突然話題を変えた。「『ほんとうに女王になったのなら』とは、どういう意味です？　どんな権利があって、自分を女王と呼ぶのです？　しかるべき試験に合格するまでは、女王にはなれないのですよ。そして、試験は早く始めるほどよいのです」

<a id="LG-09-007"></a>

**LG-09-007**

<!-- EN:LG-09-007 -->
“I only said ‘if’!” poor Alice pleaded in a piteous tone.
<!-- /EN:LG-09-007 -->

> 「『もし』って言っただけだもの！」気の毒なアリスは、哀れっぽい声で訴えた。

<a id="LG-09-008"></a>

**LG-09-008**

<!-- EN:LG-09-008 -->
The two Queens looked at each other, and the Red Queen remarked, with a little shudder, “She *says* she only said ‘if’—”
<!-- /EN:LG-09-008 -->

> 二人の女王は顔を見合わせた。赤の女王は、かすかに身震いして言った。「『もし』としか言わなかったと、この子は*言っています*よ……」

<a id="LG-09-009"></a>

**LG-09-009**

<!-- EN:LG-09-009 -->
“But she said a great deal more than that!” the White Queen moaned, wringing her hands. “Oh, ever so much more than that!”
<!-- /EN:LG-09-009 -->

> 「でも、それよりずっとたくさん言ったわ！」白の女王は両手をもみ合わせてうめいた。「ああ、ずうっと、ずうっとたくさん！」

<a id="LG-09-010"></a>

**LG-09-010**

<!-- EN:LG-09-010 -->
“So you did, you know,” the Red Queen said to Alice. “Always speak the truth—think before you speak—and write it down afterwards.”
<!-- /EN:LG-09-010 -->

> 「実際、そうでしょう」と赤の女王はアリスに言った。「いつも本当のことをお言いなさい。話す前に考えて、あとで書き留めるのです」

<a id="LG-09-011"></a>

**LG-09-011**

<!-- EN:LG-09-011 -->
“I’m sure I didn’t mean—” Alice was beginning, but the Red Queen interrupted her impatiently.
<!-- /EN:LG-09-011 -->

> 「わたし、そんな意味で言ったのでは……」アリスは言いかけたが、赤の女王がいらだって遮った。

<a id="LG-09-012"></a>

**LG-09-012**

<!-- EN:LG-09-012 -->
“That’s just what I complain of! You *should* have meant! What do you suppose is the use of child without any meaning? Even a joke should have some meaning—and a child’s more important than a joke, I hope. You couldn’t deny that, even if you tried with both hands.”
<!-- /EN:LG-09-012 -->

> 「私が問題にしているのは、まさにそれです！　意味を持って言う*べき*でした！　何の意味もない子供が、何の役に立つと思うのです？　冗談にさえ、何か意味があるべきです。それに、子供は冗談より大事でしょうよ。両手を使って否定しようとしても、否定できませんね」

> **訳注：** I didn’t mean …（そういうつもりでは）という未完の言葉を、女王は「意味することがなかった」と取り、子供そのものに意味がないという話へずらす。

<a id="LG-09-013"></a>

**LG-09-013**

<!-- EN:LG-09-013 -->
“I don’t deny things with my *hands*,” Alice objected.
<!-- /EN:LG-09-013 -->

> 「わたし、*手で*否定なんてしないわ」とアリスは反論した。

<a id="LG-09-014"></a>

**LG-09-014**

<!-- EN:LG-09-014 -->
“Nobody said you did,” said the Red Queen. “I said you couldn’t if you tried.”
<!-- /EN:LG-09-014 -->

> 「しているとは、だれも言っていません」と赤の女王。「やってみてもできないと言ったのです」

<a id="LG-09-015"></a>

**LG-09-015**

<!-- EN:LG-09-015 -->
“She’s in that state of mind,” said the White Queen, “that she wants to deny *something*—only she doesn’t know what to deny!”
<!-- /EN:LG-09-015 -->

> 「この子は、*何かを*否定したくなる気分なのですよ」と白の女王。「ただ、何を否定すればよいか、自分でも分からないの！」

<a id="LG-09-016"></a>

**LG-09-016**

<!-- EN:LG-09-016 -->
“A nasty, vicious temper,” the Red Queen remarked; and then there was an uncomfortable silence for a minute or two.
<!-- /EN:LG-09-016 -->

> 「意地が悪くて、たちの悪い気性ですこと」と赤の女王。それから一、二分、気まずい沈黙が続いた。

<a id="LG-09-017"></a>

**LG-09-017**

<!-- EN:LG-09-017 -->
The Red Queen broke the silence by saying to the White Queen, “I invite you to Alice’s dinner-party this afternoon.”
<!-- /EN:LG-09-017 -->

> 沈黙を破ったのは赤の女王で、白の女王にこう言った。「今日の午後の、アリスの晩餐会にあなたをご招待します」

<a id="LG-09-018"></a>

**LG-09-018**

<!-- EN:LG-09-018 -->
The White Queen smiled feebly, and said “And I invite *you*.”
<!-- /EN:LG-09-018 -->

> 白の女王は弱々しくほほえんで、「では、私も*あなたを*ご招待します」と言った。

<a id="LG-09-019"></a>

**LG-09-019**

<!-- EN:LG-09-019 -->
“I didn’t know I was to have a party at all,” said Alice; “but if there is to be one, I think *I* ought to invite the guests.”
<!-- /EN:LG-09-019 -->

> 「晩餐会を開くなんて、まるで知らなかったわ」とアリス。「でも、開くのなら、お客様をご招待するのは*わたし*のはずよ」

<a id="LG-09-020"></a>

**LG-09-020**

<!-- EN:LG-09-020 -->
“We gave you the opportunity of doing it,” the Red Queen remarked: “but I daresay you’ve not had many lessons in manners yet?”
<!-- /EN:LG-09-020 -->

> 「そうする機会は差し上げました」と赤の女王。「でも、まだお行儀の授業を、あまり受けていないのでしょうね？」

<a id="LG-09-021"></a>

**LG-09-021**

<!-- EN:LG-09-021 -->
“Manners are not taught in lessons,” said Alice. “Lessons teach you to do sums, and things of that sort.”
<!-- /EN:LG-09-021 -->

> 「お行儀は、授業で習うものじゃないわ」とアリス。「授業で習うのは、計算とか、そういうことよ」

<a id="LG-09-022"></a>

**LG-09-022**

<!-- EN:LG-09-022 -->
“And you do Addition?” the White Queen asked. “What’s one and one and one and one and one and one and one and one and one and one?”
<!-- /EN:LG-09-022 -->

> 「では、足し算はできるの？」白の女王が尋ねた。「一と一と一と一と一と一と一と一と一と一では？」

<a id="LG-09-023"></a>

**LG-09-023**

<!-- EN:LG-09-023 -->
“I don’t know,” said Alice. “I lost count.”
<!-- /EN:LG-09-023 -->

> 「分からないわ」とアリス。「途中で数が分からなくなっちゃった」

<a id="LG-09-024"></a>

**LG-09-024**

<!-- EN:LG-09-024 -->
“She can’t do Addition,” the Red Queen interrupted. “Can you do Subtraction? Take nine from eight.”
<!-- /EN:LG-09-024 -->

> 「足し算はできませんね」と赤の女王が口を挟んだ。「引き算はできますか？　八から九を引いてごらんなさい」

<a id="LG-09-025"></a>

**LG-09-025**

<!-- EN:LG-09-025 -->
“Nine from eight I can’t, you know,” Alice replied very readily: “but—”
<!-- /EN:LG-09-025 -->

> 「八から九は引けないわ」とアリスはすぐに答えた。「でも……」

<a id="LG-09-026"></a>

**LG-09-026**

<!-- EN:LG-09-026 -->
“She can’t do Subtraction,” said the White Queen. “Can you do Division? Divide a loaf by a knife—what’s the answer to that?”
<!-- /EN:LG-09-026 -->

> 「引き算はできませんね」と白の女王。「割り算はできますか？　パン一斤をナイフで割ると、答えは何？」

<a id="LG-09-027"></a>

**LG-09-027**

<!-- EN:LG-09-027 -->
“I suppose—” Alice was beginning, but the Red Queen answered for her. “Bread-and-butter, of course. Try another Subtraction sum. Take a bone from a dog: what remains?”
<!-- /EN:LG-09-027 -->

> 「たぶん……」アリスが言いかけると、赤の女王が代わりに答えた。「もちろん、バター付きパンです。別の引き算をしてごらんなさい。犬から骨を取り去ったら、何が残ります？」

<a id="LG-09-028"></a>

**LG-09-028**

<!-- EN:LG-09-028 -->
Alice considered. “The bone wouldn’t remain, of course, if I took it—and the dog wouldn’t remain; it would come to bite me—and I’m sure *I* shouldn’t remain!”
<!-- /EN:LG-09-028 -->

> アリスは考えた。「わたしが取るのだから、もちろん骨は残らないわ。犬も残らない。わたしにかみつこうと、こっちへ来るもの。それに、*わたし*だって絶対に残らないわ！」

<a id="LG-09-029"></a>

**LG-09-029**

<!-- EN:LG-09-029 -->
“Then you think nothing would remain?” said the Red Queen.
<!-- /EN:LG-09-029 -->

> 「では、何も残らないと思うのですね？」と赤の女王。

<a id="LG-09-030"></a>

**LG-09-030**

<!-- EN:LG-09-030 -->
“I think that’s the answer.”
<!-- /EN:LG-09-030 -->

> 「それが答えだと思うわ」

<a id="LG-09-031"></a>

**LG-09-031**

<!-- EN:LG-09-031 -->
“Wrong, as usual,” said the Red Queen: “the dog’s temper would remain.”
<!-- /EN:LG-09-031 -->

> 「いつものように、間違いです」と赤の女王。「犬の落ち着きが残ります」

<a id="LG-09-032"></a>

**LG-09-032**

<!-- EN:LG-09-032 -->
“But I don’t see how—”
<!-- /EN:LG-09-032 -->

> 「でも、どうしてそうなるのか……」

<a id="LG-09-033"></a>

**LG-09-033**

<!-- EN:LG-09-033 -->
“Why, look here!” the Red Queen cried. “The dog would lose its temper, wouldn’t it?”
<!-- /EN:LG-09-033 -->

> 「よくお聞きなさい！」赤の女王は叫んだ。「犬はかんしゃくを起こして、落ち着きをなくすでしょう？」

<a id="LG-09-034"></a>

**LG-09-034**

<!-- EN:LG-09-034 -->
“Perhaps it would,” Alice replied cautiously.
<!-- /EN:LG-09-034 -->

> 「そうなるかもしれないわ」とアリスは用心深く答えた。

<a id="LG-09-035"></a>

**LG-09-035**

<!-- EN:LG-09-035 -->
“Then if the dog went away, its temper would remain!” the Queen exclaimed triumphantly.
<!-- /EN:LG-09-035 -->

> 「だったら、犬がどこかへ行けば、なくした落ち着きは残るでしょう！」女王は勝ち誇って言った。

> **訳注：** lose its temper は「かっとなる」。女王は lose を物をなくす意味にして、犬から離れた temper がその場に残ると主張する。

<a id="LG-09-036"></a>

**LG-09-036**

<!-- EN:LG-09-036 -->
Alice said, as gravely as she could, “They might go different ways.” But she couldn’t help thinking to herself, “What dreadful nonsense we *are* talking!”
<!-- /EN:LG-09-036 -->

> アリスはできるだけまじめな顔で、「別々の方向へ行くかもしれないわ」と言った。でも心の中では、こう思わずにはいられなかった。「わたしたち、*なんて*ひどいでたらめを話しているんでしょう！」

<a id="LG-09-037"></a>

**LG-09-037**

<!-- EN:LG-09-037 -->
“She can’t do sums a *bit*!” the Queens said together, with great emphasis.
<!-- /EN:LG-09-037 -->

> 「この子、計算が*まるで*できないわ！」二人の女王は声をそろえ、力をこめて言った。

<a id="LG-09-038"></a>

**LG-09-038**

<!-- EN:LG-09-038 -->
“Can *you* do sums?” Alice said, turning suddenly on the White Queen, for she didn’t like being found fault with so much.
<!-- /EN:LG-09-038 -->

> 「*あなたは*計算できるの？」アリスは急に白の女王へ向き直って言った。あまりにあれこれ欠点を言い立てられるのが、いやになったのだ。

<a id="LG-09-039"></a>

**LG-09-039**

<!-- EN:LG-09-039 -->
The Queen gasped and shut her eyes. “I can do Addition, if you give me time—but I can’t do Subtraction, under *any* circumstances!”
<!-- /EN:LG-09-039 -->

> 女王は息をのみ、目を閉じた。「時間をいただければ、足し算はできます。でも引き算は、*どんな*場合でもできません！」

<a id="LG-09-040"></a>

**LG-09-040**

<!-- EN:LG-09-040 -->
“Of course you know your A B C?” said the Red Queen.
<!-- /EN:LG-09-040 -->

> 「もちろん、ABCは知っていますね？」と赤の女王。

<a id="LG-09-041"></a>

**LG-09-041**

<!-- EN:LG-09-041 -->
“To be sure I do.” said Alice.
<!-- /EN:LG-09-041 -->

> 「もちろん知っているわ」とアリス。

<a id="LG-09-042"></a>

**LG-09-042**

<!-- EN:LG-09-042 -->
“So do I,” the White Queen whispered: “we’ll often say it over together, dear. And I’ll tell you a secret—I can read words of one letter! Isn’t *that* grand! However, don’t be discouraged. You’ll come to it in time.”
<!-- /EN:LG-09-042 -->

> 「私もよ」と白の女王はささやいた。「これから、よく一緒に唱えましょうね。それから、秘密を教えてあげる。一文字の単語なら読めるの！　*すばらしい*でしょう！　でも、がっかりしないでね。あなたも、そのうちできるようになるわ」

<a id="LG-09-043"></a>

**LG-09-043**

<!-- EN:LG-09-043 -->
Here the Red Queen began again. “Can you answer useful questions?” she said. “How is bread made?”
<!-- /EN:LG-09-043 -->

> そこで赤の女王が、また質問を始めた。「役に立つ質問には答えられますか？」と言った。「パンは、どうやって作るのです？」

<a id="LG-09-044"></a>

**LG-09-044**

<!-- EN:LG-09-044 -->
“I know *that*!” Alice cried eagerly. “You take some flour—”
<!-- /EN:LG-09-044 -->

> 「*それなら*知っているわ！」アリスは勢いこんで叫んだ。「小麦粉を用意して……」

<a id="LG-09-045"></a>

**LG-09-045**

<!-- EN:LG-09-045 -->
“Where do you pick the flower?” the White Queen asked. “In a garden, or in the hedges?”
<!-- /EN:LG-09-045 -->

> 「お花は、どこで摘むの？」白の女王が尋ねた。「お庭、それとも生け垣？」

> **訳注：** flour（小麦粉）と flower（花）は同音。女王は前者を後者として聞き取る。

<a id="LG-09-046"></a>

**LG-09-046**

<!-- EN:LG-09-046 -->
“Well, it isn’t *picked* at all,” Alice explained: “it’s *ground*—”
<!-- /EN:LG-09-046 -->

> 「ええと、*摘む*ものじゃないの」とアリスは説明した。「*ひいて*作るのよ……」

<a id="LG-09-047"></a>

**LG-09-047**

<!-- EN:LG-09-047 -->
“How many acres of ground?” said the White Queen. “You mustn’t leave out so many things.”
<!-- /EN:LG-09-047 -->

> 「土地が何エーカー？」と白の女王。「そんなにいろいろ省いてはいけません」

> **訳注：** ground は grind（ひく）の過去分詞である一方、「地面・土地」という名詞でもある。女王は後者の意味に取り替える。

<a id="LG-09-048"></a>

**LG-09-048**

<!-- EN:LG-09-048 -->
“Fan her head!” the Red Queen anxiously interrupted. “She’ll be feverish after so much thinking.” So they set to work and fanned her with bunches of leaves, till she had to beg them to leave off, it blew her hair about so.
<!-- /EN:LG-09-048 -->

> 「頭をあおいであげて！」赤の女王が心配そうに遮った。「これだけ考えたら、熱が出てしまいます」そこで二人は葉を束にして、アリスをあおぎ始めた。髪があまりに吹き乱されるので、とうとうアリスは、やめてくださいと頼まなければならなかった。

<a id="LG-09-049"></a>

**LG-09-049**

<!-- EN:LG-09-049 -->
“She’s all right again now,” said the Red Queen. “Do you know Languages? What’s the French for fiddle-de-dee?”
<!-- /EN:LG-09-049 -->

> 「もう大丈夫ですね」と赤の女王。「外国語はできますか？　『フィドル・ディー・ディー』はフランス語で何と言います？」

<a id="LG-09-050"></a>

**LG-09-050**

<!-- EN:LG-09-050 -->
“Fiddle-de-dee’s not English,” Alice replied gravely.
<!-- /EN:LG-09-050 -->

> 「フィドル・ディー・ディーは英語じゃないわ」とアリスはまじめに答えた。

> **訳注：** fiddle-de-dee は「くだらない、ばかばかしい」といった気持ちを示す言い方。ここではアリス自身が「英語ではない」と述べている。

<a id="LG-09-051"></a>

**LG-09-051**

<!-- EN:LG-09-051 -->
“Who ever said it was?” said the Red Queen.
<!-- /EN:LG-09-051 -->

> 「英語だと、いったいだれが言いました？」と赤の女王。

<a id="LG-09-052"></a>

**LG-09-052**

<!-- EN:LG-09-052 -->
Alice thought she saw a way out of the difficulty this time. “If you’ll tell me what language ‘fiddle-de-dee’ is, I’ll tell you the French for it!” she exclaimed triumphantly.
<!-- /EN:LG-09-052 -->

> 今度は困った状況から抜け出す道が見つかった、とアリスは思った。「『フィドル・ディー・ディー』が何語か教えてくれたら、フランス語をお教えするわ！」勝ち誇って言った。

<a id="LG-09-053"></a>

**LG-09-053**

<!-- EN:LG-09-053 -->
But the Red Queen drew herself up rather stiffly, and said “Queens never make bargains.”
<!-- /EN:LG-09-053 -->

> けれど赤の女王は、いくらか堅苦しく背筋を伸ばし、「女王は取引をしません」と言った。

<a id="LG-09-054"></a>

**LG-09-054**

<!-- EN:LG-09-054 -->
“I wish Queens never asked questions,” Alice thought to herself.
<!-- /EN:LG-09-054 -->

> 「女王は質問をしない、だったらよかったのに」とアリスは心の中で思った。

<a id="LG-09-055"></a>

**LG-09-055**

<!-- EN:LG-09-055 -->
“Don’t let us quarrel,” the White Queen said in an anxious tone. “What is the cause of lightning?”
<!-- /EN:LG-09-055 -->

> 「けんかはやめましょう」と白の女王は心配そうに言った。「稲妻の原因は何ですか？」

<a id="LG-09-056"></a>

**LG-09-056**

<!-- EN:LG-09-056 -->
“The cause of lightning,” Alice said very decidedly, for she felt quite certain about this, “is the thunder—no, no!” she hastily corrected herself. “I meant the other way.”
<!-- /EN:LG-09-056 -->

> 「稲妻の原因は」とアリスはきっぱり言った。これにはすっかり自信があった。「雷の音よ――いえ、違うわ！」あわてて言い直した。「逆のことを言うつもりだったの」

<a id="LG-09-057"></a>

**LG-09-057**

<!-- EN:LG-09-057 -->
“It’s too late to correct it,” said the Red Queen: “when you’ve once said a thing, that fixes it, and you must take the consequences.”
<!-- /EN:LG-09-057 -->

> 「訂正するには遅すぎます」と赤の女王。「一度言ってしまったら、それで確定です。結果は自分で引き受けなければなりません」

<a id="LG-09-058"></a>

**LG-09-058**

<!-- EN:LG-09-058 -->
“Which reminds me—” the White Queen said, looking down and nervously clasping and unclasping her hands, “we had *such* a thunderstorm last Tuesday—I mean one of the last set of Tuesdays, you know.”
<!-- /EN:LG-09-058 -->

> 「それで思い出しましたけれど」と白の女王は、下を向き、不安げに両手を握ったり開いたりしながら言った。「この前の火曜日は、*それはそれは*ひどい雷雨でした。つまり、この前の一組の火曜日の、そのうちの一つということですけれど」

<a id="LG-09-059"></a>

**LG-09-059**

<!-- EN:LG-09-059 -->
Alice was puzzled. “In *our* country,” she remarked, “there’s only one day at a time.”
<!-- /EN:LG-09-059 -->

> アリスは戸惑った。「*わたしたちの*国では」と言った。「日は、一度に一日しか来ないわ」

<a id="LG-09-060"></a>

**LG-09-060**

<!-- EN:LG-09-060 -->
The Red Queen said, “That’s a poor thin way of doing things. Now *here*, we mostly have days and nights two or three at a time, and sometimes in the winter we take as many as five nights together—for warmth, you know.”
<!-- /EN:LG-09-060 -->

> 赤の女王は言った。「ずいぶん貧弱で薄っぺらなやり方ですね。*ここ*ではたいてい、昼も夜も二つか三つまとめて来ます。冬には、ときどき五晩いっぺんに取ることさえありますよ。暖かくするためにね」

<a id="LG-09-061"></a>

**LG-09-061**

<!-- EN:LG-09-061 -->
“Are five nights warmer than one night, then?” Alice ventured to ask.
<!-- /EN:LG-09-061 -->

> 「じゃあ、五晩は一晩より暖かいの？」アリスは思いきって尋ねた。

<a id="LG-09-062"></a>

**LG-09-062**

<!-- EN:LG-09-062 -->
“Five times as warm, of course.”
<!-- /EN:LG-09-062 -->

> 「もちろん、五倍暖かいのです」

<a id="LG-09-063"></a>

**LG-09-063**

<!-- EN:LG-09-063 -->
“But they should be five times as *cold*, by the same rule—”
<!-- /EN:LG-09-063 -->

> 「でも、同じ理屈なら、五倍*寒く*なるはずでしょう……」

<a id="LG-09-064"></a>

**LG-09-064**

<!-- EN:LG-09-064 -->
“Just so!” cried the Red Queen. “Five times as warm, *and* five times as cold—just as I’m five times as rich as you are, *and* five times as clever!”
<!-- /EN:LG-09-064 -->

> 「そのとおり！」赤の女王は叫んだ。「五倍暖かく、*しかも*五倍寒いのです。私があなたの五倍お金持ちで、*しかも*五倍賢いのと同じこと！」

<a id="LG-09-065"></a>

**LG-09-065**

<!-- EN:LG-09-065 -->
Alice sighed and gave it up. “It’s exactly like a riddle with no answer!” she thought.
<!-- /EN:LG-09-065 -->

> アリスはため息をついて、諦めた。「答えのないなぞなぞと、そっくりだわ！」と思った。

<a id="LG-09-066"></a>

**LG-09-066**

<!-- EN:LG-09-066 -->
“Humpty Dumpty saw it too,” the White Queen went on in a low voice, more as if she were talking to herself. “He came to the door with a corkscrew in his hand—”
<!-- /EN:LG-09-066 -->

> 「ハンプティ・ダンプティも見たのですよ」と白の女王は低い声で続けた。むしろ独り言のようだった。「コルク抜きを手に持って、戸口へ来ましてね……」

<a id="LG-09-067"></a>

**LG-09-067**

<!-- EN:LG-09-067 -->
“What did he want?” said the Red Queen.
<!-- /EN:LG-09-067 -->

> 「何の用だったのです？」と赤の女王。

<a id="LG-09-068"></a>

**LG-09-068**

<!-- EN:LG-09-068 -->
“He said he *would* come in,” the White Queen went on, “because he was looking for a hippopotamus. Now, as it happened, there wasn’t such a thing in the house, that morning.”
<!-- /EN:LG-09-068 -->

> 「どうしても中へ*入る*と言いました」と白の女王は続けた。「カバを探していたからです。でも、たまたま、その朝は家の中にそんな物はいなかったのです」

<a id="LG-09-069"></a>

**LG-09-069**

<!-- EN:LG-09-069 -->
“Is there generally?” Alice asked in an astonished tone.
<!-- /EN:LG-09-069 -->

> 「普段はいるの？」アリスはびっくりして尋ねた。

<a id="LG-09-070"></a>

**LG-09-070**

<!-- EN:LG-09-070 -->
“Well, only on Thursdays,” said the Queen.
<!-- /EN:LG-09-070 -->

> 「ええ、木曜日だけですけれど」と女王。

<a id="LG-09-071"></a>

**LG-09-071**

<!-- EN:LG-09-071 -->
“I know what he came for,” said Alice: “he wanted to punish the fish, because—”
<!-- /EN:LG-09-071 -->

> 「何をしに来たのか、わたし、分かるわ」とアリス。「魚たちを罰したかったのよ。だって……」

<a id="LG-09-072"></a>

**LG-09-072**

<!-- EN:LG-09-072 -->
Here the White Queen began again. “It was *such* a thunderstorm, you can’t think!” (“She *never* could, you know,” said the Red Queen.) “And part of the roof came off, and ever so much thunder got in—and it went rolling round the room in great lumps—and knocking over the tables and things—till I was so frightened, I couldn’t remember my own name!”
<!-- /EN:LG-09-072 -->

> そこで白の女王がまた話し始めた。「それは*ものすごい*雷雨で、あなたには想像もできませんよ！」（「この子には*いつだって*できません」と赤の女王が言った。）「屋根の一部が飛んでしまって、雷がたくさん入りこんだのです。それが大きな塊になって部屋じゅう転がり回り、テーブルや何やらをひっくり返して、とうとう私はすっかり怖くなって、自分の名前さえ思い出せなくなりました！」

<a id="LG-09-073"></a>

**LG-09-073**

<!-- EN:LG-09-073 -->
Alice thought to herself, “I never should *try* to remember my name in the middle of an accident! Where would be the use of it?” but she did not say this aloud, for fear of hurting the poor Queen’s feeling.
<!-- /EN:LG-09-073 -->

> アリスは心の中で思った。「事故の真っ最中に、自分の名前を思い出そうなんて*しない*わ！　何の役に立つというの？」けれど、気の毒な女王の気持ちを傷つけそうだったので、声には出さなかった。

<a id="LG-09-074"></a>

**LG-09-074**

<!-- EN:LG-09-074 -->
“Your Majesty must excuse her,” the Red Queen said to Alice, taking one of the White Queen’s hands in her own, and gently stroking it: “she means well, but she can’t help saying foolish things, as a general rule.”
<!-- /EN:LG-09-074 -->

> 「陛下、この方をお許しください」と赤の女王はアリスに言い、白の女王の片手を取って、やさしくなでた。「悪気はないのですが、概して、愚かなことを言わずにはいられないのです」

<a id="LG-09-075"></a>

**LG-09-075**

<!-- EN:LG-09-075 -->
The White Queen looked timidly at Alice, who felt she *ought* to say something kind, but really couldn’t think of anything at the moment.
<!-- /EN:LG-09-075 -->

> 白の女王はおずおずとアリスを見た。アリスは何かやさしいことを言わなければ*いけない*と思ったが、そのときはどうしても思いつかなかった。

<a id="LG-09-076"></a>

**LG-09-076**

<!-- EN:LG-09-076 -->
“She never was really well brought up,” the Red Queen went on: “but it’s amazing how good-tempered she is! Pat her on the head, and see how pleased she’ll be!” But this was more than Alice had courage to do.
<!-- /EN:LG-09-076 -->

> 「この方は、きちんとしつけられたことがないのです」と赤の女王は続けた。「でも、驚くほど気立てがいいのですよ！　頭をなでてごらんなさい。どれほど喜ぶか分かりますから！」けれど、アリスにはそこまでする勇気はなかった。

<a id="LG-09-077"></a>

**LG-09-077**

<!-- EN:LG-09-077 -->
“A little kindness—and putting her hair in papers—would do wonders with her—”
<!-- /EN:LG-09-077 -->

> 「少し親切にして、髪を紙で巻いてあげるだけで、この方は見違えるようになるでしょうに……」

> **訳注：** putting her hair in papers は、細い紙片を使って髪を巻き、巻き毛にすること。

<a id="LG-09-078"></a>

**LG-09-078**

<!-- EN:LG-09-078 -->
The White Queen gave a deep sigh, and laid her head on Alice’s shoulder. “I *am* so sleepy!” she moaned.
<!-- /EN:LG-09-078 -->

> 白の女王は深いため息をつき、アリスの肩に頭をもたせた。「*ほんとうに*眠いの！」とうめいた。

<a id="LG-09-079"></a>

**LG-09-079**

<!-- EN:LG-09-079 -->
“She’s tired, poor thing!” said the Red Queen. “Smooth her hair—lend her your nightcap—and sing her a soothing lullaby.”
<!-- /EN:LG-09-079 -->

> 「疲れているのですね、かわいそうに！」と赤の女王。「髪をなでつけて、寝るときの帽子を貸して、やさしい子守歌を歌ってあげなさい」

<a id="LG-09-080"></a>

**LG-09-080**

<!-- EN:LG-09-080 -->
“I haven’t got a nightcap with me,” said Alice, as she tried to obey the first direction: “and I don’t know any soothing lullabies.”
<!-- /EN:LG-09-080 -->

> 「寝るときの帽子は持っていないわ」とアリスは、最初の指図に従おうとしながら言った。「それに、やさしい子守歌なんて知らないもの」

<a id="LG-09-081"></a>

**LG-09-081**

<!-- EN:LG-09-081 -->
“I must do it myself, then,” said the Red Queen, and she began:
<!-- /EN:LG-09-081 -->

> 「では、私がしなければなりませんね」と赤の女王は言い、歌い始めた。

<a id="LG-09-082"></a>

**LG-09-082**

<!-- EN:LG-09-082 -->
“Hush-a-by lady, in Alice’s lap!  
Till the feast’s ready, we’ve time for a nap:  
When the feast’s over, we’ll go to the ball—  
Red Queen, and White Queen, and Alice, and all!
<!-- /EN:LG-09-082 -->

> 「ねんねんころりよ、ご婦人、アリスのお膝で。  
> 宴の支度ができるまで、ひと眠りする暇がある。  
> 宴が済んだら、舞踏会へ出かけましょう――  
> 赤の女王も、白の女王も、アリスも、みんなも！

<a id="LG-09-083"></a>

**LG-09-083**

<!-- EN:LG-09-083 -->
“And now you know the words,” she added, as she put her head down on Alice’s other shoulder, “just sing it through to *me*. I’m getting sleepy, too.” In another moment both Queens were fast asleep, and snoring loud.
<!-- /EN:LG-09-083 -->

> 「これで歌詞が分かりましたね」と言い添えて、アリスのもう片方の肩に頭をもたせた。「今度は*私に*、最後まで歌ってください。私も眠くなってきました」次の瞬間には、二人の女王ともすっかり眠りこみ、大きないびきをかいていた。

<a id="LG-09-084"></a>

**LG-09-084**

<!-- EN:LG-09-084 -->
“What *am* I to do?” exclaimed Alice, looking about in great perplexity, as first one round head, and then the other, rolled down from her shoulder, and lay like a heavy lump in her lap. “I don’t think it *ever* happened before, that any one had to take care of two Queens asleep at once! No, not in all the History of England—it couldn’t, you know, because there never was more than one Queen at a time. Do wake up, you heavy things!” she went on in an impatient tone; but there was no answer but a gentle snoring.
<!-- /EN:LG-09-084 -->

> 「いったい、どうすれば*いいの*？」アリスはひどく途方に暮れて、あたりを見回しながら叫んだ。丸い頭が片方ずつ肩から転げ落ち、重い塊になって膝の上に載った。「眠った女王様を一度に二人もお世話しなければならないなんて、これまでに*一度だって*なかったと思うわ！　ええ、イングランドの歴史をぜんぶ調べたって。あるはずないもの。女王様は一度に一人しかいなかったのだから。お願いだから起きてちょうだい、重いんだもの！」いらいらしてそう続けたが、返事は穏やかないびきだけだった。

<a id="LG-09-085"></a>

**LG-09-085**

<!-- EN:LG-09-085 -->
The snoring got more distinct every minute, and sounded more like a tune: at last she could even make out the words, and she listened so eagerly that, when the two great heads vanished from her lap, she hardly missed them.
<!-- /EN:LG-09-085 -->

> いびきはしだいにはっきり聞こえ、ますます曲のようになっていった。とうとう歌詞まで聞き取れるようになり、アリスは熱心に耳を傾けたので、二つの大きな頭が膝から消えても、ほとんど気づかなかった。

<a id="LG-09-086"></a>

**LG-09-086**

<!-- EN:LG-09-086 -->
She was standing before an arched doorway over which were the words QUEEN ALICE in large letters, and on each side of the arch there was a bell-handle; one was marked “Visitors’ Bell,” and the other “Servants’ Bell.”
<!-- /EN:LG-09-086 -->

> アリスはアーチ形の戸口の前に立っていた。その上には大きな文字で「アリス女王」と書いてあった。アーチの両側には呼び鈴の取っ手があり、一方には「来客用の呼び鈴」、もう一方には「召使い用の呼び鈴」と記してあった。

<a id="LG-09-087"></a>

**LG-09-087**

<!-- EN:LG-09-087 -->
“I’ll wait till the song’s over,” thought Alice, “and then I’ll ring—the—*which* bell must I ring?” she went on, very much puzzled by the names. “I’m not a visitor, and I’m not a servant. There *ought* to be one marked ‘Queen,’ you know—”
<!-- /EN:LG-09-087 -->

> 「歌が終わるまで待ちましょう」とアリスは思った。「それから鈴を……ええと、*どちらの*鈴を鳴らせばいいの？」その呼び名にすっかり困って、考え続けた。「わたしはお客じゃないし、召使いでもないわ。『女王用』というのがあって*いいはず*なのに……」

<a id="LG-09-088"></a>

**LG-09-088**

<!-- EN:LG-09-088 -->
Just then the door opened a little way, and a creature with a long beak put its head out for a moment and said “No admittance till the week after next!” and shut the door again with a bang.
<!-- /EN:LG-09-088 -->

> ちょうどそのとき、扉が少し開いた。長いくちばしの生き物が一瞬だけ顔を出して、「再来週までは立ち入り禁止！」と言い、またばたんと扉を閉めた。

<a id="LG-09-089"></a>

**LG-09-089**

<!-- EN:LG-09-089 -->
Alice knocked and rang in vain for a long time, but at last, a very old Frog, who was sitting under a tree, got up and hobbled slowly towards her: he was dressed in bright yellow, and had enormous boots on.
<!-- /EN:LG-09-089 -->

> アリスは長いことノックをしたり鈴を鳴らしたりしたが、むだだった。ようやく、木の下に座っていたひどく年取ったカエルが立ち上がり、ゆっくり足を引きずるようにして近づいてきた。鮮やかな黄色の服を着て、途方もなく大きな長靴を履いていた。

<a id="LG-09-090"></a>

**LG-09-090**

<!-- EN:LG-09-090 -->
“What is it, now?” the Frog said in a deep hoarse whisper.
<!-- /EN:LG-09-090 -->

> 「さて、何の用だね？」カエルは低くしわがれた、ささやき声で言った。

<a id="LG-09-091"></a>

**LG-09-091**

<!-- EN:LG-09-091 -->
Alice turned round, ready to find fault with anybody. “Where’s the servant whose business it is to answer the door?” she began angrily.
<!-- /EN:LG-09-091 -->

> アリスは振り向いた。もう相手がだれであろうと、文句を言ってやりたい気分だった。「扉の応対をする係の召使いは、どこにいるの？」怒った口調で言い始めた。

<a id="LG-09-092"></a>

**LG-09-092**

<!-- EN:LG-09-092 -->
“Which door?” said the Frog.
<!-- /EN:LG-09-092 -->

> 「どの扉だね？」とカエル。

<a id="LG-09-093"></a>

**LG-09-093**

<!-- EN:LG-09-093 -->
Alice almost stamped with irritation at the slow drawl in which he spoke. “*This* door, of course!”
<!-- /EN:LG-09-093 -->

> のろのろと間延びした話し方に、アリスはいらいらして、足を踏み鳴らしそうになった。「もちろん、*この*扉よ！」

<a id="LG-09-094"></a>

**LG-09-094**

<!-- EN:LG-09-094 -->
The Frog looked at the door with his large dull eyes for a minute: then he went nearer and rubbed it with his thumb, as if he were trying whether the paint would come off; then he looked at Alice.
<!-- /EN:LG-09-094 -->

> カエルは大きなどんよりした目で、しばらく扉を眺めた。それから近寄って、塗料が落ちるか試すように、親指でこすった。そしてアリスを見た。

<a id="LG-09-095"></a>

**LG-09-095**

<!-- EN:LG-09-095 -->
“To answer the door?” he said. “What’s it been asking of?” He was so hoarse that Alice could scarcely hear him.
<!-- /EN:LG-09-095 -->

> 「扉に返事をするだって？」とカエル。「何を尋ねてきたんだね？」声があまりにしわがれていて、アリスにはほとんど聞こえなかった。

> **訳注：** answer the door は訪問者を迎えに出ること。カエルは answer を「質問に答える」と解釈し、扉そのものが質問したと考える。

<a id="LG-09-096"></a>

**LG-09-096**

<!-- EN:LG-09-096 -->
“I don’t know what you mean,” she said.
<!-- /EN:LG-09-096 -->

> 「何を言っているのか、分からないわ」とアリス。

<a id="LG-09-097"></a>

**LG-09-097**

<!-- EN:LG-09-097 -->
“I talks English, doesn’t I?” the Frog went on. “Or are you deaf? What did it ask you?”
<!-- /EN:LG-09-097 -->

> 「英語でしゃべっとるじゃろが？」とカエルは続けた。「それとも耳が聞こえんのかね？　扉は、あんたに何と尋ねた？」

<a id="LG-09-098"></a>

**LG-09-098**

<!-- EN:LG-09-098 -->
“Nothing!” Alice said impatiently. “I’ve been knocking at it!”
<!-- /EN:LG-09-098 -->

> 「何にも！」アリスはいらいらして答えた。「わたしがたたいていたのよ！」

<a id="LG-09-099"></a>

**LG-09-099**

<!-- EN:LG-09-099 -->
“Shouldn’t do that—shouldn’t do that—” the Frog muttered. “Vexes it, you know.” Then he went up and gave the door a kick with one of his great feet. “You let *it* alone,” he panted out, as he hobbled back to his tree, “and it’ll let *you* alone, you know.”
<!-- /EN:LG-09-099 -->

> 「そんなことしちゃいかん、そんなことしちゃいかん」とカエルはぶつぶつ言った。「扉が嫌がるからな」そして近づいて、大きな足で扉を一つ蹴った。「*扉を*そっとしておけば」と、息を切らして言いながら、また木のほうへよろよろ戻っていった。「扉も*あんたを*そっとしておくさ」

<a id="LG-09-100"></a>

**LG-09-100**

<!-- EN:LG-09-100 -->
At this moment the door was flung open, and a shrill voice was heard singing:
<!-- /EN:LG-09-100 -->

> そのとき扉が勢いよく開き、甲高い歌声が聞こえた。

<a id="LG-09-101"></a>

**LG-09-101**

<!-- EN:LG-09-101 -->
“To the Looking-Glass world it was Alice that said,  
‘I’ve a sceptre in hand, I’ve a crown on my head;  
Let the Looking-Glass creatures, whatever they be,  
Come and dine with the Red Queen, the White Queen, and me.’”
<!-- /EN:LG-09-101 -->

> 「鏡の国に、アリスは言った、  
> 『わたしの手には王笏、頭には王冠。  
> 鏡の国の生き物たちよ、何者であっても、  
> 赤の女王、白の女王、そしてわたしと食卓へ』」

<a id="LG-09-102"></a>

**LG-09-102**

<!-- EN:LG-09-102 -->
And hundreds of voices joined in the chorus:
<!-- /EN:LG-09-102 -->

> すると何百もの声が、合唱に加わった。

<a id="LG-09-103"></a>

**LG-09-103**

<!-- EN:LG-09-103 -->
“Then fill up the glasses as quick as you can,  
And sprinkle the table with buttons and bran:  
Put cats in the coffee, and mice in the tea—  
And welcome Queen Alice with thirty-times-three!”
<!-- /EN:LG-09-103 -->

> 「さあ、できるだけ早くグラスを満たせ、  
> ボタンとふすまを食卓にまけ。  
> コーヒーに猫を、紅茶にネズミを――  
> アリス女王を、三十掛ける三の歓声で迎えよう！」

<a id="LG-09-104"></a>

**LG-09-104**

<!-- EN:LG-09-104 -->
Then followed a confused noise of cheering, and Alice thought to herself, “Thirty times three makes ninety. I wonder if any one’s counting?” In a minute there was silence again, and the same shrill voice sang another verse;
<!-- /EN:LG-09-104 -->

> 続いて、歓声がごちゃまぜに響いた。アリスは心の中で思った。「三十掛ける三は九十。だれか数えているのかしら？」少しすると、また静かになり、同じ甲高い声が次の節を歌った。

<a id="LG-09-105"></a>

**LG-09-105**

<!-- EN:LG-09-105 -->
“‘O Looking-Glass creatures,’ quoth Alice, ‘draw near!  
’Tis an honour to see me, a favour to hear:  
’Tis a privilege high to have dinner and tea  
Along with the Red Queen, the White Queen, and me!’”
<!-- /EN:LG-09-105 -->

> 「『鏡の国の生き物たちよ』とアリスは言った、『近う寄れ！  
> わたしに会えるは名誉、声を聞けるはお恵み。  
> 夕食やお茶をご一緒できるは、いとも高き特権、  
> 赤の女王、白の女王、そしてわたしと！』」

<a id="LG-09-106"></a>

**LG-09-106**

<!-- EN:LG-09-106 -->
Then came the chorus again:—
<!-- /EN:LG-09-106 -->

> そして、また合唱になった。

<a id="LG-09-107"></a>

**LG-09-107**

<!-- EN:LG-09-107 -->
“Then fill up the glasses with treacle and ink,  
Or anything else that is pleasant to drink:  
Mix sand with the cider, and wool with the wine—  
And welcome Queen Alice with ninety-times-nine!”
<!-- /EN:LG-09-107 -->

> 「さあ、糖蜜とインクでグラスを満たせ、  
> それとも、飲んで楽しいほかの何かで。  
> シードルに砂を、ワインに羊毛を混ぜ――  
> アリス女王を、九十掛ける九の歓声で迎えよう！」

<a id="LG-09-108"></a>

**LG-09-108**

<!-- EN:LG-09-108 -->
“Ninety times nine!” Alice repeated in despair, “Oh, that’ll never be done! I’d better go in at once—” and there was a dead silence the moment she appeared.
<!-- /EN:LG-09-108 -->

> 「九十掛ける九ですって！」アリスは絶望して繰り返した。「ああ、それじゃ、いつまでも終わらない！　すぐに入ったほうがいいわ……」そして姿を見せた瞬間、あたりはしんと静まり返った。

<a id="LG-09-109"></a>

**LG-09-109**

<!-- EN:LG-09-109 -->
Alice glanced nervously along the table, as she walked up the large hall, and noticed that there were about fifty guests, of all kinds: some were animals, some birds, and there were even a few flowers among them. “I’m glad they’ve come without waiting to be asked,” she thought: “I should never have known who were the right people to invite!”
<!-- /EN:LG-09-109 -->

> アリスは大広間の奥へ進みながら、おどおどと長い食卓を見渡した。お客様は五十人ほどで、いろいろな種類がいた。動物もいれば鳥もいて、花までいくつか交じっていた。「招待されるのを待たずに来てくれて、よかったわ」と思った。「だれを呼ぶのがふさわしいかなんて、わたしにはとても分からなかったもの！」

<a id="LG-09-110"></a>

**LG-09-110**

<!-- EN:LG-09-110 -->
There were three chairs at the head of the table; the Red and White Queens had already taken two of them, but the middle one was empty. Alice sat down in it, rather uncomfortable in the silence, and longing for some one to speak.
<!-- /EN:LG-09-110 -->

> 食卓の上座には、椅子が三つあった。赤の女王と白の女王がすでに二つを占めていたが、真ん中の一つは空いていた。アリスはそこへ座った。静まり返っているので、いくらか落ち着かず、だれか話してくれればいいのにと願った。

<a id="LG-09-111"></a>

**LG-09-111**

<!-- EN:LG-09-111 -->
At last the Red Queen began. “You’ve missed the soup and fish,” she said. “Put on the joint!” And the waiters set a leg of mutton before Alice, who looked at it rather anxiously, as she had never had to carve a joint before.
<!-- /EN:LG-09-111 -->

> ようやく、赤の女王が口を開いた。「スープと魚料理には間に合いませんでしたね」と言った。「肉の塊を出しなさい！」給仕たちはアリスの前に羊の脚肉を置いた。アリスは少し心配そうにそれを見た。肉の塊を切り分けたことは、それまで一度もなかったのだ。

<a id="LG-09-112"></a>

**LG-09-112**

<!-- EN:LG-09-112 -->
“You look a little shy; let me introduce you to that leg of mutton,” said the Red Queen. “Alice—Mutton; Mutton—Alice.” The leg of mutton got up in the dish and made a little bow to Alice; and Alice returned the bow, not knowing whether to be frightened or amused.
<!-- /EN:LG-09-112 -->

> 「少し遠慮しているようですね。あの羊の脚肉に、ご紹介しましょう」と赤の女王。「アリス、こちら羊肉。羊肉、こちらアリス」脚肉は大皿の上で立ち上がり、アリスに軽くお辞儀をした。アリスもお辞儀を返した。怖がればよいのか、おもしろがればよいのか、分からなかった。

<a id="LG-09-113"></a>

**LG-09-113**

<!-- EN:LG-09-113 -->
“May I give you a slice?” she said, taking up the knife and fork, and looking from one Queen to the other.
<!-- /EN:LG-09-113 -->

> 「一切れ、差し上げましょうか？」ナイフとフォークを取り、二人の女王を交互に見ながら言った。

<a id="LG-09-114"></a>

**LG-09-114**

<!-- EN:LG-09-114 -->
“Certainly not,” the Red Queen said, very decidedly: “it isn’t etiquette to cut any one you’ve been introduced to. Remove the joint!” And the waiters carried it off, and brought a large plum-pudding in its place.
<!-- /EN:LG-09-114 -->

> 「絶対にいけません」と赤の女王は、きっぱり言った。「紹介された相手を切るのは、礼儀に反します。肉を下げなさい！」給仕たちは肉を下げ、代わりに大きなプラムプディングを運んできた。

> **訳注：** cut は「切る」に加え、人を知っていながら無視する意味にもなる。紹介後の礼儀という話と、肉を切り分ける行為が重ねられる。

<a id="LG-09-115"></a>

**LG-09-115**

<!-- EN:LG-09-115 -->
“I won’t be introduced to the pudding, please,” Alice said rather hastily, “or we shall get no dinner at all. May I give you some?”
<!-- /EN:LG-09-115 -->

> 「お願い、プディングには紹介しないで」とアリスは、いくらかあわてて言った。「そうしないと、夕食がまったく食べられなくなるわ。少しお取りしましょうか？」

<a id="LG-09-116"></a>

**LG-09-116**

<!-- EN:LG-09-116 -->
But the Red Queen looked sulky, and growled “Pudding—Alice; Alice—Pudding. Remove the pudding!” and the waiters took it away so quickly that Alice couldn’t return its bow.
<!-- /EN:LG-09-116 -->

> けれど赤の女王は不機嫌な顔をして、「プディング、アリス。アリス、プディング。プディングを下げなさい！」とうなるように言った。給仕たちはあまりに素早く運び去ったので、アリスはプディングのお辞儀に返礼もできなかった。

<a id="LG-09-117"></a>

**LG-09-117**

<!-- EN:LG-09-117 -->
However, she didn’t see why the Red Queen should be the only one to give orders, so, as an experiment, she called out “Waiter! Bring back the pudding!” and there it was again in a moment like a conjuring-trick. It was so large that she couldn’t help feeling a *little* shy with it, as she had been with the mutton; however, she conquered her shyness by a great effort and cut a slice and handed it to the Red Queen.
<!-- /EN:LG-09-117 -->

> しかし、赤の女王だけが命令してよい理由はないと思い、試しに「給仕さん！　プディングを戻してちょうだい！」と呼んでみた。すると手品のように、たちまち元に戻ってきた。とても大きかったので、アリスは羊肉に対してと同じように、やはり*少し*気後れせずにはいられなかった。けれど懸命に勇気を出して一切れを切り、赤の女王に渡した。

<a id="LG-09-118"></a>

**LG-09-118**

<!-- EN:LG-09-118 -->
“What impertinence!” said the Pudding. “I wonder how you’d like it, if I were to cut a slice out of *you*, you creature!”
<!-- /EN:LG-09-118 -->

> 「なんて無礼な！」とプディングは言った。「私が*あなたの*体を一切れ切り取ったら、どんな気がするでしょうね、この子は！」

<a id="LG-09-119"></a>

**LG-09-119**

<!-- EN:LG-09-119 -->
It spoke in a thick, suety sort of voice, and Alice hadn’t a word to say in reply: she could only sit and look at it and gasp.
<!-- /EN:LG-09-119 -->

> それは、脂の詰まったような、もったりした声だった。アリスには返す言葉が一つもなく、ただ座ったままプディングを見て、息をのむばかりだった。

<a id="LG-09-120"></a>

**LG-09-120**

<!-- EN:LG-09-120 -->
“Make a remark,” said the Red Queen: “it’s ridiculous to leave all the conversation to the pudding!”
<!-- /EN:LG-09-120 -->

> 「何かお話しなさい」と赤の女王。「会話をぜんぶプディングに任せておくなんて、ばかげていますよ！」

<a id="LG-09-121"></a>

**LG-09-121**

<!-- EN:LG-09-121 -->
“Do you know, I’ve had such a quantity of poetry repeated to me to-day,” Alice began, a little frightened at finding that, the moment she opened her lips, there was dead silence, and all eyes were fixed upon her; “and it’s a very curious thing, I think—every poem was about fishes in some way. Do you know why they’re so fond of fishes, all about here?”
<!-- /EN:LG-09-121 -->

> 「あのね、今日はずいぶんたくさんの詩を聞かせてもらったの」とアリスは話し始めた。口を開いたとたん、あたりが静まり返り、みんなの目が自分に集まったので、少し怖くなった。「それで、とても不思議だと思うのだけれど、どの詩も、何かしら魚のことだったのよ。このあたりでは、どうしてそんなに魚が好きなのか、ご存じ？」

<a id="LG-09-122"></a>

**LG-09-122**

<!-- EN:LG-09-122 -->
She spoke to the Red Queen, whose answer was a little wide of the mark. “As to fishes,” she said, very slowly and solemnly, putting her mouth close to Alice’s ear, “her White Majesty knows a lovely riddle—all in poetry—all about fishes. Shall she repeat it?”
<!-- /EN:LG-09-122 -->

> 赤の女王に向かって話したのだが、返事は少し的外れだった。「魚といえば」と女王はアリスの耳に口を寄せ、とてもゆっくり、おごそかに言った。「白の女王陛下が、すてきななぞなぞをご存じです。ぜんぶ詩で、ぜんぶ魚のことです。聞かせてもらいますか？」

<a id="LG-09-123"></a>

**LG-09-123**

<!-- EN:LG-09-123 -->
“Her Red Majesty’s very kind to mention it,” the White Queen murmured into Alice’s other ear, in a voice like the cooing of a pigeon. “It would be *such* a treat! May I?”
<!-- /EN:LG-09-123 -->

> 「ご紹介くださって、赤の女王陛下はご親切ですこと」と白の女王は、ハトの鳴き声のような声で、アリスのもう一方の耳につぶやいた。「*すばらしい*お楽しみになりますよ！　よろしい？」

<a id="LG-09-124"></a>

**LG-09-124**

<!-- EN:LG-09-124 -->
“Please do,” Alice said very politely.
<!-- /EN:LG-09-124 -->

> 「どうぞお願いします」とアリスは、とても丁寧に答えた。

<a id="LG-09-125"></a>

**LG-09-125**

<!-- EN:LG-09-125 -->
The White Queen laughed with delight, and stroked Alice’s cheek. Then she began:
<!-- /EN:LG-09-125 -->

> 白の女王はうれしそうに笑い、アリスの頰をなでた。それから始めた。

<a id="LG-09-126"></a>

**LG-09-126**

<!-- EN:LG-09-126 -->
    “‘First, the fish must be caught.’  
That is easy: a baby, I think, could have caught it.  
    ‘Next, the fish must be bought.’  
That is easy: a penny, I think, would have bought it.  
<!-- /EN:LG-09-126 -->

> 　「『まず、魚は捕まえなくては』  
> 簡単なこと。赤ん坊でも、きっと捕まえられたでしょう。  
> 　『次に、魚は買わなくては』  
> 簡単なこと。一ペニーでも、きっと買えたでしょう。

<a id="LG-09-127"></a>

**LG-09-127**

<!-- EN:LG-09-127 -->
    ‘Now cook me the fish!’  
That is easy, and will not take more than a minute.  
    ‘Let it lie in a dish!’  
That is easy, because it already is in it.  
<!-- /EN:LG-09-127 -->

> 　『さあ、その魚を料理しておくれ！』  
> 簡単なこと。一分より長くはかかりません。  
> 　『それを皿に載せておくれ！』  
> 簡単なこと。もうすでに皿の中ですから。

<a id="LG-09-128"></a>

**LG-09-128**

<!-- EN:LG-09-128 -->
    ‘Bring it here! Let me sup!’  
It is easy to set such a dish on the table.  
    ‘Take the dish-cover up!’  
Ah, that is so hard that I fear I’m unable!  
<!-- /EN:LG-09-128 -->

> 　『ここへ持ってきて、夕飯にしよう！』  
> こんな皿を食卓に置くのは簡単なこと。  
> 　『皿のふたを持ち上げて！』  
> ああ、それは難しくて、私にはできそうもありません！

<a id="LG-09-129"></a>

**LG-09-129**

<!-- EN:LG-09-129 -->
    For it holds it like glue—  
Holds the lid to the dish, while it lies in the middle:  
    Which is easiest to do,  
Un-dish-cover the fish, or dishcover the riddle?”
<!-- /EN:LG-09-129 -->

> 　だって魚が、糊のようにくっつけている――  
> 真ん中に寝そべったまま、ふたを皿にくっつけている。  
> 　さて、どちらが簡単でしょう、  
> 魚の皿のふたを解くのと、なぞなぞの謎を解くのと？」

> **訳注：** Un-dish-cover は「皿の覆いを取る」という造語。dishcover は dish（皿）と discover（発見する・解く）を重ねた綴りで、皿のふたを取ることとなぞなぞを解くことを掛けている。

<a id="LG-09-130"></a>

**LG-09-130**

<!-- EN:LG-09-130 -->
“Take a minute to think about it, and then guess,” said the Red Queen. “Meanwhile, we’ll drink your health—Queen Alice’s health!” she screamed at the top of her voice, and all the guests began drinking it directly, and very queerly they managed it: some of them put their glasses upon their heads like extinguishers, and drank all that trickled down their faces—others upset the decanters, and drank the wine as it ran off the edges of the table—and three of them (who looked like kangaroos) scrambled into the dish of roast mutton, and began eagerly lapping up the gravy, “just like pigs in a trough!” thought Alice.
<!-- /EN:LG-09-130 -->

> 「一分考えて、それから当ててごらんなさい」と赤の女王。「そのあいだに、あなたの健康を祝って乾杯しましょう。アリス女王のご健康に！」最後は声の限りに叫んだ。お客様たちはすぐさま飲み始めたが、その飲み方はたいそう奇妙だった。グラスをろうそく消しのように頭へかぶせ、顔を伝って流れる物を全部飲む者。デカンターをひっくり返し、テーブルの縁からこぼれるワインを飲む者。そして三人――カンガルーのように見えた――は、ローストした羊肉の大皿へよじ登り、夢中で肉汁をなめ始めた。「まるで餌おけの豚みたい！」とアリスは思った。

<a id="LG-09-131"></a>

**LG-09-131**

<!-- EN:LG-09-131 -->
“You ought to return thanks in a neat speech,” the Red Queen said, frowning at Alice as she spoke.
<!-- /EN:LG-09-131 -->

> 「気の利いたご挨拶をして、お礼を述べるべきです」と赤の女王は、アリスをしかめ面で見ながら言った。

<a id="LG-09-132"></a>

**LG-09-132**

<!-- EN:LG-09-132 -->
“We must support you, you know,” the White Queen whispered, as Alice got up to do it, very obediently, but a little frightened.
<!-- /EN:LG-09-132 -->

> 「私たちが支えてあげなければね」と白の女王はささやいた。アリスが、少し怖がりながらもとても素直に、お礼を言おうと立ち上がったときだった。

<a id="LG-09-133"></a>

**LG-09-133**

<!-- EN:LG-09-133 -->
“Thank you very much,” she whispered in reply, “but I can do quite well without.”
<!-- /EN:LG-09-133 -->

> 「どうもありがとう」とアリスは、ささやき返した。「でも、支えてもらわなくても大丈夫よ」

<a id="LG-09-134"></a>

**LG-09-134**

<!-- EN:LG-09-134 -->
“That wouldn’t be at all the thing,” the Red Queen said very decidedly: so Alice tried to submit to it with a good grace.
<!-- /EN:LG-09-134 -->

> 「そんなことでは、まったくいけません」と赤の女王はきっぱり言った。それでアリスは、気持ちよく受け入れようと努めた。

<a id="LG-09-135"></a>

**LG-09-135**

<!-- EN:LG-09-135 -->
(“And they *did* push so!” she said afterwards, when she was telling her sister the history of the feast. “You would have thought they wanted to squeeze me flat!”)
<!-- /EN:LG-09-135 -->

> （「それが、*ほんとうに*ひどく押してくるの！」あとで姉に宴の様子を話したとき、アリスはそう言った。「わたしをぺちゃんこにしたかったとしか思えないわ！」）

<a id="LG-09-136"></a>

**LG-09-136**

<!-- EN:LG-09-136 -->
In fact it was rather difficult for her to keep in her place while she made her speech: the two Queens pushed her so, one on each side, that they nearly lifted her up into the air: “I rise to return thanks—” Alice began: and she really *did* rise as she spoke, several inches; but she got hold of the edge of the table, and managed to pull herself down again.
<!-- /EN:LG-09-136 -->

> 実際、挨拶のあいだ、その場にとどまっているのはかなり難しかった。二人の女王が両側から押すので、ほとんど宙へ持ち上げられそうになった。「お礼を申し上げるため、立ち上がりまして……」とアリスが言い始めると、ほんとうに体が数インチも*上がった*。けれどテーブルの縁をつかんで、なんとか自分を引き下ろすことができた。

> **訳注：** support（支える）と rise（立って挨拶する／上昇する）の比喩的な用法が、身体を押して浮かせるという文字どおりの出来事になる。

<a id="LG-09-137"></a>

**LG-09-137**

<!-- EN:LG-09-137 -->
“Take care of yourself!” screamed the White Queen, seizing Alice’s hair with both her hands. “Something’s going to happen!”
<!-- /EN:LG-09-137 -->

> 「気をつけて！」白の女王はアリスの髪を両手でつかみ、悲鳴を上げた。「何かが起こります！」

<a id="LG-09-138"></a>

**LG-09-138**

<!-- EN:LG-09-138 -->
And then (as Alice afterwards described it) all sorts of things happened in a moment. The candles all grew up to the ceiling, looking something like a bed of rushes with fireworks at the top. As to the bottles, they each took a pair of plates, which they hastily fitted on as wings, and so, with forks for legs, went fluttering about in all directions: “and very like birds they look,” Alice thought to herself, as well as she could in the dreadful confusion that was beginning.
<!-- /EN:LG-09-138 -->

> すると――あとでアリスが話したとおりに言うなら――いろいろなことが、いっぺんに起こった。ろうそくはみな天井まで伸び、先に花火のついたイグサの茂みのようになった。瓶はといえば、それぞれ皿を二枚取り、大急ぎで翼として取り付け、フォークを脚にして、四方八方へばたばた飛び回った。「ずいぶん鳥に似て見えるわね」とアリスは、始まりかけた恐ろしい混乱の中で、考えられるかぎりに考えた。

<a id="LG-09-139"></a>

**LG-09-139**

<!-- EN:LG-09-139 -->
At this moment she heard a hoarse laugh at her side, and turned to see what was the matter with the White Queen; but, instead of the Queen, there was the leg of mutton sitting in the chair. “Here I am!” cried a voice from the soup tureen, and Alice turned again, just in time to see the Queen’s broad good-natured face grinning at her for a moment over the edge of the tureen, before she disappeared into the soup.
<!-- /EN:LG-09-139 -->

> そのとき、そばでしわがれた笑い声が聞こえた。白の女王がどうしたのかと振り向くと、女王の代わりに羊の脚肉が椅子に座っていた。「ここにいますよ！」とスープ鉢の中から声がした。アリスがまた向きを変えると、ちょうど女王の大きな、人のよさそうな顔が、鉢の縁から一瞬だけにこりと笑いかけ、そのままスープの中へ消えるのが見えた。

<a id="LG-09-140"></a>

**LG-09-140**

<!-- EN:LG-09-140 -->
There was not a moment to be lost. Already several of the guests were lying down in the dishes, and the soup ladle was walking up the table towards Alice’s chair, and beckoning to her impatiently to get out of its way.
<!-- /EN:LG-09-140 -->

> 一刻の猶予もなかった。すでに何人かのお客様は皿の中に横たわり、スープのおたまは食卓の上をアリスの椅子に向かって歩いてきて、邪魔だからどくようにと、いらいらして手招きをしていた。

<a id="LG-09-141"></a>

**LG-09-141**

<!-- EN:LG-09-141 -->
“I can’t stand this any longer!” she cried as she jumped up and seized the table-cloth with both hands: one good pull, and plates, dishes, guests, and candles came crashing down together in a heap on the floor.
<!-- /EN:LG-09-141 -->

> 「もう、これ以上我慢できないわ！」アリスは叫んで飛び上がり、両手でテーブルクロスをつかんだ。思いきり一度引くと、小皿も大皿も、お客様もろうそくも、いっぺんにがらがらと落ち、床に山積みになった。

<a id="LG-09-142"></a>

**LG-09-142**

<!-- EN:LG-09-142 -->
“And as for *you*,” she went on, turning fiercely upon the Red Queen, whom she considered as the cause of all the mischief—but the Queen was no longer at her side—she had suddenly dwindled down to the size of a little doll, and was now on the table, merrily running round and round after her own shawl, which was trailing behind her.
<!-- /EN:LG-09-142 -->

> 「それから、*あなた*だけれど」と、アリスは勢いよく赤の女王へ向き直って続けた。騒ぎの原因は、みんなこの女王だと思っていた。ところが、女王はもう隣にはいなかった。突然、小さな人形ほどに縮んでしまい、今はテーブルの上で、後ろに引きずる自分のショールを追って、楽しそうにくるくる走り回っていた。

<a id="LG-09-143"></a>

**LG-09-143**

<!-- EN:LG-09-143 -->
At any other time, Alice would have felt surprised at this, but she was far too much excited to be surprised at anything *now*. “As for *you*,” she repeated, catching hold of the little creature in the very act of jumping over a bottle which had just lighted upon the table, “I’ll shake you into a kitten, that I will!”
<!-- /EN:LG-09-143 -->

> ほかのときなら驚いたはずだが、*今の*アリスはあまりに興奮していて、何を見ても驚くどころではなかった。「*あなた*だけれど」と繰り返して、小さな女王をつかまえた。ちょうど、テーブルに舞い降りたばかりの瓶を跳び越えようとしているところだった。「揺すぶって、子猫にしてやるんだから。ええ、きっとそうするわ！」

[章目次へ戻る](#book-top)

---

<a id="lg-chapter-10"></a>

## 第10章　揺すぶる

### CHAPTER X. Shaking

<a id="LG-10-001"></a>

**LG-10-001**

<!-- EN:LG-10-001 -->
She took her off the table as she spoke, and shook her backwards and forwards with all her might.
<!-- /EN:LG-10-001 -->

> そう言いながらアリスは、女王をテーブルから持ち上げ、力いっぱい前後に揺すぶった。

<a id="LG-10-002"></a>

**LG-10-002**

<!-- EN:LG-10-002 -->
The Red Queen made no resistance whatever; only her face grew very small, and her eyes got large and green: and still, as Alice went on shaking her, she kept on growing shorter—and fatter—and softer—and rounder—and—
<!-- /EN:LG-10-002 -->

> 赤の女王は、まったく抵抗しなかった。ただ、顔がとても小さくなり、目が大きく緑色になった。そしてアリスが揺すぶり続けるにつれて、ますます小さく――ますます太く――ますます柔らかく――ますます丸くなって――そして――

[章目次へ戻る](#book-top)

---

<a id="lg-chapter-11"></a>

## 第11章　目覚める

### CHAPTER XI. Waking

<a id="LG-11-001"></a>

**LG-11-001**

<!-- EN:LG-11-001 -->
—and it really *was* a kitten, after all.
<!-- /EN:LG-11-001 -->

> ――そして、やっぱりそれは、ほんとうに子猫*だった*。

[章目次へ戻る](#book-top)

---

<a id="lg-chapter-12"></a>

## 第12章　夢を見たのはどちら？

### CHAPTER XII. Which Dreamed it?

<a id="LG-12-001"></a>

**LG-12-001**

<!-- EN:LG-12-001 -->
“Your majesty shouldn’t purr so loud,” Alice said, rubbing her eyes, and addressing the kitten, respectfully, yet with some severity. “You woke me out of oh! such a nice dream! And you’ve been along with me, Kitty—all through the Looking-Glass world. Did you know it, dear?”
<!-- /EN:LG-12-001 -->

> 「陛下、そんなに大きな音で喉を鳴らしてはいけません」とアリスは目をこすりながら、敬意を払いながらも、いくらか厳しく子猫に話しかけた。「ああ、せっかくあんなにすてきな夢を見ていたのに、起こしてしまったのね！　あなたも一緒だったのよ、子猫ちゃん。鏡の国をずうっと一緒に。知っていた？」

<a id="LG-12-002"></a>

**LG-12-002**

<!-- EN:LG-12-002 -->
It is a very inconvenient habit of kittens (Alice had once made the remark) that, whatever you say to them, they *always* purr. “If they would only purr for ‘yes’ and mew for ‘no,’ or any rule of that sort,” she had said, “so that one could keep up a conversation! But how *can* you talk with a person if they always say the same thing?”
<!-- /EN:LG-12-002 -->

> 子猫には、とても困った癖がある――アリスが前にそう言ったことがあった――何を話しかけても、*いつも*喉を鳴らすのだ。「『はい』ならごろごろ、『いいえ』ならにゃあとか、そんな決まりさえあれば」とアリスは言ったものだった。「会話が続けられるのに！　いつも同じことしか言わない相手と、どうしたらお話*できる*の？」

<a id="LG-12-003"></a>

**LG-12-003**

<!-- EN:LG-12-003 -->
On this occasion the kitten only purred: and it was impossible to guess whether it meant “yes” or “no.”
<!-- /EN:LG-12-003 -->

> このときも、子猫はただ喉を鳴らしただけだった。それが「はい」なのか「いいえ」なのか、見当もつかなかった。

<a id="LG-12-004"></a>

**LG-12-004**

<!-- EN:LG-12-004 -->
So Alice hunted among the chessmen on the table till she had found the Red Queen: then she went down on her knees on the hearth-rug, and put the kitten and the Queen to look at each other. “Now, Kitty!” she cried, clapping her hands triumphantly. “Confess that was what you turned into!”
<!-- /EN:LG-12-004 -->

> そこでアリスはテーブルのチェスの駒を探し、赤の女王を見つけた。それから暖炉前の敷物に膝をつき、子猫と女王が向き合うように置いた。「さあ、子猫ちゃん！」アリスは勝ち誇って手をたたいた。「あなたが変身したのは、この姿だったって白状しなさい！」

<a id="LG-12-005"></a>

**LG-12-005**

<!-- EN:LG-12-005 -->
(“But it wouldn’t look at it,” she said, when she was explaining the thing afterwards to her sister: “it turned away its head, and pretended not to see it: but it looked a *little* ashamed of itself, so I think it *must* have been the Red Queen.”)
<!-- /EN:LG-12-005 -->

> （「でも、そっちを見ようとしなかったの」と、あとで姉に説明したとき、アリスは言った。「顔をそむけて、見えないふりをして。でも、*少し*恥ずかしそうだったから、やっぱり赤の女王だったに*違いない*と思うわ」）

<a id="LG-12-006"></a>

**LG-12-006**

<!-- EN:LG-12-006 -->
“Sit up a little more stiffly, dear!” Alice cried with a merry laugh. “And curtsey while you’re thinking what to—what to purr. It saves time, remember!” And she caught it up and gave it one little kiss, “just in honour of having been a Red Queen.”
<!-- /EN:LG-12-006 -->

> 「もう少ししゃんと座りなさいな！」アリスは楽しそうに笑って言った。「それから、何を言おうか……何をごろごろ言おうか考えているあいだに、お辞儀をするのよ。時間の節約になるんだから、忘れないでね！」そして子猫を抱き上げ、ちょんと一度口づけした。「赤の女王だったことへの、お祝いに」

<a id="LG-12-007"></a>

**LG-12-007**

<!-- EN:LG-12-007 -->
“Snowdrop, my pet!” she went on, looking over her shoulder at the White Kitten, which was still patiently undergoing its toilet, “when *will* Dinah have finished with your White Majesty, I wonder? That must be the reason you were so untidy in my dream—Dinah! do you know that you’re scrubbing a White Queen? Really, it’s most disrespectful of you!
<!-- /EN:LG-12-007 -->

> 「かわいいスノードロップ！」アリスは続けて、肩越しに白い子猫を見た。白い子猫はまだ、おとなしく毛づくろいを受けていた。「ダイナは白の女王陛下のお手入れを、*いつになったら*終えるのかしら？　夢の中であんなに身なりが乱れていたのも、きっとそのせいね。ダイナ！　あなた、白の女王様をごしごし洗っているのだと分かっている？　ほんとうに、失礼極まりないわ！

<a id="LG-12-008"></a>

**LG-12-008**

<!-- EN:LG-12-008 -->
“And what did *Dinah* turn to, I wonder?” she prattled on, as she settled comfortably down, with one elbow in the rug, and her chin in her hand, to watch the kittens. “Tell me, Dinah, did you turn to Humpty Dumpty? I *think* you did—however, you’d better not mention it to your friends just yet, for I’m not sure.
<!-- /EN:LG-12-008 -->

> 「それで、*ダイナは*何に変わったのかしら？」アリスはそうおしゃべりを続けながら、敷物に片肘をつき、手にあごを載せて楽な姿勢になり、子猫たちを眺めた。「ねえ、ダイナ、あなたはハンプティ・ダンプティになったの？　わたしは、そう*思う*のだけれど。でも、まだお友達には言わないほうがいいわ。確かではないもの。

<a id="LG-12-009"></a>

**LG-12-009**

<!-- EN:LG-12-009 -->
“By the way, Kitty, if only you’d been really with me in my dream, there was one thing you *would* have enjoyed—I had such a quantity of poetry said to me, all about fishes! To-morrow morning you shall have a real treat. All the time you’re eating your breakfast, I’ll repeat ‘The Walrus and the Carpenter’ to you; and then you can make believe it’s oysters, dear!
<!-- /EN:LG-12-009 -->

> 「そうそう、子猫ちゃん、もしほんとうに夢の中で一緒だったなら、あなたがきっと*喜んだ*ものが一つあったわ。ずいぶんたくさん詩を聞かされたのだけれど、みんな魚のことだったの！　明日の朝は、とびきりのお楽しみを用意してあげる。朝ごはんを食べているあいだじゅう、『セイウチと大工』を聞かせてあげるから、カキを食べているつもりになれるでしょう！

<a id="LG-12-010"></a>

**LG-12-010**

<!-- EN:LG-12-010 -->
“Now, Kitty, let’s consider who it was that dreamed it all. This is a serious question, my dear, and you should *not* go on licking your paw like that—as if Dinah hadn’t washed you this morning! You see, Kitty, it *must* have been either me or the Red King. He was part of my dream, of course—but then I was part of his dream, too! *Was* it the Red King, Kitty? You were his wife, my dear, so you ought to know—Oh, Kitty, *do* help to settle it! I’m sure your paw can wait!” But the provoking kitten only began on the other paw, and pretended it hadn’t heard the question.
<!-- /EN:LG-12-010 -->

> 「さあ、子猫ちゃん、あれをぜんぶ夢に見たのは、だれなのか考えましょう。これは大事な問題なのよ。だから、そんなふうに前足をなめ続けては*いけません*。今朝ダイナに洗ってもらわなかったみたいじゃない！　いいこと、子猫ちゃん、わたしか赤の王様の、どちらかだったに*違いない*のよ。もちろん、あの人はわたしの夢の一部だった。でも、わたしもあの人の夢の一部だったでしょう！　赤の王様*だった*の、子猫ちゃん？　あなたは奥様だったのだから、知っているはずよ。ああ、子猫ちゃん、*お願いだから*決着をつけるのを手伝って！　足はあとでもいいでしょう！」けれど、いまいましい子猫は、もう一方の前足をなめ始めただけで、質問が聞こえなかったふりをした。

<a id="LG-12-011"></a>

**LG-12-011**

<!-- EN:LG-12-011 -->
Which do *you* think it was?
<!-- /EN:LG-12-011 -->

> *あなたは*、どちらだったと思う？

<a id="LG-12-012"></a>

<!-- EN:LG-12-012 -->
---
<!-- /EN:LG-12-012 -->

<a id="LG-12-013"></a>

**LG-12-013**

<!-- EN:LG-12-013 -->
A boat beneath a sunny sky,  
Lingering onward dreamily  
In an evening of July—  
<!-- /EN:LG-12-013 -->

> 晴れた空の下、一そうの舟が、  
> 夢見るように、ゆるゆると進んでいく、  
> 七月の、ある夕べ――

> **訳注：** ここから最後まで、原詩21行の頭文字を続けると ALICE PLEASANCE LIDDELL となる。日本語訳では意味と各連・各行の対応を優先し、この頭文字の仕掛けは再現していない。

<a id="LG-12-014"></a>

**LG-12-014**

<!-- EN:LG-12-014 -->
Children three that nestle near,  
Eager eye and willing ear,  
Pleased a simple tale to hear—  
<!-- /EN:LG-12-014 -->

> そばに寄り添う、三人の子供たち、  
> 瞳を輝かせ、耳を傾け、  
> 素朴な物語に喜んで聞き入る――

<a id="LG-12-015"></a>

**LG-12-015**

<!-- EN:LG-12-015 -->
Long has paled that sunny sky:  
Echoes fade and memories die.  
Autumn frosts have slain July.  
<!-- /EN:LG-12-015 -->

> あの晴れた空は、とうに色あせ、  
> こだまは薄れ、思い出は消える。  
> 秋の霜が、七月を殺した。

<a id="LG-12-016"></a>

**LG-12-016**

<!-- EN:LG-12-016 -->
Still she haunts me, phantomwise,  
Alice moving under skies  
Never seen by waking eyes.  
<!-- /EN:LG-12-016 -->

> それでも彼女は、幻のように私を訪れる、  
> アリスは歩む、空の下を――  
> 目覚めた目が一度も見たことのない、その空の下を。

<a id="LG-12-017"></a>

**LG-12-017**

<!-- EN:LG-12-017 -->
Children yet, the tale to hear,  
Eager eye and willing ear,  
Lovingly shall nestle near.  
<!-- /EN:LG-12-017 -->

> これからも子供たちは、物語を聞こうと、  
> 瞳を輝かせ、耳を傾け、  
> 親しげに、そばへ寄り添うだろう。

<a id="LG-12-018"></a>

**LG-12-018**

<!-- EN:LG-12-018 -->
In a Wonderland they lie,  
Dreaming as the days go by,  
Dreaming as the summers die:  
<!-- /EN:LG-12-018 -->

> 不思議の国に横たわり、  
> 日々が過ぎゆくあいだ、夢を見て、  
> 夏が消えてゆくあいだ、夢を見て。

<a id="LG-12-019"></a>

**LG-12-019**

<!-- EN:LG-12-019 -->
Ever drifting down the stream—  
Lingering in the golden gleam—  
Life, what is it but a dream?
<!-- /EN:LG-12-019 -->

> いつまでも流れを下り――  
> 金色のきらめきに、ゆるゆると漂い――  
> 人生とは、夢でなくて何だろう？

[章目次へ戻る](#book-top)

---
