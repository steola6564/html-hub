# Alice’s Adventures in Wonderland

## 不思議の国のアリス — 英日対訳

Lewis Carroll

添付版の全12章・789対訳ブロックを収録。英語の原段落・詩の連の直下に、日本語訳を引用形式で配置しています。HTML版と同じ章・段落IDを使用しています。

英語の語句・綴り・句読点は添付原文のままです。日本語訳は本版のための新訳で、説明が必要な言葉遊び等には別途「訳注」を付けています。詩は意味と改行を優先し、韻や頭文字の仕掛けをすべて再現する訳ではありません。

添付版に挿絵データは含まれていません。本文中の挿絵への言及と、原文にある版注は残しています。

<a id="book-top"></a>

## 章目次

- [第1章　ウサギの穴を下って](#aw-chapter-01) — CHAPTER I. Down the Rabbit-Hole
- [第2章　涙の池](#aw-chapter-02) — CHAPTER II. The Pool of Tears
- [第3章　コーカス競走と長いお話](#aw-chapter-03) — CHAPTER III. A Caucus-Race and a Long Tale
- [第4章　ウサギ、小さなビルを送りこむ](#aw-chapter-04) — CHAPTER IV. The Rabbit Sends in a Little Bill
- [第5章　イモムシの助言](#aw-chapter-05) — CHAPTER V. Advice from a Caterpillar
- [第6章　豚とコショウ](#aw-chapter-06) — CHAPTER VI. Pig and Pepper
- [第7章　おかしなお茶会](#aw-chapter-07) — CHAPTER VII. A Mad Tea-Party
- [第8章　女王のクロッケー場](#aw-chapter-08) — CHAPTER VIII. The Queen’s Croquet-Ground
- [第9章　ウミガメもどきの話](#aw-chapter-09) — CHAPTER IX. The Mock Turtle’s Story
- [第10章　ロブスターのカドリール](#aw-chapter-10) — CHAPTER X. The Lobster Quadrille
- [第11章　タルトを盗んだのはだれ？](#aw-chapter-11) — CHAPTER XI. Who Stole the Tarts?
- [第12章　アリスの証言](#aw-chapter-12) — CHAPTER XII. Alice’s Evidence

---

<a id="aw-chapter-01"></a>

## 第1章　ウサギの穴を下って

### CHAPTER I. Down the Rabbit-Hole

<a id="AW-01-001"></a>

**AW-01-001**

<!-- EN:AW-01-001 -->
Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do: once or twice she had peeped into the book her sister was reading, but it had no pictures or conversations in it, “and what is the use of a book,” thought Alice “without pictures or conversations?”
<!-- /EN:AW-01-001 -->

> アリスは、川岸でお姉さんの隣に座り、何もすることがないのに、すっかり飽きはじめていた。一、二度、お姉さんの読んでいる本をのぞいてみたが、絵もなければ会話もない。「絵も会話もない本なんて、いったい何の役に立つのかしら」とアリスは思った。

<a id="AW-01-002"></a>

**AW-01-002**

<!-- EN:AW-01-002 -->
So she was considering in her own mind (as well as she could, for the hot day made her feel very sleepy and stupid), whether the pleasure of making a daisy-chain would be worth the trouble of getting up and picking the daisies, when suddenly a White Rabbit with pink eyes ran close by her.
<!-- /EN:AW-01-002 -->

> そこで、起き上がってヒナギクを摘む面倒に見合うほど、花の輪を作るのは楽しいだろうかと、心の中で考えていた（暑い日で、とても眠く、頭もぼんやりしていたので、考えられるだけ考えていたのだ）。すると突然、桃色の目をした白ウサギが、すぐそばを駆けていった。

<a id="AW-01-003"></a>

**AW-01-003**

<!-- EN:AW-01-003 -->
There was nothing so *very* remarkable in that; nor did Alice think it so *very* much out of the way to hear the Rabbit say to itself, “Oh dear! Oh dear! I shall be late!” (when she thought it over afterwards, it occurred to her that she ought to have wondered at this, but at the time it all seemed quite natural); but when the Rabbit actually *took a watch out of its waistcoat-pocket*, and looked at it, and then hurried on, Alice started to her feet, for it flashed across her mind that she had never before seen a rabbit with either a waistcoat-pocket, or a watch to take out of it, and burning with curiosity, she ran across the field after it, and fortunately was just in time to see it pop down a large rabbit-hole under the hedge.
<!-- /EN:AW-01-003 -->

> それ自体は、*そうひどく*珍しいことでもなかった。ウサギが「大変だ！　大変だ！　遅刻してしまう！」と独り言を言うのを聞いても、アリスは*それほど*変だとは思わなかった（あとで考えてみると、そこで驚くべきだったと気づいたが、そのときは何もかも、ごく自然に思えたのだ）。けれども、ウサギが本当に*チョッキのポケットから時計を取り出し*、それを見てからまた急いでいくと、アリスはぱっと立ち上がった。チョッキのポケットを持つウサギも、そこから取り出す時計を持つウサギも、今まで一度も見たことがないと、はっと気づいたからだ。好奇心で胸をいっぱいにして、アリスは野原を横切り、あとを追いかけた。そして運よく、生け垣の下にある大きなウサギ穴へ、ウサギが飛び込むところに、ちょうど間に合った。

<a id="AW-01-004"></a>

**AW-01-004**

<!-- EN:AW-01-004 -->
In another moment down went Alice after it, never once considering how in the world she was to get out again.
<!-- /EN:AW-01-004 -->

> 次の瞬間には、アリスもあとを追って穴に飛び込んでいた。いったいどうやって出てくるつもりなのか、一度も考えもしないで。

<a id="AW-01-005"></a>

**AW-01-005**

<!-- EN:AW-01-005 -->
The rabbit-hole went straight on like a tunnel for some way, and then dipped suddenly down, so suddenly that Alice had not a moment to think about stopping herself before she found herself falling down a very deep well.
<!-- /EN:AW-01-005 -->

> ウサギ穴は、しばらくトンネルのようにまっすぐ続いていたが、それから突然、下へ折れ曲がった。それがあまりに突然だったので、立ち止まろうと考える暇もなく、気がつくとアリスは、とても深い井戸を落ちていた。

<a id="AW-01-006"></a>

**AW-01-006**

<!-- EN:AW-01-006 -->
Either the well was very deep, or she fell very slowly, for she had plenty of time as she went down to look about her and to wonder what was going to happen next. First, she tried to look down and make out what she was coming to, but it was too dark to see anything; then she looked at the sides of the well, and noticed that they were filled with cupboards and book-shelves; here and there she saw maps and pictures hung upon pegs. She took down a jar from one of the shelves as she passed; it was labelled “ORANGE MARMALADE”, but to her great disappointment it was empty: she did not like to drop the jar for fear of killing somebody underneath, so managed to put it into one of the cupboards as she fell past it.
<!-- /EN:AW-01-006 -->

> 井戸がとても深かったのか、それとも落ちるのがとてもゆっくりだったのか、落ちながら辺りを見回し、次に何が起こるのだろうと考える時間は、たっぷりあった。まず下をのぞき、どこへ向かっているのか見定めようとしたが、暗すぎて何も見えない。そこで井戸の壁を見ると、一面に戸棚や本棚が並んでいて、あちこちには、掛け釘に地図や絵が掛けてあった。通りすがりに、棚の一つから瓶を取った。ラベルには「オレンジ・マーマレード」とあるが、ひどくがっかりしたことに、中は空っぽ。下にいる誰かを死なせてしまってはいけないので、瓶を落とす気にもなれず、落ちながらそばを通った戸棚に、どうにかしまった。

<a id="AW-01-007"></a>

**AW-01-007**

<!-- EN:AW-01-007 -->
“Well!” thought Alice to herself, “after such a fall as this, I shall think nothing of tumbling down stairs! How brave they’ll all think me at home! Why, I wouldn’t say anything about it, even if I fell off the top of the house!” (Which was very likely true.)
<!-- /EN:AW-01-007 -->

> 「まあ！」とアリスは思った。「こんなふうに落ちたあとなら、階段から転げ落ちるくらい、何でもなくなるわ！　家のみんなは、わたしをずいぶん勇敢だと思うでしょうね！　だって、家のてっぺんから落ちたって、一言も言わないわ！」（それは、たぶん本当だろう。）

<a id="AW-01-008"></a>

**AW-01-008**

<!-- EN:AW-01-008 -->
Down, down, down. Would the fall *never* come to an end? “I wonder how many miles I’ve fallen by this time?” she said aloud. “I must be getting somewhere near the centre of the earth. Let me see: that would be four thousand miles down, I think—” (for, you see, Alice had learnt several things of this sort in her lessons in the schoolroom, and though this was not a *very* good opportunity for showing off her knowledge, as there was no one to listen to her, still it was good practice to say it over) “—yes, that’s about the right distance—but then I wonder what Latitude or Longitude I’ve got to?” (Alice had no idea what Latitude was, or Longitude either, but thought they were nice grand words to say.)
<!-- /EN:AW-01-008 -->

> 下へ、下へ、下へ。この落下は、*いつまでも*終わらないのだろうか。「今までに、何マイルくらい落ちたのかしら？」とアリスは声に出して言った。「もう地球の中心近くまで来ているはずだわ。ええと、そこはたしか、四千マイル下だったわね――」（というのも、アリスは勉強部屋での授業で、このようなことをいくつか習っていたのだ。聞く人が誰もいないのだから、知識を披露するには*あまり*よい機会とは言えなかったが、繰り返し口に出すのは、いい練習にはなった。）「――そう、そのくらいの距離で合っているわ。でも、今の緯度や経度はどのくらいかしら？」（アリスは緯度が何なのか、経度が何なのかも知らなかったが、口にすると立派で、いい言葉だと思っていた。）

<a id="AW-01-009"></a>

**AW-01-009**

<!-- EN:AW-01-009 -->
Presently she began again. “I wonder if I shall fall right *through* the earth! How funny it’ll seem to come out among the people that walk with their heads downward! The Antipathies, I think—” (she was rather glad there *was* no one listening, this time, as it didn’t sound at all the right word) “—but I shall have to ask them what the name of the country is, you know. Please, Ma’am, is this New Zealand or Australia?” (and she tried to curtsey as she spoke—fancy *curtseying* as you’re falling through the air! Do you think you could manage it?) “And what an ignorant little girl she’ll think me for asking! No, it’ll never do to ask: perhaps I shall see it written up somewhere.”
<!-- /EN:AW-01-009 -->

> やがて、また話しはじめた。「地球をすっかり*突き抜けて*落ちてしまうのかしら！　頭を下にして歩く人たちのところへ出たら、さぞおかしいでしょうね！　たしか、アンティパシーズっていうのだったかしら――」（今度は、聞いている人が*いなくて*、かえってよかったと思った。どうも正しい言葉に聞こえなかったからだ。）「――でも、その国の名前は聞かなくちゃね。すみません、奥様、ここはニュージーランドですか、それともオーストラリアですか？」（そう言いながら、膝を曲げてお辞儀をしようとした。空中を落ちながら*お辞儀をする*なんて、考えてもみてほしい！　あなたなら、うまくできると思う？）「でも、そんなことを聞いたら、何にも知らない子だと思われるわ！　だめね、聞くのは絶対にだめ。どこかに書いてあるかもしれないもの。」

> **訳注：** Antipathies は「反感」。ここでは Antipodes（対蹠地、地球の反対側の地域）との取り違え。

<a id="AW-01-010"></a>

**AW-01-010**

<!-- EN:AW-01-010 -->
Down, down, down. There was nothing else to do, so Alice soon began talking again. “Dinah’ll miss me very much to-night, I should think!” (Dinah was the cat.) “I hope they’ll remember her saucer of milk at tea-time. Dinah my dear! I wish you were down here with me! There are no mice in the air, I’m afraid, but you might catch a bat, and that’s very like a mouse, you know. But do cats eat bats, I wonder?” And here Alice began to get rather sleepy, and went on saying to herself, in a dreamy sort of way, “Do cats eat bats? Do cats eat bats?” and sometimes, “Do bats eat cats?” for, you see, as she couldn’t answer either question, it didn’t much matter which way she put it. She felt that she was dozing off, and had just begun to dream that she was walking hand in hand with Dinah, and saying to her very earnestly, “Now, Dinah, tell me the truth: did you ever eat a bat?” when suddenly, thump! thump! down she came upon a heap of sticks and dry leaves, and the fall was over.
<!-- /EN:AW-01-010 -->

> 下へ、下へ、下へ。ほかにすることもないので、アリスはすぐにまた話しはじめた。「今夜はダイナが、わたしをとても恋しがるでしょうね！」（ダイナは飼い猫だ。）「お茶の時間に、ミルクのお皿を忘れずに出してくれるといいけれど。大好きなダイナ！　あなたも一緒に、ここにいてくれたらいいのに！　空中にはネズミはいないと思うけれど、コウモリなら捕まえられるかもしれないわ。あれはネズミにそっくりだもの。でも、猫はコウモリを食べるのかしら？」ここでアリスは、だいぶ眠くなってきて、夢うつつに独り言を繰り返した。「猫はコウモリを食べるの？　猫はコウモリを食べるの？」ときには、「コウモリは猫を食べるの？」とも。どちらの問いにも答えられないのだから、どちらの言い方をしても、大して違いはなかったのだ。アリスは、うとうとしはじめたのを感じていた。そして、ダイナと手をつないで歩きながら、とても真剣に「ねえ、ダイナ、本当のことを教えて。今までにコウモリを食べたことがある？」と話しかける夢を、ちょうど見はじめたとき、突然、どすん！　どさっ！　小枝と枯れ葉の山の上へ落ちて、落下は終わった。

<a id="AW-01-011"></a>

**AW-01-011**

<!-- EN:AW-01-011 -->
Alice was not a bit hurt, and she jumped up on to her feet in a moment: she looked up, but it was all dark overhead; before her was another long passage, and the White Rabbit was still in sight, hurrying down it. There was not a moment to be lost: away went Alice like the wind, and was just in time to hear it say, as it turned a corner, “Oh my ears and whiskers, how late it’s getting!” She was close behind it when she turned the corner, but the Rabbit was no longer to be seen: she found herself in a long, low hall, which was lit up by a row of lamps hanging from the roof.
<!-- /EN:AW-01-011 -->

> アリスは少しもけがをせず、すぐに跳ね起きた。見上げてみても、頭の上は真っ暗だ。目の前には、また長い通路が延びていて、白ウサギがそこを急いでいく姿が、まだ見えた。一瞬もぐずぐずしていられない。アリスは風のように駆けだし、ウサギが角を曲がりながら、「ああ、耳もひげも大変だ、こんなに遅くなってしまった！」と言うのを聞くのに、ちょうど間に合った。そのすぐあとを追って角を曲がったのに、ウサギの姿はもう見えない。アリスは、天井から一列につるされたランプに照らされた、細長くて天井の低い広間にいた。

<a id="AW-01-012"></a>

**AW-01-012**

<!-- EN:AW-01-012 -->
There were doors all round the hall, but they were all locked; and when Alice had been all the way down one side and up the other, trying every door, she walked sadly down the middle, wondering how she was ever to get out again.
<!-- /EN:AW-01-012 -->

> 広間の周りには、ぐるりと扉があったが、どれも鍵が掛かっていた。アリスは片側の端まで行っては反対側を戻り、すべての扉を試してみた。それから、どうすればまた外へ出られるのだろうと思いながら、悲しい気持ちで広間の真ん中を歩いた。

<a id="AW-01-013"></a>

**AW-01-013**

<!-- EN:AW-01-013 -->
Suddenly she came upon a little three-legged table, all made of solid glass; there was nothing on it except a tiny golden key, and Alice’s first thought was that it might belong to one of the doors of the hall; but, alas! either the locks were too large, or the key was too small, but at any rate it would not open any of them. However, on the second time round, she came upon a low curtain she had not noticed before, and behind it was a little door about fifteen inches high: she tried the little golden key in the lock, and to her great delight it fitted!
<!-- /EN:AW-01-013 -->

> ふいに、三本脚の小さなテーブルが目に入った。全部が厚いガラスでできている。その上には、ちっぽけな金色の鍵が一つあるだけだった。アリスはまず、広間のどれかの扉の鍵かもしれない、と思った。ところが、ああ、鍵穴が大きすぎるのか、鍵が小さすぎるのか、とにかく、どの扉も開かない。けれども二度目に回ったとき、それまで気づかなかった丈の低いカーテンがあった。その後ろには、高さ十五インチほどの小さな扉があった。小さな金色の鍵を鍵穴に差してみると、うれしいことに、ぴったり合ったのだ！

<a id="AW-01-014"></a>

**AW-01-014**

<!-- EN:AW-01-014 -->
Alice opened the door and found that it led into a small passage, not much larger than a rat-hole: she knelt down and looked along the passage into the loveliest garden you ever saw. How she longed to get out of that dark hall, and wander about among those beds of bright flowers and those cool fountains, but she could not even get her head through the doorway; “and even if my head would go through,” thought poor Alice, “it would be of very little use without my shoulders. Oh, how I wish I could shut up like a telescope! I think I could, if I only knew how to begin.” For, you see, so many out-of-the-way things had happened lately, that Alice had begun to think that very few things indeed were really impossible.
<!-- /EN:AW-01-014 -->

> アリスが扉を開けると、大ネズミの穴より少し大きいくらいの、小さな通路につながっていた。ひざまずいて、その奥をのぞくと、これまで見たこともないほど美しい庭が見えた。暗い広間を抜け出して、鮮やかな花の咲く花壇や、涼しげな噴水の間を歩き回れたら、どんなにいいだろう！　けれども、扉には頭さえ通らない。「たとえ頭が通ったとしても」と、かわいそうなアリスは考えた。「肩が一緒でなければ、ほとんど役に立たないわ。ああ、望遠鏡みたいに縮めたらいいのに！　どうやりはじめればいいかさえ分かれば、できると思うんだけど。」というのも、さっきから変わったことが次々と起きたので、本当にできないことなど、ごくわずかしかないのではないかと、アリスは思いはじめていたのだ。

<a id="AW-01-015"></a>

**AW-01-015**

<!-- EN:AW-01-015 -->
There seemed to be no use in waiting by the little door, so she went back to the table, half hoping she might find another key on it, or at any rate a book of rules for shutting people up like telescopes: this time she found a little bottle on it, (“which certainly was not here before,” said Alice,) and round the neck of the bottle was a paper label, with the words “DRINK ME,” beautifully printed on it in large letters.
<!-- /EN:AW-01-015 -->

> 小さな扉のそばで待っていても、役に立ちそうにない。そこでアリスは、別の鍵があるかもしれない、それがなくても、人を望遠鏡のように縮めるための手順書くらいはあるかもしれないと、半ば期待しながら、テーブルに戻った。今度は、その上に小さな瓶を見つけた。（「さっきは、ここに絶対なかったわ」とアリスは言った。）瓶の首には紙の札が巻いてあり、大きな字で、きれいに「わたしを飲んで」と印刷されていた。

<a id="AW-01-016"></a>

**AW-01-016**

<!-- EN:AW-01-016 -->
It was all very well to say “Drink me,” but the wise little Alice was not going to do *that* in a hurry. “No, I’ll look first,” she said, “and see whether it’s marked ‘*poison*’ or not”; for she had read several nice little histories about children who had got burnt, and eaten up by wild beasts and other unpleasant things, all because they *would* not remember the simple rules their friends had taught them: such as, that a red-hot poker will burn you if you hold it too long; and that if you cut your finger *very* deeply with a knife, it usually bleeds; and she had never forgotten that, if you drink much from a bottle marked “poison,” it is almost certain to disagree with you, sooner or later.
<!-- /EN:AW-01-016 -->

> 「わたしを飲んで」と言うのは結構だが、賢い小さなアリスは、そう慌てて*飲んだり*はしない。「いいえ、まずは確かめるわ」と言った。「『*毒*』と書いてないかどうかをね。」アリスは、やけどをしたり、野獣に食べられたり、ほかにも嫌な目に遭った子どもたちの、かわいらしいお話をいくつか読んでいた。その子たちはみんな、周りの人が教えてくれた簡単な決まりを、*どうしても*覚えようとしなかったせいで、そんなことになったのだ。例えば、真っ赤に焼けた火かき棒を長く握っていればやけどをする、とか、ナイフで指を*とても*深く切れば、たいてい血が出る、とか。そしてアリスは、「毒」と書かれた瓶からたくさん飲むと、遅かれ早かれ、ほぼ間違いなく具合が悪くなるということを、一度も忘れたことがなかった。

<a id="AW-01-017"></a>

**AW-01-017**

<!-- EN:AW-01-017 -->
However, this bottle was *not* marked “poison,” so Alice ventured to taste it, and finding it very nice, (it had, in fact, a sort of mixed flavour of cherry-tart, custard, pine-apple, roast turkey, toffee, and hot buttered toast,) she very soon finished it off.
<!-- /EN:AW-01-017 -->

> けれども、この瓶には「毒」とは書いて*なかった*。そこでアリスは思い切って味を見た。とてもおいしかったので（実際、サクランボのタルト、カスタード、パイナップル、七面鳥の丸焼き、トフィー、それに熱々のバタートーストの味が、混ざり合ったような味だった）、あっという間に全部飲んでしまった。

<a id="AW-01-018"></a>

<!-- EN:AW-01-018 -->
\*      \*      \*      \*      \*      \*      \*  
<!-- /EN:AW-01-018 -->

<a id="AW-01-019"></a>

<!-- EN:AW-01-019 -->
    \*      \*      \*      \*      \*      \*  
<!-- /EN:AW-01-019 -->

<a id="AW-01-020"></a>

<!-- EN:AW-01-020 -->
\*      \*      \*      \*      \*      \*      \*
<!-- /EN:AW-01-020 -->

<a id="AW-01-021"></a>

**AW-01-021**

<!-- EN:AW-01-021 -->
“What a curious feeling!” said Alice; “I must be shutting up like a telescope.”
<!-- /EN:AW-01-021 -->

> 「何て変な感じなの！」とアリスは言った。「きっと、望遠鏡みたいに縮んでいるんだわ。」

<a id="AW-01-022"></a>

**AW-01-022**

<!-- EN:AW-01-022 -->
And so it was indeed: she was now only ten inches high, and her face brightened up at the thought that she was now the right size for going through the little door into that lovely garden. First, however, she waited for a few minutes to see if she was going to shrink any further: she felt a little nervous about this; “for it might end, you know,” said Alice to herself, “in my going out altogether, like a candle. I wonder what I should be like then?” And she tried to fancy what the flame of a candle is like after the candle is blown out, for she could not remember ever having seen such a thing.
<!-- /EN:AW-01-022 -->

> 本当に、そのとおりだった。今では、背の高さがたった十インチしかない。これで、あの小さな扉を通って美しい庭へ行くのに、ちょうどいい大きさになったのだと思うと、顔がぱっと明るくなった。けれどもまず、それ以上縮まないか、数分間待ってみた。そのことが少し心配だったのだ。「だって、しまいには」とアリスは独り言を言った。「ろうそくみたいに、すっかり消えてしまうかもしれないもの。そうなったら、どんなふうになるのかしら？」そして、吹き消されたあとのろうそくの炎は、どんなものか想像してみようとした。そんなものを見た覚えは、どうしてもなかったからだ。

<a id="AW-01-023"></a>

**AW-01-023**

<!-- EN:AW-01-023 -->
After a while, finding that nothing more happened, she decided on going into the garden at once; but, alas for poor Alice! when she got to the door, she found she had forgotten the little golden key, and when she went back to the table for it, she found she could not possibly reach it: she could see it quite plainly through the glass, and she tried her best to climb up one of the legs of the table, but it was too slippery; and when she had tired herself out with trying, the poor little thing sat down and cried.
<!-- /EN:AW-01-023 -->

> しばらくたっても、それ以上何も起きなかったので、すぐに庭へ行くことにした。ところが、かわいそうなアリス！　扉のところへ来てみると、小さな金色の鍵を忘れてきたことに気づき、取りにテーブルへ戻ると、今度はどうやっても届かないのだ。ガラス越しに、はっきり見えているのに。テーブルの脚の一本を、何とかよじ登ろうとしたが、つるつる滑りすぎた。何度もやって、すっかり疲れ果てると、かわいそうな小さなアリスは、座り込んで泣きだした。

<a id="AW-01-024"></a>

**AW-01-024**

<!-- EN:AW-01-024 -->
“Come, there’s no use in crying like that!” said Alice to herself, rather sharply; “I advise you to leave off this minute!” She generally gave herself very good advice, (though she very seldom followed it), and sometimes she scolded herself so severely as to bring tears into her eyes; and once she remembered trying to box her own ears for having cheated herself in a game of croquet she was playing against herself, for this curious child was very fond of pretending to be two people. “But it’s no use now,” thought poor Alice, “to pretend to be two people! Why, there’s hardly enough of me left to make *one* respectable person!”
<!-- /EN:AW-01-024 -->

> 「さあ、そんなふうに泣いても、何の役にも立たないわ！」とアリスは、自分に向かってかなり厳しく言った。「今すぐやめることを、お勧めするわ！」アリスはたいてい、自分にとてもよい忠告をした（もっとも、それに従うことは、めったになかった）。ときには、目に涙が浮かぶほど厳しく、自分を叱りつけることもあった。一度など、自分を相手にクロッケーをしていて、自分に対してずるをしたので、自分の両耳をひっぱたこうとしたのを覚えている。この変わった子は、一人で二人のふりをするのが、大好きだったのだ。「でも今は」と、かわいそうなアリスは思った。「二人のふりをしたって、役に立たないわ！　だって、まともな*一人分*にするだけのわたしも、ほとんど残っていないんだもの！」

<a id="AW-01-025"></a>

**AW-01-025**

<!-- EN:AW-01-025 -->
Soon her eye fell on a little glass box that was lying under the table: she opened it, and found in it a very small cake, on which the words “EAT ME” were beautifully marked in currants. “Well, I’ll eat it,” said Alice, “and if it makes me grow larger, I can reach the key; and if it makes me grow smaller, I can creep under the door; so either way I’ll get into the garden, and I don’t care which happens!”
<!-- /EN:AW-01-025 -->

> やがて、テーブルの下に置いてある、小さなガラスの箱が目に留まった。開けてみると、中にはとても小さなお菓子があり、その上には干しブドウで、きれいに「わたしを食べて」と書いてあった。「そうね、食べるわ」とアリスは言った。「食べて大きくなったら、鍵に届くし、小さくなったら、扉の下をくぐれるもの。だから、どちらになっても庭へ行けるわ。どちらでも構わない！」

<a id="AW-01-026"></a>

**AW-01-026**

<!-- EN:AW-01-026 -->
She ate a little bit, and said anxiously to herself, “Which way? Which way?”, holding her hand on the top of her head to feel which way it was growing, and she was quite surprised to find that she remained the same size: to be sure, this generally happens when one eats cake, but Alice had got so much into the way of expecting nothing but out-of-the-way things to happen, that it seemed quite dull and stupid for life to go on in the common way.
<!-- /EN:AW-01-026 -->

> アリスは少し食べて、「どっち？　どっち？」と、心配そうに独り言を言った。頭のてっぺんに手を置いて、どちらへ大きさが変わるのか感じ取ろうとしたのだが、大きさは同じままだったので、すっかり驚いた。もちろん、お菓子を食べても大きさが変わらないのは、普通のことだ。けれどもアリスは、変わったことばかり起きるのを期待するのに、すっかり慣れてしまっていたので、物事が普通どおりに進むのは、ひどく退屈でつまらないことに思えたのだ。

<a id="AW-01-027"></a>

**AW-01-027**

<!-- EN:AW-01-027 -->
So she set to work, and very soon finished off the cake.
<!-- /EN:AW-01-027 -->

> そこでアリスはせっせと食べはじめ、あっという間にお菓子を平らげてしまった。

<a id="AW-01-028"></a>

<!-- EN:AW-01-028 -->
\*      \*      \*      \*      \*      \*      \*  
<!-- /EN:AW-01-028 -->

<a id="AW-01-029"></a>

<!-- EN:AW-01-029 -->
    \*      \*      \*      \*      \*      \*  
<!-- /EN:AW-01-029 -->

<a id="AW-01-030"></a>

<!-- EN:AW-01-030 -->
\*      \*      \*      \*      \*      \*      \*
<!-- /EN:AW-01-030 -->

[章目次へ戻る](#book-top)

---

<a id="aw-chapter-02"></a>

## 第2章　涙の池

### CHAPTER II. The Pool of Tears

<a id="AW-02-001"></a>

**AW-02-001**

<!-- EN:AW-02-001 -->
“Curiouser and curiouser!” cried Alice (she was so much surprised, that for the moment she quite forgot how to speak good English); “now I’m opening out like the largest telescope that ever was! Good-bye, feet!” (for when she looked down at her feet, they seemed to be almost out of sight, they were getting so far off). “Oh, my poor little feet, I wonder who will put on your shoes and stockings for you now, dears? I’m sure *I* shan’t be able! I shall be a great deal too far off to trouble myself about you: you must manage the best way you can;—but I must be kind to them,” thought Alice, “or perhaps they won’t walk the way I want to go! Let me see: I’ll give them a new pair of boots every Christmas.”
<!-- /EN:AW-02-001 -->

> 「もっと不思議い、もっともっと不思議い！」とアリスは叫んだ（あまりに驚いたので、そのときばかりは、きちんとした英語の話し方をすっかり忘れてしまったのだ）。「今度は、今までにあったどんな望遠鏡よりも大きな望遠鏡みたいに、伸びているわ！　さようなら、足さん！」（足を見下ろすと、どんどん遠ざかって、もうほとんど見えなくなりそうだったからだ。）「ああ、かわいそうなわたしの小さな足さん、これからは誰が、靴や靴下をはかせてくれるのかしらね？　*わたし*には、絶対できないわ！　遠すぎて、あなたたちの世話をするどころじゃなくなるもの。どうにか自分たちで、できるだけうまくやってちょうだい。――でも、親切にしてあげなくちゃ」とアリスは思った。「そうしないと、わたしの行きたいほうへ歩いてくれないかもしれないもの！　そうね、毎年クリスマスには、新しいブーツを一足贈ってあげましょう。」

<a id="AW-02-002"></a>

**AW-02-002**

<!-- EN:AW-02-002 -->
And she went on planning to herself how she would manage it. “They must go by the carrier,” she thought; “and how funny it’ll seem, sending presents to one’s own feet! And how odd the directions will look!
<!-- /EN:AW-02-002 -->

> それから、どうしたらいいか、一人で計画を立てつづけた。「運送屋さんに届けてもらわなくちゃ」と考えた。「自分の足に贈り物をするなんて、おかしいでしょうね！　宛名だって、何て妙な具合になるんでしょう！

<a id="AW-02-003"></a>

**AW-02-003**

<!-- EN:AW-02-003 -->
<pre>
     <i>Alice’s Right Foot, Esq.,
       Hearthrug,
         near the Fender,</i>
           (<i>with Alice’s love</i>).
</pre>
<!-- /EN:AW-02-003 -->

> <pre>
>      アリスの右足　様
>        暖炉前の敷物
>          暖炉の囲いのそば
>            （アリスより愛をこめて）
> </pre>

<a id="AW-02-004"></a>

**AW-02-004**

<!-- EN:AW-02-004 -->
Oh dear, what nonsense I’m talking!”
<!-- /EN:AW-02-004 -->

> ああ、わたしったら、何てばかげたことを言っているの！」

<a id="AW-02-005"></a>

**AW-02-005**

<!-- EN:AW-02-005 -->
Just then her head struck against the roof of the hall: in fact she was now more than nine feet high, and she at once took up the little golden key and hurried off to the garden door.
<!-- /EN:AW-02-005 -->

> ちょうどそのとき、アリスの頭が広間の天井にぶつかった。実際、もう九フィートを超える高さになっていたのだ。アリスはすぐに、小さな金色の鍵を取り上げ、庭へ通じる扉へ急いだ。

<a id="AW-02-006"></a>

**AW-02-006**

<!-- EN:AW-02-006 -->
Poor Alice! It was as much as she could do, lying down on one side, to look through into the garden with one eye; but to get through was more hopeless than ever: she sat down and began to cry again.
<!-- /EN:AW-02-006 -->

> かわいそうなアリス！　横向きに寝そべって、片方の目で庭をのぞくのが、精いっぱいだった。通り抜ける望みは、前よりもさらにない。アリスは座り込んで、また泣きはじめた。

<a id="AW-02-007"></a>

**AW-02-007**

<!-- EN:AW-02-007 -->
“You ought to be ashamed of yourself,” said Alice, “a great girl like you,” (she might well say this), “to go on crying in this way! Stop this moment, I tell you!” But she went on all the same, shedding gallons of tears, until there was a large pool all round her, about four inches deep and reaching half down the hall.
<!-- /EN:AW-02-007 -->

> 「恥ずかしいと思いなさい」とアリスは言った。「あなたみたいな大きな子が」（こう言うのも、もっともだ）「こんなふうに泣きつづけるなんて！　今すぐやめなさいって、言ってるのよ！」けれども、やっぱり泣くのをやめられず、何ガロンもの涙を流した。とうとう、周り一面に深さ四インチほどの大きな池ができ、広間の半分まで広がってしまった。

<a id="AW-02-008"></a>

**AW-02-008**

<!-- EN:AW-02-008 -->
After a time she heard a little pattering of feet in the distance, and she hastily dried her eyes to see what was coming. It was the White Rabbit returning, splendidly dressed, with a pair of white kid gloves in one hand and a large fan in the other: he came trotting along in a great hurry, muttering to himself as he came, “Oh! the Duchess, the Duchess! Oh! won’t she be savage if I’ve kept her waiting!” Alice felt so desperate that she was ready to ask help of any one; so, when the Rabbit came near her, she began, in a low, timid voice, “If you please, sir—” The Rabbit started violently, dropped the white kid gloves and the fan, and skurried away into the darkness as hard as he could go.
<!-- /EN:AW-02-008 -->

> しばらくすると、遠くで、ぱたぱたと小さな足音がした。何が来るのか見ようと、アリスは急いで涙を拭いた。戻ってきた白ウサギだ。立派な身なりで、片手には白い子ヤギ革の手袋を一組、もう片方の手には大きな扇を持っている。大急ぎで小走りにやって来ながら、「ああ！　公爵夫人が、公爵夫人が！　ああ、待たせていたら、どんなにお怒りになることか！」と独り言を言っている。アリスはすっかり途方に暮れていて、誰にでも助けを頼むつもりだった。そこで、ウサギが近づくと、小さなおずおずした声で、「恐れ入りますが――」と言いかけた。ウサギはびくりと飛び上がり、白い子ヤギ革の手袋と扇を落とすと、一目散に暗がりへ逃げていった。

<a id="AW-02-009"></a>

**AW-02-009**

<!-- EN:AW-02-009 -->
Alice took up the fan and gloves, and, as the hall was very hot, she kept fanning herself all the time she went on talking: “Dear, dear! How queer everything is to-day! And yesterday things went on just as usual. I wonder if I’ve been changed in the night? Let me think: was I the same when I got up this morning? I almost think I can remember feeling a little different. But if I’m not the same, the next question is, Who in the world am I? Ah, *that’s* the great puzzle!” And she began thinking over all the children she knew that were of the same age as herself, to see if she could have been changed for any of them.
<!-- /EN:AW-02-009 -->

> アリスは扇と手袋を拾った。広間はとても暑かったので、話している間じゅう、扇であおぎつづけた。「まあ、まったく！　今日は何もかも、何ておかしいんでしょう！　昨日は、何もかもいつもどおりだったのに。夜のうちに、わたしが変わってしまったのかしら？　考えてみましょう。今朝起きたとき、わたしは同じわたしだったかしら？　少し違う感じがしたような気もするわ。でも、同じでないなら、次の問題は、わたしはいったい誰なのか、ということね。ああ、*それが*大きな謎なのよ！」そして、自分と同じ年ごろの、知っている子どもたちを一人ずつ思い浮かべ、自分が誰かに変わってしまったのか、考えはじめた。

<a id="AW-02-010"></a>

**AW-02-010**

<!-- EN:AW-02-010 -->
“I’m sure I’m not Ada,” she said, “for her hair goes in such long ringlets, and mine doesn’t go in ringlets at all; and I’m sure I can’t be Mabel, for I know all sorts of things, and she, oh! she knows such a very little! Besides, *she’s* she, and *I’m* I, and—oh dear, how puzzling it all is! I’ll try if I know all the things I used to know. Let me see: four times five is twelve, and four times six is thirteen, and four times seven is—oh dear! I shall never get to twenty at that rate! However, the Multiplication Table doesn’t signify: let’s try Geography. London is the capital of Paris, and Paris is the capital of Rome, and Rome—no, *that’s* all wrong, I’m certain! I must have been changed for Mabel! I’ll try and say ‘*How doth the little*—’” and she crossed her hands on her lap as if she were saying lessons, and began to repeat it, but her voice sounded hoarse and strange, and the words did not come the same as they used to do:—
<!-- /EN:AW-02-010 -->

> 「エイダでないことは確かね」とアリスは言った。「あの子の髪は、長い巻き毛になっているけれど、わたしの髪はちっとも巻いていないもの。それに、メイベルのはずもないわ。わたしはいろんなことを知っているけれど、あの子は、もう、本当に少ししか知らないんだもの！　それに、*あの子*はあの子で、*わたし*はわたしで――ああ、何もかも、何てややこしいんでしょう！　前に知っていたことを、全部まだ知っているか、試してみましょう。ええと、四かける五は十二、四かける六は十三、四かける七は――ああ！　こんな調子じゃ、いつまでたっても二十にならないわ！　でも、掛け算の表なんて、どうでもいいわね。地理を試しましょう。ロンドンはパリの首都、パリはローマの首都、そしてローマは――違うわ、*それは*全部間違いに決まっている！　やっぱり、メイベルに変わってしまったんだわ！　『*小さなものは、いかにして*――』を言ってみよう」と、授業で暗唱をするときのように、両手を膝の上で重ねて、唱えはじめた。けれども声は、かすれて変に聞こえ、言葉も以前と同じようには出てこなかった。――

<a id="AW-02-011"></a>

**AW-02-011**

<!-- EN:AW-02-011 -->
“How doth the little crocodile  
    Improve his shining tail,  
And pour the waters of the Nile  
    On every golden scale!  
<!-- /EN:AW-02-011 -->

> 「小さなワニは、何とまあ  
> 　　輝くしっぽを磨くこと、  
> ナイルの水を振りかけて  
> 　　金色のうろこ、一枚ずつに！

<a id="AW-02-012"></a>

**AW-02-012**

<!-- EN:AW-02-012 -->
“How cheerfully he seems to grin,  
    How neatly spread his claws,  
And welcome little fishes in  
    With gently smiling jaws!”
<!-- /EN:AW-02-012 -->

> 「何とうれしげに、にっこり笑い、  
> 　　何ときれいに、爪を広げ、  
> 小さな魚を迎え入れること、  
> 　　やさしくほほえむ、その口の中へ！」

<a id="AW-02-013"></a>

**AW-02-013**

<!-- EN:AW-02-013 -->
“I’m sure those are not the right words,” said poor Alice, and her eyes filled with tears again as she went on, “I must be Mabel after all, and I shall have to go and live in that poky little house, and have next to no toys to play with, and oh! ever so many lessons to learn! No, I’ve made up my mind about it; if I’m Mabel, I’ll stay down here! It’ll be no use their putting their heads down and saying ‘Come up again, dear!’ I shall only look up and say ‘Who am I then? Tell me that first, and then, if I like being that person, I’ll come up: if not, I’ll stay down here till I’m somebody else’—but, oh dear!” cried Alice, with a sudden burst of tears, “I do wish they *would* put their heads down! I am so *very* tired of being all alone here!”
<!-- /EN:AW-02-013 -->

> 「あれは、正しい言葉じゃないわ、絶対に」と、かわいそうなアリスは言った。また目に涙をいっぱい浮かべながら、続けた。「やっぱり、わたしはメイベルなのね。あの窮屈な小さな家に住みに行って、遊ぶおもちゃもほとんどなくて、そのうえ、ああ、山ほどお勉強をしなくちゃいけないんだわ！　いいえ、もう決めた。わたしがメイベルなら、ここにいるわ！　みんなが上から顔をのぞかせて、『さあ、戻っておいで！』と言ったって、無駄よ。ただ見上げて、こう言うんだから。『それなら、わたしは誰なの？　先にそれを教えて。その人でいたいと思ったら、上がっていくわ。そうでなければ、別の誰かになるまで、ここにいるわ』――でも、ああ！」とアリスは叫び、急にわっと泣きだした。「誰かが、本当に顔をのぞかせて*くれたら*いいのに！　ここでたった一人でいるのは、*もう本当に*嫌なのよ！」

<a id="AW-02-014"></a>

**AW-02-014**

<!-- EN:AW-02-014 -->
As she said this she looked down at her hands, and was surprised to see that she had put on one of the Rabbit’s little white kid gloves while she was talking. “How *can* I have done that?” she thought. “I must be growing small again.” She got up and went to the table to measure herself by it, and found that, as nearly as she could guess, she was now about two feet high, and was going on shrinking rapidly: she soon found out that the cause of this was the fan she was holding, and she dropped it hastily, just in time to avoid shrinking away altogether.
<!-- /EN:AW-02-014 -->

> そう言いながら手を見下ろしたアリスは、話している間に、ウサギの小さな白い子ヤギ革の手袋を片方はめていたのを見て、驚いた。「どうして、そんなことが*できた*のかしら？」と考えた。「また、小さくなっているに違いないわ。」立ち上がってテーブルへ行き、それと比べて自分の背を測ってみた。できるだけ見当をつけたところ、今は高さが二フィートほどで、そのうえ、急速に縮みつづけていた。すぐに、手に持っている扇が原因だと分かったので、慌てて放り出した。完全に縮んで消えてしまう寸前で、どうにか間に合った。

<a id="AW-02-015"></a>

**AW-02-015**

<!-- EN:AW-02-015 -->
“That *was* a narrow escape!” said Alice, a good deal frightened at the sudden change, but very glad to find herself still in existence; “and now for the garden!” and she ran with all speed back to the little door: but, alas! the little door was shut again, and the little golden key was lying on the glass table as before, “and things are worse than ever,” thought the poor child, “for I never was so small as this before, never! And I declare it’s too bad, that it is!”
<!-- /EN:AW-02-015 -->

> 「*本当に*、危ないところだったわ！」とアリスは言った。突然の変化に、かなりおびえていたが、まだ自分が存在していると分かって、とてもうれしかったのだ。「さあ、今度こそ庭へ！」小さな扉へ、全速力で駆け戻った。けれども、ああ！　小さな扉は、また閉まっていた。小さな金色の鍵も、前と同じようにガラスのテーブルの上だ。「何もかも、今まででいちばんひどくなっているわ」と、かわいそうなアリスは思った。「だって、こんなに小さくなったことなんて、一度もなかったもの、一度も！　本当にひどいわ、ひどすぎる！」

<a id="AW-02-016"></a>

**AW-02-016**

<!-- EN:AW-02-016 -->
As she said these words her foot slipped, and in another moment, splash! she was up to her chin in salt water. Her first idea was that she had somehow fallen into the sea, “and in that case I can go back by railway,” she said to herself. (Alice had been to the seaside once in her life, and had come to the general conclusion, that wherever you go to on the English coast you find a number of bathing machines in the sea, some children digging in the sand with wooden spades, then a row of lodging houses, and behind them a railway station.) However, she soon made out that she was in the pool of tears which she had wept when she was nine feet high.
<!-- /EN:AW-02-016 -->

> そう言うと、足が滑り、次の瞬間、ばしゃん！　あごまで塩水につかっていた。最初は、どういうわけか海に落ちたのだと思った。「それなら、鉄道で帰れるわ」と独り言を言った。（アリスはこれまでに、一度だけ海辺へ行ったことがあった。そして、イングランドの海岸ならどこへ行っても、海の中には何台もの移動式の更衣小屋があり、子どもたちが木のシャベルで砂を掘り、その向こうには宿が並び、その後ろに鉄道の駅があるものだ、と結論を出していたのだ。）けれどもすぐに、背が九フィートあったときに泣いて作った、涙の池にいるのだと分かった。

<a id="AW-02-017"></a>

**AW-02-017**

<!-- EN:AW-02-017 -->
“I wish I hadn’t cried so much!” said Alice, as she swam about, trying to find her way out. “I shall be punished for it now, I suppose, by being drowned in my own tears! That *will* be a queer thing, to be sure! However, everything is queer to-day.”
<!-- /EN:AW-02-017 -->

> 「あんなに泣かなければよかった！」とアリスは、外へ出る道を探して泳ぎ回りながら言った。「自分の涙でおぼれるのが、その罰になるんでしょうね！　それは確かに、*ずいぶん*おかしなことになるわ！　もっとも、今日は何もかもおかしいんだけど。」

<a id="AW-02-018"></a>

**AW-02-018**

<!-- EN:AW-02-018 -->
Just then she heard something splashing about in the pool a little way off, and she swam nearer to make out what it was: at first she thought it must be a walrus or hippopotamus, but then she remembered how small she was now, and she soon made out that it was only a mouse that had slipped in like herself.
<!-- /EN:AW-02-018 -->

> ちょうどそのとき、少し離れたところで、何かが池の水をばしゃばしゃさせる音がした。何なのか見ようと、アリスは泳いで近づいた。初めは、セイウチかカバに違いないと思ったが、それから、今の自分がどんなに小さいかを思い出した。じきに、それは自分と同じように滑り落ちた、ただのネズミだと分かった。

<a id="AW-02-019"></a>

**AW-02-019**

<!-- EN:AW-02-019 -->
“Would it be of any use, now,” thought Alice, “to speak to this mouse? Everything is so out-of-the-way down here, that I should think very likely it can talk: at any rate, there’s no harm in trying.” So she began: “O Mouse, do you know the way out of this pool? I am very tired of swimming about here, O Mouse!” (Alice thought this must be the right way of speaking to a mouse: she had never done such a thing before, but she remembered having seen in her brother’s Latin Grammar, “A mouse—of a mouse—to a mouse—a mouse—O mouse!”) The Mouse looked at her rather inquisitively, and seemed to her to wink with one of its little eyes, but it said nothing.
<!-- /EN:AW-02-019 -->

> 「このネズミに話しかけてみたら」とアリスは考えた。「何かの役に立つかしら？　ここの下では、何もかも普通と違うから、きっと話せるんじゃないかしら。とにかく、試して損はないわ。」そこで、話しかけた。「おお、ネズミよ、この池から出る道を知っていますか？　ここを泳ぎ回るのは、もうすっかり疲れてしまったのです、おお、ネズミよ！」（アリスは、これがネズミへの正しい話しかけ方に違いないと思っていた。そんなことをしたのは初めてだったが、兄のラテン語文法の本に、「ネズミが――ネズミの――ネズミに――ネズミを――おお、ネズミよ！」とあるのを見た覚えがあったのだ。）ネズミは、ずいぶん物珍しそうにアリスを見た。小さな目の片方で、ウインクしたようにも見えたが、何も言わなかった。

<a id="AW-02-020"></a>

**AW-02-020**

<!-- EN:AW-02-020 -->
“Perhaps it doesn’t understand English,” thought Alice; “I daresay it’s a French mouse, come over with William the Conqueror.” (For, with all her knowledge of history, Alice had no very clear notion how long ago anything had happened.) So she began again: “Où est ma chatte?” which was the first sentence in her French lesson-book. The Mouse gave a sudden leap out of the water, and seemed to quiver all over with fright. “Oh, I beg your pardon!” cried Alice hastily, afraid that she had hurt the poor animal’s feelings. “I quite forgot you didn’t like cats.”
<!-- /EN:AW-02-020 -->

> 「英語が分からないのかもしれないわ」とアリスは思った。「きっと、征服王ウィリアムと一緒に渡ってきた、フランスのネズミなんだわ。」（歴史の知識はあっても、それぞれのことがどのくらい昔に起きたのか、アリスには、あまりはっきり分かっていなかった。）そこで、もう一度話しかけた。「Où est ma chatte?――わたしの猫はどこですか？」フランス語の教科書の、最初の文だ。ネズミは突然、水の上へ跳び上がり、恐怖で全身を震わせているようだった。「ああ、ごめんなさい！」とアリスは慌てて叫んだ。かわいそうなネズミの気を悪くしたのではないかと思ったのだ。「あなたが猫を嫌いなこと、すっかり忘れていたわ。」

<a id="AW-02-021"></a>

**AW-02-021**

<!-- EN:AW-02-021 -->
“Not like cats!” cried the Mouse, in a shrill, passionate voice. “Would *you* like cats if you were me?”
<!-- /EN:AW-02-021 -->

> 「猫が嫌いだって！」とネズミは、甲高い、怒りに満ちた声で叫んだ。「*きみ*だって、私だったら猫が好きでいられるかい？」

<a id="AW-02-022"></a>

**AW-02-022**

<!-- EN:AW-02-022 -->
“Well, perhaps not,” said Alice in a soothing tone: “don’t be angry about it. And yet I wish I could show you our cat Dinah: I think you’d take a fancy to cats if you could only see her. She is such a dear quiet thing,” Alice went on, half to herself, as she swam lazily about in the pool, “and she sits purring so nicely by the fire, licking her paws and washing her face—and she is such a nice soft thing to nurse—and she’s such a capital one for catching mice—oh, I beg your pardon!” cried Alice again, for this time the Mouse was bristling all over, and she felt certain it must be really offended. “We won’t talk about her any more if you’d rather not.”
<!-- /EN:AW-02-022 -->

> 「そうね、好きにはなれないかも」とアリスは、なだめるように言った。「そんなに怒らないで。でも、うちの猫のダイナを見せてあげられたらいいのに。あの子を見さえすれば、猫が好きになると思うわ。とってもかわいくて、おとなしい子なのよ」と、アリスは池をのんびり泳ぎながら、半ば独り言のように続けた。「暖炉のそばに座って、気持ちよさそうに喉を鳴らして、前足をなめて、顔を洗うの――それに、柔らかくて、抱くと本当にいい気持ちなの――そして、ネズミを捕まえるのが、ものすごく上手で――ああ、ごめんなさい！」とアリスは、また叫んだ。今度はネズミが全身の毛を逆立てていたので、本当に怒らせたに違いないと思ったのだ。「嫌なら、あの子のことを話すのは、もうやめましょう。」

<a id="AW-02-023"></a>

**AW-02-023**

<!-- EN:AW-02-023 -->
“We indeed!” cried the Mouse, who was trembling down to the end of his tail. “As if *I* would talk on such a subject! Our family always *hated* cats: nasty, low, vulgar things! Don’t let me hear the name again!”
<!-- /EN:AW-02-023 -->

> 「『やめましょう』とは、何だ！」と、しっぽの先まで震わせながら、ネズミは叫んだ。「まるで*私まで*、そんな話をする気でもあるようじゃないか！　私たち一族は、昔から猫が*大嫌い*なんだ。いやらしくて、卑しくて、下品なやつらめ！　二度と、その名を聞かせないでくれ！」

<a id="AW-02-024"></a>

**AW-02-024**

<!-- EN:AW-02-024 -->
“I won’t indeed!” said Alice, in a great hurry to change the subject of conversation. “Are you—are you fond—of—of dogs?” The Mouse did not answer, so Alice went on eagerly: “There is such a nice little dog near our house I should like to show you! A little bright-eyed terrier, you know, with oh, such long curly brown hair! And it’ll fetch things when you throw them, and it’ll sit up and beg for its dinner, and all sorts of things—I can’t remember half of them—and it belongs to a farmer, you know, and he says it’s so useful, it’s worth a hundred pounds! He says it kills all the rats and—oh dear!” cried Alice in a sorrowful tone, “I’m afraid I’ve offended it again!” For the Mouse was swimming away from her as hard as it could go, and making quite a commotion in the pool as it went.
<!-- /EN:AW-02-024 -->

> 「ええ、絶対に！」とアリスは言い、慌てて話題を変えようとした。「あなたは――あなたは、す、好きかしら――い、犬は？」ネズミが答えなかったので、アリスは熱心に続けた。「うちの近くに、とってもかわいい小犬がいるの。あなたにも見せてあげたいわ！　目のきらきらした小さなテリアでね、茶色の巻き毛が、もう、本当に長いの！　物を投げれば取ってくるし、ごはんが欲しいと後ろ足で座っておねだりするし、ほかにもいろいろ――半分も思い出せないくらい。農家の人が飼っているんだけど、その人は、とても役に立つから百ポンドの値打ちがあるって言っているわ！　大ネズミを全部殺して、それから――ああ！」とアリスは、悲しそうに叫んだ。「また、怒らせてしまったみたい！」ネズミは池の水をひどくかき乱しながら、全力で泳いで遠ざかっていたのだ。

<a id="AW-02-025"></a>

**AW-02-025**

<!-- EN:AW-02-025 -->
So she called softly after it, “Mouse dear! Do come back again, and we won’t talk about cats or dogs either, if you don’t like them!” When the Mouse heard this, it turned round and swam slowly back to her: its face was quite pale (with passion, Alice thought), and it said in a low trembling voice, “Let us get to the shore, and then I’ll tell you my history, and you’ll understand why it is I hate cats and dogs.”
<!-- /EN:AW-02-025 -->

> そこで、アリスは優しく呼びかけた。「ねえ、ネズミさん！　戻ってきてちょうだい。あなたが嫌いなら、猫の話も、犬の話もしないから！」それを聞くと、ネズミは振り向き、ゆっくり泳いで戻ってきた。顔は真っ青だった（怒っているからだ、とアリスは思った）。そして、低い震える声で言った。「岸へ行こう。そうしたら、私の身の上話を聞かせる。なぜ猫や犬が嫌いなのか、分かるだろう。」

<a id="AW-02-026"></a>

**AW-02-026**

<!-- EN:AW-02-026 -->
It was high time to go, for the pool was getting quite crowded with the birds and animals that had fallen into it: there were a Duck and a Dodo, a Lory and an Eaglet, and several other curious creatures. Alice led the way, and the whole party swam to the shore.
<!-- /EN:AW-02-026 -->

> 岸へ行くには、もう頃合いだった。落ちてきた鳥や獣で、池はすっかり混み合っていたのだ。アヒル、ドードー、インコ、ワシのひな、そのほかにも、いろいろと珍しい生き物がいた。アリスが先頭に立ち、一同は岸へ泳いでいった。

[章目次へ戻る](#book-top)

---

<a id="aw-chapter-03"></a>

## 第3章　コーカス競走と長いお話

### CHAPTER III. A Caucus-Race and a Long Tale

<a id="AW-03-001"></a>

**AW-03-001**

<!-- EN:AW-03-001 -->
They were indeed a queer-looking party that assembled on the bank—the birds with draggled feathers, the animals with their fur clinging close to them, and all dripping wet, cross, and uncomfortable.
<!-- /EN:AW-03-001 -->

> 岸辺に集まった一同は、本当に奇妙な姿だった。鳥の羽は濡れてだらりと垂れ、獣の毛は体にぴったり張りつき、みんな、びしょ濡れで、いらいらして、気分も悪かったのだ。

<a id="AW-03-002"></a>

**AW-03-002**

<!-- EN:AW-03-002 -->
The first question of course was, how to get dry again: they had a consultation about this, and after a few minutes it seemed quite natural to Alice to find herself talking familiarly with them, as if she had known them all her life. Indeed, she had quite a long argument with the Lory, who at last turned sulky, and would only say, “I am older than you, and must know better;” and this Alice would not allow without knowing how old it was, and, as the Lory positively refused to tell its age, there was no more to be said.
<!-- /EN:AW-03-002 -->

> もちろん、まず問題になったのは、どうやって体を乾かすかだった。みんなで相談をはじめたが、数分もすると、アリスには、生まれたときからずっと知っていたように、みんなと親しく話していることが、ごく自然に思えてきた。実際、インコとはかなり長く言い争った。しまいにインコは不機嫌になり、「私はきみより年上なんだから、よく知っているはずだ」としか言わなくなった。アリスは、いくつなのか分からない限り、それを認めようとしなかったし、インコは年齢を言うのをきっぱり拒んだので、それ以上は、どうにも話が進まなかった。

<a id="AW-03-003"></a>

**AW-03-003**

<!-- EN:AW-03-003 -->
At last the Mouse, who seemed to be a person of authority among them, called out, “Sit down, all of you, and listen to me! *I’ll* soon make you dry enough!” They all sat down at once, in a large ring, with the Mouse in the middle. Alice kept her eyes anxiously fixed on it, for she felt sure she would catch a bad cold if she did not get dry very soon.
<!-- /EN:AW-03-003 -->

> とうとう、一同の中では権威のある者らしいネズミが、声を張り上げた。「みんな座って、私の話を聞きなさい！　*私が*すぐに、十分乾かしてあげよう！」みんなはすぐに、ネズミを真ん中にして、大きな輪になって座った。アリスは心配そうに、じっとネズミを見つめていた。早く体を乾かさないと、ひどい風邪を引くに違いないと思ったからだ。

<a id="AW-03-004"></a>

**AW-03-004**

<!-- EN:AW-03-004 -->
“Ahem!” said the Mouse with an important air, “are you all ready? This is the driest thing I know. Silence all round, if you please! ‘William the Conqueror, whose cause was favoured by the pope, was soon submitted to by the English, who wanted leaders, and had been of late much accustomed to usurpation and conquest. Edwin and Morcar, the earls of Mercia and Northumbria—’”
<!-- /EN:AW-03-004 -->

> 「えへん！」とネズミは、もったいぶって言った。「みんな、よろしいかな？　これは、私の知る限り、いちばん乾いた話だ。皆さん、どうぞお静かに！　『その大義が教皇の支持を得ていた征服王ウィリアムに、イングランド人はまもなく服従した。彼らには指導者がおらず、近ごろは簒奪と征服に、すっかり慣れていたのである。マーシア伯とノーサンブリア伯であるエドウィンとモーカーは――』」

> **訳注：** dry には「乾いた」のほか、「退屈で味気ない」という意味がある。ネズミはその二つを重ねて、歴史の話で体を乾かそうとする。

<a id="AW-03-005"></a>

**AW-03-005**

<!-- EN:AW-03-005 -->
“Ugh!” said the Lory, with a shiver.
<!-- /EN:AW-03-005 -->

> 「ううっ！」とインコは、身震いして言った。

<a id="AW-03-006"></a>

**AW-03-006**

<!-- EN:AW-03-006 -->
“I beg your pardon!” said the Mouse, frowning, but very politely: “Did you speak?”
<!-- /EN:AW-03-006 -->

> 「失礼ですが！」とネズミは、眉をひそめながらも、とても丁寧に言った。「何かおっしゃいましたか？」

<a id="AW-03-007"></a>

**AW-03-007**

<!-- EN:AW-03-007 -->
“Not I!” said the Lory hastily.
<!-- /EN:AW-03-007 -->

> 「私は何も！」とインコは慌てて言った。

<a id="AW-03-008"></a>

**AW-03-008**

<!-- EN:AW-03-008 -->
“I thought you did,” said the Mouse. “—I proceed. ‘Edwin and Morcar, the earls of Mercia and Northumbria, declared for him: and even Stigand, the patriotic archbishop of Canterbury, found it advisable—’”
<!-- /EN:AW-03-008 -->

> 「何か言ったと思ったが」とネズミは言った。「――続けよう。『マーシア伯とノーサンブリア伯であるエドウィンとモーカーは、彼への支持を表明した。そして愛国者であったカンタベリー大司教スティガンドでさえ、それが賢明だと見いだし――』」

<a id="AW-03-009"></a>

**AW-03-009**

<!-- EN:AW-03-009 -->
“Found *what*?” said the Duck.
<!-- /EN:AW-03-009 -->

> 「*何を*見つけたんだ？」とアヒルが言った。

<a id="AW-03-010"></a>

**AW-03-010**

<!-- EN:AW-03-010 -->
“Found *it*,” the Mouse replied rather crossly: “of course you know what ‘it’ means.”
<!-- /EN:AW-03-010 -->

> 「*それ*をだ」とネズミは、少しいらいらして答えた。「『それ』の意味くらい、もちろん分かるだろう。」

> **訳注：** found it advisable は「そうするのが賢明だと判断した」。アヒルは found を「何かを見つけた」と受け取り、it が何の物体を指すのか尋ねている。

<a id="AW-03-011"></a>

**AW-03-011**

<!-- EN:AW-03-011 -->
“I know what ‘it’ means well enough, when *I* find a thing,” said the Duck: “it’s generally a frog or a worm. The question is, what did the archbishop find?”
<!-- /EN:AW-03-011 -->

> 「*私が*何か見つけたときなら、『それ』が何なのか、ちゃんと分かっているさ」とアヒルは言った。「たいてい、カエルか虫だ。問題は、その大司教が何を見つけたか、ということだよ。」

<a id="AW-03-012"></a>

**AW-03-012**

<!-- EN:AW-03-012 -->
The Mouse did not notice this question, but hurriedly went on, “‘—found it advisable to go with Edgar Atheling to meet William and offer him the crown. William’s conduct at first was moderate. But the insolence of his Normans—’ How are you getting on now, my dear?” it continued, turning to Alice as it spoke.
<!-- /EN:AW-03-012 -->

> ネズミはこの問いを取り合わず、急いで続けた。「『――エドガー・アセリングとともにウィリアムを訪れ、王冠を差し出すのが賢明だと判断した。初めのうち、ウィリアムの行動は穏健だった。しかし、配下のノルマン人たちの横柄な振る舞いが――』さて、きみは今、どんな具合かな？」そう言いながらアリスのほうを向いた。

<a id="AW-03-013"></a>

**AW-03-013**

<!-- EN:AW-03-013 -->
“As wet as ever,” said Alice in a melancholy tone: “it doesn’t seem to dry me at all.”
<!-- /EN:AW-03-013 -->

> 「相変わらず、びしょ濡れよ」とアリスは、悲しそうに言った。「ちっとも乾かないみたい。」

<a id="AW-03-014"></a>

**AW-03-014**

<!-- EN:AW-03-014 -->
“In that case,” said the Dodo solemnly, rising to its feet, “I move that the meeting adjourn, for the immediate adoption of more energetic remedies—”
<!-- /EN:AW-03-014 -->

> 「それならば」とドードーは、立ち上がって厳かに言った。「ただちに、より精力的な処置を採用するため、本会議の休会を提議する――」

<a id="AW-03-015"></a>

**AW-03-015**

<!-- EN:AW-03-015 -->
“Speak English!” said the Eaglet. “I don’t know the meaning of half those long words, and, what’s more, I don’t believe you do either!” And the Eaglet bent down its head to hide a smile: some of the other birds tittered audibly.
<!-- /EN:AW-03-015 -->

> 「英語で話してよ！」とワシのひなは言った。「そんな長ったらしい言葉、半分も意味が分からないよ。それに、あなただって分かってないと思うな！」ワシのひなは、笑いを隠すために頭をうつむけた。ほかの鳥も何羽か、聞こえるほどの声でくすくす笑った。

<a id="AW-03-016"></a>

**AW-03-016**

<!-- EN:AW-03-016 -->
“What I was going to say,” said the Dodo in an offended tone, “was, that the best thing to get us dry would be a Caucus-race.”
<!-- /EN:AW-03-016 -->

> 「私が言おうとしていたのは」とドードーは、気を悪くした声で言った。「私たちの体を乾かすには、コーカス競走がいちばんだ、ということだ。」

> **訳注：** caucus は党員集会や党内会議などを指す。ここでは、その名を付けた奇妙な競走が行われる。

<a id="AW-03-017"></a>

**AW-03-017**

<!-- EN:AW-03-017 -->
“What *is* a Caucus-race?” said Alice; not that she wanted much to know, but the Dodo had paused as if it thought that *somebody* ought to speak, and no one else seemed inclined to say anything.
<!-- /EN:AW-03-017 -->

> 「コーカス競走って、*どんなもの*なの？」とアリスが聞いた。特に知りたかったわけではない。ドードーが、*誰かが*何か言うべきだと思っているように話を止めたのに、ほかの誰も、何か言う気がなさそうだったからだ。

<a id="AW-03-018"></a>

**AW-03-018**

<!-- EN:AW-03-018 -->
“Why,” said the Dodo, “the best way to explain it is to do it.” (And, as you might like to try the thing yourself, some winter day, I will tell you how the Dodo managed it.)
<!-- /EN:AW-03-018 -->

> 「なに」とドードーは言った。「いちばんよく分かる説明は、やってみることだ。」（あなたも、いつか冬の日に、自分でやってみたくなるかもしれないから、ドードーがどうしたのか、お話ししよう。）

<a id="AW-03-019"></a>

**AW-03-019**

<!-- EN:AW-03-019 -->
First it marked out a race-course, in a sort of circle, (“the exact shape doesn’t matter,” it said,) and then all the party were placed along the course, here and there. There was no “One, two, three, and away,” but they began running when they liked, and left off when they liked, so that it was not easy to know when the race was over. However, when they had been running half an hour or so, and were quite dry again, the Dodo suddenly called out “The race is over!” and they all crowded round it, panting, and asking, “But who has won?”
<!-- /EN:AW-03-019 -->

> まず、丸いような形の競走コースを、地面に印をつけて作った。（「形は、きっちりしていなくてもいい」と言った。）それから、みんなをコースのあちこちに配置した。「一、二、三、さあ走れ」という合図はない。みんな、好きなときに走りはじめ、好きなときにやめたので、競走がいつ終わったのか、分かりにくいものだった。けれども、三十分ほど走って、すっかり乾いたころ、ドードーが突然、「競走は終了！」と叫んだ。みんなは息を切らしながら、その周りに押し寄せ、「でも、誰が勝ったの？」と聞いた。

<a id="AW-03-020"></a>

**AW-03-020**

<!-- EN:AW-03-020 -->
This question the Dodo could not answer without a great deal of thought, and it sat for a long time with one finger pressed upon its forehead (the position in which you usually see Shakespeare, in the pictures of him), while the rest waited in silence. At last the Dodo said, “*Everybody* has won, and all must have prizes.”
<!-- /EN:AW-03-020 -->

> この問いに答えるには、ドードーもずいぶん考えなければならなかった。指を一本、額に押し当てたまま、長い間座り込んでいた（シェイクスピアの絵で、よく見る姿勢だ）。その間、ほかのみんなは、黙って待っていた。とうとう、ドードーは言った。「*全員*が勝った。みんなに賞品を出さなければならない。」

<a id="AW-03-021"></a>

**AW-03-021**

<!-- EN:AW-03-021 -->
“But who is to give the prizes?” quite a chorus of voices asked.
<!-- /EN:AW-03-021 -->

> 「でも、誰が賞品を出すの？」と、まるで合唱のように声が上がった。

<a id="AW-03-022"></a>

**AW-03-022**

<!-- EN:AW-03-022 -->
“Why, *she*, of course,” said the Dodo, pointing to Alice with one finger; and the whole party at once crowded round her, calling out in a confused way, “Prizes! Prizes!”
<!-- /EN:AW-03-022 -->

> 「もちろん、*この子*だ」とドードーは、一本の指でアリスを指した。たちまち一同はアリスの周りに押し寄せ、口々に「賞品！　賞品！」と叫んだ。

<a id="AW-03-023"></a>

**AW-03-023**

<!-- EN:AW-03-023 -->
Alice had no idea what to do, and in despair she put her hand in her pocket, and pulled out a box of comfits, (luckily the salt water had not got into it), and handed them round as prizes. There was exactly one a-piece, all round.
<!-- /EN:AW-03-023 -->

> アリスには、どうしたらいいのか、まったく分からなかった。困り果ててポケットに手を入れ、糖衣菓子の箱を取り出した（運よく、塩水は中へ入っていなかった）。それを賞品として、みんなに配った。全員に、ちょうど一個ずつ行き渡った。

<a id="AW-03-024"></a>

**AW-03-024**

<!-- EN:AW-03-024 -->
“But she must have a prize herself, you know,” said the Mouse.
<!-- /EN:AW-03-024 -->

> 「だが、この子自身にも賞品をあげなければね」とネズミが言った。

<a id="AW-03-025"></a>

**AW-03-025**

<!-- EN:AW-03-025 -->
“Of course,” the Dodo replied very gravely. “What else have you got in your pocket?” he went on, turning to Alice.
<!-- /EN:AW-03-025 -->

> 「もちろんだ」とドードーは、とても真面目に答えた。それからアリスに向かい、「ポケットには、ほかに何が入っている？」と続けた。

<a id="AW-03-026"></a>

**AW-03-026**

<!-- EN:AW-03-026 -->
“Only a thimble,” said Alice sadly.
<!-- /EN:AW-03-026 -->

> 「指ぬきだけよ」とアリスは、悲しそうに言った。

<a id="AW-03-027"></a>

**AW-03-027**

<!-- EN:AW-03-027 -->
“Hand it over here,” said the Dodo.
<!-- /EN:AW-03-027 -->

> 「それを、こちらへ渡してくれ」とドードーは言った。

<a id="AW-03-028"></a>

**AW-03-028**

<!-- EN:AW-03-028 -->
Then they all crowded round her once more, while the Dodo solemnly presented the thimble, saying “We beg your acceptance of this elegant thimble;” and, when it had finished this short speech, they all cheered.
<!-- /EN:AW-03-028 -->

> そこでみんなは、もう一度アリスの周りに押し寄せた。ドードーは「この優美なる指ぬきを、どうぞお受け取りください」と言いながら、厳かに指ぬきを贈呈した。この短い演説が終わると、みんなは歓声を上げた。

<a id="AW-03-029"></a>

**AW-03-029**

<!-- EN:AW-03-029 -->
Alice thought the whole thing very absurd, but they all looked so grave that she did not dare to laugh; and, as she could not think of anything to say, she simply bowed, and took the thimble, looking as solemn as she could.
<!-- /EN:AW-03-029 -->

> アリスは、何もかも実にばかばかしいと思ったが、みんながあまりに真面目な顔をしているので、とても笑えなかった。何と言ったらいいのかも思いつかず、ただお辞儀をして、できるだけ厳粛な顔で指ぬきを受け取った。

<a id="AW-03-030"></a>

**AW-03-030**

<!-- EN:AW-03-030 -->
The next thing was to eat the comfits: this caused some noise and confusion, as the large birds complained that they could not taste theirs, and the small ones choked and had to be patted on the back. However, it was over at last, and they sat down again in a ring, and begged the Mouse to tell them something more.
<!-- /EN:AW-03-030 -->

> 次は、糖衣菓子を食べる番だった。これで、少し騒ぎになった。大きな鳥たちは、味が分からないと文句を言い、小さな鳥たちは、喉に詰まらせて、背中をたたいてもらわなければならなかったのだ。それでも、ようやく食べ終えると、みんなはまた輪になって座り、ネズミに、もう少し何か話してほしいと頼んだ。

<a id="AW-03-031"></a>

**AW-03-031**

<!-- EN:AW-03-031 -->
“You promised to tell me your history, you know,” said Alice, “and why it is you hate—C and D,” she added in a whisper, half afraid that it would be offended again.
<!-- /EN:AW-03-031 -->

> 「あなたの身の上話をしてくれるって、約束したでしょう」とアリスは言った。「それから、どうして嫌いなのかも――ＣとＤを」と、また気を悪くさせるのではないかと少し怖くなり、最後のところはささやき声で付け加えた。

> **訳注：** ＣとＤは cats（猫）と dogs（犬）の頭文字。

<a id="AW-03-032"></a>

**AW-03-032**

<!-- EN:AW-03-032 -->
“Mine is a long and a sad tale!” said the Mouse, turning to Alice, and sighing.
<!-- /EN:AW-03-032 -->

> 「私のは、長くて悲しい話なのだよ！」とネズミは、アリスに向き直って、ため息をついた。

<a id="AW-03-033"></a>

**AW-03-033**

<!-- EN:AW-03-033 -->
“It *is* a long tail, certainly,” said Alice, looking down with wonder at the Mouse’s tail; “but why do you call it sad?” And she kept on puzzling about it while the Mouse was speaking, so that her idea of the tale was something like this:—
<!-- /EN:AW-03-033 -->

> 「確かに、*長い*しっぽね」とアリスは、ネズミのしっぽを不思議そうに見下ろして言った。「でも、どうして悲しいというの？」ネズミが話している間も、アリスはずっと、そのことを不思議に思っていた。そのため、アリスの思い描いた話は、こんな具合になった。――

> **訳注：** tale（話）と tail（しっぽ）は同じ発音。アリスは、ネズミの言う「長い話」を「長いしっぽ」と聞き違えている。

<a id="AW-03-034"></a>

**AW-03-034**

<!-- EN:AW-03-034 -->
<pre>
         “Fury said to a
         mouse, That he
        met in the
       house,
     ‘Let us
      both go to
       law: <i>I</i> will
        prosecute
         <i>you</i>.—Come,
           I’ll take no
           denial; We
          must have a
        trial: For
      really this
     morning I’ve
    nothing
    to do.’
      Said the
      mouse to the
       cur, ‘Such
        a trial,
         dear sir,
            With
          no jury
        or judge,
       would be
      wasting
      our
      breath.’
        ‘I’ll be
        judge, I’ll
         be jury,’
             Said
         cunning
          old Fury:
          ‘I’ll
          try the
            whole
            cause,
              and
           condemn
           you
          to
           death.’”
</pre>
<!-- /EN:AW-03-034 -->

> <pre>
>          「フューリーが
>          家で出会った
>         ネズミに言った、
>        『さあ、
>      二人で
>       裁判に
>        行こう。私が
>         おまえを
>          訴える。――さあ、
>            嫌とは
>            言わせぬ。
>           裁判は
>         どうしても
>       やるのだ。
>      今朝は本当に
>     何もすることが
>     ないからな。』
>       ネズミは
>       その駄犬に
>        言った、
>         『そんな
>          裁判では、
>             旦那様、
>           陪審も
>         裁判官も
>        いなければ、
>       ただ口を
>       動かす
>       無駄ですよ。』
>         『私が
>         裁判官だ。
>          私が陪審だ』
>              と言った、
>          ずる賢い
>           老フューリー。
>           『私が
>           事件の
>             一切を
>             審理して、
>               そして
>            おまえに
>            宣告する、
>           死刑
>            だと。』」
> </pre>

<a id="AW-03-035"></a>

**AW-03-035**

<!-- EN:AW-03-035 -->
“You are not attending!” said the Mouse to Alice severely. “What are you thinking of?”
<!-- /EN:AW-03-035 -->

> 「きみは、話を聞いていない！」とネズミは、アリスを厳しく叱った。「何を考えているんだ？」

<a id="AW-03-036"></a>

**AW-03-036**

<!-- EN:AW-03-036 -->
“I beg your pardon,” said Alice very humbly: “you had got to the fifth bend, I think?”
<!-- /EN:AW-03-036 -->

> 「ごめんなさい」とアリスは、とても恐縮して言った。「五つ目の曲がり角まで行ったところ、だったかしら？」

<a id="AW-03-037"></a>

**AW-03-037**

<!-- EN:AW-03-037 -->
“I had *not!*” cried the Mouse, sharply and very angrily.
<!-- /EN:AW-03-037 -->

> 「*違う！*」とネズミは、ひどく怒って、鋭く叫んだ。

<a id="AW-03-038"></a>

**AW-03-038**

<!-- EN:AW-03-038 -->
“A knot!” said Alice, always ready to make herself useful, and looking anxiously about her. “Oh, do let me help to undo it!”
<!-- /EN:AW-03-038 -->

> 「結び目なの！」とアリスは、心配そうに辺りを見回して言った。いつでも、役に立とうとしていたのだ。「ああ、ほどくのを手伝わせてちょうだい！」

> **訳注：** ネズミの not（違う、そうではない）を、アリスは同じ発音の knot（結び目）と聞き違える。

<a id="AW-03-039"></a>

**AW-03-039**

<!-- EN:AW-03-039 -->
“I shall do nothing of the sort,” said the Mouse, getting up and walking away. “You insult me by talking such nonsense!”
<!-- /EN:AW-03-039 -->

> 「そんなことは、まっぴらだ」とネズミは、立ち上がって歩きだした。「そんなくだらないことを言うのは、私への侮辱だ！」

<a id="AW-03-040"></a>

**AW-03-040**

<!-- EN:AW-03-040 -->
“I didn’t mean it!” pleaded poor Alice. “But you’re so easily offended, you know!”
<!-- /EN:AW-03-040 -->

> 「そんなつもりじゃなかったの！」と、かわいそうなアリスは、すがるように言った。「でも、あなたったら、すぐに怒るんだもの！」

<a id="AW-03-041"></a>

**AW-03-041**

<!-- EN:AW-03-041 -->
The Mouse only growled in reply.
<!-- /EN:AW-03-041 -->

> ネズミは、返事の代わりに、うなるだけだった。

<a id="AW-03-042"></a>

**AW-03-042**

<!-- EN:AW-03-042 -->
“Please come back and finish your story!” Alice called after it; and the others all joined in chorus, “Yes, please do!” but the Mouse only shook its head impatiently, and walked a little quicker.
<!-- /EN:AW-03-042 -->

> 「お願い、戻ってきて、お話を最後まで聞かせて！」とアリスは呼びかけた。ほかのみんなも、一斉に「そうだよ、お願いだよ！」と声を合わせた。けれどもネズミは、いらいらしたように首を振っただけで、少し足を速めた。

<a id="AW-03-043"></a>

**AW-03-043**

<!-- EN:AW-03-043 -->
“What a pity it wouldn’t stay!” sighed the Lory, as soon as it was quite out of sight; and an old Crab took the opportunity of saying to her daughter “Ah, my dear! Let this be a lesson to you never to lose *your* temper!” “Hold your tongue, Ma!” said the young Crab, a little snappishly. “You’re enough to try the patience of an oyster!”
<!-- /EN:AW-03-043 -->

> 姿がすっかり見えなくなると、インコは「いてくれないなんて、残念だな！」と、ため息をついた。年を取ったカニは、その機会を逃さず、娘にこう言った。「ねえ、いいこと。これを教訓にして、*あなたは*決して、かんしゃくを起こさないようにね！」「黙ってよ、お母さん！」と、若いカニは少しとげとげしく言った。「お母さんときたら、カキだって我慢できなくなるわ！」

<a id="AW-03-044"></a>

**AW-03-044**

<!-- EN:AW-03-044 -->
“I wish I had our Dinah here, I know I do!” said Alice aloud, addressing nobody in particular. “She’d soon fetch it back!”
<!-- /EN:AW-03-044 -->

> 「うちのダイナがここにいればいいのに、本当にそう思うわ！」とアリスは、誰にともなく声に出して言った。「あの子なら、すぐに連れ戻してくれるのに！」

<a id="AW-03-045"></a>

**AW-03-045**

<!-- EN:AW-03-045 -->
“And who is Dinah, if I might venture to ask the question?” said the Lory.
<!-- /EN:AW-03-045 -->

> 「そのダイナとは、どなたなのかな。差し支えなければ、聞いてもいいだろうか？」とインコは言った。

<a id="AW-03-046"></a>

**AW-03-046**

<!-- EN:AW-03-046 -->
Alice replied eagerly, for she was always ready to talk about her pet: “Dinah’s our cat. And she’s such a capital one for catching mice you can’t think! And oh, I wish you could see her after the birds! Why, she’ll eat a little bird as soon as look at it!”
<!-- /EN:AW-03-046 -->

> 飼い猫のことなら、いつでも話したかったので、アリスは熱心に答えた。「ダイナは、うちの猫よ。ネズミを捕まえるのが、あなたには想像もできないくらい上手なの！　ああ、鳥を追いかけるところも、見せてあげたいわ！　だって、小鳥を見つけたら、ためらいもなく食べてしまうのよ！」

<a id="AW-03-047"></a>

**AW-03-047**

<!-- EN:AW-03-047 -->
This speech caused a remarkable sensation among the party. Some of the birds hurried off at once: one old Magpie began wrapping itself up very carefully, remarking, “I really must be getting home; the night-air doesn’t suit my throat!” and a Canary called out in a trembling voice to its children, “Come away, my dears! It’s high time you were all in bed!” On various pretexts they all moved off, and Alice was soon left alone.
<!-- /EN:AW-03-047 -->

> この発言は、一同を大いにざわつかせた。鳥たちの何羽かは、すぐに大急ぎで立ち去った。年を取ったカササギは一羽、とても念入りに体を包みはじめ、「本当に、もう家へ帰らなくては。夜風は、喉によくないのでね！」と言った。カナリアは、震える声で子どもたちを呼んだ。「さあ、みんな、行きますよ！　とっくに寝る時間を過ぎています！」みんな、さまざまな口実で去っていき、アリスはすぐに、一人きりになった。

<a id="AW-03-048"></a>

**AW-03-048**

<!-- EN:AW-03-048 -->
“I wish I hadn’t mentioned Dinah!” she said to herself in a melancholy tone. “Nobody seems to like her, down here, and I’m sure she’s the best cat in the world! Oh, my dear Dinah! I wonder if I shall ever see you any more!” And here poor Alice began to cry again, for she felt very lonely and low-spirited. In a little while, however, she again heard a little pattering of footsteps in the distance, and she looked up eagerly, half hoping that the Mouse had changed his mind, and was coming back to finish his story.
<!-- /EN:AW-03-048 -->

> 「ダイナのことを言わなければよかった！」とアリスは、悲しそうに独り言を言った。「ここの下では、誰もあの子を好きになってくれないみたい。でも、あの子は世界でいちばんいい猫なのよ、絶対に！　ああ、大好きなダイナ！　また、あなたに会えることはあるのかしら！」ここで、かわいそうなアリスは、また泣きはじめた。とても寂しく、気持ちが沈んでいたのだ。けれども少しすると、また遠くで、ぱたぱたと小さな足音が聞こえた。アリスは、はっと顔を上げた。ネズミが気を変えて、話の続きをするために戻ってきたのではないかと、少し期待したのだ。

[章目次へ戻る](#book-top)

---

<a id="aw-chapter-04"></a>

## 第4章　ウサギ、小さなビルを送りこむ

### CHAPTER IV. The Rabbit Sends in a Little Bill

<a id="AW-04-001"></a>

**AW-04-001**

<!-- EN:AW-04-001 -->
It was the White Rabbit, trotting slowly back again, and looking anxiously about as it went, as if it had lost something; and she heard it muttering to itself “The Duchess! The Duchess! Oh my dear paws! Oh my fur and whiskers! She’ll get me executed, as sure as ferrets are ferrets! Where *can* I have dropped them, I wonder?” Alice guessed in a moment that it was looking for the fan and the pair of white kid gloves, and she very good-naturedly began hunting about for them, but they were nowhere to be seen—everything seemed to have changed since her swim in the pool, and the great hall, with the glass table and the little door, had vanished completely.
<!-- /EN:AW-04-001 -->

> それは白ウサギだった。ゆっくり小走りに戻ってきながら、何かなくしたらしく、心配そうに辺りを見回していた。「公爵夫人が！　公爵夫人が！　ああ、大事な前足が！　ああ、毛皮もひげも！　処刑されてしまう。フェレットがフェレットであるのと同じくらい、間違いなく！　いったい、*どこで*落としたんだろう？」と、独り言を言うのが聞こえた。アリスは、扇と一組の白い子ヤギ革の手袋を探しているのだと、すぐに察した。そして、とても親切に、辺りを探しはじめたが、どこにも見当たらない。池を泳いでいる間に、何もかも変わってしまったようだった。大きな広間も、ガラスのテーブルも、小さな扉も、すっかり消えてしまっていたのだ。

<a id="AW-04-002"></a>

**AW-04-002**

<!-- EN:AW-04-002 -->
Very soon the Rabbit noticed Alice, as she went hunting about, and called out to her in an angry tone, “Why, Mary Ann, what *are* you doing out here? Run home this moment, and fetch me a pair of gloves and a fan! Quick, now!” And Alice was so much frightened that she ran off at once in the direction it pointed to, without trying to explain the mistake it had made.
<!-- /EN:AW-04-002 -->

> ウサギはすぐに、探し回っているアリスに気づき、怒った声で呼びかけた。「おい、メアリー・アン、こんなところで、いったい*何を*している？　今すぐ家へ走って、手袋を一組と、扇を取ってきなさい！　さあ、早く！」アリスはすっかりおびえてしまい、ウサギが人違いをしていると説明しようともせず、指さされたほうへ、すぐに駆けだした。

<a id="AW-04-003"></a>

**AW-04-003**

<!-- EN:AW-04-003 -->
“He took me for his housemaid,” she said to herself as she ran. “How surprised he’ll be when he finds out who I am! But I’d better take him his fan and gloves—that is, if I can find them.” As she said this, she came upon a neat little house, on the door of which was a bright brass plate with the name “W. RABBIT,” engraved upon it. She went in without knocking, and hurried upstairs, in great fear lest she should meet the real Mary Ann, and be turned out of the house before she had found the fan and gloves.
<!-- /EN:AW-04-003 -->

> 「わたしを、自分の家の女中さんだと思ったのね」と、走りながら独り言を言った。「本当は誰なのか分かったら、どんなに驚くでしょう！　でも、扇と手袋は持っていってあげたほうがいいわね。つまり、見つかればの話だけど。」そう言いながら、こぎれいな小さな家の前に来た。扉には、ぴかぴかの真鍮の表札があり、「W. RABBIT」と刻まれていた。アリスはノックもせずに入り、急いで階段を上った。本物のメアリー・アンに出会って、扇と手袋を見つける前に、家から追い出されるのではないかと、ひどく心配していたのだ。

<a id="AW-04-004"></a>

**AW-04-004**

<!-- EN:AW-04-004 -->
“How queer it seems,” Alice said to herself, “to be going messages for a rabbit! I suppose Dinah’ll be sending me on messages next!” And she began fancying the sort of thing that would happen: “‘Miss Alice! Come here directly, and get ready for your walk!’ ‘Coming in a minute, nurse! But I’ve got to see that the mouse doesn’t get out.’ Only I don’t think,” Alice went on, “that they’d let Dinah stop in the house if it began ordering people about like that!”
<!-- /EN:AW-04-004 -->

> 「ウサギのお使いに行くなんて」とアリスは独り言を言った。「何ておかしいんでしょう！　次はダイナが、わたしをお使いにやるのかしら！」そして、どんなことが起きるか、想像しはじめた。「『アリスお嬢様！　すぐこちらへ来て、お散歩の支度をなさい！』『すぐ行くわ、ばあや！　でも、ネズミが逃げないように、見張ってなくちゃいけないの』。でも」とアリスは続けた。「あんなふうに、人にあれこれ命令しはじめたら、ダイナを家に置いてはくれないと思うわ！」

<a id="AW-04-005"></a>

**AW-04-005**

<!-- EN:AW-04-005 -->
By this time she had found her way into a tidy little room with a table in the window, and on it (as she had hoped) a fan and two or three pairs of tiny white kid gloves: she took up the fan and a pair of the gloves, and was just going to leave the room, when her eye fell upon a little bottle that stood near the looking-glass. There was no label this time with the words “DRINK ME,” but nevertheless she uncorked it and put it to her lips. “I know *something* interesting is sure to happen,” she said to herself, “whenever I eat or drink anything; so I’ll just see what this bottle does. I do hope it’ll make me grow large again, for really I’m quite tired of being such a tiny little thing!”
<!-- /EN:AW-04-005 -->

> そうしているうちに、アリスは、きちんと片づいた小さな部屋にたどり着いた。窓辺にはテーブルがあり、その上には（期待どおり）扇と、小さな白い子ヤギ革の手袋が二、三組あった。扇と手袋一組を取り、部屋を出ようとした、そのとき、鏡のそばに立っている小さな瓶が目に留まった。今度は「わたしを飲んで」という札はない。それでもアリスは、コルクの栓を抜き、瓶を唇へ持っていった。「何か食べたり飲んだりすると、必ず*何か*面白いことが起こるのは、もう分かっているわ」と独り言を言った。「だから、この瓶が何をするか、試してみましょう。また大きくなれるといいんだけど。こんなちっぽけでいるのは、本当にもう、うんざりなの！」

<a id="AW-04-006"></a>

**AW-04-006**

<!-- EN:AW-04-006 -->
It did so indeed, and much sooner than she had expected: before she had drunk half the bottle, she found her head pressing against the ceiling, and had to stoop to save her neck from being broken. She hastily put down the bottle, saying to herself “That’s quite enough—I hope I shan’t grow any more—As it is, I can’t get out at the door—I do wish I hadn’t drunk quite so much!”
<!-- /EN:AW-04-006 -->

> 本当に、大きくなった。それも、思っていたよりずっと早く。瓶の半分も飲まないうちに、頭が天井に押しつけられ、首が折れないように、かがまなければならなくなった。アリスは急いで瓶を置き、独り言を言った。「もう十分だわ――これ以上、大きくならないといいけれど――今のままでも、扉から出られないわ――あんなに飲まなければよかった！」

<a id="AW-04-007"></a>

**AW-04-007**

<!-- EN:AW-04-007 -->
Alas! it was too late to wish that! She went on growing, and growing, and very soon had to kneel down on the floor: in another minute there was not even room for this, and she tried the effect of lying down with one elbow against the door, and the other arm curled round her head. Still she went on growing, and, as a last resource, she put one arm out of the window, and one foot up the chimney, and said to herself “Now I can do no more, whatever happens. What *will* become of me?”
<!-- /EN:AW-04-007 -->

> ああ！　そう願うには、もう遅すぎた。アリスは、どんどん、どんどん大きくなり、すぐに、床にひざまずかなければならなくなった。もう少したつと、そのための場所さえなくなり、片方の肘を扉に押し当て、もう片方の腕を頭の周りに曲げて、横になってみた。それでも大きくなりつづけたので、最後の手段として、片腕を窓の外へ出し、片足を煙突の中へ突っ込んで、こう独り言を言った。「もう、どうなろうと、これ以上は何もできないわ。わたし、いったい*どうなる*のかしら？」

<a id="AW-04-008"></a>

**AW-04-008**

<!-- EN:AW-04-008 -->
Luckily for Alice, the little magic bottle had now had its full effect, and she grew no larger: still it was very uncomfortable, and, as there seemed to be no sort of chance of her ever getting out of the room again, no wonder she felt unhappy.
<!-- /EN:AW-04-008 -->

> 幸い、魔法の小瓶の効き目は、そこで出尽くし、アリスはそれ以上大きくならなかった。それでも、とても窮屈だったし、もう二度と部屋から出られる見込みもなさそうだったのだから、悲しくなるのも無理はない。

<a id="AW-04-009"></a>

**AW-04-009**

<!-- EN:AW-04-009 -->
“It was much pleasanter at home,” thought poor Alice, “when one wasn’t always growing larger and smaller, and being ordered about by mice and rabbits. I almost wish I hadn’t gone down that rabbit-hole—and yet—and yet—it’s rather curious, you know, this sort of life! I do wonder what *can* have happened to me! When I used to read fairy-tales, I fancied that kind of thing never happened, and now here I am in the middle of one! There ought to be a book written about me, that there ought! And when I grow up, I’ll write one—but I’m grown up now,” she added in a sorrowful tone; “at least there’s no room to grow up any more *here*.”
<!-- /EN:AW-04-009 -->

> 「家にいたほうが、ずっとよかったわ」と、かわいそうなアリスは思った。「しょっちゅう大きくなったり小さくなったり、ネズミやウサギに命令されたりすることも、なかったもの。あのウサギ穴に入らなければよかった、と言いたいくらいだわ――それでも――それでも――こんな暮らしって、なかなか不思議ではあるのよね！　わたしに、いったい何が*起きた*のかしら！　おとぎ話を読んでいたころは、あんなことは本当に起こるはずがないと思っていたのに、今では、わたしがその真っただ中にいるんだわ！　わたしのことを、本に書くべきだわ、絶対に！　大きくなったら、自分で一冊書きましょう――でも、もう大きくなっているのね」と、悲しそうに付け加えた。「少なくとも、*ここ*では、これ以上大きくなる場所はないわ。」

<a id="AW-04-010"></a>

**AW-04-010**

<!-- EN:AW-04-010 -->
“But then,” thought Alice, “shall I *never* get any older than I am now? That’ll be a comfort, one way—never to be an old woman—but then—always to have lessons to learn! Oh, I shouldn’t like *that!*”
<!-- /EN:AW-04-010 -->

> 「でも、そうすると」とアリスは考えた。「今より年を取ることは、*いつまでも*ないのかしら？　それは、ある意味では安心ね――おばあさんにならずに済むんだから。でも、そうすると――ずっと、お勉強をしなければならないわ！　ああ、*それは*嫌だわ！」

<a id="AW-04-011"></a>

**AW-04-011**

<!-- EN:AW-04-011 -->
“Oh, you foolish Alice!” she answered herself. “How can you learn lessons in here? Why, there’s hardly room for *you*, and no room at all for any lesson-books!”
<!-- /EN:AW-04-011 -->

> 「ああ、ばかなアリスね！」と、自分に答えた。「こんなところで、どうやってお勉強するの？　だって、*あなた*がいる場所も、ほとんどないのに、教科書を置く場所なんて、まるでないじゃない！」

<a id="AW-04-012"></a>

**AW-04-012**

<!-- EN:AW-04-012 -->
And so she went on, taking first one side and then the other, and making quite a conversation of it altogether; but after a few minutes she heard a voice outside, and stopped to listen.
<!-- /EN:AW-04-012 -->

> そんなふうに、こちらの立場になったり、あちらの立場になったりして、一人でちゃんとした会話を続けていた。けれども数分後、外から声が聞こえたので、口をつぐんで耳を澄ませた。

<a id="AW-04-013"></a>

**AW-04-013**

<!-- EN:AW-04-013 -->
“Mary Ann! Mary Ann!” said the voice. “Fetch me my gloves this moment!” Then came a little pattering of feet on the stairs. Alice knew it was the Rabbit coming to look for her, and she trembled till she shook the house, quite forgetting that she was now about a thousand times as large as the Rabbit, and had no reason to be afraid of it.
<!-- /EN:AW-04-013 -->

> 「メアリー・アン！　メアリー・アン！」と声がした。「今すぐ、私の手袋を持ってきなさい！」それから、階段で小さな、ぱたぱたという足音がした。ウサギが自分を探しに来たのだと分かって、アリスは、家が揺れるほど震えた。今や自分がウサギの千倍ほども大きく、怖がる理由などないことを、すっかり忘れていたのだ。

<a id="AW-04-014"></a>

**AW-04-014**

<!-- EN:AW-04-014 -->
Presently the Rabbit came up to the door, and tried to open it; but, as the door opened inwards, and Alice’s elbow was pressed hard against it, that attempt proved a failure. Alice heard it say to itself “Then I’ll go round and get in at the window.”
<!-- /EN:AW-04-014 -->

> やがてウサギは、扉の前まで来て、開けようとした。けれども扉は内開きで、アリスの肘が強く押しつけられていたので、うまくいかなかった。「それなら、回って窓から入ろう」と、ウサギが独り言を言うのが聞こえた。

<a id="AW-04-015"></a>

**AW-04-015**

<!-- EN:AW-04-015 -->
“*That* you won’t!” thought Alice, and, after waiting till she fancied she heard the Rabbit just under the window, she suddenly spread out her hand, and made a snatch in the air. She did not get hold of anything, but she heard a little shriek and a fall, and a crash of broken glass, from which she concluded that it was just possible it had fallen into a cucumber-frame, or something of the sort.
<!-- /EN:AW-04-015 -->

> 「*そうは*させないわ！」とアリスは思った。ウサギが窓の真下へ来た音がした気がするまで待つと、いきなり手を広げ、宙を引っつかんだ。何もつかめなかったが、小さな悲鳴と、何かが落ちる音、それから、ガラスが派手に割れる音が聞こえた。そこで、キュウリを育てるガラスの覆いか、何かそういうものに、ウサギが落ちたのかもしれないと考えた。

<a id="AW-04-016"></a>

**AW-04-016**

<!-- EN:AW-04-016 -->
Next came an angry voice—the Rabbit’s—“Pat! Pat! Where are you?” And then a voice she had never heard before, “Sure then I’m here! Digging for apples, yer honour!”
<!-- /EN:AW-04-016 -->

> 次に、怒った声がした。ウサギの声だ。「パット！　パット！　どこにいる？」それから、今まで聞いたことのない声がした。「はい、ここでさぁ！　リンゴを掘ってるところです、旦那様！」

<a id="AW-04-017"></a>

**AW-04-017**

<!-- EN:AW-04-017 -->
“Digging for apples, indeed!” said the Rabbit angrily. “Here! Come and help me out of *this!*” (Sounds of more broken glass.)
<!-- /EN:AW-04-017 -->

> 「リンゴを掘っているだと！」とウサギは怒って言った。「こっちだ！　来て、*ここ*から出るのを手伝え！」（またガラスの割れる音。）

<a id="AW-04-018"></a>

**AW-04-018**

<!-- EN:AW-04-018 -->
“Now tell me, Pat, what’s that in the window?”
<!-- /EN:AW-04-018 -->

> 「さあ、教えてくれ、パット。あの窓にあるのは何だ？」

<a id="AW-04-019"></a>

**AW-04-019**

<!-- EN:AW-04-019 -->
“Sure, it’s an arm, yer honour!” (He pronounced it “arrum.”)
<!-- /EN:AW-04-019 -->

> 「そりゃ、腕でさぁ、旦那様！」（腕を表す arm を、「アラム」と発音した。）

<a id="AW-04-020"></a>

**AW-04-020**

<!-- EN:AW-04-020 -->
“An arm, you goose! Who ever saw one that size? Why, it fills the whole window!”
<!-- /EN:AW-04-020 -->

> 「腕だと、このまぬけ！　あんな大きさの腕を、誰が見たことがある？　窓いっぱいに広がっているじゃないか！」

<a id="AW-04-021"></a>

**AW-04-021**

<!-- EN:AW-04-021 -->
“Sure, it does, yer honour: but it’s an arm for all that.”
<!-- /EN:AW-04-021 -->

> 「確かに、そうでさぁ、旦那様。それでも、腕は腕です。」

<a id="AW-04-022"></a>

**AW-04-022**

<!-- EN:AW-04-022 -->
“Well, it’s got no business there, at any rate: go and take it away!”
<!-- /EN:AW-04-022 -->

> 「とにかく、あんなところにあっていいものではない。行って、どけてこい！」

<a id="AW-04-023"></a>

**AW-04-023**

<!-- EN:AW-04-023 -->
There was a long silence after this, and Alice could only hear whispers now and then; such as, “Sure, I don’t like it, yer honour, at all, at all!” “Do as I tell you, you coward!” and at last she spread out her hand again, and made another snatch in the air. This time there were *two* little shrieks, and more sounds of broken glass. “What a number of cucumber-frames there must be!” thought Alice. “I wonder what they’ll do next! As for pulling me out of the window, I only wish they *could!* I’m sure *I* don’t want to stay in here any longer!”
<!-- /EN:AW-04-023 -->

> そのあとは、長い沈黙が続き、ときどき、ひそひそ話が聞こえるだけだった。「そりゃ嫌でさぁ、旦那様、本当に、本当に！」「言うとおりにしろ、この臆病者！」といった声だ。とうとうアリスは、また手を広げ、もう一度、宙を引っつかんだ。今度は、小さな悲鳴が*二つ*と、またガラスの割れる音がした。「キュウリのガラスの覆いが、ずいぶんたくさんあるのね！」とアリスは思った。「次は何をするのかしら！　窓から引っ張り出そうというなら、むしろ、*そうできたらいいのに*！　*わたし*だって、もうこれ以上、ここにいたくないんだから！」

<a id="AW-04-024"></a>

**AW-04-024**

<!-- EN:AW-04-024 -->
She waited for some time without hearing anything more: at last came a rumbling of little cartwheels, and the sound of a good many voices all talking together: she made out the words: “Where’s the other ladder?—Why, I hadn’t to bring but one; Bill’s got the other—Bill! fetch it here, lad!—Here, put ’em up at this corner—No, tie ’em together first—they don’t reach half high enough yet—Oh! they’ll do well enough; don’t be particular—Here, Bill! catch hold of this rope—Will the roof bear?—Mind that loose slate—Oh, it’s coming down! Heads below!” (a loud crash)—“Now, who did that?—It was Bill, I fancy—Who’s to go down the chimney?—Nay, *I* shan’t! *You* do it!—*That* I won’t, then!—Bill’s to go down—Here, Bill! the master says you’re to go down the chimney!”
<!-- /EN:AW-04-024 -->

> しばらく待ったが、それ以上、何も聞こえなかった。やがて、小さな荷車の車輪が、ごろごろと鳴る音と、大勢が一緒に話す声が聞こえた。聞き取れたのは、こんな言葉だ。「もう一つのはしごはどこだ？――いや、私は一つだけ持ってくればよかったんだ。もう一つはビルが持っている――ビル！　おい、こっちへ持ってこい！――さあ、この角に立てかけて――違う、まず結び合わせろ。まだ必要な高さの半分にも届かない――ああ！　十分だよ、細かいことを言うな――おい、ビル！　この綱をつかめ――屋根はもつかな？――あの浮いた石板に気をつけろ――ああ、落ちるぞ！　下の者、頭に気をつけろ！」（大きな破壊音。）「おい、今のは誰だ？――ビルだと思うよ――誰が煙突を下りる？――いや、*私は*嫌だ！　*きみが*やれ！――*それは*お断りだ！――ビルに下りてもらおう――おい、ビル！　ご主人様が、煙突を下りろってさ！」

<a id="AW-04-025"></a>

**AW-04-025**

<!-- EN:AW-04-025 -->
“Oh! So Bill’s got to come down the chimney, has he?” said Alice to herself. “Shy, they seem to put everything upon Bill! I wouldn’t be in Bill’s place for a good deal: this fireplace is narrow, to be sure; but I *think* I can kick a little!”
<!-- /EN:AW-04-025 -->

> 「ああ！　それで、ビルが煙突を下りてくることになったのね？」とアリスは独り言を言った。「まあ、何でもかんでも、ビルに押しつけるみたい！　どんなにお礼をもらっても、ビルの身代わりにはなりたくないわ。この暖炉は確かに狭いけれど、少しくらいは蹴れると*思う*もの！」

<a id="AW-04-026"></a>

**AW-04-026**

<!-- EN:AW-04-026 -->
She drew her foot as far down the chimney as she could, and waited till she heard a little animal (she couldn’t guess of what sort it was) scratching and scrambling about in the chimney close above her: then, saying to herself “This is Bill,” she gave one sharp kick, and waited to see what would happen next.
<!-- /EN:AW-04-026 -->

> アリスは、煙突に入れた足を、できるだけ下へ引き戻し、待った。小さな動物が（何の動物かは、見当もつかなかった）、すぐ上の煙突の中で、引っかいたり、はい回ったりする音が聞こえてきた。「これがビルね」と独り言を言って、鋭く一蹴りし、次に何が起こるか、じっと待った。

<a id="AW-04-027"></a>

**AW-04-027**

<!-- EN:AW-04-027 -->
The first thing she heard was a general chorus of “There goes Bill!” then the Rabbit’s voice along—“Catch him, you by the hedge!” then silence, and then another confusion of voices—“Hold up his head—Brandy now—Don’t choke him—How was it, old fellow? What happened to you? Tell us all about it!”
<!-- /EN:AW-04-027 -->

> 最初に聞こえたのは、みんなの「ビルが飛んだ！」という合唱だった。それからウサギの声だけが、「生け垣のそばにいる者、受け止めろ！」と響いた。そのあと静かになり、また声が入り乱れた。「頭を支えて――さあ、ブランデーだ――むせさせるな――おい、どうだった？　何があった？　全部話してくれ！」

<a id="AW-04-028"></a>

**AW-04-028**

<!-- EN:AW-04-028 -->
Last came a little feeble, squeaking voice, (“That’s Bill,” thought Alice,) “Well, I hardly know—No more, thank ye; I’m better now—but I’m a deal too flustered to tell you—all I know is, something comes at me like a Jack-in-the-box, and up I goes like a sky-rocket!”
<!-- /EN:AW-04-028 -->

> 最後に、小さな、弱々しい、きいきいした声がした。（「あれがビルね」とアリスは思った。）「いや、何が何だか――もう結構、ありがとよ。気分はよくなった――でも、まだ気が動転していて、話せないんだ――分かっているのは、何かがびっくり箱みたいに飛びかかってきて、私は打ち上げ花火みたいに、すっ飛んだってことだけさ！」

<a id="AW-04-029"></a>

**AW-04-029**

<!-- EN:AW-04-029 -->
“So you did, old fellow!” said the others.
<!-- /EN:AW-04-029 -->

> 「確かに、すっ飛んだよな、おい！」と、ほかのみんなが言った。

<a id="AW-04-030"></a>

**AW-04-030**

<!-- EN:AW-04-030 -->
“We must burn the house down!” said the Rabbit’s voice; and Alice called out as loud as she could, “If you do, I’ll set Dinah at you!”
<!-- /EN:AW-04-030 -->

> 「家を焼き払うしかない！」とウサギの声がした。そこでアリスは、出せる限りの大声で叫んだ。「そんなことをしたら、ダイナに、あなたたちを襲わせるわよ！」

<a id="AW-04-031"></a>

**AW-04-031**

<!-- EN:AW-04-031 -->
There was a dead silence instantly, and Alice thought to herself, “I wonder what they *will* do next! If they had any sense, they’d take the roof off.” After a minute or two, they began moving about again, and Alice heard the Rabbit say, “A barrowful will do, to begin with.”
<!-- /EN:AW-04-031 -->

> たちまち、しんと静まり返った。アリスは心の中で思った。「次は、いったい*何をする*のかしら！　少しでも分別があれば、屋根を外すでしょうに。」一、二分すると、また動き回りはじめ、ウサギが「手始めに、手押し車一杯あればよかろう」と言うのが聞こえた。

<a id="AW-04-032"></a>

**AW-04-032**

<!-- EN:AW-04-032 -->
“A barrowful of *what?*” thought Alice; but she had not long to doubt, for the next moment a shower of little pebbles came rattling in at the window, and some of them hit her in the face. “I’ll put a stop to this,” she said to herself, and shouted out, “You’d better not do that again!” which produced another dead silence.
<!-- /EN:AW-04-032 -->

> 「*何を*、手押し車一杯なの？」とアリスは思った。けれども、長く疑問に思っている必要はなかった。次の瞬間、小石の雨が、がらがらと窓から降り込み、いくつかは顔に当たったのだ。「これは、やめさせなくちゃ」と独り言を言い、「もう、そんなことはしないほうがいいわよ！」と叫んだ。すると、またしんと静まり返った。

<a id="AW-04-033"></a>

**AW-04-033**

<!-- EN:AW-04-033 -->
Alice noticed with some surprise that the pebbles were all turning into little cakes as they lay on the floor, and a bright idea came into her head. “If I eat one of these cakes,” she thought, “it’s sure to make *some* change in my size; and as it can’t possibly make me larger, it must make me smaller, I suppose.”
<!-- /EN:AW-04-033 -->

> 床に転がった小石が、どれも小さなお菓子に変わっていくのを見て、アリスは少し驚いた。そして、いい考えがひらめいた。「このお菓子を一つ食べれば」と考えた。「わたしの大きさは、きっと*何かしら*変わるはず。これ以上、大きくなることは、どうしてもできないんだから、小さくなるはずよね。」

<a id="AW-04-034"></a>

**AW-04-034**

<!-- EN:AW-04-034 -->
So she swallowed one of the cakes, and was delighted to find that she began shrinking directly. As soon as she was small enough to get through the door, she ran out of the house, and found quite a crowd of little animals and birds waiting outside. The poor little Lizard, Bill, was in the middle, being held up by two guinea-pigs, who were giving it something out of a bottle. They all made a rush at Alice the moment she appeared; but she ran off as hard as she could, and soon found herself safe in a thick wood.
<!-- /EN:AW-04-034 -->

> そこで、お菓子を一つ飲み込んだ。すぐに縮みはじめたので、大喜びだ。扉を通れるくらい小さくなると、すぐに家から駆け出した。外には、小さな獣や鳥の大群が待ち構えていた。真ん中には、かわいそうな小さなトカゲのビルがいて、二匹のモルモットに体を支えられ、瓶から何か飲ませてもらっていた。アリスの姿が現れると、一斉に飛びかかってきたが、アリスは全力で逃げ、すぐに、深い森の中へ無事にたどり着いた。

<a id="AW-04-035"></a>

**AW-04-035**

<!-- EN:AW-04-035 -->
“The first thing I’ve got to do,” said Alice to herself, as she wandered about in the wood, “is to grow to my right size again; and the second thing is to find my way into that lovely garden. I think that will be the best plan.”
<!-- /EN:AW-04-035 -->

> 「まず、しなくちゃいけないのは」とアリスは、森を歩き回りながら独り言を言った。「元の大きさに戻ることね。それから二番目は、あの美しい庭へ行く道を見つけること。それが、いちばんいい計画だと思うわ。」

<a id="AW-04-036"></a>

**AW-04-036**

<!-- EN:AW-04-036 -->
It sounded an excellent plan, no doubt, and very neatly and simply arranged; the only difficulty was, that she had not the smallest idea how to set about it; and while she was peering about anxiously among the trees, a little sharp bark just over her head made her look up in a great hurry.
<!-- /EN:AW-04-036 -->

> なるほど、すばらしい計画に聞こえた。とてもきちんと、簡潔にまとまっている。たった一つの難点は、どうやりはじめたらいいのか、まるで見当がつかないことだった。心配そうに木々の間を見回していると、頭のすぐ上で、小さく鋭い犬の鳴き声がしたので、大慌てで見上げた。

<a id="AW-04-037"></a>

**AW-04-037**

<!-- EN:AW-04-037 -->
An enormous puppy was looking down at her with large round eyes, and feebly stretching out one paw, trying to touch her. “Poor little thing!” said Alice, in a coaxing tone, and she tried hard to whistle to it; but she was terribly frightened all the time at the thought that it might be hungry, in which case it would be very likely to eat her up in spite of all her coaxing.
<!-- /EN:AW-04-037 -->

> 巨大な子犬が、大きな丸い目でアリスを見下ろしていた。前足を一本、頼りなげに伸ばし、触ろうとしている。「かわいそうに、小犬ちゃん！」とアリスは、あやすような声で言い、一生懸命、口笛を吹こうとした。けれどもその間じゅう、子犬がおなかをすかせていたらどうしようと、ひどくおびえていた。もしそうなら、どんなにあやしても、きっと食べられてしまうからだ。

<a id="AW-04-038"></a>

**AW-04-038**

<!-- EN:AW-04-038 -->
Hardly knowing what she did, she picked up a little bit of stick, and held it out to the puppy; whereupon the puppy jumped into the air off all its feet at once, with a yelp of delight, and rushed at the stick, and made believe to worry it; then Alice dodged behind a great thistle, to keep herself from being run over; and the moment she appeared on the other side, the puppy made another rush at the stick, and tumbled head over heels in its hurry to get hold of it; then Alice, thinking it was very like having a game of play with a cart-horse, and expecting every moment to be trampled under its feet, ran round the thistle again; then the puppy began a series of short charges at the stick, running a very little way forwards each time and a long way back, and barking hoarsely all the while, till at last it sat down a good way off, panting, with its tongue hanging out of its mouth, and its great eyes half shut.
<!-- /EN:AW-04-038 -->

> 自分が何をしているかも、ほとんど分からないまま、アリスは小さな棒切れを拾い、子犬に差し出した。すると子犬は、うれしそうに吠えて、四本の足を一度に地面から離して跳び上がり、棒に飛びついて、かみついて振り回すふりをした。アリスは、跳ね飛ばされないように、大きなアザミの後ろへ身をかわした。反対側から姿を見せたとたん、子犬はまた棒に飛びかかり、つかまえようと急ぐあまり、頭からひっくり返った。アリスは、まるで荷馬車を引く馬と遊んでいるようだと思った。今にも足で踏みつぶされそうなので、もう一度、アザミの周りを駆けた。それから子犬は、棒に向かって、短い突進を繰り返しはじめた。毎回、ほんの少し前へ走っては、ずっと遠くへ後ずさりし、その間ずっと、かすれた声で吠えていた。とうとう、かなり離れたところへ座り込み、口から舌を垂らし、大きな目を半分閉じて、はあはあと息をした。

<a id="AW-04-039"></a>

**AW-04-039**

<!-- EN:AW-04-039 -->
This seemed to Alice a good opportunity for making her escape; so she set off at once, and ran till she was quite tired and out of breath, and till the puppy’s bark sounded quite faint in the distance.
<!-- /EN:AW-04-039 -->

> アリスには、逃げ出すのにいい機会だと思えた。そこで、すぐに駆けだした。すっかり疲れて息が切れるまで、そして、子犬の吠える声が遠くで、ごくかすかにしか聞こえなくなるまで、走りつづけた。

<a id="AW-04-040"></a>

**AW-04-040**

<!-- EN:AW-04-040 -->
“And yet what a dear little puppy it was!” said Alice, as she leant against a buttercup to rest herself, and fanned herself with one of the leaves: “I should have liked teaching it tricks very much, if—if I’d only been the right size to do it! Oh dear! I’d nearly forgotten that I’ve got to grow up again! Let me see—how *is* it to be managed? I suppose I ought to eat or drink something or other; but the great question is, what?”
<!-- /EN:AW-04-040 -->

> 「それにしても、何てかわいい子犬だったんでしょう！」とアリスは言った。休むためにキンポウゲにもたれ、その葉を一枚使って、あおいでいた。「芸を教えてあげられたら、どんなに楽しかったでしょう。もし――もし、そうするのに、ちょうどいい大きさだったら！　ああ！　また大きくならなくちゃいけないことを、ほとんど忘れていたわ！　ええと――*どうやって*、そうすればいいのかしら？　何か食べるか飲むか、しなくちゃいけないんでしょうね。でも、大きな問題は、何を、ということだわ。」

<a id="AW-04-041"></a>

**AW-04-041**

<!-- EN:AW-04-041 -->
The great question certainly was, what? Alice looked all round her at the flowers and the blades of grass, but she did not see anything that looked like the right thing to eat or drink under the circumstances. There was a large mushroom growing near her, about the same height as herself; and when she had looked under it, and on both sides of it, and behind it, it occurred to her that she might as well look and see what was on the top of it.
<!-- /EN:AW-04-041 -->

> 確かに、大きな問題は、何を、ということだった。アリスは周りの花や草の葉を、ぐるりと見回したが、今のようなときに食べたり飲んだりするのに、ふさわしそうなものは、何も見つからない。そばには、自分の背と同じくらいの、大きなキノコが生えていた。その下と、両側と、後ろを見てから、上に何があるかも、見ておいてよさそうだと思いついた。

<a id="AW-04-042"></a>

**AW-04-042**

<!-- EN:AW-04-042 -->
She stretched herself up on tiptoe, and peeped over the edge of the mushroom, and her eyes immediately met those of a large blue caterpillar, that was sitting on the top with its arms folded, quietly smoking a long hookah, and taking not the smallest notice of her or of anything else.
<!-- /EN:AW-04-042 -->

> つま先立ちで体を伸ばし、キノコの縁からのぞき込むと、すぐに、大きな青いイモムシと目が合った。イモムシはキノコの上で腕を組み、長い水ぎせるを静かに吸いながら、アリスにも、ほかの何にも、少しも気を留めずに座っていたのだ。

[章目次へ戻る](#book-top)

---

<a id="aw-chapter-05"></a>

## 第5章　イモムシの助言

### CHAPTER V. Advice from a Caterpillar

<a id="AW-05-001"></a>

**AW-05-001**

<!-- EN:AW-05-001 -->
The Caterpillar and Alice looked at each other for some time in silence: at last the Caterpillar took the hookah out of its mouth, and addressed her in a languid, sleepy voice.
<!-- /EN:AW-05-001 -->

> イモムシとアリスは、しばらく黙って見つめ合っていた。やがてイモムシは、水ぎせるを口から外し、気だるい、眠そうな声で話しかけた。

<a id="AW-05-002"></a>

**AW-05-002**

<!-- EN:AW-05-002 -->
“Who are *you?*” said the Caterpillar.
<!-- /EN:AW-05-002 -->

> 「*おまえ*は誰だ？」とイモムシは言った。

<a id="AW-05-003"></a>

**AW-05-003**

<!-- EN:AW-05-003 -->
This was not an encouraging opening for a conversation. Alice replied, rather shyly, “I—I hardly know, sir, just at present—at least I know who I *was* when I got up this morning, but I think I must have been changed several times since then.”
<!-- /EN:AW-05-003 -->

> これは、話を続けたくなるような切り出し方ではなかった。アリスは、少しおずおずと答えた。「わ、わたしにも、今はほとんど分からないんです――少なくとも、今朝起きたときに誰*だったか*は分かるんですけれど、そのあと何度か、変わってしまったみたいなんです。」

<a id="AW-05-004"></a>

**AW-05-004**

<!-- EN:AW-05-004 -->
“What do you mean by that?” said the Caterpillar sternly. “Explain yourself!”
<!-- /EN:AW-05-004 -->

> 「それは、どういう意味だ？」とイモムシは、厳しく言った。「自分のことを、説明しろ！」

<a id="AW-05-005"></a>

**AW-05-005**

<!-- EN:AW-05-005 -->
“I can’t explain *myself*, I’m afraid, sir,” said Alice, “because I’m not myself, you see.”
<!-- /EN:AW-05-005 -->

> 「あの、*自分のこと*は、説明できないと思います」とアリスは言った。「だって、わたしは自分ではないんですもの。」

<a id="AW-05-006"></a>

**AW-05-006**

<!-- EN:AW-05-006 -->
“I don’t see,” said the Caterpillar.
<!-- /EN:AW-05-006 -->

> 「分からんな」とイモムシは言った。

<a id="AW-05-007"></a>

**AW-05-007**

<!-- EN:AW-05-007 -->
“I’m afraid I can’t put it more clearly,” Alice replied very politely, “for I can’t understand it myself to begin with; and being so many different sizes in a day is very confusing.”
<!-- /EN:AW-05-007 -->

> 「これ以上はっきりとは、言えないんです」とアリスは、とても丁寧に答えた。「そもそも、自分でも理解できないんですから。それに、一日のうちに、こんなに何度も大きさが変わると、とても混乱してしまいます。」

<a id="AW-05-008"></a>

**AW-05-008**

<!-- EN:AW-05-008 -->
“It isn’t,” said the Caterpillar.
<!-- /EN:AW-05-008 -->

> 「しない」とイモムシは言った。

<a id="AW-05-009"></a>

**AW-05-009**

<!-- EN:AW-05-009 -->
“Well, perhaps you haven’t found it so yet,” said Alice; “but when you have to turn into a chrysalis—you will some day, you know—and then after that into a butterfly, I should think you’ll feel it a little queer, won’t you?”
<!-- /EN:AW-05-009 -->

> 「そうね、まだ、そう感じたことがないのかもしれないわ」とアリスは言った。「でも、さなぎに変わらなければならないときが来て――いつかは、そうなるんでしょう――それから蝶になったら、少しは変な感じがするんじゃないかしら？」

<a id="AW-05-010"></a>

**AW-05-010**

<!-- EN:AW-05-010 -->
“Not a bit,” said the Caterpillar.
<!-- /EN:AW-05-010 -->

> 「少しも」とイモムシは言った。

<a id="AW-05-011"></a>

**AW-05-011**

<!-- EN:AW-05-011 -->
“Well, perhaps your feelings may be different,” said Alice; “all I know is, it would feel very queer to *me*.”
<!-- /EN:AW-05-011 -->

> 「そうね、あなたの感じ方は、違うのかもしれないわ」とアリスは言った。「ただ、*わたしなら*、とても変に感じるということしか、分からないけれど。」

<a id="AW-05-012"></a>

**AW-05-012**

<!-- EN:AW-05-012 -->
“You!” said the Caterpillar contemptuously. “Who are *you?*”
<!-- /EN:AW-05-012 -->

> 「おまえだと！」とイモムシは、見下したように言った。「*おまえ*は誰だ？」

<a id="AW-05-013"></a>

**AW-05-013**

<!-- EN:AW-05-013 -->
Which brought them back again to the beginning of the conversation. Alice felt a little irritated at the Caterpillar’s making such *very* short remarks, and she drew herself up and said, very gravely, “I think, you ought to tell me who *you* are, first.”
<!-- /EN:AW-05-013 -->

> これで、話の始めに戻ってしまった。イモムシの返事が*あまりにも*短いので、アリスは少しいらいらしてきた。そこで、しゃんと背を伸ばし、とても真面目に言った。「まず、*あなた*が誰なのか、教えてくださるべきだと思います。」

<a id="AW-05-014"></a>

**AW-05-014**

<!-- EN:AW-05-014 -->
“Why?” said the Caterpillar.
<!-- /EN:AW-05-014 -->

> 「なぜだ？」とイモムシは言った。

<a id="AW-05-015"></a>

**AW-05-015**

<!-- EN:AW-05-015 -->
Here was another puzzling question; and as Alice could not think of any good reason, and as the Caterpillar seemed to be in a *very* unpleasant state of mind, she turned away.
<!-- /EN:AW-05-015 -->

> またしても、答えに困る問いだった。アリスには、もっともらしい理由が思いつかなかったし、イモムシは*ひどく*機嫌が悪そうだったので、背を向けた。

<a id="AW-05-016"></a>

**AW-05-016**

<!-- EN:AW-05-016 -->
“Come back!” the Caterpillar called after her. “I’ve something important to say!”
<!-- /EN:AW-05-016 -->

> 「戻ってこい！」とイモムシが、あとから呼びかけた。「大事な話がある！」

<a id="AW-05-017"></a>

**AW-05-017**

<!-- EN:AW-05-017 -->
This sounded promising, certainly: Alice turned and came back again.
<!-- /EN:AW-05-017 -->

> それなら、確かに期待できそうだった。アリスは振り向き、戻ってきた。

<a id="AW-05-018"></a>

**AW-05-018**

<!-- EN:AW-05-018 -->
“Keep your temper,” said the Caterpillar.
<!-- /EN:AW-05-018 -->

> 「かんしゃくを起こすな」とイモムシは言った。

<a id="AW-05-019"></a>

**AW-05-019**

<!-- EN:AW-05-019 -->
“Is that all?” said Alice, swallowing down her anger as well as she could.
<!-- /EN:AW-05-019 -->

> 「それだけですか？」とアリスは、できる限り怒りをのみ込んで言った。

<a id="AW-05-020"></a>

**AW-05-020**

<!-- EN:AW-05-020 -->
“No,” said the Caterpillar.
<!-- /EN:AW-05-020 -->

> 「いや」とイモムシは言った。

<a id="AW-05-021"></a>

**AW-05-021**

<!-- EN:AW-05-021 -->
Alice thought she might as well wait, as she had nothing else to do, and perhaps after all it might tell her something worth hearing. For some minutes it puffed away without speaking, but at last it unfolded its arms, took the hookah out of its mouth again, and said, “So you think you’re changed, do you?”
<!-- /EN:AW-05-021 -->

> ほかにすることもないし、結局、聞く価値のあることを話してくれるかもしれないので、アリスは待っていてもよさそうだと思った。数分の間、イモムシは黙って煙を吹かしていたが、やがて組んだ腕をほどき、また水ぎせるを口から外して、言った。「それで、おまえは、自分が変わったと思っているのか？」

<a id="AW-05-022"></a>

**AW-05-022**

<!-- EN:AW-05-022 -->
“I’m afraid I am, sir,” said Alice; “I can’t remember things as I used—and I don’t keep the same size for ten minutes together!”
<!-- /EN:AW-05-022 -->

> 「残念ですけれど、そうなんです」とアリスは言った。「前のように、いろいろ思い出せませんし――十分間も続けて、同じ大きさでいられないんです！」

<a id="AW-05-023"></a>

**AW-05-023**

<!-- EN:AW-05-023 -->
“Can’t remember *what* things?” said the Caterpillar.
<!-- /EN:AW-05-023 -->

> 「*何を*思い出せない？」とイモムシは言った。

<a id="AW-05-024"></a>

**AW-05-024**

<!-- EN:AW-05-024 -->
“Well, I’ve tried to say “How doth the little busy bee,” but it all came different!” Alice replied in a very melancholy voice.
<!-- /EN:AW-05-024 -->

> 「ええと、『小さな働き蜂は、いかにして』を唱えようとしたんですけれど、全部違って出てきたんです！」とアリスは、とても悲しそうな声で答えた。

<a id="AW-05-025"></a>

**AW-05-025**

<!-- EN:AW-05-025 -->
“Repeat, ‘*You are old, Father William*,’” said the Caterpillar.
<!-- /EN:AW-05-025 -->

> 「『*お年ですね、ウィリアム父さん*』を暗唱しろ」とイモムシは言った。

<a id="AW-05-026"></a>

**AW-05-026**

<!-- EN:AW-05-026 -->
Alice folded her hands, and began:—
<!-- /EN:AW-05-026 -->

> アリスは両手を重ね、唱えはじめた。――

<a id="AW-05-027"></a>

**AW-05-027**

<!-- EN:AW-05-027 -->
“You are old, Father William,” the young man said,  
    “And your hair has become very white;  
And yet you incessantly stand on your head—  
    Do you think, at your age, it is right?”  
<!-- /EN:AW-05-027 -->

> 「『お年ですね、ウィリアム父さん』と若者は言った、  
> 　　『髪の毛だって、すっかり白い。  
> それなのに、いつでも逆立ちばかり――  
> 　　そのお年で、それがよいことだとお思いですか？』

<a id="AW-05-028"></a>

**AW-05-028**

<!-- EN:AW-05-028 -->
“In my youth,” Father William replied to his son,  
    “I feared it might injure the brain;  
But, now that I’m perfectly sure I have none,  
    Why, I do it again and again.”  
<!-- /EN:AW-05-028 -->

> 「『若いころは』とウィリアム父さんは息子に答えた、  
> 　　『脳を傷めるのでは、と心配したものだ。  
> だが今は、脳などないと、すっかり確信しているので、  
> 　　なに、何度でも繰り返すのさ。』

<a id="AW-05-029"></a>

**AW-05-029**

<!-- EN:AW-05-029 -->
“You are old,” said the youth, “as I mentioned before,  
    And have grown most uncommonly fat;  
Yet you turned a back-somersault in at the door—  
    Pray, what is the reason of that?”  
<!-- /EN:AW-05-029 -->

> 「『お年ですね』と若者は言った、『先ほども申しましたが、  
> 　　そのうえ、並外れて太っておられる。  
> それなのに、後ろへ宙返りして、戸口から入ってこられた――  
> 　　どうぞ、その理由をお聞かせください。』

<a id="AW-05-030"></a>

**AW-05-030**

<!-- EN:AW-05-030 -->
“In my youth,” said the sage, as he shook his grey locks,  
    “I kept all my limbs very supple  
By the use of this ointment—one shilling the box—  
    Allow me to sell you a couple?”  
<!-- /EN:AW-05-030 -->

> 「『若いころは』と賢人は、白髪を振りながら言った、  
> 　　『手も足も、たいそう柔らかく保っていたのだ、  
> この軟膏を使ってな――一箱一シリング――  
> 　　二箱ほど、お売りしてもよろしいかな？』

<a id="AW-05-031"></a>

**AW-05-031**

<!-- EN:AW-05-031 -->
“You are old,” said the youth, “and your jaws are too weak  
    For anything tougher than suet;  
Yet you finished the goose, with the bones and the beak—  
    Pray, how did you manage to do it?”  
<!-- /EN:AW-05-031 -->

> 「『お年ですね』と若者は言った、『顎も弱くて、  
> 　　牛脂より硬いものは、とても無理でしょう。  
> それなのに、ガチョウを骨もくちばしも平らげた――  
> 　　どうぞ、どうやってできたか、お聞かせください。』

<a id="AW-05-032"></a>

**AW-05-032**

<!-- EN:AW-05-032 -->
“In my youth,” said his father, “I took to the law,  
    And argued each case with my wife;  
And the muscular strength, which it gave to my jaw,  
    Has lasted the rest of my life.”  
<!-- /EN:AW-05-032 -->

> 「『若いころは』と父親は言った、『法律に親しんで、  
> 　　どの事件も、妻と論じ合った。  
> そのおかげで顎に備わった、筋肉の力が、  
> 　　その後の一生、衰えずに残ったのだ。』

<a id="AW-05-033"></a>

**AW-05-033**

<!-- EN:AW-05-033 -->
“You are old,” said the youth, “one would hardly suppose  
    That your eye was as steady as ever;  
Yet you balanced an eel on the end of your nose—  
    What made you so awfully clever?”  
<!-- /EN:AW-05-033 -->

> 「『お年ですね』と若者は言った、『誰も思わないでしょう、  
> 　　目が今でも、昔のように確かだとは。  
> それなのに、鼻の先でウナギを釣り合わせた――  
> 　　どうして、それほどお見事になったのですか？』

<a id="AW-05-034"></a>

**AW-05-034**

<!-- EN:AW-05-034 -->
“I have answered three questions, and that is enough,”  
    Said his father; “don’t give yourself airs!  
Do you think I can listen all day to such stuff?  
    Be off, or I’ll kick you down stairs!”
<!-- /EN:AW-05-034 -->

> 「『三つの問いに答えたのだ。それで十分だ』  
> 　　と父親は言った。『偉そうにするな！  
> 一日中、そんなことを聞いていられると思うか？  
> 　　出ていけ、さもないと階段から蹴落とすぞ！』」

<a id="AW-05-035"></a>

**AW-05-035**

<!-- EN:AW-05-035 -->
“That is not said right,” said the Caterpillar.
<!-- /EN:AW-05-035 -->

> 「正しく言えていない」とイモムシは言った。

<a id="AW-05-036"></a>

**AW-05-036**

<!-- EN:AW-05-036 -->
“Not *quite* right, I’m afraid,” said Alice, timidly; “some of the words have got altered.”
<!-- /EN:AW-05-036 -->

> 「ええ、*完全には*、正しくないと思います」とアリスは、おずおずと言った。「言葉が、いくつか変わってしまったんです。」

<a id="AW-05-037"></a>

**AW-05-037**

<!-- EN:AW-05-037 -->
“It is wrong from beginning to end,” said the Caterpillar decidedly, and there was silence for some minutes.
<!-- /EN:AW-05-037 -->

> 「最初から最後まで、間違っている」とイモムシは、きっぱり言った。それから、数分の間、沈黙が続いた。

<a id="AW-05-038"></a>

**AW-05-038**

<!-- EN:AW-05-038 -->
The Caterpillar was the first to speak.
<!-- /EN:AW-05-038 -->

> 先に口を開いたのは、イモムシだった。

<a id="AW-05-039"></a>

**AW-05-039**

<!-- EN:AW-05-039 -->
“What size do you want to be?” it asked.
<!-- /EN:AW-05-039 -->

> 「どんな大きさになりたいんだ？」と聞いた。

<a id="AW-05-040"></a>

**AW-05-040**

<!-- EN:AW-05-040 -->
“Oh, I’m not particular as to size,” Alice hastily replied; “only one doesn’t like changing so often, you know.”
<!-- /EN:AW-05-040 -->

> 「ああ、大きさには、こだわりません」とアリスは慌てて答えた。「ただ、あんなにしょっちゅう変わるのは、嫌なものですから。分かるでしょう。」

<a id="AW-05-041"></a>

**AW-05-041**

<!-- EN:AW-05-041 -->
“I *don’t* know,” said the Caterpillar.
<!-- /EN:AW-05-041 -->

> 「*分からん*」とイモムシは言った。

<a id="AW-05-042"></a>

**AW-05-042**

<!-- EN:AW-05-042 -->
Alice said nothing: she had never been so much contradicted in her life before, and she felt that she was losing her temper.
<!-- /EN:AW-05-042 -->

> アリスは何も言わなかった。生まれてから今まで、こんなに何もかも言い返されたことはない。かんしゃくを起こしそうだと、自分でも感じていた。

<a id="AW-05-043"></a>

**AW-05-043**

<!-- EN:AW-05-043 -->
“Are you content now?” said the Caterpillar.
<!-- /EN:AW-05-043 -->

> 「今のままで、満足なのか？」とイモムシは言った。

<a id="AW-05-044"></a>

**AW-05-044**

<!-- EN:AW-05-044 -->
“Well, I should like to be a *little* larger, sir, if you wouldn’t mind,” said Alice: “three inches is such a wretched height to be.”
<!-- /EN:AW-05-044 -->

> 「ええと、ご迷惑でなければ、*もう少し*大きくなりたいです」とアリスは言った。「三インチの背丈では、あんまり惨めですもの。」

<a id="AW-05-045"></a>

**AW-05-045**

<!-- EN:AW-05-045 -->
“It is a very good height indeed!” said the Caterpillar angrily, rearing itself upright as it spoke (it was exactly three inches high).
<!-- /EN:AW-05-045 -->

> 「実に、申し分のない高さだ！」とイモムシは、怒って言いながら、体をまっすぐ起こした（高さは、ちょうど三インチだった）。

<a id="AW-05-046"></a>

**AW-05-046**

<!-- EN:AW-05-046 -->
“But I’m not used to it!” pleaded poor Alice in a piteous tone. And she thought of herself, “I wish the creatures wouldn’t be so easily offended!”
<!-- /EN:AW-05-046 -->

> 「でも、わたしは慣れていないんです！」と、かわいそうなアリスは、哀れっぽい声で訴えた。そして心の中で、「ここの生き物たちが、こんなにすぐ怒らなければいいのに！」と思った。

<a id="AW-05-047"></a>

**AW-05-047**

<!-- EN:AW-05-047 -->
“You’ll get used to it in time,” said the Caterpillar; and it put the hookah into its mouth and began smoking again.
<!-- /EN:AW-05-047 -->

> 「そのうち慣れる」とイモムシは言い、水ぎせるを口にくわえて、また吸いはじめた。

<a id="AW-05-048"></a>

**AW-05-048**

<!-- EN:AW-05-048 -->
This time Alice waited patiently until it chose to speak again. In a minute or two the Caterpillar took the hookah out of its mouth and yawned once or twice, and shook itself. Then it got down off the mushroom, and crawled away in the grass, merely remarking as it went, “One side will make you grow taller, and the other side will make you grow shorter.”
<!-- /EN:AW-05-048 -->

> 今度はアリスも、イモムシがまた話す気になるまで、辛抱強く待った。一、二分すると、イモムシは水ぎせるを口から外し、一、二度あくびをして、体を震わせた。それからキノコを下り、草の中をはっていった。去り際に、ただ一言、こう言った。「片側で背が伸び、もう片側で背が縮む。」

<a id="AW-05-049"></a>

**AW-05-049**

<!-- EN:AW-05-049 -->
“One side of *what?* The other side of *what?*” thought Alice to herself.
<!-- /EN:AW-05-049 -->

> 「*何の*片側？　*何の*もう片側？」とアリスは心の中で思った。

<a id="AW-05-050"></a>

**AW-05-050**

<!-- EN:AW-05-050 -->
“Of the mushroom,” said the Caterpillar, just as if she had asked it aloud; and in another moment it was out of sight.
<!-- /EN:AW-05-050 -->

> 「キノコのだ」とイモムシは言った。まるで、アリスが声に出して聞いたかのようだ。そして次の瞬間には、姿が見えなくなった。

<a id="AW-05-051"></a>

**AW-05-051**

<!-- EN:AW-05-051 -->
Alice remained looking thoughtfully at the mushroom for a minute, trying to make out which were the two sides of it; and as it was perfectly round, she found this a very difficult question. However, at last she stretched her arms round it as far as they would go, and broke off a bit of the edge with each hand.
<!-- /EN:AW-05-051 -->

> アリスは、しばらく考え込みながらキノコを見つめ、どことどこが、その両側なのか、見定めようとした。けれども、まん丸なので、とても難しい問題だった。それでも、とうとう両腕を、届く限りキノコの周りへ回し、それぞれの手で、縁を少しずつもぎ取った。

<a id="AW-05-052"></a>

**AW-05-052**

<!-- EN:AW-05-052 -->
“And now which is which?” she said to herself, and nibbled a little of the right-hand bit to try the effect: the next moment she felt a violent blow underneath her chin: it had struck her foot!
<!-- /EN:AW-05-052 -->

> 「さて、どちらがどちらなのかしら？」と独り言を言い、効き目を試すために、右手のかけらを少しかじった。次の瞬間、あごの下に激しい衝撃を感じた。あごが、自分の足にぶつかったのだ！

<a id="AW-05-053"></a>

**AW-05-053**

<!-- EN:AW-05-053 -->
She was a good deal frightened by this very sudden change, but she felt that there was no time to be lost, as she was shrinking rapidly; so she set to work at once to eat some of the other bit. Her chin was pressed so closely against her foot, that there was hardly room to open her mouth; but she did it at last, and managed to swallow a morsel of the lefthand bit.
<!-- /EN:AW-05-053 -->

> あまりに急な変化で、アリスはひどく驚いたが、ぐんぐん縮んでいたので、一刻も無駄にはできないと思った。そこで、すぐに、もう一方のかけらを食べようとした。あごが足にぴったり押しつけられていて、口を開ける隙間もほとんどなかったが、ようやく開き、左手のかけらを、どうにか一口飲み込むことができた。

<a id="AW-05-054"></a>

<!-- EN:AW-05-054 -->
\*      \*      \*      \*      \*      \*      \*  
<!-- /EN:AW-05-054 -->

<a id="AW-05-055"></a>

<!-- EN:AW-05-055 -->
    \*      \*      \*      \*      \*      \*  
<!-- /EN:AW-05-055 -->

<a id="AW-05-056"></a>

<!-- EN:AW-05-056 -->
\*      \*      \*      \*      \*      \*      \*
<!-- /EN:AW-05-056 -->

<a id="AW-05-057"></a>

**AW-05-057**

<!-- EN:AW-05-057 -->
“Come, my head’s free at last!” said Alice in a tone of delight, which changed into alarm in another moment, when she found that her shoulders were nowhere to be found: all she could see, when she looked down, was an immense length of neck, which seemed to rise like a stalk out of a sea of green leaves that lay far below her.
<!-- /EN:AW-05-057 -->

> 「さあ、やっと頭が自由になったわ！」とアリスは、うれしそうに言った。けれども次の瞬間、その声はおびえたものに変わった。肩が、どこにも見当たらなかったのだ。見下ろして見えるのは、途方もなく長い首だけだった。はるか下に広がる緑の葉の海から、一本の茎のように伸びているようだった。

<a id="AW-05-058"></a>

**AW-05-058**

<!-- EN:AW-05-058 -->
“What *can* all that green stuff be?” said Alice. “And where *have* my shoulders got to? And oh, my poor hands, how is it I can’t see you?” She was moving them about as she spoke, but no result seemed to follow, except a little shaking among the distant green leaves.
<!-- /EN:AW-05-058 -->

> 「あの緑のものは、いったい*何*なの？」とアリスは言った。「それに、肩は*どこへ*行ってしまったのかしら？　ああ、かわいそうなわたしの手、どうして見えないの？」話しながら両手を動かしていたが、遠くの緑の葉が少し揺れるほか、何の変化もないようだった。

<a id="AW-05-059"></a>

**AW-05-059**

<!-- EN:AW-05-059 -->
As there seemed to be no chance of getting her hands up to her head, she tried to get her head down to them, and was delighted to find that her neck would bend about easily in any direction, like a serpent. She had just succeeded in curving it down into a graceful zigzag, and was going to dive in among the leaves, which she found to be nothing but the tops of the trees under which she had been wandering, when a sharp hiss made her draw back in a hurry: a large pigeon had flown into her face, and was beating her violently with its wings.
<!-- /EN:AW-05-059 -->

> 手を頭のところまで上げるのは、とても無理そうだったので、頭を手のほうへ下ろしてみた。すると、首が蛇のように、どの方向へも簡単に曲がることが分かり、うれしくなった。首を優美なジグザグに曲げながら下ろすことに、ちょうど成功したところで、葉の間へ潜り込もうとした。葉というのは、先ほどまで歩き回っていた木々の、てっぺんにすぎないと分かっていた。すると、鋭いシューッという音がしたので、慌てて頭を引っ込めた。大きなハトが顔めがけて飛んできて、翼で激しくたたいていたのだ。

<a id="AW-05-060"></a>

**AW-05-060**

<!-- EN:AW-05-060 -->
“Serpent!” screamed the Pigeon.
<!-- /EN:AW-05-060 -->

> 「蛇！」とハトは叫んだ。

<a id="AW-05-061"></a>

**AW-05-061**

<!-- EN:AW-05-061 -->
“I’m *not* a serpent!” said Alice indignantly. “Let me alone!”
<!-- /EN:AW-05-061 -->

> 「わたしは蛇じゃ*ないわ*！」とアリスは憤慨して言った。「放っておいて！」

<a id="AW-05-062"></a>

**AW-05-062**

<!-- EN:AW-05-062 -->
“Serpent, I say again!” repeated the Pigeon, but in a more subdued tone, and added with a kind of sob, “I’ve tried every way, and nothing seems to suit them!”
<!-- /EN:AW-05-062 -->

> 「蛇だって、もう一度言うよ！」とハトは繰り返した。けれども声はいくらか弱まり、すすり泣くように付け加えた。「どんなやり方も試したのに、あいつらには、どれも気に入らないらしい！」

<a id="AW-05-063"></a>

**AW-05-063**

<!-- EN:AW-05-063 -->
“I haven’t the least idea what you’re talking about,” said Alice.
<!-- /EN:AW-05-063 -->

> 「何のことを話しているのか、さっぱり分からないわ」とアリスは言った。

<a id="AW-05-064"></a>

**AW-05-064**

<!-- EN:AW-05-064 -->
“I’ve tried the roots of trees, and I’ve tried banks, and I’ve tried hedges,” the Pigeon went on, without attending to her; “but those serpents! There’s no pleasing them!”
<!-- /EN:AW-05-064 -->

> 「木の根元も試したし、土手も試したし、生け垣も試した」とハトは、アリスの言葉に構わず続けた。「でも、あの蛇たちときたら！　どうしたって、満足させられないんだ！」

<a id="AW-05-065"></a>

**AW-05-065**

<!-- EN:AW-05-065 -->
Alice was more and more puzzled, but she thought there was no use in saying anything more till the Pigeon had finished.
<!-- /EN:AW-05-065 -->

> アリスは、ますます訳が分からなくなったが、ハトが話し終えるまでは、何を言っても無駄だと思った。

<a id="AW-05-066"></a>

**AW-05-066**

<!-- EN:AW-05-066 -->
“As if it wasn’t trouble enough hatching the eggs,” said the Pigeon; “but I must be on the look-out for serpents night and day! Why, I haven’t had a wink of sleep these three weeks!”
<!-- /EN:AW-05-066 -->

> 「卵をかえすだけでは、まだ苦労が足りないとでもいうように」とハトは言った。「昼も夜も、蛇を見張っていなくちゃならない！　この三週間、一睡もしていないんだよ！」

<a id="AW-05-067"></a>

**AW-05-067**

<!-- EN:AW-05-067 -->
“I’m very sorry you’ve been annoyed,” said Alice, who was beginning to see its meaning.
<!-- /EN:AW-05-067 -->

> 「そんなに困らされているなんて、お気の毒だわ」とアリスは言った。何を言っているのか、分かりはじめていた。

<a id="AW-05-068"></a>

**AW-05-068**

<!-- EN:AW-05-068 -->
“And just as I’d taken the highest tree in the wood,” continued the Pigeon, raising its voice to a shriek, “and just as I was thinking I should be free of them at last, they must needs come wriggling down from the sky! Ugh, Serpent!”
<!-- /EN:AW-05-068 -->

> 「それで、森でいちばん高い木に移った、まさにそのとき」とハトは続け、声を悲鳴のように高めた。「やっとあいつらから逃れられたと思った、そのときに、わざわざ空から、くねくね下りてくるなんて！　ああ、蛇め！」

<a id="AW-05-069"></a>

**AW-05-069**

<!-- EN:AW-05-069 -->
“But I’m *not* a serpent, I tell you!” said Alice. “I’m a—I’m a—”
<!-- /EN:AW-05-069 -->

> 「でも、蛇じゃ*ない*って、言っているでしょう！」とアリスは言った。「わたしは――わたしは――」

<a id="AW-05-070"></a>

**AW-05-070**

<!-- EN:AW-05-070 -->
“Well! *What* are you?” said the Pigeon. “I can see you’re trying to invent something!”
<!-- /EN:AW-05-070 -->

> 「それで！　*何*だっていうんだい？」とハトは言った。「何かでっち上げようとしているのは、分かっているよ！」

<a id="AW-05-071"></a>

**AW-05-071**

<!-- EN:AW-05-071 -->
“I—I’m a little girl,” said Alice, rather doubtfully, as she remembered the number of changes she had gone through that day.
<!-- /EN:AW-05-071 -->

> 「わ、わたしは、小さな女の子よ」とアリスは、少し自信なさそうに言った。その日に、何度も変わってきたことを思い出したのだ。

<a id="AW-05-072"></a>

**AW-05-072**

<!-- EN:AW-05-072 -->
“A likely story indeed!” said the Pigeon in a tone of the deepest contempt. “I’ve seen a good many little girls in my time, but never *one* with such a neck as that! No, no! You’re a serpent; and there’s no use denying it. I suppose you’ll be telling me next that you never tasted an egg!”
<!-- /EN:AW-05-072 -->

> 「よくも、そんなもっともらしいことを！」とハトは、この上なく見下した声で言った。「これまで、小さな女の子は、ずいぶん見てきたよ。でも、そんな首をした子は、*一人も*いなかった！　違う、違う！　おまえは蛇だ。否定したって、無駄だよ。今度は、卵なんて一度も食べたことがない、とでも言うんだろうね！」

<a id="AW-05-073"></a>

**AW-05-073**

<!-- EN:AW-05-073 -->
“I *have* tasted eggs, certainly,” said Alice, who was a very truthful child; “but little girls eat eggs quite as much as serpents do, you know.”
<!-- /EN:AW-05-073 -->

> 「確かに、卵は食べたことが*ある*わ」とアリスは言った。とても正直な子だったのだ。「でも、小さな女の子だって、蛇とまったく同じくらい、卵を食べるものよ。」

<a id="AW-05-074"></a>

**AW-05-074**

<!-- EN:AW-05-074 -->
“I don’t believe it,” said the Pigeon; “but if they do, why then they’re a kind of serpent, that’s all I can say.”
<!-- /EN:AW-05-074 -->

> 「信じないね」とハトは言った。「でも、もしそうなら、女の子も蛇の一種だ。それしか言いようがないね。」

<a id="AW-05-075"></a>

**AW-05-075**

<!-- EN:AW-05-075 -->
This was such a new idea to Alice, that she was quite silent for a minute or two, which gave the Pigeon the opportunity of adding, “You’re looking for eggs, I know *that* well enough; and what does it matter to me whether you’re a little girl or a serpent?”
<!-- /EN:AW-05-075 -->

> アリスには、あまりにも新しい考えだったので、一、二分、すっかり黙り込んでしまった。そのためハトは、さらに付け加えることができた。「おまえは卵を探しているんだ。*それは*、よく分かっているよ。おまえが小さな女の子だろうが蛇だろうが、私に何の違いがある？」

<a id="AW-05-076"></a>

**AW-05-076**

<!-- EN:AW-05-076 -->
“It matters a good deal to *me*,” said Alice hastily; “but I’m not looking for eggs, as it happens; and if I was, I shouldn’t want *yours*: I don’t like them raw.”
<!-- /EN:AW-05-076 -->

> 「*わたしには*、大きな違いがあるわ」とアリスは慌てて言った。「でも、あいにく卵を探しているんじゃないの。それに、もし探していたって、*あなたの*卵はいらないわ。生では好きじゃないもの。」

<a id="AW-05-077"></a>

**AW-05-077**

<!-- EN:AW-05-077 -->
“Well, be off, then!” said the Pigeon in a sulky tone, as it settled down again into its nest. Alice crouched down among the trees as well as she could, for her neck kept getting entangled among the branches, and every now and then she had to stop and untwist it. After a while she remembered that she still held the pieces of mushroom in her hands, and she set to work very carefully, nibbling first at one and then at the other, and growing sometimes taller and sometimes shorter, until she had succeeded in bringing herself down to her usual height.
<!-- /EN:AW-05-077 -->

> 「それなら、行ってしまいな！」とハトは、不機嫌な声で言い、また巣の中に落ち着いた。アリスは、できるだけ低くかがんで、木々の間を進んだ。首がしょっちゅう枝に絡まるので、ときどき立ち止まって、ほどかなければならなかったのだ。しばらくして、まだ両手にキノコのかけらを持っていることを思い出した。そこで、細心の注意を払って、片方をかじり、もう片方をかじり、背を伸ばしたり縮めたりして、とうとう、いつもの高さまで戻ることができた。

<a id="AW-05-078"></a>

**AW-05-078**

<!-- EN:AW-05-078 -->
It was so long since she had been anything near the right size, that it felt quite strange at first; but she got used to it in a few minutes, and began talking to herself, as usual. “Come, there’s half my plan done now! How puzzling all these changes are! I’m never sure what I’m going to be, from one minute to another! However, I’ve got back to my right size: the next thing is, to get into that beautiful garden—how *is* that to be done, I wonder?” As she said this, she came suddenly upon an open place, with a little house in it about four feet high. “Whoever lives there,” thought Alice, “it’ll never do to come upon them *this* size: why, I should frighten them out of their wits!” So she began nibbling at the righthand bit again, and did not venture to go near the house till she had brought herself down to nine inches high.
<!-- /EN:AW-05-078 -->

> 元の大きさに近い状態でいるのは、本当に久しぶりだったので、最初は、とても変な感じがした。けれども数分で慣れ、いつものように、独り言をはじめた。「さあ、これで計画の半分はできたわ！　こう次々と変わるなんて、何てややこしいんでしょう！　一分先に何になるのか、少しも分からないんだもの！　でも、元の大きさには戻れたわ。次は、あの美しい庭に入ることね――*どうしたら*入れるのかしら？」そう言いながら進むと、突然、開けた場所に出た。そこには、高さ四フィートほどの小さな家があった。「誰が住んでいるにせよ」とアリスは思った。「*この*大きさで、いきなり訪ねるのは、絶対にだめね。だって、気を失うほど驚かせてしまうもの！」そこで、また右手のかけらをかじりはじめ、背が九インチになるまで、家へ近づこうとはしなかった。

[章目次へ戻る](#book-top)

---

<a id="aw-chapter-06"></a>

## 第6章　豚とコショウ

### CHAPTER VI. Pig and Pepper

<a id="AW-06-001"></a>

**AW-06-001**

<!-- EN:AW-06-001 -->
For a minute or two she stood looking at the house, and wondering what to do next, when suddenly a footman in livery came running out of the wood—(she considered him to be a footman because he was in livery: otherwise, judging by his face only, she would have called him a fish)—and rapped loudly at the door with his knuckles. It was opened by another footman in livery, with a round face, and large eyes like a frog; and both footmen, Alice noticed, had powdered hair that curled all over their heads. She felt very curious to know what it was all about, and crept a little way out of the wood to listen.
<!-- /EN:AW-06-001 -->

> アリスは一、二分、立ち止まって家を眺め、次にどうしようかと考えていた。すると突然、お仕着せを着た召使いが、森から駆けてきた。（お仕着せを着ているから、召使いだと思ったのだ。そうでなければ、顔だけ見て、魚と呼んだだろう。）その召使いは、指の関節で、大きな音を立てて扉をたたいた。扉を開けたのは、やはりお仕着せを着た、別の召使いだった。丸い顔に、カエルのような大きな目をしている。二人とも、頭じゅうに巻き毛があり、粉を振ってあることに、アリスは気づいた。何事なのか、とても知りたくなって、話を聞こうと、森から少しだけ、そっと出た。

<a id="AW-06-002"></a>

**AW-06-002**

<!-- EN:AW-06-002 -->
The Fish-Footman began by producing from under his arm a great letter, nearly as large as himself, and this he handed over to the other, saying, in a solemn tone, “For the Duchess. An invitation from the Queen to play croquet.” The Frog-Footman repeated, in the same solemn tone, only changing the order of the words a little, “From the Queen. An invitation for the Duchess to play croquet.”
<!-- /EN:AW-06-002 -->

> 魚の召使いは、まず、脇の下から、自分とほとんど同じ大きさの大きな手紙を取り出した。それをもう一人に渡し、厳かな声で言った。「公爵夫人へ。女王様から、クロッケーへのご招待です。」カエルの召使いも、同じように厳かな声で、言葉の順を少しだけ変えて、繰り返した。「女王様から。公爵夫人へ、クロッケーのご招待です。」

<a id="AW-06-003"></a>

**AW-06-003**

<!-- EN:AW-06-003 -->
Then they both bowed low, and their curls got entangled together.
<!-- /EN:AW-06-003 -->

> それから二人とも、深くお辞儀をしたので、巻き毛が互いに絡まってしまった。

<a id="AW-06-004"></a>

**AW-06-004**

<!-- EN:AW-06-004 -->
Alice laughed so much at this, that she had to run back into the wood for fear of their hearing her; and when she next peeped out the Fish-Footman was gone, and the other was sitting on the ground near the door, staring stupidly up into the sky.
<!-- /EN:AW-06-004 -->

> アリスは、あまりにおかしくて笑ったので、聞かれては困ると、森の中へ駆け戻らなければならなかった。次にのぞいたときには、魚の召使いはもういなかった。もう一人は、扉のそばの地面に座り、ぼんやり空を見上げていた。

<a id="AW-06-005"></a>

**AW-06-005**

<!-- EN:AW-06-005 -->
Alice went timidly up to the door, and knocked.
<!-- /EN:AW-06-005 -->

> アリスは、おずおずと扉へ近づき、ノックした。

<a id="AW-06-006"></a>

**AW-06-006**

<!-- EN:AW-06-006 -->
“There’s no sort of use in knocking,” said the Footman, “and that for two reasons. First, because I’m on the same side of the door as you are; secondly, because they’re making such a noise inside, no one could possibly hear you.” And certainly there *was* a most extraordinary noise going on within—a constant howling and sneezing, and every now and then a great crash, as if a dish or kettle had been broken to pieces.
<!-- /EN:AW-06-006 -->

> 「ノックしても、何の役にも立たないよ」と召使いは言った。「それには、二つ理由がある。第一に、私は、扉のきみと同じ側にいるから。第二に、中ではあんな騒ぎをしているから、きみのノックなんて、誰にも聞こえるはずがない。」確かに中では、*並大抵でない*騒ぎが続いていた。泣き声とくしゃみが絶え間なく響き、ときどき、皿ややかんが粉々に割れたような、大きな音がするのだ。

<a id="AW-06-007"></a>

**AW-06-007**

<!-- EN:AW-06-007 -->
“Please, then,” said Alice, “how am I to get in?”
<!-- /EN:AW-06-007 -->

> 「それでは、すみませんが」とアリスは言った。「わたしは、どうやって入ればいいのでしょう？」

<a id="AW-06-008"></a>

**AW-06-008**

<!-- EN:AW-06-008 -->
“There might be some sense in your knocking,” the Footman went on without attending to her, “if we had the door between us. For instance, if you were *inside*, you might knock, and I could let you out, you know.” He was looking up into the sky all the time he was speaking, and this Alice thought decidedly uncivil. “But perhaps he can’t help it,” she said to herself; “his eyes are so *very* nearly at the top of his head. But at any rate he might answer questions.—How am I to get in?” she repeated, aloud.
<!-- /EN:AW-06-008 -->

> 「きみのノックにも、多少の意味はあるだろうね」と召使いは、アリスの言葉を気にせずに続けた。「私たちの間に、扉があれば。例えば、きみが*中に*いたなら、ノックして、私に外へ出してもらえるわけだ。」話している間じゅう、空を見上げていたので、アリスは、これは明らかに無作法だと思った。「でも、仕方がないのかもしれないわ」と独り言を言った。「目が、*ほとんど*頭のてっぺんにあるんだもの。でも、とにかく、質問には答えてくれてもいいでしょうに。――どうやって入ればいいのでしょう？」と、声に出して繰り返した。

<a id="AW-06-009"></a>

**AW-06-009**

<!-- EN:AW-06-009 -->
“I shall sit here,” the Footman remarked, “till tomorrow—”
<!-- /EN:AW-06-009 -->

> 「私は、ここに座っていよう」と召使いは言った。「明日まで――」

<a id="AW-06-010"></a>

**AW-06-010**

<!-- EN:AW-06-010 -->
At this moment the door of the house opened, and a large plate came skimming out, straight at the Footman’s head: it just grazed his nose, and broke to pieces against one of the trees behind him.
<!-- /EN:AW-06-010 -->

> そのとき、家の扉が開き、大きな皿が、召使いの頭をめがけて、まっすぐ滑るように飛び出してきた。皿は、鼻をかすめただけで、後ろの木にぶつかり、粉々になった。

<a id="AW-06-011"></a>

**AW-06-011**

<!-- EN:AW-06-011 -->
“—or next day, maybe,” the Footman continued in the same tone, exactly as if nothing had happened.
<!-- /EN:AW-06-011 -->

> 「――いや、あさってまでかもしれない」と召使いは、まるで何事もなかったかのように、同じ調子で続けた。

<a id="AW-06-012"></a>

**AW-06-012**

<!-- EN:AW-06-012 -->
“How am I to get in?” asked Alice again, in a louder tone.
<!-- /EN:AW-06-012 -->

> 「どうやって入ればいいのでしょう？」とアリスは、声を大きくして、もう一度聞いた。

<a id="AW-06-013"></a>

**AW-06-013**

<!-- EN:AW-06-013 -->
“*Are* you to get in at all?” said the Footman. “That’s the first question, you know.”
<!-- /EN:AW-06-013 -->

> 「そもそも、きみは入ることに*なっているのかい*？」と召使いは言った。「まず、それが問題だよ。」

<a id="AW-06-014"></a>

**AW-06-014**

<!-- EN:AW-06-014 -->
It was, no doubt: only Alice did not like to be told so. “It’s really dreadful,” she muttered to herself, “the way all the creatures argue. It’s enough to drive one crazy!”
<!-- /EN:AW-06-014 -->

> 確かに、そのとおりだった。ただ、アリスは、そう言われるのが嫌だった。「本当にひどいわ」と小声で独り言を言った。「ここの生き物は、みんな、あんなふうに理屈をこねるんだから。気がおかしくなりそうよ！」

<a id="AW-06-015"></a>

**AW-06-015**

<!-- EN:AW-06-015 -->
The Footman seemed to think this a good opportunity for repeating his remark, with variations. “I shall sit here,” he said, “on and off, for days and days.”
<!-- /EN:AW-06-015 -->

> 召使いは、言葉を少し変えて、さっきの発言を繰り返すのに、ちょうどいい機会だと思ったようだった。「私は、ここに座っていよう」と言った。「ときどきね、何日も、何日も。」

<a id="AW-06-016"></a>

**AW-06-016**

<!-- EN:AW-06-016 -->
“But what am *I* to do?” said Alice.
<!-- /EN:AW-06-016 -->

> 「でも、*わたしは*、どうすればいいの？」とアリスは言った。

<a id="AW-06-017"></a>

**AW-06-017**

<!-- EN:AW-06-017 -->
“Anything you like,” said the Footman, and began whistling.
<!-- /EN:AW-06-017 -->

> 「好きなようにすればいい」と召使いは言い、口笛を吹きはじめた。

<a id="AW-06-018"></a>

**AW-06-018**

<!-- EN:AW-06-018 -->
“Oh, there’s no use in talking to him,” said Alice desperately: “he’s perfectly idiotic!” And she opened the door and went in.
<!-- /EN:AW-06-018 -->

> 「ああ、この人と話しても、無駄だわ」とアリスは、すっかり困り果てて言った。「まったくの、ばかなんだもの！」そして、扉を開けて、中へ入った。

<a id="AW-06-019"></a>

**AW-06-019**

<!-- EN:AW-06-019 -->
The door led right into a large kitchen, which was full of smoke from one end to the other: the Duchess was sitting on a three-legged stool in the middle, nursing a baby; the cook was leaning over the fire, stirring a large cauldron which seemed to be full of soup.
<!-- /EN:AW-06-019 -->

> 扉のすぐ先は、大きな台所で、端から端まで煙が立ちこめていた。真ん中の三本脚の腰掛けには、公爵夫人が座り、赤ん坊を抱いていた。料理人は、火の上へ身をかがめ、スープでいっぱいらしい大鍋を、かき回していた。

<a id="AW-06-020"></a>

**AW-06-020**

<!-- EN:AW-06-020 -->
“There’s certainly too much pepper in that soup!” Alice said to herself, as well as she could for sneezing.
<!-- /EN:AW-06-020 -->

> 「あのスープには、絶対にコショウが入りすぎているわ！」とアリスは、くしゃみの合間を縫って、どうにか独り言を言った。

<a id="AW-06-021"></a>

**AW-06-021**

<!-- EN:AW-06-021 -->
There was certainly too much of it in the air. Even the Duchess sneezed occasionally; and as for the baby, it was sneezing and howling alternately without a moment’s pause. The only things in the kitchen that did not sneeze, were the cook, and a large cat which was sitting on the hearth and grinning from ear to ear.
<!-- /EN:AW-06-021 -->

> 確かに、空気の中にはコショウが多すぎた。公爵夫人でさえ、ときどきくしゃみをした。赤ん坊となると、一瞬の休みもなく、くしゃみと大泣きを交互に続けていた。台所でくしゃみをしないのは、料理人と、暖炉の炉床に座って、口を耳まで広げてにやにや笑っている、大きな猫だけだった。

<a id="AW-06-022"></a>

**AW-06-022**

<!-- EN:AW-06-022 -->
“Please would you tell me,” said Alice, a little timidly, for she was not quite sure whether it was good manners for her to speak first, “why your cat grins like that?”
<!-- /EN:AW-06-022 -->

> 「どうぞ、教えていただけますか」とアリスは、少しおずおずと言った。自分から話しかけるのが、礼儀にかなうのかどうか、確信がなかったのだ。「どうして、あなたの猫は、あんなふうににやにや笑うのでしょう？」

<a id="AW-06-023"></a>

**AW-06-023**

<!-- EN:AW-06-023 -->
“It’s a Cheshire cat,” said the Duchess, “and that’s why. Pig!”
<!-- /EN:AW-06-023 -->

> 「チェシャ猫だからよ」と公爵夫人は言った。「それが理由。豚め！」

<a id="AW-06-024"></a>

**AW-06-024**

<!-- EN:AW-06-024 -->
She said the last word with such sudden violence that Alice quite jumped; but she saw in another moment that it was addressed to the baby, and not to her, so she took courage, and went on again:—
<!-- /EN:AW-06-024 -->

> 最後の一言が、あまりに突然で激しかったので、アリスは飛び上がってしまった。けれどもすぐに、自分にではなく赤ん坊に言ったのだと分かったので、勇気を出して、また話を続けた。――

<a id="AW-06-025"></a>

**AW-06-025**

<!-- EN:AW-06-025 -->
“I didn’t know that Cheshire cats always grinned; in fact, I didn’t know that cats *could* grin.”
<!-- /EN:AW-06-025 -->

> 「チェシャ猫が、いつもにやにやするなんて、知りませんでした。それどころか、猫がにやにや笑えること*自体*、知りませんでした。」

<a id="AW-06-026"></a>

**AW-06-026**

<!-- EN:AW-06-026 -->
“They all can,” said the Duchess; “and most of ’em do.”
<!-- /EN:AW-06-026 -->

> 「どの猫にも、できるわ」と公爵夫人は言った。「たいていの猫は、実際にするしね。」

<a id="AW-06-027"></a>

**AW-06-027**

<!-- EN:AW-06-027 -->
“I don’t know of any that do,” Alice said very politely, feeling quite pleased to have got into a conversation.
<!-- /EN:AW-06-027 -->

> 「そういう猫を、わたしは一匹も知りません」とアリスは、とても丁寧に言った。会話に入れたことが、すっかりうれしくなっていた。

<a id="AW-06-028"></a>

**AW-06-028**

<!-- EN:AW-06-028 -->
“You don’t know much,” said the Duchess; “and that’s a fact.”
<!-- /EN:AW-06-028 -->

> 「あなたは、物をあまり知らないのね」と公爵夫人は言った。「それは、事実よ。」

<a id="AW-06-029"></a>

**AW-06-029**

<!-- EN:AW-06-029 -->
Alice did not at all like the tone of this remark, and thought it would be as well to introduce some other subject of conversation. While she was trying to fix on one, the cook took the cauldron of soup off the fire, and at once set to work throwing everything within her reach at the Duchess and the baby—the fire-irons came first; then followed a shower of saucepans, plates, and dishes. The Duchess took no notice of them even when they hit her; and the baby was howling so much already, that it was quite impossible to say whether the blows hurt it or not.
<!-- /EN:AW-06-029 -->

> アリスは、この言い方がまったく気に入らなかった。別の話題を持ち出したほうがよさそうだと思い、何にしようかと考えていた。すると料理人が、スープの大鍋を火から下ろし、すぐに、手の届くものを何でも、公爵夫人と赤ん坊に投げつけはじめた。まずは、火かき棒などの暖炉道具。それから、片手鍋や大小の皿が、雨あられと続いた。公爵夫人は、当たっても、まるで気にしない。赤ん坊は、すでにひどく泣きわめいていたので、当たって痛いのかどうか、とても分からなかった。

<a id="AW-06-030"></a>

**AW-06-030**

<!-- EN:AW-06-030 -->
“Oh, *please* mind what you’re doing!” cried Alice, jumping up and down in an agony of terror. “Oh, there goes his *precious* nose!” as an unusually large saucepan flew close by it, and very nearly carried it off.
<!-- /EN:AW-06-030 -->

> 「ああ、*お願いですから*、何をしているか、気をつけて！」とアリスは、恐ろしさにたまらず跳びはねながら叫んだ。「ああ、赤ちゃんの*大事な*鼻が！」ひときわ大きな片手鍋が、鼻のすぐそばを飛び、もう少しで、もぎ取るところだったのだ。

<a id="AW-06-031"></a>

**AW-06-031**

<!-- EN:AW-06-031 -->
“If everybody minded their own business,” the Duchess said in a hoarse growl, “the world would go round a deal faster than it does.”
<!-- /EN:AW-06-031 -->

> 「誰もが自分のことだけ、気にしていればね」と公爵夫人は、かすれたうなり声で言った。「世の中は、今よりずっと速く回るものよ。」

<a id="AW-06-032"></a>

**AW-06-032**

<!-- EN:AW-06-032 -->
“Which would *not* be an advantage,” said Alice, who felt very glad to get an opportunity of showing off a little of her knowledge. “Just think of what work it would make with the day and night! You see the earth takes twenty-four hours to turn round on its axis—”
<!-- /EN:AW-06-032 -->

> 「それは、よいことでは*ありません*」とアリスは言った。自分の知識を少し披露する機会ができて、とてもうれしかったのだ。「昼と夜が、どんな大変なことになるか、考えてみてください！　地球は、その軸の周りを一回転するのに、二十四時間かかるんですから――」

<a id="AW-06-033"></a>

**AW-06-033**

<!-- EN:AW-06-033 -->
“Talking of axes,” said the Duchess, “chop off her head!”
<!-- /EN:AW-06-033 -->

> 「斧の話なら」と公爵夫人は言った。「この子の首を切り落としなさい！」

> **訳注：** axis（軸）から、似た音の axes（斧の複数形）へ、公爵夫人が話をすり替える。

<a id="AW-06-034"></a>

**AW-06-034**

<!-- EN:AW-06-034 -->
Alice glanced rather anxiously at the cook, to see if she meant to take the hint; but the cook was busily stirring the soup, and seemed not to be listening, so she went on again: “Twenty-four hours, I *think*; or is it twelve? I—”
<!-- /EN:AW-06-034 -->

> アリスは、料理人がその言葉に従うつもりなのか、心配そうにちらりと見た。けれども料理人は、忙しくスープをかき回していて、聞いていないようだったので、また続けた。「二十四時間、だと*思います*。それとも十二時間だったかしら？　わたし――」

<a id="AW-06-035"></a>

**AW-06-035**

<!-- EN:AW-06-035 -->
“Oh, don’t bother *me*,” said the Duchess; “I never could abide figures!” And with that she began nursing her child again, singing a sort of lullaby to it as she did so, and giving it a violent shake at the end of every line:
<!-- /EN:AW-06-035 -->

> 「ああ、*私を*煩わせないで」と公爵夫人は言った。「数字は、昔から我慢ならないの！」そう言うと、また子どもを抱いてあやしはじめ、子守歌のようなものを歌った。そして、一行歌い終わるたびに、赤ん坊を激しく揺さぶった。

<a id="AW-06-036"></a>

**AW-06-036**

<!-- EN:AW-06-036 -->
“Speak roughly to your little boy,  
    And beat him when he sneezes:  
He only does it to annoy,  
    Because he knows it teases.”
<!-- /EN:AW-06-036 -->

> 「小さな男の子には、荒っぽく言いな、  
> 　　くしゃみをしたら、ひっぱたけ。  
> あれは、ただ人を困らせたいだけ、  
> 　　こっちが嫌がると、知ってるからさ。」

<a id="AW-06-037"></a>

**AW-06-037**

<!-- EN:AW-06-037 -->
CHORUS.  
(In which the cook and the baby joined):
<!-- /EN:AW-06-037 -->

> 合唱。  
> （料理人と赤ん坊も加わって）

<a id="AW-06-038"></a>

**AW-06-038**

<!-- EN:AW-06-038 -->
“Wow! wow! wow!”
<!-- /EN:AW-06-038 -->

> 「わあ！　わあ！　わあ！」

<a id="AW-06-039"></a>

**AW-06-039**

<!-- EN:AW-06-039 -->
While the Duchess sang the second verse of the song, she kept tossing the baby violently up and down, and the poor little thing howled so, that Alice could hardly hear the words:—
<!-- /EN:AW-06-039 -->

> 公爵夫人は歌の二番を歌いながら、赤ん坊を激しく上へ放り上げたり、下へ受け止めたりしつづけた。かわいそうな赤ん坊が、あまりに大声で泣くので、アリスには歌詞がほとんど聞こえなかった。――

<a id="AW-06-040"></a>

**AW-06-040**

<!-- EN:AW-06-040 -->
“I speak severely to my boy,  
    I beat him when he sneezes;  
For he can thoroughly enjoy  
    The pepper when he pleases!”
<!-- /EN:AW-06-040 -->

> 「私は息子を、厳しく叱る、  
> 　　くしゃみをしたら、ひっぱたく。  
> だって、その気になりさえすれば、  
> 　　コショウを、うんと楽しめるんだから！」

<a id="AW-06-041"></a>

**AW-06-041**

<!-- EN:AW-06-041 -->
CHORUS.
<!-- /EN:AW-06-041 -->

> 合唱。

<a id="AW-06-042"></a>

**AW-06-042**

<!-- EN:AW-06-042 -->
“Wow! wow! wow!”
<!-- /EN:AW-06-042 -->

> 「わあ！　わあ！　わあ！」

<a id="AW-06-043"></a>

**AW-06-043**

<!-- EN:AW-06-043 -->
“Here! you may nurse it a bit, if you like!” the Duchess said to Alice, flinging the baby at her as she spoke. “I must go and get ready to play croquet with the Queen,” and she hurried out of the room. The cook threw a frying-pan after her as she went out, but it just missed her.
<!-- /EN:AW-06-043 -->

> 「ほら！　よければ、しばらく抱いていてもいいわよ！」と公爵夫人はアリスに言い、そう言いながら赤ん坊を投げ渡した。「私は、女王様とクロッケーをする支度をしなくちゃ。」そして、急いで部屋を出た。出ていく公爵夫人のあとへ、料理人はフライパンを投げたが、わずかに外れた。

<a id="AW-06-044"></a>

**AW-06-044**

<!-- EN:AW-06-044 -->
Alice caught the baby with some difficulty, as it was a queer-shaped little creature, and held out its arms and legs in all directions, “just like a star-fish,” thought Alice. The poor little thing was snorting like a steam-engine when she caught it, and kept doubling itself up and straightening itself out again, so that altogether, for the first minute or two, it was as much as she could do to hold it.
<!-- /EN:AW-06-044 -->

> アリスは、少し苦労して赤ん坊を受け止めた。奇妙な形をした小さな生き物で、手足を四方八方へ突き出していたからだ。「まるでヒトデだわ」とアリスは思った。受け止めたとき、かわいそうな赤ん坊は、蒸気機関のように鼻を鳴らしていた。そのうえ、体を二つに折り曲げては、また伸ばすのを繰り返していたので、最初の一、二分は、とにかく抱いているだけで精いっぱいだった。

<a id="AW-06-045"></a>

**AW-06-045**

<!-- EN:AW-06-045 -->
As soon as she had made out the proper way of nursing it, (which was to twist it up into a sort of knot, and then keep tight hold of its right ear and left foot, so as to prevent its undoing itself,) she carried it out into the open air. “If I don’t take this child away with me,” thought Alice, “they’re sure to kill it in a day or two: wouldn’t it be murder to leave it behind?” She said the last words out loud, and the little thing grunted in reply (it had left off sneezing by this time). “Don’t grunt,” said Alice; “that’s not at all a proper way of expressing yourself.”
<!-- /EN:AW-06-045 -->

> うまい抱き方が分かると、アリスはすぐに、外の空気の中へ連れ出した。（その抱き方というのは、体を結び目のようにひねってから、ほどけないよう、右耳と左足をしっかりつかんでおくことだった。）「この子を連れていかなければ」とアリスは考えた。「あの人たちは、一日か二日で、きっと殺してしまうわ。置いていくのは、人殺しと同じじゃないかしら？」最後の言葉は声に出したので、赤ん坊は返事に、ぶうっと鳴いた（このころには、くしゃみをやめていた）。「ぶうぶう言わないで」とアリスは言った。「そんなの、ちゃんとした気持ちの伝え方じゃないわ。」

<a id="AW-06-046"></a>

**AW-06-046**

<!-- EN:AW-06-046 -->
The baby grunted again, and Alice looked very anxiously into its face to see what was the matter with it. There could be no doubt that it had a *very* turn-up nose, much more like a snout than a real nose; also its eyes were getting extremely small for a baby: altogether Alice did not like the look of the thing at all. “But perhaps it was only sobbing,” she thought, and looked into its eyes again, to see if there were any tears.
<!-- /EN:AW-06-046 -->

> 赤ん坊がまたぶうっと鳴いたので、アリスは、どうしたのかと、とても心配そうに顔をのぞき込んだ。鼻が*ひどく*上を向いているのは、間違いない。人の鼻というより、ずっと豚の鼻面に似ていた。それに、目も赤ん坊にしては、極端に小さくなっていた。全体として、アリスには、その見た目が少しも気に入らなかった。「でも、ただ、すすり泣いていただけかもしれないわ」と思い、涙があるかどうか、もう一度目をのぞき込んだ。

<a id="AW-06-047"></a>

**AW-06-047**

<!-- EN:AW-06-047 -->
No, there were no tears. “If you’re going to turn into a pig, my dear,” said Alice, seriously, “I’ll have nothing more to do with you. Mind now!” The poor little thing sobbed again (or grunted, it was impossible to say which), and they went on for some while in silence.
<!-- /EN:AW-06-047 -->

> いいえ、涙はなかった。「ねえ、豚になるつもりなら」とアリスは、真剣に言った。「わたしは、もうあなたにはかかわらないわよ。分かったわね！」かわいそうな赤ん坊は、またすすり泣いた（あるいは、ぶうっと鳴いたのか。どちらなのか、分からなかった）。それからしばらくは、黙って進んだ。

<a id="AW-06-048"></a>

**AW-06-048**

<!-- EN:AW-06-048 -->
Alice was just beginning to think to herself, “Now, what am I to do with this creature when I get it home?” when it grunted again, so violently, that she looked down into its face in some alarm. This time there could be *no* mistake about it: it was neither more nor less than a pig, and she felt that it would be quite absurd for her to carry it further.
<!-- /EN:AW-06-048 -->

> アリスが心の中で、「さて、この子を家に連れて帰って、どうすればいいのかしら？」と考えはじめた、ちょうどそのとき、赤ん坊がまたぶうっと鳴いた。あまりに激しかったので、アリスは少しおびえて、その顔を見下ろした。今度は、間違いようが*ない*。それは、まったくもって、ただの豚だった。これ以上抱いて運ぶのは、とてもばかげていると感じた。

<a id="AW-06-049"></a>

**AW-06-049**

<!-- EN:AW-06-049 -->
So she set the little creature down, and felt quite relieved to see it trot away quietly into the wood. “If it had grown up,” she said to herself, “it would have made a dreadfully ugly child: but it makes rather a handsome pig, I think.” And she began thinking over other children she knew, who might do very well as pigs, and was just saying to herself, “if one only knew the right way to change them—” when she was a little startled by seeing the Cheshire Cat sitting on a bough of a tree a few yards off.
<!-- /EN:AW-06-049 -->

> そこでアリスは、その小さな生き物を地面に下ろした。静かに小走りで森へ去っていくのを見て、すっかり安心した。「あのまま育っていたら」と独り言を言った。「ひどく不器量な子どもになっていたでしょうね。でも、豚としては、なかなかいい顔だと思うわ。」そして、知っているほかの子どもたちのうち、豚になったら、うまくいきそうな子たちを思い浮かべはじめた。「どうやって変えたらいいかさえ、分かれば――」と言いかけたとき、数ヤード先の木の枝に、チェシャ猫が座っているのを見て、少しびっくりした。

<a id="AW-06-050"></a>

**AW-06-050**

<!-- EN:AW-06-050 -->
The Cat only grinned when it saw Alice. It looked good-natured, she thought: still it had *very* long claws and a great many teeth, so she felt that it ought to be treated with respect.
<!-- /EN:AW-06-050 -->

> 猫はアリスを見ると、ただ、にやりと笑った。気立てはよさそうだ、とアリスは思った。それでも、*とても*長い爪と、たくさんの歯があったので、礼を尽くして接するべきだと感じた。

<a id="AW-06-051"></a>

**AW-06-051**

<!-- EN:AW-06-051 -->
“Cheshire Puss,” she began, rather timidly, as she did not at all know whether it would like the name: however, it only grinned a little wider. “Come, it’s pleased so far,” thought Alice, and she went on. “Would you tell me, please, which way I ought to go from here?”
<!-- /EN:AW-06-051 -->

> 「チェシャの猫ちゃん」とアリスは、少しおずおずと呼びかけた。その呼び名を気に入るかどうか、まったく分からなかったのだ。けれども猫は、少し笑みを広げただけだった。「さて、今のところは気に入ってくれたわ」と思い、続けた。「ここから、どちらへ行けばいいか、教えていただけるかしら？」

<a id="AW-06-052"></a>

**AW-06-052**

<!-- EN:AW-06-052 -->
“That depends a good deal on where you want to get to,” said the Cat.
<!-- /EN:AW-06-052 -->

> 「それは、きみがどこへ行きたいかによって、ずいぶん違ってくるね」と猫は言った。

<a id="AW-06-053"></a>

**AW-06-053**

<!-- EN:AW-06-053 -->
“I don’t much care where—” said Alice.
<!-- /EN:AW-06-053 -->

> 「どこでも、あまり構わないんだけれど――」とアリスは言った。

<a id="AW-06-054"></a>

**AW-06-054**

<!-- EN:AW-06-054 -->
“Then it doesn’t matter which way you go,” said the Cat.
<!-- /EN:AW-06-054 -->

> 「それなら、どちらへ行っても構わないね」と猫は言った。

<a id="AW-06-055"></a>

**AW-06-055**

<!-- EN:AW-06-055 -->
“—so long as I get *somewhere*,” Alice added as an explanation.
<!-- /EN:AW-06-055 -->

> 「――*どこかへ*着きさえすれば」とアリスは、説明を付け足した。

<a id="AW-06-056"></a>

**AW-06-056**

<!-- EN:AW-06-056 -->
“Oh, you’re sure to do that,” said the Cat, “if you only walk long enough.”
<!-- /EN:AW-06-056 -->

> 「ああ、それなら必ず着くよ」と猫は言った。「十分長く歩きさえすればね。」

<a id="AW-06-057"></a>

**AW-06-057**

<!-- EN:AW-06-057 -->
Alice felt that this could not be denied, so she tried another question. “What sort of people live about here?”
<!-- /EN:AW-06-057 -->

> アリスは、それは否定できないと思ったので、別の質問をしてみた。「この辺りには、どんな人たちが住んでいるの？」

<a id="AW-06-058"></a>

**AW-06-058**

<!-- EN:AW-06-058 -->
“In *that* direction,” the Cat said, waving its right paw round, “lives a Hatter: and in *that* direction,” waving the other paw, “lives a March Hare. Visit either you like: they’re both mad.”
<!-- /EN:AW-06-058 -->

> 「*あちら*には」と猫は、右の前足を振り回して言った。「帽子屋が住んでいる。そして*あちら*には」と、もう一方の前足を振って、「三月ウサギが住んでいる。好きなほうを訪ねるといい。どちらも、気が狂っているよ。」

<a id="AW-06-059"></a>

**AW-06-059**

<!-- EN:AW-06-059 -->
“But I don’t want to go among mad people,” Alice remarked.
<!-- /EN:AW-06-059 -->

> 「でも、気が狂った人たちのところへは、行きたくないわ」とアリスは言った。

<a id="AW-06-060"></a>

**AW-06-060**

<!-- EN:AW-06-060 -->
“Oh, you can’t help that,” said the Cat: “we’re all mad here. I’m mad. You’re mad.”
<!-- /EN:AW-06-060 -->

> 「ああ、それはどうにもならない」と猫は言った。「ここでは、みんな気が狂っている。私も狂っている。きみも狂っている。」

<a id="AW-06-061"></a>

**AW-06-061**

<!-- EN:AW-06-061 -->
“How do you know I’m mad?” said Alice.
<!-- /EN:AW-06-061 -->

> 「どうして、わたしの気が狂っていると分かるの？」とアリスは言った。

<a id="AW-06-062"></a>

**AW-06-062**

<!-- EN:AW-06-062 -->
“You must be,” said the Cat, “or you wouldn’t have come here.”
<!-- /EN:AW-06-062 -->

> 「そうに決まっている」と猫は言った。「そうでなければ、ここへ来なかったはずだからね。」

<a id="AW-06-063"></a>

**AW-06-063**

<!-- EN:AW-06-063 -->
Alice didn’t think that proved it at all; however, she went on “And how do you know that you’re mad?”
<!-- /EN:AW-06-063 -->

> アリスは、それでは少しも証明になっていないと思った。それでも、続けた。「それなら、あなた自身が狂っていることは、どうして分かるの？」

<a id="AW-06-064"></a>

**AW-06-064**

<!-- EN:AW-06-064 -->
“To begin with,” said the Cat, “a dog’s not mad. You grant that?”
<!-- /EN:AW-06-064 -->

> 「まず」と猫は言った。「犬は狂っていない。それは、認めるかい？」

<a id="AW-06-065"></a>

**AW-06-065**

<!-- EN:AW-06-065 -->
“I suppose so,” said Alice.
<!-- /EN:AW-06-065 -->

> 「そうだと思うわ」とアリスは言った。

<a id="AW-06-066"></a>

**AW-06-066**

<!-- EN:AW-06-066 -->
“Well, then,” the Cat went on, “you see, a dog growls when it’s angry, and wags its tail when it’s pleased. Now *I* growl when I’m pleased, and wag my tail when I’m angry. Therefore I’m mad.”
<!-- /EN:AW-06-066 -->

> 「それなら」と猫は続けた。「犬は、怒ったときにうなり、喜んだときに、しっぽを振る。ところが*私は*、喜んだときにうなり、怒ったときに、しっぽを振る。したがって、私は狂っている。」

<a id="AW-06-067"></a>

**AW-06-067**

<!-- EN:AW-06-067 -->
“*I* call it purring, not growling,” said Alice.
<!-- /EN:AW-06-067 -->

> 「*わたしは*、それを、うなるとは言わずに、喉を鳴らすと言うわ」とアリスは言った。

<a id="AW-06-068"></a>

**AW-06-068**

<!-- EN:AW-06-068 -->
“Call it what you like,” said the Cat. “Do you play croquet with the Queen to-day?”
<!-- /EN:AW-06-068 -->

> 「好きなように呼べばいい」と猫は言った。「今日は、女王とクロッケーをするのかい？」

<a id="AW-06-069"></a>

**AW-06-069**

<!-- EN:AW-06-069 -->
“I should like it very much,” said Alice, “but I haven’t been invited yet.”
<!-- /EN:AW-06-069 -->

> 「ぜひ、そうしたいわ」とアリスは言った。「でも、まだ招待されていないの。」

<a id="AW-06-070"></a>

**AW-06-070**

<!-- EN:AW-06-070 -->
“You’ll see me there,” said the Cat, and vanished.
<!-- /EN:AW-06-070 -->

> 「そこで、私に会えるよ」と猫は言い、消えた。

<a id="AW-06-071"></a>

**AW-06-071**

<!-- EN:AW-06-071 -->
Alice was not much surprised at this, she was getting so used to queer things happening. While she was looking at the place where it had been, it suddenly appeared again.
<!-- /EN:AW-06-071 -->

> アリスは、それほど驚かなかった。変わったことが起きるのに、それくらい慣れてきていたのだ。猫のいた場所を見つめていると、突然、また現れた。

<a id="AW-06-072"></a>

**AW-06-072**

<!-- EN:AW-06-072 -->
“By-the-bye, what became of the baby?” said the Cat. “I’d nearly forgotten to ask.”
<!-- /EN:AW-06-072 -->

> 「ところで、赤ん坊はどうなった？」と猫は言った。「聞くのを、危うく忘れるところだった。」

<a id="AW-06-073"></a>

**AW-06-073**

<!-- EN:AW-06-073 -->
“It turned into a pig,” Alice quietly said, just as if it had come back in a natural way.
<!-- /EN:AW-06-073 -->

> 「豚になったわ」とアリスは、落ち着いて答えた。まるで猫が、ごく普通のやり方で戻ってきたかのようだった。

<a id="AW-06-074"></a>

**AW-06-074**

<!-- EN:AW-06-074 -->
“I thought it would,” said the Cat, and vanished again.
<!-- /EN:AW-06-074 -->

> 「そうなると思った」と猫は言い、また消えた。

<a id="AW-06-075"></a>

**AW-06-075**

<!-- EN:AW-06-075 -->
Alice waited a little, half expecting to see it again, but it did not appear, and after a minute or two she walked on in the direction in which the March Hare was said to live. “I’ve seen hatters before,” she said to herself; “the March Hare will be much the most interesting, and perhaps as this is May it won’t be raving mad—at least not so mad as it was in March.” As she said this, she looked up, and there was the Cat again, sitting on a branch of a tree.
<!-- /EN:AW-06-075 -->

> アリスは、また現れるのではないかと、半ば期待しながら、少し待った。けれども現れなかったので、一、二分後、三月ウサギが住んでいるというほうへ、歩きだした。「帽子屋なら、前にも見たことがあるわ」と独り言を言った。「三月ウサギのほうが、ずっと面白いでしょうね。それに、今は五月だから、取り乱すほど狂ってはいないかもしれないわ。少なくとも、三月のときほどには。」そう言いながら見上げると、また猫が、木の枝に座っていた。

<a id="AW-06-076"></a>

**AW-06-076**

<!-- EN:AW-06-076 -->
“Did you say pig, or fig?” said the Cat.
<!-- /EN:AW-06-076 -->

> 「豚と言ったのかい、それともイチジク？」と猫は言った。

> **訳注：** pig（豚）と fig（イチジク）は、最初の子音だけが違う。猫は、その二語を聞き直している。

<a id="AW-06-077"></a>

**AW-06-077**

<!-- EN:AW-06-077 -->
“I said pig,” replied Alice; “and I wish you wouldn’t keep appearing and vanishing so suddenly: you make one quite giddy.”
<!-- /EN:AW-06-077 -->

> 「豚と言ったのよ」とアリスは答えた。「それから、そんなに突然、現れたり消えたりするのを、繰り返さないでほしいわ。すっかり目が回ってしまうもの。」

<a id="AW-06-078"></a>

**AW-06-078**

<!-- EN:AW-06-078 -->
“All right,” said the Cat; and this time it vanished quite slowly, beginning with the end of the tail, and ending with the grin, which remained some time after the rest of it had gone.
<!-- /EN:AW-06-078 -->

> 「分かった」と猫は言った。今度は、しっぽの先から始めて、にやにや笑いを最後に残し、とてもゆっくり消えた。その笑いは、体のほかの部分が消えてからも、しばらく残っていた。

<a id="AW-06-079"></a>

**AW-06-079**

<!-- EN:AW-06-079 -->
“Well! I’ve often seen a cat without a grin,” thought Alice; “but a grin without a cat! It’s the most curious thing I ever saw in my life!”
<!-- /EN:AW-06-079 -->

> 「まあ！　にやにや笑いのない猫なら、何度も見たけれど」とアリスは思った。「猫のない、にやにや笑いだなんて！　生まれてこのかた、見た中で、いちばん不思議なものだわ！」

<a id="AW-06-080"></a>

**AW-06-080**

<!-- EN:AW-06-080 -->
She had not gone much farther before she came in sight of the house of the March Hare: she thought it must be the right house, because the chimneys were shaped like ears and the roof was thatched with fur. It was so large a house, that she did not like to go nearer till she had nibbled some more of the lefthand bit of mushroom, and raised herself to about two feet high: even then she walked up towards it rather timidly, saying to herself “Suppose it should be raving mad after all! I almost wish I’d gone to see the Hatter instead!”
<!-- /EN:AW-06-080 -->

> それから、あまり遠くまで行かないうちに、三月ウサギの家が見えてきた。煙突が耳の形で、屋根には毛皮が葺いてあったので、この家に違いないと思った。とても大きな家だったので、アリスは、左手のキノコのかけらをもう少しかじり、背を二フィートほどに伸ばすまで、近づく気にはなれなかった。それでも、かなりおずおずと家へ向かって歩きながら、独り言を言った。「やっぱり、ものすごく狂っていたら、どうしましょう！　代わりに帽子屋のところへ行けばよかった、と言いたいくらいだわ！」

[章目次へ戻る](#book-top)

---

<a id="aw-chapter-07"></a>

## 第7章　おかしなお茶会

### CHAPTER VII. A Mad Tea-Party

<a id="AW-07-001"></a>

**AW-07-001**

<!-- EN:AW-07-001 -->
There was a table set out under a tree in front of the house, and the March Hare and the Hatter were having tea at it: a Dormouse was sitting between them, fast asleep, and the other two were using it as a cushion, resting their elbows on it, and talking over its head. “Very uncomfortable for the Dormouse,” thought Alice; “only, as it’s asleep, I suppose it doesn’t mind.”
<!-- /EN:AW-07-001 -->

> 家の前の木の下にテーブルが出してあり、三月ウサギと帽子屋がお茶を飲んでいた。二人のあいだにはヤマネが座ってぐっすり眠っていて、二人はそれをクッション代わりにし、肘をのせて、頭越しに話していた。「ヤマネはずいぶん居心地が悪そう」とアリスは思った。「でも、眠っているんだから、気にならないのかしら」

<a id="AW-07-002"></a>

**AW-07-002**

<!-- EN:AW-07-002 -->
The table was a large one, but the three were all crowded together at one corner of it: “No room! No room!” they cried out when they saw Alice coming. “There’s *plenty* of room!” said Alice indignantly, and she sat down in a large arm-chair at one end of the table.
<!-- /EN:AW-07-002 -->

> テーブルは大きかったのに、三人は一つの隅にぎゅうぎゅうに集まっていた。アリスが来るのを見ると、「席はない！　席はない！」と叫んだ。「席なら*いくらでも*あるじゃない！」とアリスは憤慨して言い、テーブルの端にある大きな肘掛け椅子に腰を下ろした。

<a id="AW-07-003"></a>

**AW-07-003**

<!-- EN:AW-07-003 -->
“Have some wine,” the March Hare said in an encouraging tone.
<!-- /EN:AW-07-003 -->

> 「ワインでもどうぞ」と三月ウサギが、勧めるような口調で言った。

<a id="AW-07-004"></a>

**AW-07-004**

<!-- EN:AW-07-004 -->
Alice looked all round the table, but there was nothing on it but tea. “I don’t see any wine,” she remarked.
<!-- /EN:AW-07-004 -->

> アリスはテーブルじゅうを見回したが、のっているのはお茶だけだった。「ワインなんて見当たらないけれど」と言った。

<a id="AW-07-005"></a>

**AW-07-005**

<!-- EN:AW-07-005 -->
“There isn’t any,” said the March Hare.
<!-- /EN:AW-07-005 -->

> 「ないもの」と三月ウサギは言った。

<a id="AW-07-006"></a>

**AW-07-006**

<!-- EN:AW-07-006 -->
“Then it wasn’t very civil of you to offer it,” said Alice angrily.
<!-- /EN:AW-07-006 -->

> 「それなら、勧めるなんてあまり礼儀正しいことではないわ」とアリスは腹を立てて言った。

<a id="AW-07-007"></a>

**AW-07-007**

<!-- EN:AW-07-007 -->
“It wasn’t very civil of you to sit down without being invited,” said the March Hare.
<!-- /EN:AW-07-007 -->

> 「招かれもしないのに座るのも、あまり礼儀正しいことではないね」と三月ウサギは言った。

<a id="AW-07-008"></a>

**AW-07-008**

<!-- EN:AW-07-008 -->
“I didn’t know it was *your* table,” said Alice; “it’s laid for a great many more than three.”
<!-- /EN:AW-07-008 -->

> 「*あなたの*テーブルだとは知らなかったの」とアリスは言った。「三人よりずっと大勢の支度がしてあるんですもの」

<a id="AW-07-009"></a>

**AW-07-009**

<!-- EN:AW-07-009 -->
“Your hair wants cutting,” said the Hatter. He had been looking at Alice for some time with great curiosity, and this was his first speech.
<!-- /EN:AW-07-009 -->

> 「髪を切ったほうがいいね」と帽子屋が言った。しばらく前からたいそう物珍しそうにアリスを眺めていたが、これが初めて口にした言葉だった。

<a id="AW-07-010"></a>

**AW-07-010**

<!-- EN:AW-07-010 -->
“You should learn not to make personal remarks,” Alice said with some severity; “it’s very rude.”
<!-- /EN:AW-07-010 -->

> 「人のことをあれこれ言わないように、覚えたほうがいいわ」とアリスは少し厳しく言った。「とても失礼よ」

<a id="AW-07-011"></a>

**AW-07-011**

<!-- EN:AW-07-011 -->
The Hatter opened his eyes very wide on hearing this; but all he *said* was, “Why is a raven like a writing-desk?”
<!-- /EN:AW-07-011 -->

> それを聞くと帽子屋は目を大きく見開いた。けれど、*口にした*のはただ、「カラスと書き物机は、どうして似ているんだろう？」ということだけだった。

<a id="AW-07-012"></a>

**AW-07-012**

<!-- EN:AW-07-012 -->
“Come, we shall have some fun now!” thought Alice. “I’m glad they’ve begun asking riddles.—I believe I can guess that,” she added aloud.
<!-- /EN:AW-07-012 -->

> 「さあ、これから面白くなりそう！」とアリスは思った。「なぞなぞを出し始めてくれて、うれしいわ。――それなら当てられそう」と、最後は声に出して付け加えた。

<a id="AW-07-013"></a>

**AW-07-013**

<!-- EN:AW-07-013 -->
“Do you mean that you think you can find out the answer to it?” said the March Hare.
<!-- /EN:AW-07-013 -->

> 「その答えを見つけられると思う、という意味かい？」と三月ウサギが言った。

<a id="AW-07-014"></a>

**AW-07-014**

<!-- EN:AW-07-014 -->
“Exactly so,” said Alice.
<!-- /EN:AW-07-014 -->

> 「まさにそうよ」とアリスは言った。

<a id="AW-07-015"></a>

**AW-07-015**

<!-- EN:AW-07-015 -->
“Then you should say what you mean,” the March Hare went on.
<!-- /EN:AW-07-015 -->

> 「だったら、思っていることを言うべきだね」と三月ウサギは続けた。

<a id="AW-07-016"></a>

**AW-07-016**

<!-- EN:AW-07-016 -->
“I do,” Alice hastily replied; “at least—at least I mean what I say—that’s the same thing, you know.”
<!-- /EN:AW-07-016 -->

> 「言っているわ」とアリスは急いで答えた。「少なくとも――少なくとも、言っていることは思っているわ。それなら同じことでしょう」

<a id="AW-07-017"></a>

**AW-07-017**

<!-- EN:AW-07-017 -->
“Not the same thing a bit!” said the Hatter. “You might just as well say that ‘I see what I eat’ is the same thing as ‘I eat what I see’!”
<!-- /EN:AW-07-017 -->

> 「ちっとも同じじゃない！」と帽子屋が言った。「それじゃ、『食べるものを見る』と『見るものを食べる』が同じだと言うようなものだ！」

<a id="AW-07-018"></a>

**AW-07-018**

<!-- EN:AW-07-018 -->
“You might just as well say,” added the March Hare, “that ‘I like what I get’ is the same thing as ‘I get what I like’!”
<!-- /EN:AW-07-018 -->

> 「それじゃ」と三月ウサギも付け加えた。「『手に入れたものを好きになる』と『好きなものを手に入れる』が同じだと言うようなものだ！」

<a id="AW-07-019"></a>

**AW-07-019**

<!-- EN:AW-07-019 -->
“You might just as well say,” added the Dormouse, who seemed to be talking in his sleep, “that ‘I breathe when I sleep’ is the same thing as ‘I sleep when I breathe’!”
<!-- /EN:AW-07-019 -->

> 「それじゃ」とヤマネも付け加えた。どうやら寝言を言っているらしかった。「『眠っているときに息をする』と『息をしているときに眠る』が同じだと言うようなものだ！」

<a id="AW-07-020"></a>

**AW-07-020**

<!-- EN:AW-07-020 -->
“It *is* the same thing with you,” said the Hatter, and here the conversation dropped, and the party sat silent for a minute, while Alice thought over all she could remember about ravens and writing-desks, which wasn’t much.
<!-- /EN:AW-07-020 -->

> 「きみの場合は*同じだ*よ」と帽子屋が言った。そこで話は途切れ、一同は一分ほど黙って座っていた。そのあいだアリスは、カラスと書き物机について覚えていることを残らず考えてみたが、大して覚えていることはなかった。

<a id="AW-07-021"></a>

**AW-07-021**

<!-- EN:AW-07-021 -->
The Hatter was the first to break the silence. “What day of the month is it?” he said, turning to Alice: he had taken his watch out of his pocket, and was looking at it uneasily, shaking it every now and then, and holding it to his ear.
<!-- /EN:AW-07-021 -->

> 最初に沈黙を破ったのは帽子屋だった。「今日は何日だい？」とアリスに顔を向けて尋ねた。ポケットから時計を取り出して、不安そうに眺め、時々振ったり耳に当てたりしていた。

<a id="AW-07-022"></a>

**AW-07-022**

<!-- EN:AW-07-022 -->
Alice considered a little, and then said “The fourth.”
<!-- /EN:AW-07-022 -->

> アリスは少し考えてから、「四日よ」と言った。

<a id="AW-07-023"></a>

**AW-07-023**

<!-- EN:AW-07-023 -->
“Two days wrong!” sighed the Hatter. “I told you butter wouldn’t suit the works!” he added looking angrily at the March Hare.
<!-- /EN:AW-07-023 -->

> 「二日も違っている！」と帽子屋はため息をついた。「バターは機械に合わないって言ったじゃないか！」と、三月ウサギを怒ってにらみながら付け加えた。

<a id="AW-07-024"></a>

**AW-07-024**

<!-- EN:AW-07-024 -->
“It was the *best* butter,” the March Hare meekly replied.
<!-- /EN:AW-07-024 -->

> 「*いちばん上等な*バターだったんだけど」と三月ウサギはおとなしく答えた。

<a id="AW-07-025"></a>

**AW-07-025**

<!-- EN:AW-07-025 -->
“Yes, but some crumbs must have got in as well,” the Hatter grumbled: “you shouldn’t have put it in with the bread-knife.”
<!-- /EN:AW-07-025 -->

> 「そうだが、パンくずまで入ったに違いない」と帽子屋はぶつぶつ言った。「パン切りナイフで入れるんじゃなかったね」

<a id="AW-07-026"></a>

**AW-07-026**

<!-- EN:AW-07-026 -->
The March Hare took the watch and looked at it gloomily: then he dipped it into his cup of tea, and looked at it again: but he could think of nothing better to say than his first remark, “It was the *best* butter, you know.”
<!-- /EN:AW-07-026 -->

> 三月ウサギは時計を受け取って、陰気な顔で眺めた。それから自分の紅茶のカップにつけて、もう一度眺めた。けれど、最初の言葉より気の利いたことは何も思いつかず、「*いちばん上等な*バターだったんだよ」と言った。

<a id="AW-07-027"></a>

**AW-07-027**

<!-- EN:AW-07-027 -->
Alice had been looking over his shoulder with some curiosity. “What a funny watch!” she remarked. “It tells the day of the month, and doesn’t tell what o’clock it is!”
<!-- /EN:AW-07-027 -->

> アリスは少し興味をひかれて、その肩越しにのぞき込んでいた。「なんて変わった時計！」と言った。「何日かはわかるのに、何時かはわからないのね！」

<a id="AW-07-028"></a>

**AW-07-028**

<!-- EN:AW-07-028 -->
“Why should it?” muttered the Hatter. “Does *your* watch tell you what year it is?”
<!-- /EN:AW-07-028 -->

> 「どうしてわからなくちゃいけないんだ？」と帽子屋はつぶやいた。「*きみの*時計は、何年なのかわかるのかい？」

<a id="AW-07-029"></a>

**AW-07-029**

<!-- EN:AW-07-029 -->
“Of course not,” Alice replied very readily: “but that’s because it stays the same year for such a long time together.”
<!-- /EN:AW-07-029 -->

> 「もちろん、わからないわ」とアリスはすぐに答えた。「でもそれは、同じ年がとても長いあいだ続くからでしょう」

<a id="AW-07-030"></a>

**AW-07-030**

<!-- EN:AW-07-030 -->
“Which is just the case with *mine*,” said the Hatter.
<!-- /EN:AW-07-030 -->

> 「*ぼくの*も、まったくそれと同じなんだ」と帽子屋は言った。

<a id="AW-07-031"></a>

**AW-07-031**

<!-- EN:AW-07-031 -->
Alice felt dreadfully puzzled, The Hatter’s remark seemed to have no sort of meaning in it, and yet it was certainly English. “I don’t quite understand you,” she said, as politely as she could.
<!-- /EN:AW-07-031 -->

> アリスはひどく戸惑った。帽子屋の言葉には何の意味もないように思えるのに、それでも確かに英語なのだ。「おっしゃることが、よくわからないわ」と、できるかぎり丁寧に言った。

<a id="AW-07-032"></a>

**AW-07-032**

<!-- EN:AW-07-032 -->
“The Dormouse is asleep again,” said the Hatter, and he poured a little hot tea upon its nose.
<!-- /EN:AW-07-032 -->

> 「ヤマネがまた眠っている」と帽子屋は言い、その鼻に熱いお茶を少しかけた。

<a id="AW-07-033"></a>

**AW-07-033**

<!-- EN:AW-07-033 -->
The Dormouse shook its head impatiently, and said, without opening its eyes, “Of course, of course; just what I was going to remark myself.”
<!-- /EN:AW-07-033 -->

> ヤマネはじれったそうに頭を振り、目も開けずに言った。「もちろん、もちろん。ぼくも、まさにそう言おうと思っていたところだよ」

<a id="AW-07-034"></a>

**AW-07-034**

<!-- EN:AW-07-034 -->
“Have you guessed the riddle yet?” the Hatter said, turning to Alice again.
<!-- /EN:AW-07-034 -->

> 「もうなぞなぞは解けたかい？」と帽子屋は、またアリスのほうを向いて言った。

<a id="AW-07-035"></a>

**AW-07-035**

<!-- EN:AW-07-035 -->
“No, I give it up,” Alice replied: “what’s the answer?”
<!-- /EN:AW-07-035 -->

> 「いいえ、降参だわ」とアリスは答えた。「答えは何なの？」

<a id="AW-07-036"></a>

**AW-07-036**

<!-- EN:AW-07-036 -->
“I haven’t the slightest idea,” said the Hatter.
<!-- /EN:AW-07-036 -->

> 「さっぱり見当もつかない」と帽子屋は言った。

<a id="AW-07-037"></a>

**AW-07-037**

<!-- EN:AW-07-037 -->
“Nor I,” said the March Hare.
<!-- /EN:AW-07-037 -->

> 「ぼくもだ」と三月ウサギは言った。

<a id="AW-07-038"></a>

**AW-07-038**

<!-- EN:AW-07-038 -->
Alice sighed wearily. “I think you might do something better with the time,” she said, “than waste it in asking riddles that have no answers.”
<!-- /EN:AW-07-038 -->

> アリスはうんざりしてため息をついた。「答えのないなぞなぞを出して時間をむだにするより、もっとましな時間の使い方があると思うわ」と言った。

<a id="AW-07-039"></a>

**AW-07-039**

<!-- EN:AW-07-039 -->
“If you knew Time as well as I do,” said the Hatter, “you wouldn’t talk about wasting *it*. It’s *him*.”
<!-- /EN:AW-07-039 -->

> 「ぼくくらい時間のことをよく知っていたら」と帽子屋が言った。「*それ*をむだにする、なんて言い方はしないだろうね。時間は*あの人*なんだよ」

> **訳注：** 英語では通常、時間を it で受けるが、帽子屋は Time を人物として扱い、him と呼んでいる。

<a id="AW-07-040"></a>

**AW-07-040**

<!-- EN:AW-07-040 -->
“I don’t know what you mean,” said Alice.
<!-- /EN:AW-07-040 -->

> 「どういう意味かわからないわ」とアリスは言った。

<a id="AW-07-041"></a>

**AW-07-041**

<!-- EN:AW-07-041 -->
“Of course you don’t!” the Hatter said, tossing his head contemptuously. “I dare say you never even spoke to Time!”
<!-- /EN:AW-07-041 -->

> 「そりゃ、わからないだろう！」と帽子屋は、人をばかにしたように頭を振って言った。「きっと時間に話しかけたことすらないんだろう！」

<a id="AW-07-042"></a>

**AW-07-042**

<!-- EN:AW-07-042 -->
“Perhaps not,” Alice cautiously replied: “but I know I have to beat time when I learn music.”
<!-- /EN:AW-07-042 -->

> 「ないかもしれないわ」とアリスは用心深く答えた。「でも、音楽を習うときには、拍子をとらなくちゃいけないことは知っているわ」

> **訳注：** beat time は「拍子をとる」。帽子屋は次の発話で、beat を「殴る」、time を「時間という人物」と読み替える。

<a id="AW-07-043"></a>

**AW-07-043**

<!-- EN:AW-07-043 -->
“Ah! that accounts for it,” said the Hatter. “He won’t stand beating. Now, if you only kept on good terms with him, he’d do almost anything you liked with the clock. For instance, suppose it were nine o’clock in the morning, just time to begin lessons: you’d only have to whisper a hint to Time, and round goes the clock in a twinkling! Half-past one, time for dinner!”
<!-- /EN:AW-07-043 -->

> 「ああ！　それでわかった」と帽子屋は言った。「あの人は殴られるのが大嫌いなんだ。さて、仲良くしてさえいれば、時計をどうするかなんて、たいてい何でも望みどおりにしてくれる。たとえば、朝の九時、ちょうど授業が始まる時間だとしよう。時間にそっと一言ほのめかすだけで、時計はたちまちぐるりと回る！　一時半、食事の時間さ！」

<a id="AW-07-044"></a>

**AW-07-044**

<!-- EN:AW-07-044 -->
(“I only wish it was,” the March Hare said to itself in a whisper.)
<!-- /EN:AW-07-044 -->

> （「本当にそうだったらいいのに」と三月ウサギは、小声でひとりごとを言った。）

<a id="AW-07-045"></a>

**AW-07-045**

<!-- EN:AW-07-045 -->
“That would be grand, certainly,” said Alice thoughtfully: “but then—I shouldn’t be hungry for it, you know.”
<!-- /EN:AW-07-045 -->

> 「それは確かにすてきね」とアリスは考えながら言った。「でも、そうすると――まだおなかがすいていないでしょう」

<a id="AW-07-046"></a>

**AW-07-046**

<!-- EN:AW-07-046 -->
“Not at first, perhaps,” said the Hatter: “but you could keep it to half-past one as long as you liked.”
<!-- /EN:AW-07-046 -->

> 「最初はそうかもしれないね」と帽子屋は言った。「だが、好きなだけ一時半にしておけるじゃないか」

<a id="AW-07-047"></a>

**AW-07-047**

<!-- EN:AW-07-047 -->
“Is that the way *you* manage?” Alice asked.
<!-- /EN:AW-07-047 -->

> 「*あなたは*そうしているの？」とアリスは尋ねた。

<a id="AW-07-048"></a>

**AW-07-048**

<!-- EN:AW-07-048 -->
The Hatter shook his head mournfully. “Not I!” he replied. “We quarrelled last March—just before *he* went mad, you know—” (pointing with his tea spoon at the March Hare,) “—it was at the great concert given by the Queen of Hearts, and I had to sing
<!-- /EN:AW-07-048 -->

> 帽子屋は悲しそうに首を振った。「ぼくは違う！」と答えた。「この前の三月に、けんかをしてね。ちょうど*こいつが*おかしくなる少し前さ――」（ティースプーンで三月ウサギを指した。）「――ハートの女王の催した大音楽会でのことだった。ぼくは歌わなくちゃいけなかったんだ。

<a id="AW-07-049"></a>

**AW-07-049**

<!-- EN:AW-07-049 -->
‘Twinkle, twinkle, little bat!  
How I wonder what you’re at!’
<!-- /EN:AW-07-049 -->

> 『きらきら光れ、小さなコウモリ！  
> いったい何をしてるのか、不思議だな！』

> **訳注：** 原文は ‘Twinkle, twinkle, little star’ の歌い出しをもじり、star を bat、what you are を what you’re at に変えている。

<a id="AW-07-050"></a>

**AW-07-050**

<!-- EN:AW-07-050 -->
You know the song, perhaps?”
<!-- /EN:AW-07-050 -->

> この歌は、知っているかもしれないね？」

<a id="AW-07-051"></a>

**AW-07-051**

<!-- EN:AW-07-051 -->
“I’ve heard something like it,” said Alice.
<!-- /EN:AW-07-051 -->

> 「似たものなら聞いたことがあるわ」とアリスは言った。

<a id="AW-07-052"></a>

**AW-07-052**

<!-- EN:AW-07-052 -->
“It goes on, you know,” the Hatter continued, “in this way:—
<!-- /EN:AW-07-052 -->

> 「その先はね」と帽子屋は続けた。「こうなるんだ――

<a id="AW-07-053"></a>

**AW-07-053**

<!-- EN:AW-07-053 -->
‘Up above the world you fly,  
Like a tea-tray in the sky.  
                    Twinkle, twinkle—’”
<!-- /EN:AW-07-053 -->

> 『世界の上を高々と飛び、  
> 空のお盆のように浮かぶ。  
> 　　　　　　　　　　きらきら、きらきら――』」

<a id="AW-07-054"></a>

**AW-07-054**

<!-- EN:AW-07-054 -->
Here the Dormouse shook itself, and began singing in its sleep “*Twinkle, twinkle, twinkle, twinkle*—” and went on so long that they had to pinch it to make it stop.
<!-- /EN:AW-07-054 -->

> ここでヤマネが身震いし、眠ったまま「*きらきら、きらきら、きらきら、きらきら*――」と歌い出した。あまりにいつまでも続けるので、みんなはつねって止めさせなければならなかった。

<a id="AW-07-055"></a>

**AW-07-055**

<!-- EN:AW-07-055 -->
“Well, I’d hardly finished the first verse,” said the Hatter, “when the Queen jumped up and bawled out, ‘He’s murdering the time! Off with his head!’”
<!-- /EN:AW-07-055 -->

> 「ところが、一番を歌い終わるか終わらないうちに」と帽子屋は言った。「女王が立ち上がって怒鳴ったんだ。『あいつは時間を殺している！　首をはねよ！』ってね」

> **訳注：** murdering the time は、音楽の拍子をひどく崩していることと、人物としての「時間」を殺していることを重ねた表現。

<a id="AW-07-056"></a>

**AW-07-056**

<!-- EN:AW-07-056 -->
“How dreadfully savage!” exclaimed Alice.
<!-- /EN:AW-07-056 -->

> 「なんてひどく乱暴なの！」とアリスは叫んだ。

<a id="AW-07-057"></a>

**AW-07-057**

<!-- EN:AW-07-057 -->
“And ever since that,” the Hatter went on in a mournful tone, “he won’t do a thing I ask! It’s always six o’clock now.”
<!-- /EN:AW-07-057 -->

> 「それ以来」と帽子屋は悲しげな声で続けた。「あの人は頼んでも何一つしてくれないんだ！　今では、いつだって六時さ」

<a id="AW-07-058"></a>

**AW-07-058**

<!-- EN:AW-07-058 -->
A bright idea came into Alice’s head. “Is that the reason so many tea-things are put out here?” she asked.
<!-- /EN:AW-07-058 -->

> アリスの頭に、ぱっと考えがひらめいた。「だから、ここにはこんなにたくさんお茶の道具が出してあるの？」と尋ねた。

<a id="AW-07-059"></a>

**AW-07-059**

<!-- EN:AW-07-059 -->
“Yes, that’s it,” said the Hatter with a sigh: “it’s always tea-time, and we’ve no time to wash the things between whiles.”
<!-- /EN:AW-07-059 -->

> 「そう、そのとおり」と帽子屋はため息まじりに言った。「いつもお茶の時間だから、合間に洗う時間がないんだ」

<a id="AW-07-060"></a>

**AW-07-060**

<!-- EN:AW-07-060 -->
“Then you keep moving round, I suppose?” said Alice.
<!-- /EN:AW-07-060 -->

> 「それで、次々に席を回っていくわけね？」とアリスは言った。

<a id="AW-07-061"></a>

**AW-07-061**

<!-- EN:AW-07-061 -->
“Exactly so,” said the Hatter: “as the things get used up.”
<!-- /EN:AW-07-061 -->

> 「まさにそのとおり」と帽子屋は言った。「道具を使ってしまうたびにね」

<a id="AW-07-062"></a>

**AW-07-062**

<!-- EN:AW-07-062 -->
“But what happens when you come to the beginning again?” Alice ventured to ask.
<!-- /EN:AW-07-062 -->

> 「でも、また最初のところに戻ってきたら、どうなるの？」とアリスは思い切って尋ねた。

<a id="AW-07-063"></a>

**AW-07-063**

<!-- EN:AW-07-063 -->
“Suppose we change the subject,” the March Hare interrupted, yawning. “I’m getting tired of this. I vote the young lady tells us a story.”
<!-- /EN:AW-07-063 -->

> 「話題を変えたらどうだろう」と三月ウサギが、あくびをしながら口を挟んだ。「この話は飽きてきた。お嬢さんにお話をしてもらうのがいいと思うね」

<a id="AW-07-064"></a>

**AW-07-064**

<!-- EN:AW-07-064 -->
“I’m afraid I don’t know one,” said Alice, rather alarmed at the proposal.
<!-- /EN:AW-07-064 -->

> 「残念だけれど、お話は知らないの」とアリスは、その提案に少しぎょっとして言った。

<a id="AW-07-065"></a>

**AW-07-065**

<!-- EN:AW-07-065 -->
“Then the Dormouse shall!” they both cried. “Wake up, Dormouse!” And they pinched it on both sides at once.
<!-- /EN:AW-07-065 -->

> 「じゃあ、ヤマネにしてもらおう！」と二人そろって叫んだ。「起きろ、ヤマネ！」そして両側から一度につねった。

<a id="AW-07-066"></a>

**AW-07-066**

<!-- EN:AW-07-066 -->
The Dormouse slowly opened his eyes. “I wasn’t asleep,” he said in a hoarse, feeble voice: “I heard every word you fellows were saying.”
<!-- /EN:AW-07-066 -->

> ヤマネはゆっくり目を開けた。「眠ってなんかいなかったよ」と、かすれた弱々しい声で言った。「きみたちの言っていたことは、一言残らず聞いていたよ」

<a id="AW-07-067"></a>

**AW-07-067**

<!-- EN:AW-07-067 -->
“Tell us a story!” said the March Hare.
<!-- /EN:AW-07-067 -->

> 「お話をしてくれ！」と三月ウサギは言った。

<a id="AW-07-068"></a>

**AW-07-068**

<!-- EN:AW-07-068 -->
“Yes, please do!” pleaded Alice.
<!-- /EN:AW-07-068 -->

> 「ええ、お願い！」とアリスも頼んだ。

<a id="AW-07-069"></a>

**AW-07-069**

<!-- EN:AW-07-069 -->
“And be quick about it,” added the Hatter, “or you’ll be asleep again before it’s done.”
<!-- /EN:AW-07-069 -->

> 「しかも手早くね」と帽子屋が付け加えた。「でないと、終わる前にまた眠ってしまうよ」

<a id="AW-07-070"></a>

**AW-07-070**

<!-- EN:AW-07-070 -->
“Once upon a time there were three little sisters,” the Dormouse began in a great hurry; “and their names were Elsie, Lacie, and Tillie; and they lived at the bottom of a well—”
<!-- /EN:AW-07-070 -->

> 「昔々、幼い三人の姉妹がいました」とヤマネは大急ぎで話し始めた。「名前をエルシー、レイシー、ティリーといって、井戸の底に住んでいました――」

<a id="AW-07-071"></a>

**AW-07-071**

<!-- EN:AW-07-071 -->
“What did they live on?” said Alice, who always took a great interest in questions of eating and drinking.
<!-- /EN:AW-07-071 -->

> 「何を食べて暮らしていたの？」とアリスは言った。食べ物や飲み物のことには、いつもたいそう関心があったのだ。

<a id="AW-07-072"></a>

**AW-07-072**

<!-- EN:AW-07-072 -->
“They lived on treacle,” said the Dormouse, after thinking a minute or two.
<!-- /EN:AW-07-072 -->

> 「糖蜜を食べて暮らしていました」とヤマネは、一、二分考えてから言った。

<a id="AW-07-073"></a>

**AW-07-073**

<!-- EN:AW-07-073 -->
“They couldn’t have done that, you know,” Alice gently remarked; “they’d have been ill.”
<!-- /EN:AW-07-073 -->

> 「そんなことはできなかったはずよ」とアリスはそっと言った。「病気になってしまったでしょう」

<a id="AW-07-074"></a>

**AW-07-074**

<!-- EN:AW-07-074 -->
“So they were,” said the Dormouse; “*very* ill.”
<!-- /EN:AW-07-074 -->

> 「なりましたとも」とヤマネは言った。「*ひどい*病気に」

<a id="AW-07-075"></a>

**AW-07-075**

<!-- EN:AW-07-075 -->
Alice tried to fancy to herself what such an extraordinary way of living would be like, but it puzzled her too much, so she went on: “But why did they live at the bottom of a well?”
<!-- /EN:AW-07-075 -->

> アリスは、そんな途方もない暮らしとはどんなものか想像してみた。けれど、あまりにわからなかったので、さらに尋ねた。「でも、どうして井戸の底に住んでいたの？」

<a id="AW-07-076"></a>

**AW-07-076**

<!-- EN:AW-07-076 -->
“Take some more tea,” the March Hare said to Alice, very earnestly.
<!-- /EN:AW-07-076 -->

> 「もう少しお茶をどうぞ」と三月ウサギが、たいそう熱心にアリスに言った。

<a id="AW-07-077"></a>

**AW-07-077**

<!-- EN:AW-07-077 -->
“I’ve had nothing yet,” Alice replied in an offended tone, “so I can’t take more.”
<!-- /EN:AW-07-077 -->

> 「まだ少しもいただいていないわ」とアリスは、むっとして答えた。「だから、もう少しはいただけないの」

<a id="AW-07-078"></a>

**AW-07-078**

<!-- EN:AW-07-078 -->
“You mean you can’t take *less*,” said the Hatter: “it’s very easy to take *more* than nothing.”
<!-- /EN:AW-07-078 -->

> 「*もっと少なくは*いただけない、という意味だろう」と帽子屋が言った。「何もないより*もっと多く*いただくのは、とても簡単だよ」

<a id="AW-07-079"></a>

**AW-07-079**

<!-- EN:AW-07-079 -->
“Nobody asked *your* opinion,” said Alice.
<!-- /EN:AW-07-079 -->

> 「*あなたの*意見は誰も聞いていないわ」とアリスは言った。

<a id="AW-07-080"></a>

**AW-07-080**

<!-- EN:AW-07-080 -->
“Who’s making personal remarks now?” the Hatter asked triumphantly.
<!-- /EN:AW-07-080 -->

> 「今、人のことをあれこれ言っているのは誰だい？」と帽子屋は得意げに尋ねた。

<a id="AW-07-081"></a>

**AW-07-081**

<!-- EN:AW-07-081 -->
Alice did not quite know what to say to this: so she helped herself to some tea and bread-and-butter, and then turned to the Dormouse, and repeated her question. “Why did they live at the bottom of a well?”
<!-- /EN:AW-07-081 -->

> これにはアリスも何と言えばよいか、よくわからなかった。そこでお茶とバターを塗ったパンを自分で取り、それからヤマネに向き直って、同じことをもう一度尋ねた。「どうして井戸の底に住んでいたの？」

<a id="AW-07-082"></a>

**AW-07-082**

<!-- EN:AW-07-082 -->
The Dormouse again took a minute or two to think about it, and then said, “It was a treacle-well.”
<!-- /EN:AW-07-082 -->

> ヤマネはまた一、二分考えてから言った。「糖蜜の井戸だったからです」

<a id="AW-07-083"></a>

**AW-07-083**

<!-- EN:AW-07-083 -->
“There’s no such thing!” Alice was beginning very angrily, but the Hatter and the March Hare went “Sh! sh!” and the Dormouse sulkily remarked, “If you can’t be civil, you’d better finish the story for yourself.”
<!-- /EN:AW-07-083 -->

> 「そんなもの、ないわ！」とアリスはひどく腹を立てて言いかけたが、帽子屋と三月ウサギが「しっ、しっ！」と言い、ヤマネはすねたように言った。「礼儀正しくできないなら、お話の続きは自分でしたほうがいいよ」

<a id="AW-07-084"></a>

**AW-07-084**

<!-- EN:AW-07-084 -->
“No, please go on!” Alice said very humbly; “I won’t interrupt again. I dare say there may be *one*.”
<!-- /EN:AW-07-084 -->

> 「いいえ、どうぞ続けて！」とアリスはすっかり低姿勢になって言った。「もう口を挟まないわ。*一つくらいは*、あるのかもしれないもの」

<a id="AW-07-085"></a>

**AW-07-085**

<!-- EN:AW-07-085 -->
“One, indeed!” said the Dormouse indignantly. However, he consented to go on. “And so these three little sisters—they were learning to draw, you know—”
<!-- /EN:AW-07-085 -->

> 「一つだって、まったく！」とヤマネは憤慨して言った。それでも、続きを話すことには応じた。「さて、この幼い三人の姉妹は――絵を描くことを習っていました――」

> **訳注：** draw には「絵を描く」と「水などを汲み上げる」の意味がある。この二つの意味が、以後のやり取りで行き来する。

<a id="AW-07-086"></a>

**AW-07-086**

<!-- EN:AW-07-086 -->
“What did they draw?” said Alice, quite forgetting her promise.
<!-- /EN:AW-07-086 -->

> 「何を描いていたの？」とアリスは、約束をすっかり忘れて言った。

<a id="AW-07-087"></a>

**AW-07-087**

<!-- EN:AW-07-087 -->
“Treacle,” said the Dormouse, without considering at all this time.
<!-- /EN:AW-07-087 -->

> 「糖蜜を」とヤマネは、今度は少しも考えずに言った。

<a id="AW-07-088"></a>

**AW-07-088**

<!-- EN:AW-07-088 -->
“I want a clean cup,” interrupted the Hatter: “let’s all move one place on.”
<!-- /EN:AW-07-088 -->

> 「きれいなカップが欲しい」と帽子屋が割り込んだ。「みんな、一つずつ隣へ移ろう」

<a id="AW-07-089"></a>

**AW-07-089**

<!-- EN:AW-07-089 -->
He moved on as he spoke, and the Dormouse followed him: the March Hare moved into the Dormouse’s place, and Alice rather unwillingly took the place of the March Hare. The Hatter was the only one who got any advantage from the change: and Alice was a good deal worse off than before, as the March Hare had just upset the milk-jug into his plate.
<!-- /EN:AW-07-089 -->

> そう言いながら帽子屋は移り、ヤマネもそれに続いた。三月ウサギがヤマネの席へ移り、アリスは気が進まないまま三月ウサギの席に移った。この席替えで得をしたのは帽子屋だけだった。アリスは前よりずっとひどい目にあった。三月ウサギが、たった今、ミルク差しを自分の皿にひっくり返していたからだ。

<a id="AW-07-090"></a>

**AW-07-090**

<!-- EN:AW-07-090 -->
Alice did not wish to offend the Dormouse again, so she began very cautiously: “But I don’t understand. Where did they draw the treacle from?”
<!-- /EN:AW-07-090 -->

> アリスはもうヤマネの機嫌を損ねたくなかったので、とても用心深く切り出した。「でも、わからないわ。糖蜜は、どこから汲み上げていたの？」

<a id="AW-07-091"></a>

**AW-07-091**

<!-- EN:AW-07-091 -->
“You can draw water out of a water-well,” said the Hatter; “so I should think you could draw treacle out of a treacle-well—eh, stupid?”
<!-- /EN:AW-07-091 -->

> 「水の井戸からは水が汲めるだろう」と帽子屋が言った。「だから糖蜜の井戸からは糖蜜が汲めると思うがね。え、おばかさん？」

<a id="AW-07-092"></a>

**AW-07-092**

<!-- EN:AW-07-092 -->
“But they were *in* the well,” Alice said to the Dormouse, not choosing to notice this last remark.
<!-- /EN:AW-07-092 -->

> 「でも、その子たちは井戸の*中に*いたんでしょう」とアリスはヤマネに言い、最後の言葉は取り合わないことにした。

<a id="AW-07-093"></a>

**AW-07-093**

<!-- EN:AW-07-093 -->
“Of course they were,” said the Dormouse; “—well in.”
<!-- /EN:AW-07-093 -->

> 「もちろん、そうさ」とヤマネは言った。「――たっぷり中にね」

> **訳注：** in the well（井戸の中に）に対して well in（十分に中に）と返している。well の「井戸」と「十分に・うまく」の意味を掛けた返答。

<a id="AW-07-094"></a>

**AW-07-094**

<!-- EN:AW-07-094 -->
This answer so confused poor Alice, that she let the Dormouse go on for some time without interrupting it.
<!-- /EN:AW-07-094 -->

> この返事でかわいそうなアリスはますます混乱してしまい、しばらくは口を挟まずにヤマネの話を聞いた。

<a id="AW-07-095"></a>

**AW-07-095**

<!-- EN:AW-07-095 -->
“They were learning to draw,” the Dormouse went on, yawning and rubbing its eyes, for it was getting very sleepy; “and they drew all manner of things—everything that begins with an M—”
<!-- /EN:AW-07-095 -->

> 「三人は、絵を描くことを習っていました」とヤマネは続けた。ひどく眠くなってきたので、あくびをして目をこすっていた。「それで、ありとあらゆるものを描きました――Mで始まるものなら何でも――」

<a id="AW-07-096"></a>

**AW-07-096**

<!-- EN:AW-07-096 -->
“Why with an M?” said Alice.
<!-- /EN:AW-07-096 -->

> 「どうしてMなの？」とアリスは言った。

<a id="AW-07-097"></a>

**AW-07-097**

<!-- EN:AW-07-097 -->
“Why not?” said the March Hare.
<!-- /EN:AW-07-097 -->

> 「どうしていけないんだい？」と三月ウサギは言った。

<a id="AW-07-098"></a>

**AW-07-098**

<!-- EN:AW-07-098 -->
Alice was silent.
<!-- /EN:AW-07-098 -->

> アリスは黙った。

<a id="AW-07-099"></a>

**AW-07-099**

<!-- EN:AW-07-099 -->
The Dormouse had closed its eyes by this time, and was going off into a doze; but, on being pinched by the Hatter, it woke up again with a little shriek, and went on: “—that begins with an M, such as mouse-traps, and the moon, and memory, and muchness—you know you say things are “much of a muchness”—did you ever see such a thing as a drawing of a muchness?”
<!-- /EN:AW-07-099 -->

> そのころにはヤマネは目を閉じ、うとうとし始めていた。けれど帽子屋につねられると、小さく悲鳴を上げてまた目を覚まし、続けた。「――Mで始まるもの。ネズミ捕り、月、記憶、それに多さとかね。ものが『同じような多さ』だ、なんて言うだろう――多さを描いた絵なんて、見たことがあるかい？」

> **訳注：** mouse-traps、moon、memory、muchness はすべて M で始まる。much of a muchness は「似たり寄ったり」の意味だが、ヤマネは muchness（多さ）を描ける物のように扱っている。

<a id="AW-07-100"></a>

**AW-07-100**

<!-- EN:AW-07-100 -->
“Really, now you ask me,” said Alice, very much confused, “I don’t think—”
<!-- /EN:AW-07-100 -->

> 「そうね、そう聞かれると」とアリスは、すっかりまごついて言った。「見たことはないと思う――」

> **訳注：** I don’t think— はここでは「見たことはないと思う――」と続けかけた形。帽子屋は、それを「私は考えない」の意味に取って遮る。訳文も未完のままにしている。

<a id="AW-07-101"></a>

**AW-07-101**

<!-- EN:AW-07-101 -->
“Then you shouldn’t talk,” said the Hatter.
<!-- /EN:AW-07-101 -->

> 「じゃあ、しゃべるべきじゃない」と帽子屋は言った。

<a id="AW-07-102"></a>

**AW-07-102**

<!-- EN:AW-07-102 -->
This piece of rudeness was more than Alice could bear: she got up in great disgust, and walked off; the Dormouse fell asleep instantly, and neither of the others took the least notice of her going, though she looked back once or twice, half hoping that they would call after her: the last time she saw them, they were trying to put the Dormouse into the teapot.
<!-- /EN:AW-07-102 -->

> この無礼には、アリスももう我慢できなかった。すっかり嫌になって立ち上がり、歩き去った。ヤマネはたちまち眠り込み、残る二人もアリスが立ち去るのをまるで気に留めなかった。アリスは呼び止めてくれないかと、少し期待して一、二度振り返ったのだけれど。最後に振り返ったとき、二人はヤマネをティーポットに押し込もうとしていた。

<a id="AW-07-103"></a>

**AW-07-103**

<!-- EN:AW-07-103 -->
“At any rate I’ll never go *there* again!” said Alice as she picked her way through the wood. “It’s the stupidest tea-party I ever was at in all my life!”
<!-- /EN:AW-07-103 -->

> 「とにかく、*あそこには*もう二度と行かないわ！」とアリスは、森の中を足元に気をつけて進みながら言った。「生まれてから出たお茶会の中で、いちばんばかげたお茶会だわ！」

<a id="AW-07-104"></a>

**AW-07-104**

<!-- EN:AW-07-104 -->
Just as she said this, she noticed that one of the trees had a door leading right into it. “That’s very curious!” she thought. “But everything’s curious today. I think I may as well go in at once.” And in she went.
<!-- /EN:AW-07-104 -->

> そう言ったちょうどそのとき、木の一本に、中へそのまま入れる扉があるのに気づいた。「なんて不思議なの！」と思った。「でも今日は何もかも不思議だわ。すぐ入ってみてもよさそうね」そして中へ入った。

<a id="AW-07-105"></a>

**AW-07-105**

<!-- EN:AW-07-105 -->
Once more she found herself in the long hall, and close to the little glass table. “Now, I’ll manage better this time,” she said to herself, and began by taking the little golden key, and unlocking the door that led into the garden. Then she went to work nibbling at the mushroom (she had kept a piece of it in her pocket) till she was about a foot high: then she walked down the little passage: and *then*—she found herself at last in the beautiful garden, among the bright flower-beds and the cool fountains.
<!-- /EN:AW-07-105 -->

> 気がつくと、またあの長い広間の、小さなガラスのテーブルのそばにいた。「さあ、今度はもっと上手にやるわ」とひとりごとを言い、まず小さな金の鍵を取って、庭へ通じる扉の鍵を開けた。それからキノコを少しずつかじって――一かけらをポケットに取っておいたのだ――背丈が一フィートほどになるまで続けた。それから小さな通路を歩いていった。そして*とうとう*――あの美しい庭にたどり着いた。鮮やかな花壇と、涼しげな噴水に囲まれた庭に。

[章目次へ戻る](#book-top)

---

<a id="aw-chapter-08"></a>

## 第8章　女王のクロッケー場

### CHAPTER VIII. The Queen’s Croquet-Ground

<a id="AW-08-001"></a>

**AW-08-001**

<!-- EN:AW-08-001 -->
A large rose-tree stood near the entrance of the garden: the roses growing on it were white, but there were three gardeners at it, busily painting them red. Alice thought this a very curious thing, and she went nearer to watch them, and just as she came up to them she heard one of them say, “Look out now, Five! Don’t go splashing paint over me like that!”
<!-- /EN:AW-08-001 -->

> 庭の入り口の近くに、大きなバラの木が立っていた。咲いている花は白かったが、三人の庭師がせっせと赤く塗っていた。アリスはとても不思議に思い、そばへ寄って眺めた。ちょうど近づいたとき、一人がこう言うのが聞こえた。「おい、気をつけろ、五番！　そんなふうに、おれに絵の具を飛ばすな！」

<a id="AW-08-002"></a>

**AW-08-002**

<!-- EN:AW-08-002 -->
“I couldn’t help it,” said Five, in a sulky tone; “Seven jogged my elbow.”
<!-- /EN:AW-08-002 -->

> 「仕方なかったんだ」と五番は不機嫌そうに言った。「七番がおれの肘をつついたんだから」

<a id="AW-08-003"></a>

**AW-08-003**

<!-- EN:AW-08-003 -->
On which Seven looked up and said, “That’s right, Five! Always lay the blame on others!”
<!-- /EN:AW-08-003 -->

> すると七番が顔を上げて言った。「そうかい、五番！　何でも人のせいにするんだな！」

<a id="AW-08-004"></a>

**AW-08-004**

<!-- EN:AW-08-004 -->
“*You’d* better not talk!” said Five. “I heard the Queen say only yesterday you deserved to be beheaded!”
<!-- /EN:AW-08-004 -->

> 「*おまえこそ*黙ってろ！」と五番は言った。「つい昨日、女王さまがおまえの首をはねて当然だっておっしゃるのを聞いたぞ！」

<a id="AW-08-005"></a>

**AW-08-005**

<!-- EN:AW-08-005 -->
“What for?” said the one who had spoken first.
<!-- /EN:AW-08-005 -->

> 「何をしたんだ？」と、最初にしゃべった庭師が言った。

<a id="AW-08-006"></a>

**AW-08-006**

<!-- EN:AW-08-006 -->
“That’s none of *your* business, Two!” said Seven.
<!-- /EN:AW-08-006 -->

> 「*おまえには*関係ない、二番！」と七番は言った。

<a id="AW-08-007"></a>

**AW-08-007**

<!-- EN:AW-08-007 -->
“Yes, it *is* his business!” said Five, “and I’ll tell him—it was for bringing the cook tulip-roots instead of onions.”
<!-- /EN:AW-08-007 -->

> 「いや、*関係ある*ね！」と五番は言った。「教えてやるよ。料理人にタマネギを持っていくはずが、チューリップの球根を持っていったんだ」

<a id="AW-08-008"></a>

**AW-08-008**

<!-- EN:AW-08-008 -->
Seven flung down his brush, and had just begun “Well, of all the unjust things—” when his eye chanced to fall upon Alice, as she stood watching them, and he checked himself suddenly: the others looked round also, and all of them bowed low.
<!-- /EN:AW-08-008 -->

> 七番は刷毛を投げ捨て、「まったく、こんなひどい言いがかりは――」と言いかけた。そのとき、そばに立って見ているアリスがふと目に入り、急に言葉を止めた。ほかの二人も振り返り、三人とも深々とお辞儀をした。

<a id="AW-08-009"></a>

**AW-08-009**

<!-- EN:AW-08-009 -->
“Would you tell me,” said Alice, a little timidly, “why you are painting those roses?”
<!-- /EN:AW-08-009 -->

> 「教えていただけるかしら」とアリスは少しおずおずと言った。「どうして、そのバラに色を塗っているの？」

<a id="AW-08-010"></a>

**AW-08-010**

<!-- EN:AW-08-010 -->
Five and Seven said nothing, but looked at Two. Two began in a low voice, “Why the fact is, you see, Miss, this here ought to have been a *red* rose-tree, and we put a white one in by mistake; and if the Queen was to find it out, we should all have our heads cut off, you know. So you see, Miss, we’re doing our best, afore she comes, to—” At this moment Five, who had been anxiously looking across the garden, called out “The Queen! The Queen!” and the three gardeners instantly threw themselves flat upon their faces. There was a sound of many footsteps, and Alice looked round, eager to see the Queen.
<!-- /EN:AW-08-010 -->

> 五番と七番は何も言わず、二番を見た。二番は低い声で話し始めた。「いや、実はですね、お嬢さん、ここの木は*赤い*バラでなくちゃいけなかったんですが、間違えて白いのを植えちまったんです。もし女王さまにばれたら、みんな首をはねられちまいます。それでですね、お嬢さん、おいでになる前に、何とか――」このとき、心配そうに庭の向こうを見ていた五番が、「女王さまだ！　女王さまだ！」と叫び、三人の庭師はたちまち地面にうつぶせに伏せた。大勢の足音がして、アリスは女王を見たいと、はやる気持ちで振り返った。

<a id="AW-08-011"></a>

**AW-08-011**

<!-- EN:AW-08-011 -->
First came ten soldiers carrying clubs; these were all shaped like the three gardeners, oblong and flat, with their hands and feet at the corners: next the ten courtiers; these were ornamented all over with diamonds, and walked two and two, as the soldiers did. After these came the royal children; there were ten of them, and the little dears came jumping merrily along hand in hand, in couples: they were all ornamented with hearts. Next came the guests, mostly Kings and Queens, and among them Alice recognised the White Rabbit: it was talking in a hurried nervous manner, smiling at everything that was said, and went by without noticing her. Then followed the Knave of Hearts, carrying the King’s crown on a crimson velvet cushion; and, last of all this grand procession, came THE KING AND QUEEN OF HEARTS.
<!-- /EN:AW-08-011 -->

> 最初に、棍棒を持った十人の兵士が来た。みんなあの三人の庭師と同じ形で、長方形で平たく、四隅に手足がついていた。次は十人の廷臣で、体じゅうにダイヤの模様があり、兵士と同じように二人ずつ並んで歩いていた。その後から王家の子どもたちが来た。十人いて、かわいい子どもたちは二人ずつ手をつなぎ、楽しげに跳ねながらやって来た。みんなハートの模様をつけていた。続いて招待客が来た。たいていは王や女王で、その中にアリスは白ウサギを見つけた。白ウサギはそわそわとせわしなくしゃべり、誰が何を言ってもにこにこしていて、アリスに気づかず通り過ぎた。それからハートのジャックが、深紅のビロードのクッションに王冠をのせて運んできた。そして、この盛大な行列のいちばん最後に現れたのが、ハートの王と女王だった。

> **訳注：** clubs は「棍棒」とトランプの「クラブ」の両方を表す。行列はクラブ、ダイヤ、ハートの札によって構成されている。

<a id="AW-08-012"></a>

**AW-08-012**

<!-- EN:AW-08-012 -->
Alice was rather doubtful whether she ought not to lie down on her face like the three gardeners, but she could not remember ever having heard of such a rule at processions; “and besides, what would be the use of a procession,” thought she, “if people had all to lie down upon their faces, so that they couldn’t see it?” So she stood still where she was, and waited.
<!-- /EN:AW-08-012 -->

> アリスは、自分も三人の庭師のようにうつぶせにならなくてはいけないのかと少し迷った。けれど、行列でそんな決まりがあると聞いた覚えはなかった。「それに、みんなうつぶせにならなくちゃいけなくて、見ることもできないなら、行列なんて何の役に立つのかしら」と思った。そこで、その場に立ったまま待った。

<a id="AW-08-013"></a>

**AW-08-013**

<!-- EN:AW-08-013 -->
When the procession came opposite to Alice, they all stopped and looked at her, and the Queen said severely “Who is this?” She said it to the Knave of Hearts, who only bowed and smiled in reply.
<!-- /EN:AW-08-013 -->

> 行列がアリスの前まで来ると、みんな立ち止まってアリスを見た。女王は厳しく「これは誰だ？」と言った。尋ねられたのはハートのジャックだったが、返事の代わりに、ただお辞儀をして微笑んだ。

<a id="AW-08-014"></a>

**AW-08-014**

<!-- EN:AW-08-014 -->
“Idiot!” said the Queen, tossing her head impatiently; and, turning to Alice, she went on, “What’s your name, child?”
<!-- /EN:AW-08-014 -->

> 「ばか者！」と女王はじれったそうに頭を振って言った。そしてアリスに向き直ると、続けた。「名前は何という、子ども？」

<a id="AW-08-015"></a>

**AW-08-015**

<!-- EN:AW-08-015 -->
“My name is Alice, so please your Majesty,” said Alice very politely; but she added, to herself, “Why, they’re only a pack of cards, after all. I needn’t be afraid of them!”
<!-- /EN:AW-08-015 -->

> 「恐れながら、陛下、アリスと申します」とアリスはとても丁寧に答えた。けれど心の中で付け加えた。「なあんだ、結局ただのトランプ一組じゃない。怖がることなんてないわ！」

<a id="AW-08-016"></a>

**AW-08-016**

<!-- EN:AW-08-016 -->
“And who are *these?*” said the Queen, pointing to the three gardeners who were lying round the rose-tree; for, you see, as they were lying on their faces, and the pattern on their backs was the same as the rest of the pack, she could not tell whether they were gardeners, or soldiers, or courtiers, or three of her own children.
<!-- /EN:AW-08-016 -->

> 「それで、*こいつらは*誰だ？」と女王は、バラの木のまわりに伏せている三人の庭師を指して言った。というのも、三人はうつぶせで、背中の模様はほかの札と同じだったから、庭師なのか、兵士なのか、廷臣なのか、それとも自分の子ども三人なのか、見分けがつかなかったのだ。

<a id="AW-08-017"></a>

**AW-08-017**

<!-- EN:AW-08-017 -->
“How should *I* know?” said Alice, surprised at her own courage. “It’s no business of *mine*.”
<!-- /EN:AW-08-017 -->

> 「どうして*わたしに*わかるんですか？」とアリスは、自分の大胆さに驚きながら言った。「*わたしには*関係のないことですもの」

<a id="AW-08-018"></a>

**AW-08-018**

<!-- EN:AW-08-018 -->
The Queen turned crimson with fury, and, after glaring at her for a moment like a wild beast, screamed “Off with her head! Off—”
<!-- /EN:AW-08-018 -->

> 女王は怒りで真っ赤になり、しばらく野獣のようにアリスをにらみつけたあと、金切り声を上げた。「この子の首をはねよ！　首を――」

<a id="AW-08-019"></a>

**AW-08-019**

<!-- EN:AW-08-019 -->
“Nonsense!” said Alice, very loudly and decidedly, and the Queen was silent.
<!-- /EN:AW-08-019 -->

> 「ばかばかしい！」とアリスは大きな声できっぱり言った。女王は黙った。

<a id="AW-08-020"></a>

**AW-08-020**

<!-- EN:AW-08-020 -->
The King laid his hand upon her arm, and timidly said “Consider, my dear: she is only a child!”
<!-- /EN:AW-08-020 -->

> 王は女王の腕に手を置き、おそるおそる言った。「よく考えておくれ、おまえ。ほんの子どもじゃないか！」

<a id="AW-08-021"></a>

**AW-08-021**

<!-- EN:AW-08-021 -->
The Queen turned angrily away from him, and said to the Knave “Turn them over!”
<!-- /EN:AW-08-021 -->

> 女王は怒って王から顔を背け、ジャックに言った。「こいつらを裏返せ！」

<a id="AW-08-022"></a>

**AW-08-022**

<!-- EN:AW-08-022 -->
The Knave did so, very carefully, with one foot.
<!-- /EN:AW-08-022 -->

> ジャックは片足を使って、たいそう慎重にそのとおりにした。

<a id="AW-08-023"></a>

**AW-08-023**

<!-- EN:AW-08-023 -->
“Get up!” said the Queen, in a shrill, loud voice, and the three gardeners instantly jumped up, and began bowing to the King, the Queen, the royal children, and everybody else.
<!-- /EN:AW-08-023 -->

> 「立て！」と女王は、甲高い大声で言った。三人の庭師はたちまち跳ね起き、王に、女王に、王家の子どもたちに、それからほかのみんなに、お辞儀をし始めた。

<a id="AW-08-024"></a>

**AW-08-024**

<!-- EN:AW-08-024 -->
“Leave off that!” screamed the Queen. “You make me giddy.” And then, turning to the rose-tree, she went on, “What *have* you been doing here?”
<!-- /EN:AW-08-024 -->

> 「やめろ！」と女王は叫んだ。「目が回るわ」そしてバラの木に向き直り、続けた。「ここで、*いったい*何をしていた？」

<a id="AW-08-025"></a>

**AW-08-025**

<!-- EN:AW-08-025 -->
“May it please your Majesty,” said Two, in a very humble tone, going down on one knee as he spoke, “we were trying—”
<!-- /EN:AW-08-025 -->

> 「恐れながら、陛下」と二番は、片膝をつきながら、たいそうへりくだった声で言った。「私どもは、どうにか――」

<a id="AW-08-026"></a>

**AW-08-026**

<!-- EN:AW-08-026 -->
“*I* see!” said the Queen, who had meanwhile been examining the roses. “Off with their heads!” and the procession moved on, three of the soldiers remaining behind to execute the unfortunate gardeners, who ran to Alice for protection.
<!-- /EN:AW-08-026 -->

> 「*わかったぞ！*」と、そのあいだにバラを調べていた女王は言った。「こいつらの首をはねよ！」行列はまた進み、三人の兵士が残って、気の毒な庭師たちを処刑しようとした。庭師たちは、助けを求めてアリスのところへ走ってきた。

<a id="AW-08-027"></a>

**AW-08-027**

<!-- EN:AW-08-027 -->
“You shan’t be beheaded!” said Alice, and she put them into a large flower-pot that stood near. The three soldiers wandered about for a minute or two, looking for them, and then quietly marched off after the others.
<!-- /EN:AW-08-027 -->

> 「首なんか、はねさせないわ！」とアリスは言い、そばにあった大きな植木鉢の中へ三人を入れた。三人の兵士は一、二分、あちこち歩き回って探したあと、そっとほかの者たちの後を追って行進していった。

<a id="AW-08-028"></a>

**AW-08-028**

<!-- EN:AW-08-028 -->
“Are their heads off?” shouted the Queen.
<!-- /EN:AW-08-028 -->

> 「首は落としたか？」と女王が叫んだ。

<a id="AW-08-029"></a>

**AW-08-029**

<!-- EN:AW-08-029 -->
“Their heads are gone, if it please your Majesty!” the soldiers shouted in reply.
<!-- /EN:AW-08-029 -->

> 「首はもうありません、陛下！」と兵士たちは叫んで答えた。

<a id="AW-08-030"></a>

**AW-08-030**

<!-- EN:AW-08-030 -->
“That’s right!” shouted the Queen. “Can you play croquet?”
<!-- /EN:AW-08-030 -->

> 「よろしい！」と女王は叫んだ。「クロッケーはできるか？」

<a id="AW-08-031"></a>

**AW-08-031**

<!-- EN:AW-08-031 -->
The soldiers were silent, and looked at Alice, as the question was evidently meant for her.
<!-- /EN:AW-08-031 -->

> その質問は明らかにアリスに向けられていたので、兵士たちは黙ってアリスを見た。

<a id="AW-08-032"></a>

**AW-08-032**

<!-- EN:AW-08-032 -->
“Yes!” shouted Alice.
<!-- /EN:AW-08-032 -->

> 「はい！」とアリスは叫んだ。

<a id="AW-08-033"></a>

**AW-08-033**

<!-- EN:AW-08-033 -->
“Come on, then!” roared the Queen, and Alice joined the procession, wondering very much what would happen next.
<!-- /EN:AW-08-033 -->

> 「では、来い！」と女王は吠えるように言った。アリスは、これから何が起こるのだろうと大いに気にしながら、行列に加わった。

<a id="AW-08-034"></a>

**AW-08-034**

<!-- EN:AW-08-034 -->
“It’s—it’s a very fine day!” said a timid voice at her side. She was walking by the White Rabbit, who was peeping anxiously into her face.
<!-- /EN:AW-08-034 -->

> 「と、とてもいいお天気ですね！」と、かたわらでおどおどした声がした。アリスは白ウサギの隣を歩いていて、白ウサギは心配そうにアリスの顔をのぞき込んでいた。

<a id="AW-08-035"></a>

**AW-08-035**

<!-- EN:AW-08-035 -->
“Very,” said Alice: “—where’s the Duchess?”
<!-- /EN:AW-08-035 -->

> 「とてもね」とアリスは言った。「――公爵夫人はどこ？」

<a id="AW-08-036"></a>

**AW-08-036**

<!-- EN:AW-08-036 -->
“Hush! Hush!” said the Rabbit in a low, hurried tone. He looked anxiously over his shoulder as he spoke, and then raised himself upon tiptoe, put his mouth close to her ear, and whispered “She’s under sentence of execution.”
<!-- /EN:AW-08-036 -->

> 「しっ！　しっ！」と白ウサギは低い声で慌ただしく言った。心配そうに肩越しに振り返り、それからつま先立ちになってアリスの耳に口を寄せ、ささやいた。「死刑の判決を受けているんです」

<a id="AW-08-037"></a>

**AW-08-037**

<!-- EN:AW-08-037 -->
“What for?” said Alice.
<!-- /EN:AW-08-037 -->

> 「何をしたの？」とアリスは言った。

<a id="AW-08-038"></a>

**AW-08-038**

<!-- EN:AW-08-038 -->
“Did you say ‘What a pity!’?” the Rabbit asked.
<!-- /EN:AW-08-038 -->

> 「『お気の毒に！』とおっしゃいましたか？」と白ウサギは尋ねた。

<a id="AW-08-039"></a>

**AW-08-039**

<!-- EN:AW-08-039 -->
“No, I didn’t,” said Alice: “I don’t think it’s at all a pity. I said ‘What for?’”
<!-- /EN:AW-08-039 -->

> 「いいえ、言っていないわ」とアリスは言った。「少しもお気の毒だとは思わないもの。『何をしたの？』と言ったのよ」

<a id="AW-08-040"></a>

**AW-08-040**

<!-- EN:AW-08-040 -->
“She boxed the Queen’s ears—” the Rabbit began. Alice gave a little scream of laughter. “Oh, hush!” the Rabbit whispered in a frightened tone. “The Queen will hear you! You see, she came rather late, and the Queen said—”
<!-- /EN:AW-08-040 -->

> 「女王の耳を平手打ちしたんです――」と白ウサギは話し始めた。アリスは小さく甲高い笑い声を上げた。「ああ、静かに！」と白ウサギはおびえた声でささやいた。「女王に聞こえますよ！　その、夫人はだいぶ遅れて来たもので、女王がこうおっしゃって――」

<a id="AW-08-041"></a>

**AW-08-041**

<!-- EN:AW-08-041 -->
“Get to your places!” shouted the Queen in a voice of thunder, and people began running about in all directions, tumbling up against each other; however, they got settled down in a minute or two, and the game began. Alice thought she had never seen such a curious croquet-ground in her life; it was all ridges and furrows; the balls were live hedgehogs, the mallets live flamingoes, and the soldiers had to double themselves up and to stand on their hands and feet, to make the arches.
<!-- /EN:AW-08-041 -->

> 「持ち場につけ！」と女王が雷のような声で叫んだ。みんなは四方八方へ走り回り、互いにぶつかり合い始めた。それでも一、二分で落ち着き、試合が始まった。アリスは、生まれてこのかた、こんな奇妙なクロッケー場は見たことがないと思った。地面は一面、畝と溝だらけ。球は生きたハリネズミ、マレットは生きたフラミンゴで、兵士たちは体を二つ折りにし、手と足で立ってアーチを作らなくてはならなかった。

<a id="AW-08-042"></a>

**AW-08-042**

<!-- EN:AW-08-042 -->
The chief difficulty Alice found at first was in managing her flamingo: she succeeded in getting its body tucked away, comfortably enough, under her arm, with its legs hanging down, but generally, just as she had got its neck nicely straightened out, and was going to give the hedgehog a blow with its head, it *would* twist itself round and look up in her face, with such a puzzled expression that she could not help bursting out laughing: and when she had got its head down, and was going to begin again, it was very provoking to find that the hedgehog had unrolled itself, and was in the act of crawling away: besides all this, there was generally a ridge or furrow in the way wherever she wanted to send the hedgehog to, and, as the doubled-up soldiers were always getting up and walking off to other parts of the ground, Alice soon came to the conclusion that it was a very difficult game indeed.
<!-- /EN:AW-08-042 -->

> 最初にアリスがいちばん困ったのは、フラミンゴの扱いだった。体を脇の下にきちんと抱え込み、脚を下に垂らさせるところまでは、どうにかうまくいった。けれど、首をちょうどよくまっすぐ伸ばして、その頭でハリネズミを打とうとすると、たいてい*決まって*首をねじり、アリスの顔を見上げるのだった。その表情があまりに当惑しきっているので、アリスは思わず噴き出してしまった。頭をまた下ろして、もう一度始めようとすると、今度はハリネズミが丸まっていた体をほどき、這って逃げだそうとしているので、まったくじれったかった。そのうえ、ハリネズミをどこへ飛ばそうとしても、たいてい途中には畝か溝があった。さらに、二つ折りになった兵士たちは、しょっちゅう立ち上がって別の場所へ歩いていってしまう。アリスはすぐに、これは本当にたいへん難しい競技なのだ、と結論を出した。

<a id="AW-08-043"></a>

**AW-08-043**

<!-- EN:AW-08-043 -->
The players all played at once without waiting for turns, quarrelling all the while, and fighting for the hedgehogs; and in a very short time the Queen was in a furious passion, and went stamping about, and shouting “Off with his head!” or “Off with her head!” about once in a minute.
<!-- /EN:AW-08-043 -->

> 競技者たちは順番を待たずに一斉に打ち、そのあいだじゅう言い争い、ハリネズミを奪い合っていた。あっという間に女王はかんかんに怒りだし、地面を踏み鳴らして歩き回り、一分に一度くらいは「あの男の首をはねよ！」とか「あの女の首をはねよ！」とか叫んでいた。

<a id="AW-08-044"></a>

**AW-08-044**

<!-- EN:AW-08-044 -->
Alice began to feel very uneasy: to be sure, she had not as yet had any dispute with the Queen, but she knew that it might happen any minute, “and then,” thought she, “what would become of me? They’re dreadfully fond of beheading people here; the great wonder is, that there’s any one left alive!”
<!-- /EN:AW-08-044 -->

> アリスはひどく不安になってきた。確かに、まだ女王と争いにはなっていなかったが、いつそうなってもおかしくないことはわかっていた。「そうしたら、わたしはどうなるのかしら」と思った。「ここでは、人の首をはねるのが恐ろしく好きなのね。誰か一人でも生き残っているほうが、よっぽど不思議だわ！」

<a id="AW-08-045"></a>

**AW-08-045**

<!-- EN:AW-08-045 -->
She was looking about for some way of escape, and wondering whether she could get away without being seen, when she noticed a curious appearance in the air: it puzzled her very much at first, but, after watching it a minute or two, she made it out to be a grin, and she said to herself “It’s the Cheshire Cat: now I shall have somebody to talk to.”
<!-- /EN:AW-08-045 -->

> アリスは逃げ道を求めてあたりを見回し、見つからずに抜け出せるかしらと考えていた。そのとき、空中に奇妙なものが現れているのに気づいた。最初はひどく戸惑ったが、一、二分眺めているうちに、それがにやにや笑いだとわかり、ひとりごとを言った。「チェシャ猫だわ。これで、話し相手ができる」

<a id="AW-08-046"></a>

**AW-08-046**

<!-- EN:AW-08-046 -->
“How are you getting on?” said the Cat, as soon as there was mouth enough for it to speak with.
<!-- /EN:AW-08-046 -->

> 「調子はどうだい？」と猫が言った。しゃべれるだけの口が現れると、すぐにそう言ったのだ。

<a id="AW-08-047"></a>

**AW-08-047**

<!-- EN:AW-08-047 -->
Alice waited till the eyes appeared, and then nodded. “It’s no use speaking to it,” she thought, “till its ears have come, or at least one of them.” In another minute the whole head appeared, and then Alice put down her flamingo, and began an account of the game, feeling very glad she had someone to listen to her. The Cat seemed to think that there was enough of it now in sight, and no more of it appeared.
<!-- /EN:AW-08-047 -->

> アリスは目が現れるまで待って、それからうなずいた。「耳が出てくるまでは、少なくとも片方が出てくるまでは、話しかけてもむだね」と思った。もう少したつと、頭全体が現れた。そこでアリスはフラミンゴを下ろし、試合の様子を話し始めた。聞いてくれる相手ができて、とてもうれしかった。猫のほうは、もう十分に姿を見せたと思っているらしく、それ以上はどこも現れなかった。

<a id="AW-08-048"></a>

**AW-08-048**

<!-- EN:AW-08-048 -->
“I don’t think they play at all fairly,” Alice began, in rather a complaining tone, “and they all quarrel so dreadfully one can’t hear oneself speak—and they don’t seem to have any rules in particular; at least, if there are, nobody attends to them—and you’ve no idea how confusing it is all the things being alive; for instance, there’s the arch I’ve got to go through next walking about at the other end of the ground—and I should have croqueted the Queen’s hedgehog just now, only it ran away when it saw mine coming!”
<!-- /EN:AW-08-048 -->

> 「みんな、少しも公平にやっていないと思うの」とアリスは、少し不満をこぼすような調子で話し始めた。「みんなひどく言い争うものだから、自分の声も聞こえないし――特に決まりがあるようにも見えないの。少なくとも、あったって誰も守っていないわ――それから、何もかも生きていると、どれほどややこしいか、あなたには想像もつかないでしょう。たとえば、次に通さなくちゃいけないアーチが、あそこ、競技場の反対の端を歩いているのよ――それに、さっきは女王のハリネズミを打ち飛ばせるはずだったのに、わたしのが来るのを見て逃げてしまったの！」

<a id="AW-08-049"></a>

**AW-08-049**

<!-- EN:AW-08-049 -->
“How do you like the Queen?” said the Cat in a low voice.
<!-- /EN:AW-08-049 -->

> 「女王は気に入ったかい？」と猫は低い声で言った。

<a id="AW-08-050"></a>

**AW-08-050**

<!-- EN:AW-08-050 -->
“Not at all,” said Alice: “she’s so extremely—” Just then she noticed that the Queen was close behind her, listening: so she went on, “—likely to win, that it’s hardly worth while finishing the game.”
<!-- /EN:AW-08-050 -->

> 「ちっとも」とアリスは言った。「だって、あんまり――」ちょうどそのとき、女王がすぐ後ろで聞いているのに気づいたので、続けた。「――勝ちそうなんですもの。試合を最後までやるだけの甲斐も、ほとんどないくらい」

<a id="AW-08-051"></a>

**AW-08-051**

<!-- EN:AW-08-051 -->
The Queen smiled and passed on.
<!-- /EN:AW-08-051 -->

> 女王は微笑んで通り過ぎた。

<a id="AW-08-052"></a>

**AW-08-052**

<!-- EN:AW-08-052 -->
“Who *are* you talking to?” said the King, going up to Alice, and looking at the Cat’s head with great curiosity.
<!-- /EN:AW-08-052 -->

> 「*いったい*誰と話しているのだ？」と王が言った。アリスに近づき、たいそう物珍しそうに猫の頭を眺めていた。

<a id="AW-08-053"></a>

**AW-08-053**

<!-- EN:AW-08-053 -->
“It’s a friend of mine—a Cheshire Cat,” said Alice: “allow me to introduce it.”
<!-- /EN:AW-08-053 -->

> 「わたしの友だちです。チェシャ猫です」とアリスは言った。「ご紹介させてください」

<a id="AW-08-054"></a>

**AW-08-054**

<!-- EN:AW-08-054 -->
“I don’t like the look of it at all,” said the King: “however, it may kiss my hand if it likes.”
<!-- /EN:AW-08-054 -->

> 「まるで気に入らん顔だ」と王は言った。「だが、望むならわしの手に口づけしてもよいぞ」

<a id="AW-08-055"></a>

**AW-08-055**

<!-- EN:AW-08-055 -->
“I’d rather not,” the Cat remarked.
<!-- /EN:AW-08-055 -->

> 「遠慮しておくよ」と猫は言った。

<a id="AW-08-056"></a>

**AW-08-056**

<!-- EN:AW-08-056 -->
“Don’t be impertinent,” said the King, “and don’t look at me like that!” He got behind Alice as he spoke.
<!-- /EN:AW-08-056 -->

> 「無礼なことを言うな」と王は言った。「それに、そんなふうにわしを見るな！」そう言いながら、アリスの後ろへ隠れた。

<a id="AW-08-057"></a>

**AW-08-057**

<!-- EN:AW-08-057 -->
“A cat may look at a king,” said Alice. “I’ve read that in some book, but I don’t remember where.”
<!-- /EN:AW-08-057 -->

> 「猫だって王さまを見てもいいのよ」とアリスは言った。「どこかの本で読んだわ。どこだったかは覚えていないけれど」

> **訳注：** A cat may look at a king は、身分の低い者にも一定の権利はある、という趣旨のことわざ。ここでは猫と王が実際に向き合っている。

<a id="AW-08-058"></a>

**AW-08-058**

<!-- EN:AW-08-058 -->
“Well, it must be removed,” said the King very decidedly, and he called the Queen, who was passing at the moment, “My dear! I wish you would have this cat removed!”
<!-- /EN:AW-08-058 -->

> 「とにかく、どかさねばならん」と王はきっぱり言い、ちょうど通りかかった女王を呼んだ。「おまえ！　この猫をどかしてくれないか！」

<a id="AW-08-059"></a>

**AW-08-059**

<!-- EN:AW-08-059 -->
The Queen had only one way of settling all difficulties, great or small. “Off with his head!” she said, without even looking round.
<!-- /EN:AW-08-059 -->

> 女王には、大きな問題でも小さな問題でも、解決の仕方は一つしかなかった。「首をはねよ！」と、振り向きもせずに言った。

<a id="AW-08-060"></a>

**AW-08-060**

<!-- EN:AW-08-060 -->
“I’ll fetch the executioner myself,” said the King eagerly, and he hurried off.
<!-- /EN:AW-08-060 -->

> 「わしが自分で処刑人を呼んでこよう」と王は張り切って言い、急いで立ち去った。

<a id="AW-08-061"></a>

**AW-08-061**

<!-- EN:AW-08-061 -->
Alice thought she might as well go back, and see how the game was going on, as she heard the Queen’s voice in the distance, screaming with passion. She had already heard her sentence three of the players to be executed for having missed their turns, and she did not like the look of things at all, as the game was in such confusion that she never knew whether it was her turn or not. So she went in search of her hedgehog.
<!-- /EN:AW-08-061 -->

> 遠くで女王が怒り狂って叫ぶ声が聞こえたので、アリスは戻って試合の様子を見てもよさそうだと思った。すでに、順番を逃したという理由で、競技者三人に死刑を言い渡すのを聞いていた。試合はあまりに混乱していて、自分の番かどうかさえまるでわからなかったから、この様子は少しも気に入らなかった。そこで、自分のハリネズミを探しに行った。

<a id="AW-08-062"></a>

**AW-08-062**

<!-- EN:AW-08-062 -->
The hedgehog was engaged in a fight with another hedgehog, which seemed to Alice an excellent opportunity for croqueting one of them with the other: the only difficulty was, that her flamingo was gone across to the other side of the garden, where Alice could see it trying in a helpless sort of way to fly up into a tree.
<!-- /EN:AW-08-062 -->

> ハリネズミは、別のハリネズミとけんかをしていた。アリスには、一匹でもう一匹を打ち飛ばす絶好の機会に思えた。ただ一つ困ったことに、フラミンゴは庭の反対側へ行ってしまっていた。そちらを見ると、どうにもならない様子で、木の上へ飛び上がろうとしているのが見えた。

<a id="AW-08-063"></a>

**AW-08-063**

<!-- EN:AW-08-063 -->
By the time she had caught the flamingo and brought it back, the fight was over, and both the hedgehogs were out of sight: “but it doesn’t matter much,” thought Alice, “as all the arches are gone from this side of the ground.” So she tucked it away under her arm, that it might not escape again, and went back for a little more conversation with her friend.
<!-- /EN:AW-08-063 -->

> フラミンゴを捕まえて戻ってきたころには、けんかは終わり、ハリネズミは二匹とも見えなくなっていた。「でも、大したことはないわ」とアリスは思った。「こっち側のアーチは、みんないなくなってしまったんですもの」そこで、もう逃げないようにフラミンゴを脇に抱え込み、友だちともう少し話そうと戻っていった。

<a id="AW-08-064"></a>

**AW-08-064**

<!-- EN:AW-08-064 -->
When she got back to the Cheshire Cat, she was surprised to find quite a large crowd collected round it: there was a dispute going on between the executioner, the King, and the Queen, who were all talking at once, while all the rest were quite silent, and looked very uncomfortable.
<!-- /EN:AW-08-064 -->

> チェシャ猫のところへ戻ってみると、まわりにかなりの人だかりができていて、アリスは驚いた。処刑人と王と女王が言い争い、三人とも一度にしゃべっていた。ほかのみんなはすっかり黙り込み、ひどく居心地が悪そうだった。

<a id="AW-08-065"></a>

**AW-08-065**

<!-- EN:AW-08-065 -->
The moment Alice appeared, she was appealed to by all three to settle the question, and they repeated their arguments to her, though, as they all spoke at once, she found it very hard indeed to make out exactly what they said.
<!-- /EN:AW-08-065 -->

> アリスが現れたとたん、三人そろって、どちらが正しいか決めてくれと頼み、それぞれの言い分を繰り返した。けれど三人が一度にしゃべるので、何を言っているのか正確につかむのは、まったくたいへんだった。

<a id="AW-08-066"></a>

**AW-08-066**

<!-- EN:AW-08-066 -->
The executioner’s argument was, that you couldn’t cut off a head unless there was a body to cut it off from: that he had never had to do such a thing before, and he wasn’t going to begin at *his* time of life.
<!-- /EN:AW-08-066 -->

> 処刑人の言い分は、切り離す胴体がなければ首ははねられない、というものだった。これまでそんなことをさせられたことは一度もないし、*この年になって*始めるつもりもない、と言うのだ。

<a id="AW-08-067"></a>

**AW-08-067**

<!-- EN:AW-08-067 -->
The King’s argument was, that anything that had a head could be beheaded, and that you weren’t to talk nonsense.
<!-- /EN:AW-08-067 -->

> 王の言い分は、頭がついているものなら何でも首ははねられるのだから、ばかなことを言うな、というものだった。

<a id="AW-08-068"></a>

**AW-08-068**

<!-- EN:AW-08-068 -->
The Queen’s argument was, that if something wasn’t done about it in less than no time she’d have everybody executed, all round. (It was this last remark that had made the whole party look so grave and anxious.)
<!-- /EN:AW-08-068 -->

> 女王の言い分は、今すぐ、今すぐよりも早く何とかしないなら、その場にいる全員を一人残らず処刑させる、というものだった。（みんながあれほど深刻で心配そうな顔をしていたのは、この最後の言葉のせいだった。）

<a id="AW-08-069"></a>

**AW-08-069**

<!-- EN:AW-08-069 -->
Alice could think of nothing else to say but “It belongs to the Duchess: you’d better ask *her* about it.”
<!-- /EN:AW-08-069 -->

> アリスには、ほかに何も思いつかなかったので、こう言った。「この猫は公爵夫人の猫よ。*夫人に*聞いたほうがいいわ」

<a id="AW-08-070"></a>

**AW-08-070**

<!-- EN:AW-08-070 -->
“She’s in prison,” the Queen said to the executioner: “fetch her here.” And the executioner went off like an arrow.
<!-- /EN:AW-08-070 -->

> 「あの者は牢にいる」と女王は処刑人に言った。「ここへ連れてこい」処刑人は矢のように走っていった。

<a id="AW-08-071"></a>

**AW-08-071**

<!-- EN:AW-08-071 -->
The Cat’s head began fading away the moment he was gone, and, by the time he had come back with the Duchess, it had entirely disappeared; so the King and the executioner ran wildly up and down looking for it, while the rest of the party went back to the game.
<!-- /EN:AW-08-071 -->

> 処刑人がいなくなったとたん、猫の頭は薄れ始め、公爵夫人を連れて戻ってきたころには、すっかり消えていた。そこで王と処刑人は、やっきになってあちこち走り回り、猫の頭を探した。そのあいだに、ほかのみんなは試合へ戻っていった。

[章目次へ戻る](#book-top)

---

<a id="aw-chapter-09"></a>

## 第9章　ウミガメもどきの話

### CHAPTER IX. The Mock Turtle’s Story

<a id="AW-09-001"></a>

**AW-09-001**

<!-- EN:AW-09-001 -->
“You can’t think how glad I am to see you again, you dear old thing!” said the Duchess, as she tucked her arm affectionately into Alice’s, and they walked off together.
<!-- /EN:AW-09-001 -->

> 「また会えて、どんなにうれしいか、あなたにはわからないでしょうね、かわいいあなた！」と公爵夫人は言い、親しげにアリスの腕に自分の腕をからめた。二人は連れ立って歩きだした。

<a id="AW-09-002"></a>

**AW-09-002**

<!-- EN:AW-09-002 -->
Alice was very glad to find her in such a pleasant temper, and thought to herself that perhaps it was only the pepper that had made her so savage when they met in the kitchen.
<!-- /EN:AW-09-002 -->

> アリスは、公爵夫人がこんなに機嫌よくしているのを見て、とてもうれしかった。台所で会ったときにあんなに荒々しかったのは、ただコショウのせいだったのかもしれない、と心の中で思った。

<a id="AW-09-003"></a>

**AW-09-003**

<!-- EN:AW-09-003 -->
“When *I’m* a Duchess,” she said to herself, (not in a very hopeful tone though), “I won’t have any pepper in my kitchen *at all*. Soup does very well without—Maybe it’s always pepper that makes people hot-tempered,” she went on, very much pleased at having found out a new kind of rule, “and vinegar that makes them sour—and camomile that makes them bitter—and—and barley-sugar and such things that make children sweet-tempered. I only wish people knew *that*: then they wouldn’t be so stingy about it, you know—”
<!-- /EN:AW-09-003 -->

> 「*わたしが*公爵夫人になったら」とひとりごとを言った。もっとも、あまり実現を期待している声ではなかったけれど。「台所にはコショウを*一粒も*置かせないわ。スープはなくたって十分おいしいもの――人がかっかしやすくなるのは、いつだってコショウのせいなのかもしれないわね」と、新しい種類の法則を見つけたのがとてもうれしくて、話し続けた。「それから、お酢が人を酸っぱい顔にして――カモミールが苦々しくして――それから、それから、大麦あめやそんなものが、子どもを甘く優しい気立てにするのね。みんなが*それを*知っていたらいいのに。そうすれば、あんなにけちけちしないでしょうに――」

> **訳注：** hot、sour、bitter、sweet には、味や刺激を表す用法と、人の気性を表す用法がある。アリスは食べ物の性質と性格を結びつけている。

<a id="AW-09-004"></a>

**AW-09-004**

<!-- EN:AW-09-004 -->
She had quite forgotten the Duchess by this time, and was a little startled when she heard her voice close to her ear. “You’re thinking about something, my dear, and that makes you forget to talk. I can’t tell you just now what the moral of that is, but I shall remember it in a bit.”
<!-- /EN:AW-09-004 -->

> このころには、公爵夫人のことをすっかり忘れていたので、すぐ耳元でその声が聞こえたときは、少しどきりとした。「何か考えているのね、あなた。それで、しゃべるのを忘れてしまうのよ。このことの教訓は、今すぐには言えないけれど、そのうち思い出すわ」

<a id="AW-09-005"></a>

**AW-09-005**

<!-- EN:AW-09-005 -->
“Perhaps it hasn’t one,” Alice ventured to remark.
<!-- /EN:AW-09-005 -->

> 「教訓なんて、ないのかもしれません」とアリスは思い切って言った。

<a id="AW-09-006"></a>

**AW-09-006**

<!-- EN:AW-09-006 -->
“Tut, tut, child!” said the Duchess. “Everything’s got a moral, if only you can find it.” And she squeezed herself up closer to Alice’s side as she spoke.
<!-- /EN:AW-09-006 -->

> 「まあまあ、何を言うの！」と公爵夫人は言った。「何にだって教訓はあるのよ。見つけられさえすればね」そう言いながら、いっそうぴったりとアリスの脇へ身を寄せた。

<a id="AW-09-007"></a>

**AW-09-007**

<!-- EN:AW-09-007 -->
Alice did not much like keeping so close to her: first, because the Duchess was *very* ugly; and secondly, because she was exactly the right height to rest her chin upon Alice’s shoulder, and it was an uncomfortably sharp chin. However, she did not like to be rude, so she bore it as well as she could.
<!-- /EN:AW-09-007 -->

> アリスは、こんなにくっついているのは、あまり好きではなかった。第一に、公爵夫人は*たいそう*醜かったし、第二に、ちょうどアリスの肩に顎をのせられる背丈で、しかもその顎が、痛いくらいとがっていたからだ。それでも失礼なことはしたくなかったので、できるだけ我慢した。

<a id="AW-09-008"></a>

**AW-09-008**

<!-- EN:AW-09-008 -->
“The game’s going on rather better now,” she said, by way of keeping up the conversation a little.
<!-- /EN:AW-09-008 -->

> 「今は、試合もだいぶうまく進んでいますね」と、少しでも会話を続けようとして言った。

<a id="AW-09-009"></a>

**AW-09-009**

<!-- EN:AW-09-009 -->
“’Tis so,” said the Duchess: “and the moral of that is—‘Oh, ’tis love, ’tis love, that makes the world go round!’”
<!-- /EN:AW-09-009 -->

> 「そのとおり」と公爵夫人は言った。「そして、その教訓は――『ああ、愛、愛こそが、世界を回すのです！』」

<a id="AW-09-010"></a>

**AW-09-010**

<!-- EN:AW-09-010 -->
“Somebody said,” Alice whispered, “that it’s done by everybody minding their own business!”
<!-- /EN:AW-09-010 -->

> 「誰かが言っていました」とアリスは小声で言った。「世界が回るのは、みんなが自分のことだけにかまっているからだって！」

<a id="AW-09-011"></a>

**AW-09-011**

<!-- EN:AW-09-011 -->
“Ah, well! It means much the same thing,” said the Duchess, digging her sharp little chin into Alice’s shoulder as she added, “and the moral of *that* is—‘Take care of the sense, and the sounds will take care of themselves.’”
<!-- /EN:AW-09-011 -->

> 「ああ、まあ！　ほとんど同じ意味よ」と公爵夫人は言った。小さなとがった顎をアリスの肩に食い込ませながら、付け加えた。「そして、*その*教訓は――『意味を大切にすれば、音のほうはひとりでに整う』」

<a id="AW-09-012"></a>

**AW-09-012**

<!-- EN:AW-09-012 -->
“How fond she is of finding morals in things!” Alice thought to herself.
<!-- /EN:AW-09-012 -->

> 「何でも教訓を見つけるのが、本当に好きなのね！」とアリスは心の中で思った。

<a id="AW-09-013"></a>

**AW-09-013**

<!-- EN:AW-09-013 -->
“I dare say you’re wondering why I don’t put my arm round your waist,” the Duchess said after a pause: “the reason is, that I’m doubtful about the temper of your flamingo. Shall I try the experiment?”
<!-- /EN:AW-09-013 -->

> 「どうしてわたしが、あなたの腰に腕を回さないのか、不思議に思っているでしょうね」と、公爵夫人は少し間を置いて言った。「それはね、あなたのフラミンゴがどんな気性か、わからないからなの。試してみましょうか？」

<a id="AW-09-014"></a>

**AW-09-014**

<!-- EN:AW-09-014 -->
“He might bite,” Alice cautiously replied, not feeling at all anxious to have the experiment tried.
<!-- /EN:AW-09-014 -->

> 「かみつくかもしれません」とアリスは用心深く答えた。その実験をしてもらいたいとは、少しも思わなかった。

<a id="AW-09-015"></a>

**AW-09-015**

<!-- EN:AW-09-015 -->
“Very true,” said the Duchess: “flamingoes and mustard both bite. And the moral of that is—‘Birds of a feather flock together.’”
<!-- /EN:AW-09-015 -->

> 「本当にそうね」と公爵夫人は言った。「フラミンゴもカラシも、ぴりりとかみつくもの。そして、その教訓は――『同じ羽の鳥は群れをなす』」

> **訳注：** bite は動物が「かむ」ことにも、カラシなどが舌を「ぴりっと刺激する」ことにも使う。Birds of a feather flock together は「類は友を呼ぶ」に相当するが、次の会話につながるよう鳥の比喩を残している。

<a id="AW-09-016"></a>

**AW-09-016**

<!-- EN:AW-09-016 -->
“Only mustard isn’t a bird,” Alice remarked.
<!-- /EN:AW-09-016 -->

> 「でも、カラシは鳥ではありません」とアリスは言った。

<a id="AW-09-017"></a>

**AW-09-017**

<!-- EN:AW-09-017 -->
“Right, as usual,” said the Duchess: “what a clear way you have of putting things!”
<!-- /EN:AW-09-017 -->

> 「いつものとおり、正しいわ」と公爵夫人は言った。「あなたって、何でもなんてはっきりと言えるのでしょう！」

<a id="AW-09-018"></a>

**AW-09-018**

<!-- EN:AW-09-018 -->
“It’s a mineral, I *think*,” said Alice.
<!-- /EN:AW-09-018 -->

> 「鉱物だと*思います*」とアリスは言った。

<a id="AW-09-019"></a>

**AW-09-019**

<!-- EN:AW-09-019 -->
“Of course it is,” said the Duchess, who seemed ready to agree to everything that Alice said; “there’s a large mustard-mine near here. And the moral of that is—‘The more there is of mine, the less there is of yours.’”
<!-- /EN:AW-09-019 -->

> 「もちろん、そうよ」と公爵夫人は言った。アリスの言うことなら何でも賛成するつもりらしかった。「この近くには、大きなカラシ鉱山があるわ。そして、その教訓は――『わたしのものが多いほど、あなたのものは少なくなる』」

> **訳注：** mine には「鉱山」と「私のもの」の意味がある。mustard-mine から、mine と yours の対比へ飛躍している。

<a id="AW-09-020"></a>

**AW-09-020**

<!-- EN:AW-09-020 -->
“Oh, I know!” exclaimed Alice, who had not attended to this last remark, “it’s a vegetable. It doesn’t look like one, but it is.”
<!-- /EN:AW-09-020 -->

> 「ああ、わかった！」とアリスは叫んだ。最後の言葉は聞いていなかったのだ。「植物です。そうは見えないけれど、植物なんです」

<a id="AW-09-021"></a>

**AW-09-021**

<!-- EN:AW-09-021 -->
“I quite agree with you,” said the Duchess; “and the moral of that is—‘Be what you would seem to be’—or if you’d like it put more simply—‘Never imagine yourself not to be otherwise than what it might appear to others that what you were or might have been was not otherwise than what you had been would have appeared to them to be otherwise.’”
<!-- /EN:AW-09-021 -->

> 「まったく同感だわ」と公爵夫人は言った。「そして、その教訓は――『そう見られたいと思うとおりの人であれ』――あるいは、もっと簡単に言ってほしいなら――『あなたがそうだった、あるいはそうだったかもしれないものが、それまでそうだったものとは違っていなかったということが、ほかの人たちには違うものとして見えたであろうように、その人たちには見えるかもしれないものと、あなた自身が違っていないのだなどとは、決して想像しないこと』」

> **訳注：** 「もっと簡単に」と言いながら、否定・比較・過去や仮定の表現を重ねて極端に込み入った文にしている。訳も短い格言に整理せず、その重なりを残している。

<a id="AW-09-022"></a>

**AW-09-022**

<!-- EN:AW-09-022 -->
“I think I should understand that better,” Alice said very politely, “if I had it written down: but I can’t quite follow it as you say it.”
<!-- /EN:AW-09-022 -->

> 「それは、書いたものを見せていただければ、もっとよくわかると思います」とアリスはとても丁寧に言った。「でも、お話しになるのを聞いただけでは、うまくついていけません」

<a id="AW-09-023"></a>

**AW-09-023**

<!-- EN:AW-09-023 -->
“That’s nothing to what I could say if I chose,” the Duchess replied, in a pleased tone.
<!-- /EN:AW-09-023 -->

> 「その気になって言えることに比べたら、こんなのは何でもないのよ」と公爵夫人は満足そうに答えた。

<a id="AW-09-024"></a>

**AW-09-024**

<!-- EN:AW-09-024 -->
“Pray don’t trouble yourself to say it any longer than that,” said Alice.
<!-- /EN:AW-09-024 -->

> 「どうぞ、それ以上長くおっしゃるようなお手数は、おかけにならないでください」とアリスは言った。

<a id="AW-09-025"></a>

**AW-09-025**

<!-- EN:AW-09-025 -->
“Oh, don’t talk about trouble!” said the Duchess. “I make you a present of everything I’ve said as yet.”
<!-- /EN:AW-09-025 -->

> 「まあ、手数だなんて言わないで！」と公爵夫人は言った。「今まで言ったことは、全部あなたへの贈り物にしてあげるわ」

<a id="AW-09-026"></a>

**AW-09-026**

<!-- EN:AW-09-026 -->
“A cheap sort of present!” thought Alice. “I’m glad they don’t give birthday presents like that!” But she did not venture to say it out loud.
<!-- /EN:AW-09-026 -->

> 「ずいぶん安っぽい贈り物！」とアリスは思った。「誕生日の贈り物が、あんなものでなくてよかった！」けれど、声に出して言う勇気はなかった。

<a id="AW-09-027"></a>

**AW-09-027**

<!-- EN:AW-09-027 -->
“Thinking again?” the Duchess asked, with another dig of her sharp little chin.
<!-- /EN:AW-09-027 -->

> 「また考えごと？」と公爵夫人は尋ね、小さなとがった顎をもう一度ぐいと押しつけた。

<a id="AW-09-028"></a>

**AW-09-028**

<!-- EN:AW-09-028 -->
“I’ve a right to think,” said Alice sharply, for she was beginning to feel a little worried.
<!-- /EN:AW-09-028 -->

> 「わたしには考える権利があります」とアリスはきつく言った。少しうんざりし始めていたのだ。

<a id="AW-09-029"></a>

**AW-09-029**

<!-- EN:AW-09-029 -->
“Just about as much right,” said the Duchess, “as pigs have to fly; and the m—”
<!-- /EN:AW-09-029 -->

> 「それはちょうど」と公爵夫人は言った。「ブタに空を飛ぶ権利があるくらいのものね。そして、そのきょ――」

<a id="AW-09-030"></a>

**AW-09-030**

<!-- EN:AW-09-030 -->
But here, to Alice’s great surprise, the Duchess’s voice died away, even in the middle of her favourite word ‘moral,’ and the arm that was linked into hers began to tremble. Alice looked up, and there stood the Queen in front of them, with her arms folded, frowning like a thunderstorm.
<!-- /EN:AW-09-030 -->

> ところがここで、アリスはひどく驚いた。大好きな「教訓」という言葉の途中なのに、公爵夫人の声が消え入り、からめていた腕が震え始めたのだ。アリスが見上げると、目の前に女王が立っていた。腕を組み、雷雨のような顔でにらんでいた。

<a id="AW-09-031"></a>

**AW-09-031**

<!-- EN:AW-09-031 -->
“A fine day, your Majesty!” the Duchess began in a low, weak voice.
<!-- /EN:AW-09-031 -->

> 「よいお天気ですこと、陛下！」と公爵夫人は、低く弱々しい声で言い始めた。

<a id="AW-09-032"></a>

**AW-09-032**

<!-- EN:AW-09-032 -->
“Now, I give you fair warning,” shouted the Queen, stamping on the ground as she spoke; “either you or your head must be off, and that in about half no time! Take your choice!”
<!-- /EN:AW-09-032 -->

> 「さあ、はっきり警告しておく」と女王は地面を踏み鳴らしながら叫んだ。「おまえが去るか、おまえの首が取れるか、どちらかだ。しかも、あっという間の半分のうちに！　好きなほうを選べ！」

> **訳注：** be off を、公爵夫人が「立ち去る」ことと、頭が「取れる」ことの両方に掛けている。

<a id="AW-09-033"></a>

**AW-09-033**

<!-- EN:AW-09-033 -->
The Duchess took her choice, and was gone in a moment.
<!-- /EN:AW-09-033 -->

> 公爵夫人は好きなほうを選び、一瞬のうちにいなくなった。

<a id="AW-09-034"></a>

**AW-09-034**

<!-- EN:AW-09-034 -->
“Let’s go on with the game,” the Queen said to Alice; and Alice was too much frightened to say a word, but slowly followed her back to the croquet-ground.
<!-- /EN:AW-09-034 -->

> 「試合を続けよう」と女王はアリスに言った。アリスは怖くて一言も言えず、ゆっくり後をついて、クロッケー場へ戻った。

<a id="AW-09-035"></a>

**AW-09-035**

<!-- EN:AW-09-035 -->
The other guests had taken advantage of the Queen’s absence, and were resting in the shade: however, the moment they saw her, they hurried back to the game, the Queen merely remarking that a moment’s delay would cost them their lives.
<!-- /EN:AW-09-035 -->

> ほかの招待客は、女王のいないのを幸いに、木陰で休んでいた。けれど、女王を見るとたちまち大急ぎで試合へ戻った。女王は、ほんの一瞬でも遅れたら命を失うぞ、と言うだけで済ませた。

<a id="AW-09-036"></a>

**AW-09-036**

<!-- EN:AW-09-036 -->
All the time they were playing the Queen never left off quarrelling with the other players, and shouting “Off with his head!” or “Off with her head!” Those whom she sentenced were taken into custody by the soldiers, who of course had to leave off being arches to do this, so that by the end of half an hour or so there were no arches left, and all the players, except the King, the Queen, and Alice, were in custody and under sentence of execution.
<!-- /EN:AW-09-036 -->

> 試合をしているあいだじゅう、女王はほかの競技者と言い争い、「あの男の首をはねよ！」とか「あの女の首をはねよ！」とか叫ぶのをやめなかった。死刑を言い渡された者は兵士に捕らえられ、兵士は当然、そのためにアーチをやめなくてはならなかった。だから三十分ほどたつころには、アーチは一つも残っておらず、王と女王とアリス以外の競技者はみんな拘束され、死刑の宣告を受けていた。

<a id="AW-09-037"></a>

**AW-09-037**

<!-- EN:AW-09-037 -->
Then the Queen left off, quite out of breath, and said to Alice, “Have you seen the Mock Turtle yet?”
<!-- /EN:AW-09-037 -->

> すると女王は、すっかり息を切らしてやめ、アリスに言った。「ウミガメもどきには、もう会ったか？」

<a id="AW-09-038"></a>

**AW-09-038**

<!-- EN:AW-09-038 -->
“No,” said Alice. “I don’t even know what a Mock Turtle is.”
<!-- /EN:AW-09-038 -->

> 「いいえ」とアリスは言った。「ウミガメもどきが何なのかも知りません」

<a id="AW-09-039"></a>

**AW-09-039**

<!-- EN:AW-09-039 -->
“It’s the thing Mock Turtle Soup is made from,” said the Queen.
<!-- /EN:AW-09-039 -->

> 「ウミガメスープもどきの材料になるものだ」と女王は言った。

> **訳注：** Mock Turtle Soup（ウミガメスープもどき）という料理名を、Mock Turtle（ウミガメもどき）という動物から作るスープだと読み替えている。

<a id="AW-09-040"></a>

**AW-09-040**

<!-- EN:AW-09-040 -->
“I never saw one, or heard of one,” said Alice.
<!-- /EN:AW-09-040 -->

> 「見たことも、聞いたこともありません」とアリスは言った。

<a id="AW-09-041"></a>

**AW-09-041**

<!-- EN:AW-09-041 -->
“Come on, then,” said the Queen, “and he shall tell you his history.”
<!-- /EN:AW-09-041 -->

> 「では、来るがよい」と女王は言った。「あいつに身の上話をさせよう」

<a id="AW-09-042"></a>

**AW-09-042**

<!-- EN:AW-09-042 -->
As they walked off together, Alice heard the King say in a low voice, to the company generally, “You are all pardoned.” “Come, *that’s* a good thing!” she said to herself, for she had felt quite unhappy at the number of executions the Queen had ordered.
<!-- /EN:AW-09-042 -->

> 二人が連れ立って歩き去るとき、王が一同に向かって、低い声で「みな、赦す」と言うのが聞こえた。「まあ、*それは*よかった！」とアリスはひとりごとを言った。女王があまりに多くの処刑を命じたので、すっかり気が沈んでいたのだ。

<a id="AW-09-043"></a>

**AW-09-043**

<!-- EN:AW-09-043 -->
They very soon came upon a Gryphon, lying fast asleep in the sun. (If you don’t know what a Gryphon is, look at the picture.) “Up, lazy thing!” said the Queen, “and take this young lady to see the Mock Turtle, and to hear his history. I must go back and see after some executions I have ordered;” and she walked off, leaving Alice alone with the Gryphon. Alice did not quite like the look of the creature, but on the whole she thought it would be quite as safe to stay with it as to go after that savage Queen: so she waited.
<!-- /EN:AW-09-043 -->

> まもなく二人は、日なたに横たわってぐっすり眠っているグリフォンに行き当たった。（グリフォンが何かわからなかったら、挿絵を見てほしい。）「起きろ、怠け者！」と女王は言った。「このお嬢さんをウミガメもどきに会わせて、身の上話を聞かせてやれ。わたしは戻って、命じておいた処刑をいくつか見届けねばならん」そう言って歩き去り、アリスはグリフォンと二人きりで残された。アリスはその生き物の見かけがあまり好きではなかったが、全体として考えれば、あの乱暴な女王についていくのと比べても、ここにいるほうが危ないわけではないと思った。そこで待っていた。

<a id="AW-09-044"></a>

**AW-09-044**

<!-- EN:AW-09-044 -->
The Gryphon sat up and rubbed its eyes: then it watched the Queen till she was out of sight: then it chuckled. “What fun!” said the Gryphon, half to itself, half to Alice.
<!-- /EN:AW-09-044 -->

> グリフォンは起き上がって目をこすった。それから女王の姿が見えなくなるまで見送り、そのあと、くっくっと笑った。「こりゃおかしい！」と、半分は自分に、半分はアリスに向けて言った。

<a id="AW-09-045"></a>

**AW-09-045**

<!-- EN:AW-09-045 -->
“What *is* the fun?” said Alice.
<!-- /EN:AW-09-045 -->

> 「*何が*おかしいの？」とアリスは言った。

<a id="AW-09-046"></a>

**AW-09-046**

<!-- EN:AW-09-046 -->
“Why, *she*,” said the Gryphon. “It’s all her fancy, that: they never executes nobody, you know. Come on!”
<!-- /EN:AW-09-046 -->

> 「そりゃ、*あの女王さまさ*」とグリフォンは言った。「みんな、あの方がそう思い込んでるだけさ。誰ひとり処刑なんぞされやしないんだよ。さあ、来な！」

<a id="AW-09-047"></a>

**AW-09-047**

<!-- EN:AW-09-047 -->
“Everybody says ‘come on!’ here,” thought Alice, as she went slowly after it: “I never was so ordered about in all my life, never!”
<!-- /EN:AW-09-047 -->

> 「ここでは、誰もが『来い！』と言うのね」とアリスは、ゆっくり後についていきながら思った。「生まれてから、こんなにあれこれ命令されたことはないわ。ほんとうに、一度も！」

<a id="AW-09-048"></a>

**AW-09-048**

<!-- EN:AW-09-048 -->
They had not gone far before they saw the Mock Turtle in the distance, sitting sad and lonely on a little ledge of rock, and, as they came nearer, Alice could hear him sighing as if his heart would break. She pitied him deeply. “What is his sorrow?” she asked the Gryphon, and the Gryphon answered, very nearly in the same words as before, “It’s all his fancy, that: he hasn’t got no sorrow, you know. Come on!”
<!-- /EN:AW-09-048 -->

> あまり遠くへ行かないうちに、ウミガメもどきが見えた。小さな岩の出っ張りに、悲しげに、ぽつんと座っていた。近づくにつれて、胸も張り裂けそうなため息がアリスにも聞こえてきた。アリスは心から気の毒に思った。「何がそんなに悲しいの？」とグリフォンに尋ねると、グリフォンはさっきとほとんど同じ言葉で答えた。「みんな、あいつがそう思い込んでるだけさ。悲しいことなんぞ何もないんだよ。さあ、来な！」

<a id="AW-09-049"></a>

**AW-09-049**

<!-- EN:AW-09-049 -->
So they went up to the Mock Turtle, who looked at them with large eyes full of tears, but said nothing.
<!-- /EN:AW-09-049 -->

> そこで二人はウミガメもどきのところへ近づいた。ウミガメもどきは、涙でいっぱいの大きな目で二人を見たが、何も言わなかった。

<a id="AW-09-050"></a>

**AW-09-050**

<!-- EN:AW-09-050 -->
“This here young lady,” said the Gryphon, “she wants for to know your history, she do.”
<!-- /EN:AW-09-050 -->

> 「このお嬢さんがな」とグリフォンは言った。「おまえの身の上話を知りたいんだとさ、そうなんだよ」

<a id="AW-09-051"></a>

**AW-09-051**

<!-- EN:AW-09-051 -->
“I’ll tell it her,” said the Mock Turtle in a deep, hollow tone: “sit down, both of you, and don’t speak a word till I’ve finished.”
<!-- /EN:AW-09-051 -->

> 「話してあげよう」とウミガメもどきは、深くうつろに響く声で言った。「二人とも座って、私が話し終わるまでは、一言もしゃべらないでおくれ」

<a id="AW-09-052"></a>

**AW-09-052**

<!-- EN:AW-09-052 -->
So they sat down, and nobody spoke for some minutes. Alice thought to herself, “I don’t see how he can *ever* finish, if he doesn’t begin.” But she waited patiently.
<!-- /EN:AW-09-052 -->

> そこで二人は座り、しばらく誰も口をきかなかった。アリスは心の中で思った。「始めなかったら、*いつまでたっても*終わりようがないと思うんだけれど」けれど、辛抱強く待っていた。

<a id="AW-09-053"></a>

**AW-09-053**

<!-- EN:AW-09-053 -->
“Once,” said the Mock Turtle at last, with a deep sigh, “I was a real Turtle.”
<!-- /EN:AW-09-053 -->

> 「昔は」とウミガメもどきはようやく、深いため息をついて言った。「私も本物のウミガメだった」

<a id="AW-09-054"></a>

**AW-09-054**

<!-- EN:AW-09-054 -->
These words were followed by a very long silence, broken only by an occasional exclamation of “Hjckrrh!” from the Gryphon, and the constant heavy sobbing of the Mock Turtle. Alice was very nearly getting up and saying, “Thank you, sir, for your interesting story,” but she could not help thinking there *must* be more to come, so she sat still and said nothing.
<!-- /EN:AW-09-054 -->

> その言葉のあと、たいそう長い沈黙が続いた。時々グリフォンが「ヒャックルフ！」と声を出し、ウミガメもどきが絶えず深くすすり泣くほかは、何の音もしなかった。アリスはもう少しで立ち上がり、「面白いお話を、ありがとうございました」と言うところだった。けれど、まだ続きが*あるはず*だと思わずにはいられず、何も言わずに座っていた。

<a id="AW-09-055"></a>

**AW-09-055**

<!-- EN:AW-09-055 -->
“When we were little,” the Mock Turtle went on at last, more calmly, though still sobbing a little now and then, “we went to school in the sea. The master was an old Turtle—we used to call him Tortoise—”
<!-- /EN:AW-09-055 -->

> 「小さかったころ」とウミガメもどきはようやく続けた。まだ時々少しすすり泣いていたが、前より落ち着いていた。「私たちは海の中の学校へ通っていた。先生は年を取ったウミガメでね――私たちはリクガメ先生と呼んでいた――」

<a id="AW-09-056"></a>

**AW-09-056**

<!-- EN:AW-09-056 -->
“Why did you call him Tortoise, if he wasn’t one?” Alice asked.
<!-- /EN:AW-09-056 -->

> 「リクガメではなかったのに、どうしてリクガメ先生と呼んだの？」とアリスは尋ねた。

<a id="AW-09-057"></a>

**AW-09-057**

<!-- EN:AW-09-057 -->
“We called him Tortoise because he taught us,” said the Mock Turtle angrily: “really you are very dull!”
<!-- /EN:AW-09-057 -->

> 「私たちに教えてくれたから、リクガメ先生と呼んだんだ」とウミガメもどきは怒って言った。「まったく、きみはひどく鈍いな！」

> **訳注：** Tortoise（リクガメ）と taught us（私たちに教えた）の音を近づけた言葉遊び。

<a id="AW-09-058"></a>

**AW-09-058**

<!-- EN:AW-09-058 -->
“You ought to be ashamed of yourself for asking such a simple question,” added the Gryphon; and then they both sat silent and looked at poor Alice, who felt ready to sink into the earth. At last the Gryphon said to the Mock Turtle, “Drive on, old fellow! Don’t be all day about it!” and he went on in these words:
<!-- /EN:AW-09-058 -->

> 「そんな簡単なことを聞くなんて、恥ずかしいと思わなきゃいけないよ」とグリフォンも付け加えた。それから二人は黙り込み、かわいそうなアリスを見つめた。アリスは地面にもぐり込みたい気持ちになった。やっとグリフォンがウミガメもどきに、「先を続けな、相棒！　一日じゅうかけるんじゃないぞ！」と言った。ウミガメもどきは、こう続けた。

<a id="AW-09-059"></a>

**AW-09-059**

<!-- EN:AW-09-059 -->
“Yes, we went to school in the sea, though you mayn’t believe it—”
<!-- /EN:AW-09-059 -->

> 「そう、私たちは海の中の学校へ通っていたんだ。きみは信じないかもしれないが――」

<a id="AW-09-060"></a>

**AW-09-060**

<!-- EN:AW-09-060 -->
“I never said I didn’t!” interrupted Alice.
<!-- /EN:AW-09-060 -->

> 「信じないなんて、一度も言っていないわ！」とアリスは口を挟んだ。

<a id="AW-09-061"></a>

**AW-09-061**

<!-- EN:AW-09-061 -->
“You did,” said the Mock Turtle.
<!-- /EN:AW-09-061 -->

> 「言ったよ」とウミガメもどきは言った。

<a id="AW-09-062"></a>

**AW-09-062**

<!-- EN:AW-09-062 -->
“Hold your tongue!” added the Gryphon, before Alice could speak again. The Mock Turtle went on.
<!-- /EN:AW-09-062 -->

> アリスがまた口を開くより先に、グリフォンも「黙ってな！」と付け加えた。ウミガメもどきは続けた。

<a id="AW-09-063"></a>

**AW-09-063**

<!-- EN:AW-09-063 -->
“We had the best of educations—in fact, we went to school every day—”
<!-- /EN:AW-09-063 -->

> 「私たちは、この上ない教育を受けた――実際、毎日学校へ行っていたんだから――」

<a id="AW-09-064"></a>

**AW-09-064**

<!-- EN:AW-09-064 -->
“*I’ve* been to a day-school, too,” said Alice; “you needn’t be so proud as all that.”
<!-- /EN:AW-09-064 -->

> 「*わたしだって*、昼間に通う学校へ行ったことがあるわ」とアリスは言った。「そんなに得意にならなくてもいいでしょう」

> **訳注：** every day（毎日）に対して、アリスは day-school（日中に通う学校）を持ち出している。

<a id="AW-09-065"></a>

**AW-09-065**

<!-- EN:AW-09-065 -->
“With extras?” asked the Mock Turtle a little anxiously.
<!-- /EN:AW-09-065 -->

> 「別料金のものも？」とウミガメもどきは、少し心配そうに尋ねた。

<a id="AW-09-066"></a>

**AW-09-066**

<!-- EN:AW-09-066 -->
“Yes,” said Alice, “we learned French and music.”
<!-- /EN:AW-09-066 -->

> 「ええ」とアリスは言った。「フランス語と音楽を習ったわ」

<a id="AW-09-067"></a>

**AW-09-067**

<!-- EN:AW-09-067 -->
“And washing?” said the Mock Turtle.
<!-- /EN:AW-09-067 -->

> 「洗濯も？」とウミガメもどきは言った。

<a id="AW-09-068"></a>

**AW-09-068**

<!-- EN:AW-09-068 -->
“Certainly not!” said Alice indignantly.
<!-- /EN:AW-09-068 -->

> 「もちろん、そんなものは習っていないわ！」とアリスは憤慨して言った。

<a id="AW-09-069"></a>

**AW-09-069**

<!-- EN:AW-09-069 -->
“Ah! then yours wasn’t a really good school,” said the Mock Turtle in a tone of great relief. “Now at *ours* they had at the end of the bill, ‘French, music, *and washing*—extra.’”
<!-- /EN:AW-09-069 -->

> 「ああ！　では、きみのは本当によい学校ではなかったんだね」とウミガメもどきは、すっかり安心した声で言った。「なにしろ、*私たちの*学校では請求書のいちばん下に、『フランス語、音楽、*および洗濯*――別料金』とあったんだ」

> **訳注：** extras は別料金の項目。フランス語・音楽の授業料と洗濯代をひとまとめにし、洗濯まで習う科目のように話している。

<a id="AW-09-070"></a>

**AW-09-070**

<!-- EN:AW-09-070 -->
“You couldn’t have wanted it much,” said Alice; “living at the bottom of the sea.”
<!-- /EN:AW-09-070 -->

> 「あまり必要ではなかったはずでしょう」とアリスは言った。「海の底に住んでいたのなら」

<a id="AW-09-071"></a>

**AW-09-071**

<!-- EN:AW-09-071 -->
“I couldn’t afford to learn it.” said the Mock Turtle with a sigh. “I only took the regular course.”
<!-- /EN:AW-09-071 -->

> 「習うだけのお金はなかった」とウミガメもどきはため息をついた。「普通の課程しか受けなかったんだ」

<a id="AW-09-072"></a>

**AW-09-072**

<!-- EN:AW-09-072 -->
“What was that?” inquired Alice.
<!-- /EN:AW-09-072 -->

> 「それは、どんなものだったの？」とアリスは尋ねた。

<a id="AW-09-073"></a>

**AW-09-073**

<!-- EN:AW-09-073 -->
“Reeling and Writhing, of course, to begin with,” the Mock Turtle replied; “and then the different branches of Arithmetic—Ambition, Distraction, Uglification, and Derision.”
<!-- /EN:AW-09-073 -->

> 「もちろん、まずは『よろめき』と『のたうち』さ」とウミガメもどきは答えた。「それから算術のいろいろな分野――『野心』『注意散漫』『醜化』『嘲笑』だ」

> **訳注：** Reeling／Writhing は Reading／Writing（読み／書き）を、Ambition／Distraction／Uglification／Derision は Addition／Subtraction／Multiplication／Division（加法／減法／乗法／除法）をもじった科目名。訳文では、もじったあとの語の意味を示している。

<a id="AW-09-074"></a>

**AW-09-074**

<!-- EN:AW-09-074 -->
“I never heard of ‘Uglification,’” Alice ventured to say. “What is it?”
<!-- /EN:AW-09-074 -->

> 「『醜化』なんて、聞いたことがないわ」とアリスは思い切って言った。「何なの？」

<a id="AW-09-075"></a>

**AW-09-075**

<!-- EN:AW-09-075 -->
The Gryphon lifted up both its paws in surprise. “What! Never heard of uglifying!” it exclaimed. “You know what to beautify is, I suppose?”
<!-- /EN:AW-09-075 -->

> グリフォンは驚いて、両方の前足を上げた。「何だって！　醜くすることを、聞いたこともないのか！」と叫んだ。「美しくする、なら、どういうことかわかるだろう？」

<a id="AW-09-076"></a>

**AW-09-076**

<!-- EN:AW-09-076 -->
“Yes,” said Alice doubtfully: “it means—to—make—anything—prettier.”
<!-- /EN:AW-09-076 -->

> 「ええ」とアリスは自信なさそうに言った。「それは――何かを――もっと――きれいに――することよ」

<a id="AW-09-077"></a>

**AW-09-077**

<!-- EN:AW-09-077 -->
“Well, then,” the Gryphon went on, “if you don’t know what to uglify is, you *are* a simpleton.”
<!-- /EN:AW-09-077 -->

> 「それなら」とグリフォンは続けた。「醜くすることがわからないなんて、きみは*本物の*おばかさんだ」

<a id="AW-09-078"></a>

**AW-09-078**

<!-- EN:AW-09-078 -->
Alice did not feel encouraged to ask any more questions about it, so she turned to the Mock Turtle, and said “What else had you to learn?”
<!-- /EN:AW-09-078 -->

> それ以上、そのことを質問する気にはなれなかったので、アリスはウミガメもどきに向き直って言った。「ほかには何を習わなくてはいけなかったの？」

<a id="AW-09-079"></a>

**AW-09-079**

<!-- EN:AW-09-079 -->
“Well, there was Mystery,” the Mock Turtle replied, counting off the subjects on his flappers, “—Mystery, ancient and modern, with Seaography: then Drawling—the Drawling-master was an old conger-eel, that used to come once a week: *he* taught us Drawling, Stretching, and Fainting in Coils.”
<!-- /EN:AW-09-079 -->

> 「そうだな、『謎』があった」とウミガメもどきは、ひれで科目を数えながら答えた。「――古代と近代の『謎』、それに『海理学』。次は『だらだらしゃべり』――その先生は年取ったアナゴで、週に一度来ていた。*その先生が*、『だらだらしゃべり』『引き伸ばし』それから『とぐろを巻いて気絶すること』を教えてくれたんだ」

> **訳注：** Mystery／Seaography は History／Geography（歴史／地理）、Drawling／Stretching／Fainting in Coils は Drawing／Sketching／Painting in Oils（絵画／スケッチ／油絵）をもじっている。Seaography は sea（海）を含む造語として「海理学」とした。

<a id="AW-09-080"></a>

**AW-09-080**

<!-- EN:AW-09-080 -->
“What was *that* like?” said Alice.
<!-- /EN:AW-09-080 -->

> 「*それは*どんなふうにするの？」とアリスは言った。

<a id="AW-09-081"></a>

**AW-09-081**

<!-- EN:AW-09-081 -->
“Well, I can’t show it you myself,” the Mock Turtle said: “I’m too stiff. And the Gryphon never learnt it.”
<!-- /EN:AW-09-081 -->

> 「いや、私には実演してみせられない」とウミガメもどきは言った。「体が硬すぎるからね。それに、グリフォンは習ったことがないんだ」

<a id="AW-09-082"></a>

**AW-09-082**

<!-- EN:AW-09-082 -->
“Hadn’t time,” said the Gryphon: “I went to the Classics master, though. He was an old crab, *he* was.”
<!-- /EN:AW-09-082 -->

> 「時間がなかった」とグリフォンは言った。「けれど、古典の先生には習ったぞ。あれは年取ったカニだった、*あの先生は*」

<a id="AW-09-083"></a>

**AW-09-083**

<!-- EN:AW-09-083 -->
“I never went to him,” the Mock Turtle said with a sigh: “he taught Laughing and Grief, they used to say.”
<!-- /EN:AW-09-083 -->

> 「私はその先生には習わなかった」とウミガメもどきはため息をついた。「『笑い』と『悲嘆』を教えていたと、みんな言っていたな」

> **訳注：** Laughing／Grief は Latin／Greek（ラテン語／ギリシャ語）をもじった科目名。

<a id="AW-09-084"></a>

**AW-09-084**

<!-- EN:AW-09-084 -->
“So he did, so he did,” said the Gryphon, sighing in his turn; and both creatures hid their faces in their paws.
<!-- /EN:AW-09-084 -->

> 「そうだった、そうだった」と、今度はグリフォンがため息をついて言った。二人とも、前足で顔を覆った。

<a id="AW-09-085"></a>

**AW-09-085**

<!-- EN:AW-09-085 -->
“And how many hours a day did you do lessons?” said Alice, in a hurry to change the subject.
<!-- /EN:AW-09-085 -->

> 「それで、一日に何時間授業があったの？」とアリスは、急いで話題を変えようとして言った。

<a id="AW-09-086"></a>

**AW-09-086**

<!-- EN:AW-09-086 -->
“Ten hours the first day,” said the Mock Turtle: “nine the next, and so on.”
<!-- /EN:AW-09-086 -->

> 「最初の日は十時間」とウミガメもどきは言った。「次の日は九時間、その先も同じ調子でね」

<a id="AW-09-087"></a>

**AW-09-087**

<!-- EN:AW-09-087 -->
“What a curious plan!” exclaimed Alice.
<!-- /EN:AW-09-087 -->

> 「なんて変わった計画なの！」とアリスは叫んだ。

<a id="AW-09-088"></a>

**AW-09-088**

<!-- EN:AW-09-088 -->
“That’s the reason they’re called lessons,” the Gryphon remarked: “because they lessen from day to day.”
<!-- /EN:AW-09-088 -->

> 「だからレッスンというんだよ」とグリフォンは言った。「日ごとに減っていくからね」

> **訳注：** lessons（授業）と lessen（減る）の音を掛けている。

<a id="AW-09-089"></a>

**AW-09-089**

<!-- EN:AW-09-089 -->
This was quite a new idea to Alice, and she thought it over a little before she made her next remark. “Then the eleventh day must have been a holiday?”
<!-- /EN:AW-09-089 -->

> アリスには、まったく新しい考えだった。少し考えてから、次の質問をした。「それなら、十一日目はお休みだったはずね？」

<a id="AW-09-090"></a>

**AW-09-090**

<!-- EN:AW-09-090 -->
“Of course it was,” said the Mock Turtle.
<!-- /EN:AW-09-090 -->

> 「もちろん、そうだった」とウミガメもどきは言った。

<a id="AW-09-091"></a>

**AW-09-091**

<!-- EN:AW-09-091 -->
“And how did you manage on the twelfth?” Alice went on eagerly.
<!-- /EN:AW-09-091 -->

> 「じゃあ、十二日目はどうしていたの？」とアリスは熱心に続けた。

<a id="AW-09-092"></a>

**AW-09-092**

<!-- EN:AW-09-092 -->
“That’s enough about lessons,” the Gryphon interrupted in a very decided tone: “tell her something about the games now.”
<!-- /EN:AW-09-092 -->

> 「授業の話はもう十分」とグリフォンが、たいそうきっぱりした口調で遮った。「今度は遊びの話をしてやりな」

[章目次へ戻る](#book-top)

---

<a id="aw-chapter-10"></a>

## 第10章　ロブスターのカドリール

### CHAPTER X. The Lobster Quadrille

<a id="AW-10-001"></a>

**AW-10-001**

<!-- EN:AW-10-001 -->
The Mock Turtle sighed deeply, and drew the back of one flapper across his eyes. He looked at Alice, and tried to speak, but for a minute or two sobs choked his voice. “Same as if he had a bone in his throat,” said the Gryphon: and it set to work shaking him and punching him in the back. At last the Mock Turtle recovered his voice, and, with tears running down his cheeks, he went on again:—
<!-- /EN:AW-10-001 -->

> ウミガメもどきは深いため息をつき、片方のひれの裏で目をぬぐった。アリスを見て話そうとしたが、一、二分は嗚咽が喉につかえて声が出なかった。「まるで喉に骨が刺さってるみたいだ」とグリフォンは言い、体を揺さぶり、背中をどんどんたたき始めた。やっとウミガメもどきは声を取り戻し、頬に涙を流しながら、また話し始めた。

<a id="AW-10-002"></a>

**AW-10-002**

<!-- EN:AW-10-002 -->
“You may not have lived much under the sea—” (“I haven’t,” said Alice)—“and perhaps you were never even introduced to a lobster—” (Alice began to say “I once tasted—” but checked herself hastily, and said “No, never”) “—so you can have no idea what a delightful thing a Lobster Quadrille is!”
<!-- /EN:AW-10-002 -->

> 「きみは、海の底にあまり長く住んだことがないかもしれない――」（「ないわ」とアリスは言った。）「――それに、ロブスターに紹介されたことさえ、一度もないのかもしれない――」（アリスは「一度、味わった――」と言いかけたが、慌てて言葉を止め、「ええ、一度も」と言った。）「――それなら、ロブスターのカドリールがどれほど楽しいものか、想像もつかないだろうね！」

<a id="AW-10-003"></a>

**AW-10-003**

<!-- EN:AW-10-003 -->
“No, indeed,” said Alice. “What sort of a dance is it?”
<!-- /EN:AW-10-003 -->

> 「ええ、本当に」とアリスは言った。「どんな踊りなの？」

<a id="AW-10-004"></a>

**AW-10-004**

<!-- EN:AW-10-004 -->
“Why,” said the Gryphon, “you first form into a line along the sea-shore—”
<!-- /EN:AW-10-004 -->

> 「それはだな」とグリフォンは言った。「まず、海辺に沿って一列に並ぶ――」

<a id="AW-10-005"></a>

**AW-10-005**

<!-- EN:AW-10-005 -->
“Two lines!” cried the Mock Turtle. “Seals, turtles, salmon, and so on; then, when you’ve cleared all the jelly-fish out of the way—”
<!-- /EN:AW-10-005 -->

> 「二列だ！」とウミガメもどきは叫んだ。「アザラシや、ウミガメや、サケや、そんな連中がね。それから、クラゲをみんな邪魔にならないところへどけたら――」

<a id="AW-10-006"></a>

**AW-10-006**

<!-- EN:AW-10-006 -->
“*That* generally takes some time,” interrupted the Gryphon.
<!-- /EN:AW-10-006 -->

> 「*それには*、たいてい少し時間がかかる」とグリフォンが口を挟んだ。

<a id="AW-10-007"></a>

**AW-10-007**

<!-- EN:AW-10-007 -->
“—you advance twice—”
<!-- /EN:AW-10-007 -->

> 「――二度、前へ進む――」

<a id="AW-10-008"></a>

**AW-10-008**

<!-- EN:AW-10-008 -->
“Each with a lobster as a partner!” cried the Gryphon.
<!-- /EN:AW-10-008 -->

> 「一人ずつ、ロブスターを相手にしてな！」とグリフォンは叫んだ。

<a id="AW-10-009"></a>

**AW-10-009**

<!-- EN:AW-10-009 -->
“Of course,” the Mock Turtle said: “advance twice, set to partners—”
<!-- /EN:AW-10-009 -->

> 「もちろん」とウミガメもどきは言った。「二度前へ進んで、相手と向き合ってステップを踏み――」

<a id="AW-10-010"></a>

**AW-10-010**

<!-- EN:AW-10-010 -->
“—change lobsters, and retire in same order,” continued the Gryphon.
<!-- /EN:AW-10-010 -->

> 「――ロブスターを取り替え、同じ並びで後ろへ下がる」とグリフォンは続けた。

<a id="AW-10-011"></a>

**AW-10-011**

<!-- EN:AW-10-011 -->
“Then, you know,” the Mock Turtle went on, “you throw the—”
<!-- /EN:AW-10-011 -->

> 「それからね」とウミガメもどきは続けた。「投げるんだ、その――」

<a id="AW-10-012"></a>

**AW-10-012**

<!-- EN:AW-10-012 -->
“The lobsters!” shouted the Gryphon, with a bound into the air.
<!-- /EN:AW-10-012 -->

> 「ロブスターを！」とグリフォンは、空中へ跳び上がりながら叫んだ。

<a id="AW-10-013"></a>

**AW-10-013**

<!-- EN:AW-10-013 -->
“—as far out to sea as you can—”
<!-- /EN:AW-10-013 -->

> 「――できるかぎり遠く、海の沖へ――」

<a id="AW-10-014"></a>

**AW-10-014**

<!-- EN:AW-10-014 -->
“Swim after them!” screamed the Gryphon.
<!-- /EN:AW-10-014 -->

> 「泳いで追いかける！」とグリフォンは金切り声を上げた。

<a id="AW-10-015"></a>

**AW-10-015**

<!-- EN:AW-10-015 -->
“Turn a somersault in the sea!” cried the Mock Turtle, capering wildly about.
<!-- /EN:AW-10-015 -->

> 「海の中で、とんぼ返りをする！」とウミガメもどきは、めちゃくちゃに跳ね回りながら叫んだ。

<a id="AW-10-016"></a>

**AW-10-016**

<!-- EN:AW-10-016 -->
“Change lobsters again!” yelled the Gryphon at the top of its voice.
<!-- /EN:AW-10-016 -->

> 「もう一度、ロブスターを取り替える！」とグリフォンは声のかぎりに叫んだ。

<a id="AW-10-017"></a>

**AW-10-017**

<!-- EN:AW-10-017 -->
“Back to land again, and that’s all the first figure,” said the Mock Turtle, suddenly dropping his voice; and the two creatures, who had been jumping about like mad things all this time, sat down again very sadly and quietly, and looked at Alice.
<!-- /EN:AW-10-017 -->

> 「また陸へ戻って、それで最初の型はおしまい」とウミガメもどきは、急に声を落として言った。それまで狂ったように跳ね回っていた二人は、また、たいそう悲しそうに静かに腰を下ろし、アリスを見た。

<a id="AW-10-018"></a>

**AW-10-018**

<!-- EN:AW-10-018 -->
“It must be a very pretty dance,” said Alice timidly.
<!-- /EN:AW-10-018 -->

> 「とてもきれいな踊りなんでしょうね」とアリスはおずおずと言った。

<a id="AW-10-019"></a>

**AW-10-019**

<!-- EN:AW-10-019 -->
“Would you like to see a little of it?” said the Mock Turtle.
<!-- /EN:AW-10-019 -->

> 「少し見てみたいかい？」とウミガメもどきは言った。

<a id="AW-10-020"></a>

**AW-10-020**

<!-- EN:AW-10-020 -->
“Very much indeed,” said Alice.
<!-- /EN:AW-10-020 -->

> 「ええ、とても」とアリスは言った。

<a id="AW-10-021"></a>

**AW-10-021**

<!-- EN:AW-10-021 -->
“Come, let’s try the first figure!” said the Mock Turtle to the Gryphon. “We can do without lobsters, you know. Which shall sing?”
<!-- /EN:AW-10-021 -->

> 「さあ、最初の型をやってみよう！」とウミガメもどきはグリフォンに言った。「ロブスターはいなくてもできるさ。どっちが歌おうか？」

<a id="AW-10-022"></a>

**AW-10-022**

<!-- EN:AW-10-022 -->
“Oh, *you* sing,” said the Gryphon. “I’ve forgotten the words.”
<!-- /EN:AW-10-022 -->

> 「ああ、*おまえが*歌いな」とグリフォンは言った。「歌詞を忘れちまった」

<a id="AW-10-023"></a>

**AW-10-023**

<!-- EN:AW-10-023 -->
So they began solemnly dancing round and round Alice, every now and then treading on her toes when they passed too close, and waving their forepaws to mark the time, while the Mock Turtle sang this, very slowly and sadly:—
<!-- /EN:AW-10-023 -->

> そこで二人は、おごそかにアリスのまわりをぐるぐる踊り始めた。近づきすぎるたびに時々アリスのつま先を踏み、前足を振って拍子をとっていた。そのあいだウミガメもどきは、とてもゆっくりと悲しげに、こう歌った。

<a id="AW-10-024"></a>

**AW-10-024**

<!-- EN:AW-10-024 -->
“Will you walk a little faster?” said a whiting to a snail.  
“There’s a porpoise close behind us, and he’s treading on my tail.  
See how eagerly the lobsters and the turtles all advance!  
They are waiting on the shingle—will you come and join the dance?  
Will you, won’t you, will you, won’t you, will you join the dance?  
Will you, won’t you, will you, won’t you, won’t you join the dance?  
<!-- /EN:AW-10-024 -->

> 「もう少し早く歩いてくれない？」とホワイティングがカタツムリに言った。  
> 「すぐ後ろにネズミイルカがいて、ぼくの尻尾を踏んでいる。  
> 見て、ロブスターもウミガメも、なんて熱心に前へ進むこと！  
> みんな小石の浜で待っている――きみも来て、踊りに加わらない？  
> 踊る？　踊らぬ？　踊る？　踊らぬ？　踊りに加わる？  
> 踊る？　踊らぬ？　踊る？　踊らぬ？　踊りに加わらない？

> **訳注：** whiting は魚の名。後の whiting／blacking の言葉遊びに対応させるため、「ホワイティング」と表記する。

<a id="AW-10-025"></a>

**AW-10-025**

<!-- EN:AW-10-025 -->
“You can really have no notion how delightful it will be  
When they take us up and throw us, with the lobsters, out to sea!”  
But the snail replied “Too far, too far!” and gave a look askance—  
Said he thanked the whiting kindly, but he would not join the dance.  
Would not, could not, would not, could not, would not join the dance.  
Would not, could not, would not, could not, could not join the dance.  
<!-- /EN:AW-10-025 -->

> 「どんなに楽しいか、きみには本当に想像もつかないよ、  
> みんながぼくらを持ち上げて、ロブスターと一緒に海へ投げるとき！」  
> でもカタツムリは「遠すぎる、遠すぎる！」と答え、横目を向けた――  
> ホワイティングに丁寧にお礼を言ったが、踊りには加わらないと言った。  
> 踊らぬ、踊れぬ、踊らぬ、踊れぬ、踊りには加わらぬ。  
> 踊らぬ、踊れぬ、踊らぬ、踊れぬ、踊りには加われぬ。

<a id="AW-10-026"></a>

**AW-10-026**

<!-- EN:AW-10-026 -->
“What matters it how far we go?” his scaly friend replied.  
“There is another shore, you know, upon the other side.  
The further off from England the nearer is to France—  
Then turn not pale, beloved snail, but come and join the dance.  
Will you, won’t you, will you, won’t you, will you join the dance?  
Will you, won’t you, will you, won’t you, won’t you join the dance?”
<!-- /EN:AW-10-026 -->

> 「どれほど遠くへ行こうと、かまわないじゃないか」とウロコのある友だちは答えた。  
> 「向こう側にも、別の岸があるんだよ。  
> イングランドから遠ざかるほど、フランスには近くなる――  
> だから青くならないで、いとしいカタツムリ、来て踊りに加わって。  
> 踊る？　踊らぬ？　踊る？　踊らぬ？　踊りに加わる？  
> 踊る？　踊らぬ？　踊る？　踊らぬ？　踊りに加わらない？」

<a id="AW-10-027"></a>

**AW-10-027**

<!-- EN:AW-10-027 -->
“Thank you, it’s a very interesting dance to watch,” said Alice, feeling very glad that it was over at last: “and I do so like that curious song about the whiting!”
<!-- /EN:AW-10-027 -->

> 「ありがとう。見ていて、とても面白い踊りね」とアリスは言った。ようやく終わったのが、とてもうれしかった。「それに、あのホワイティングの不思議な歌も、すごく好きだわ！」

<a id="AW-10-028"></a>

**AW-10-028**

<!-- EN:AW-10-028 -->
“Oh, as to the whiting,” said the Mock Turtle, “they—you’ve seen them, of course?”
<!-- /EN:AW-10-028 -->

> 「ああ、ホワイティングといえば」とウミガメもどきは言った。「あれは――もちろん、見たことがあるね？」

<a id="AW-10-029"></a>

**AW-10-029**

<!-- EN:AW-10-029 -->
“Yes,” said Alice, “I’ve often seen them at dinn—” she checked herself hastily.
<!-- /EN:AW-10-029 -->

> 「ええ」とアリスは言った。「よく見たわ、ディン――で」慌てて言葉を止めた。

> **訳注：** 原文では dinner（食事）と言いかけて dinn— で止めている。次の台詞では、それが Dinn という地名のように扱われるため、途切れた音を「ディン」と残した。

<a id="AW-10-030"></a>

**AW-10-030**

<!-- EN:AW-10-030 -->
“I don’t know where Dinn may be,” said the Mock Turtle, “but if you’ve seen them so often, of course you know what they’re like.”
<!-- /EN:AW-10-030 -->

> 「ディンがどこにあるかは知らないが」とウミガメもどきは言った。「そんなによく見たのなら、もちろん、どんな姿かは知っているね」

<a id="AW-10-031"></a>

**AW-10-031**

<!-- EN:AW-10-031 -->
“I believe so,” Alice replied thoughtfully. “They have their tails in their mouths—and they’re all over crumbs.”
<!-- /EN:AW-10-031 -->

> 「そう思うわ」とアリスは考えながら答えた。「口に尻尾をくわえていて――それから、全身にパン粉がついているの」

<a id="AW-10-032"></a>

**AW-10-032**

<!-- EN:AW-10-032 -->
“You’re wrong about the crumbs,” said the Mock Turtle: “crumbs would all wash off in the sea. But they *have* their tails in their mouths; and the reason is—” here the Mock Turtle yawned and shut his eyes.—“Tell her about the reason and all that,” he said to the Gryphon.
<!-- /EN:AW-10-032 -->

> 「パン粉のところは間違っている」とウミガメもどきは言った。「海の中では、すっかり洗い流されてしまうだろう。けれど、口に尻尾は*くわえている*。そのわけは――」ここでウミガメもどきはあくびをして、目を閉じた。「わけやら何やらを話してやってくれ」とグリフォンに言った。

<a id="AW-10-033"></a>

**AW-10-033**

<!-- EN:AW-10-033 -->
“The reason is,” said the Gryphon, “that they *would* go with the lobsters to the dance. So they got thrown out to sea. So they had to fall a long way. So they got their tails fast in their mouths. So they couldn’t get them out again. That’s all.”
<!-- /EN:AW-10-033 -->

> 「わけというのは」とグリフォンは言った。「どうしてもロブスターと一緒に踊りに行くと*言い張った*からさ。それで海の沖へ投げられた。それで、長い距離を落ちなくちゃならなかった。それで、尻尾が口にしっかりはまってしまった。それで、もう抜けなくなった。それだけだ」

<a id="AW-10-034"></a>

**AW-10-034**

<!-- EN:AW-10-034 -->
“Thank you,” said Alice, “it’s very interesting. I never knew so much about a whiting before.”
<!-- /EN:AW-10-034 -->

> 「ありがとう」とアリスは言った。「とても面白いわ。ホワイティングについて、こんなにたくさん知ったのは初めてよ」

<a id="AW-10-035"></a>

**AW-10-035**

<!-- EN:AW-10-035 -->
“I can tell you more than that, if you like,” said the Gryphon. “Do you know why it’s called a whiting?”
<!-- /EN:AW-10-035 -->

> 「よければ、もっと教えてやれるぞ」とグリフォンは言った。「どうしてホワイティングと呼ばれるか、知っているかい？」

<a id="AW-10-036"></a>

**AW-10-036**

<!-- EN:AW-10-036 -->
“I never thought about it,” said Alice. “Why?”
<!-- /EN:AW-10-036 -->

> 「考えたこともなかったわ」とアリスは言った。「どうして？」

<a id="AW-10-037"></a>

**AW-10-037**

<!-- EN:AW-10-037 -->
“*It does the boots and shoes*,” the Gryphon replied very solemnly.
<!-- /EN:AW-10-037 -->

> 「*長靴や短靴を磨くからさ*」とグリフォンは、たいそうおごそかに答えた。

<a id="AW-10-038"></a>

**AW-10-038**

<!-- EN:AW-10-038 -->
Alice was thoroughly puzzled. “Does the boots and shoes!” she repeated in a wondering tone.
<!-- /EN:AW-10-038 -->

> アリスはすっかりわからなくなった。「長靴や短靴を磨く！」と、不思議そうな声で繰り返した。

<a id="AW-10-039"></a>

**AW-10-039**

<!-- EN:AW-10-039 -->
“Why, what are *your* shoes done with?” said the Gryphon. “I mean, what makes them so shiny?”
<!-- /EN:AW-10-039 -->

> 「じゃあ、*きみの*靴は何で磨くんだ？」とグリフォンは言った。「つまり、何でそんなにつやつやになるんだい？」

<a id="AW-10-040"></a>

**AW-10-040**

<!-- EN:AW-10-040 -->
Alice looked down at them, and considered a little before she gave her answer. “They’re done with blacking, I believe.”
<!-- /EN:AW-10-040 -->

> アリスは自分の靴を見下ろし、少し考えてから答えた。「黒い靴墨で磨くんだと思うわ」

<a id="AW-10-041"></a>

**AW-10-041**

<!-- EN:AW-10-041 -->
“Boots and shoes under the sea,” the Gryphon went on in a deep voice, “are done with a whiting. Now you know.”
<!-- /EN:AW-10-041 -->

> 「海の底の長靴や短靴は」とグリフォンは低い声で続けた。「ホワイティングで磨くのさ。これでわかっただろう」

> **訳注：** blacking は黒い靴墨。black に対して、魚名 whiting の white を連想させ、海ではそれで靴を磨くという説明にしている。

<a id="AW-10-042"></a>

**AW-10-042**

<!-- EN:AW-10-042 -->
“And what are they made of?” Alice asked in a tone of great curiosity.
<!-- /EN:AW-10-042 -->

> 「それで、靴は何でできているの？」とアリスは、たいそう興味深そうに尋ねた。

<a id="AW-10-043"></a>

**AW-10-043**

<!-- EN:AW-10-043 -->
“Soles and eels, of course,” the Gryphon replied rather impatiently: “any shrimp could have told you that.”
<!-- /EN:AW-10-043 -->

> 「もちろん、シタビラメとウナギさ」とグリフォンは少しいらいらして答えた。「そんなことは、小エビに聞いても教えてくれるよ」

> **訳注：** sole は「シタビラメ」と「靴底」。eels（ウナギ）は heels（かかと）の h を落としたような音になり、soles and heels を海の生き物に置き換えている。

<a id="AW-10-044"></a>

**AW-10-044**

<!-- EN:AW-10-044 -->
“If I’d been the whiting,” said Alice, whose thoughts were still running on the song, “I’d have said to the porpoise, ‘Keep back, please: we don’t want *you* with us!’”
<!-- /EN:AW-10-044 -->

> 「わたしがホワイティングだったら」と、まだ歌のことを考えていたアリスは言った。「ネズミイルカに、『下がってちょうだい。*あなたには*一緒に来てもらいたくないの！』と言ったわ」

<a id="AW-10-045"></a>

**AW-10-045**

<!-- EN:AW-10-045 -->
“They were obliged to have him with them,” the Mock Turtle said: “no wise fish would go anywhere without a porpoise.”
<!-- /EN:AW-10-045 -->

> 「一緒に連れていかなくてはいけなかったんだ」とウミガメもどきは言った。「賢い魚なら、ネズミイルカなしでどこかへ行ったりはしないからね」

<a id="AW-10-046"></a>

**AW-10-046**

<!-- EN:AW-10-046 -->
“Wouldn’t it really?” said Alice in a tone of great surprise.
<!-- /EN:AW-10-046 -->

> 「本当に、行かないの？」とアリスは、とても驚いた声で言った。

<a id="AW-10-047"></a>

**AW-10-047**

<!-- EN:AW-10-047 -->
“Of course not,” said the Mock Turtle: “why, if a fish came to *me*, and told me he was going a journey, I should say ‘With what porpoise?’”
<!-- /EN:AW-10-047 -->

> 「もちろん、行かない」とウミガメもどきは言った。「たとえば、魚が*私の*ところへ来て、旅に出ると言ったら、私は『どんなネズミイルカを連れて？』と聞くだろうね」

<a id="AW-10-048"></a>

**AW-10-048**

<!-- EN:AW-10-048 -->
“Don’t you mean ‘purpose’?” said Alice.
<!-- /EN:AW-10-048 -->

> 「『どんな目的で？』ということではないの？」とアリスは言った。

> **訳注：** porpoise（ネズミイルカ）と purpose（目的）の音を掛けている。

<a id="AW-10-049"></a>

**AW-10-049**

<!-- EN:AW-10-049 -->
“I mean what I say,” the Mock Turtle replied in an offended tone. And the Gryphon added “Come, let’s hear some of *your* adventures.”
<!-- /EN:AW-10-049 -->

> 「言ったとおりの意味だよ」とウミガメもどきは、気を悪くして答えた。グリフォンが付け加えた。「さあ、今度は*きみの*冒険を少し聞かせてもらおう」

<a id="AW-10-050"></a>

**AW-10-050**

<!-- EN:AW-10-050 -->
“I could tell you my adventures—beginning from this morning,” said Alice a little timidly: “but it’s no use going back to yesterday, because I was a different person then.”
<!-- /EN:AW-10-050 -->

> 「わたしの冒険なら話せるわ――今朝からのことなら」とアリスは少しおずおずと言った。「でも、昨日までさかのぼっても仕方がないの。そのときは、わたしは別の人だったから」

<a id="AW-10-051"></a>

**AW-10-051**

<!-- EN:AW-10-051 -->
“Explain all that,” said the Mock Turtle.
<!-- /EN:AW-10-051 -->

> 「それをみんな説明しておくれ」とウミガメもどきは言った。

<a id="AW-10-052"></a>

**AW-10-052**

<!-- EN:AW-10-052 -->
“No, no! The adventures first,” said the Gryphon in an impatient tone: “explanations take such a dreadful time.”
<!-- /EN:AW-10-052 -->

> 「いや、いや！　先に冒険だ」とグリフォンはいらいらした声で言った。「説明は、ひどく時間がかかるからな」

<a id="AW-10-053"></a>

**AW-10-053**

<!-- EN:AW-10-053 -->
So Alice began telling them her adventures from the time when she first saw the White Rabbit. She was a little nervous about it just at first, the two creatures got so close to her, one on each side, and opened their eyes and mouths so *very* wide, but she gained courage as she went on. Her listeners were perfectly quiet till she got to the part about her repeating “*You are old, Father William*,” to the Caterpillar, and the words all coming different, and then the Mock Turtle drew a long breath, and said “That’s very curious.”
<!-- /EN:AW-10-053 -->

> そこでアリスは、最初に白ウサギを見たときからの冒険を話し始めた。初めのうちは、少し落ち着かなかった。二人が左右からひどく近くへ寄ってきて、目も口も*たいそう*大きく開けていたからだ。けれど、話すにつれて勇気が出てきた。聞き手の二人は、アリスがイモムシに「*お年ですね、ウィリアム父さん*」を暗唱してみせたら、言葉がすっかり違って出てきた、というところに至るまでは、まったく静かにしていた。そこでウミガメもどきが長く息を吸い込み、「それはたいそう不思議だ」と言った。

<a id="AW-10-054"></a>

**AW-10-054**

<!-- EN:AW-10-054 -->
“It’s all about as curious as it can be,” said the Gryphon.
<!-- /EN:AW-10-054 -->

> 「何もかも、これ以上ないくらい不思議だな」とグリフォンは言った。

<a id="AW-10-055"></a>

**AW-10-055**

<!-- EN:AW-10-055 -->
“It all came different!” the Mock Turtle repeated thoughtfully. “I should like to hear her try and repeat something now. Tell her to begin.” He looked at the Gryphon as if he thought it had some kind of authority over Alice.
<!-- /EN:AW-10-055 -->

> 「すっかり違って出てきた！」とウミガメもどきは、考え深げに繰り返した。「今、何か暗唱してみるのを聞きたいものだ。始めるように言っておくれ」まるでグリフォンにはアリスを従わせる何らかの権限があると思っているかのように、グリフォンを見た。

<a id="AW-10-056"></a>

**AW-10-056**

<!-- EN:AW-10-056 -->
“Stand up and repeat ‘’*Tis the voice of the sluggard*,’” said the Gryphon.
<!-- /EN:AW-10-056 -->

> 「立って、『*怠け者の声がする*』を暗唱しな」とグリフォンは言った。

<a id="AW-10-057"></a>

**AW-10-057**

<!-- EN:AW-10-057 -->
“How the creatures order one about, and make one repeat lessons!” thought Alice; “I might as well be at school at once.” However, she got up, and began to repeat it, but her head was so full of the Lobster Quadrille, that she hardly knew what she was saying, and the words came very queer indeed:—
<!-- /EN:AW-10-057 -->

> 「なんてあれこれ命令して、習ったことを暗唱させる生き物たちなの！」とアリスは思った。「これでは、学校にいるのと同じじゃない」それでも立ち上がって暗唱を始めた。けれど頭の中がロブスターのカドリールでいっぱいだったので、自分が何を言っているのかもほとんどわからず、言葉は実に奇妙なものになった。

<a id="AW-10-058"></a>

**AW-10-058**

<!-- EN:AW-10-058 -->
“’Tis the voice of the Lobster; I heard him declare,  
“You have baked me too brown, I must sugar my hair.”  
As a duck with its eyelids, so he with his nose  
Trims his belt and his buttons, and turns out his toes.”  
<!-- /EN:AW-10-058 -->

> 「ロブスターの声がする。こんな宣言を聞いた。  
> 『私をこんがり焼きすぎたね、髪に砂糖を振らなくちゃ』  
> アヒルがまぶたを使うように、彼は鼻を使い、  
> ベルトとボタンを整えて、つま先を外へ向ける」

<a id="AW-10-059"></a>

**AW-10-059**

<!-- EN:AW-10-059 -->
\[later editions continued as follows  
When the sands are all dry, he is gay as a lark,  
And will talk in contemptuous tones of the Shark,  
But, when the tide rises and sharks are around,  
His voice has a timid and tremulous sound.\]
<!-- /EN:AW-10-059 -->

> ［後の版では、次のように続く。  
> 砂浜がすっかり乾いていると、彼はヒバリのように陽気になり、  
> サメのことを、さげすむような口調で話す。  
> けれど潮が満ち、サメがあたりに現れると、  
> その声は、おずおずと震える響きになる。］

> **訳注：** この角括弧内の版に関する記述と追加の詩行も、添付原文に含まれているため訳出している。

<a id="AW-10-060"></a>

**AW-10-060**

<!-- EN:AW-10-060 -->
“That’s different from what *I* used to say when I was a child,” said the Gryphon.
<!-- /EN:AW-10-060 -->

> 「*おれが*子どものころに言っていたのとは違うな」とグリフォンは言った。

<a id="AW-10-061"></a>

**AW-10-061**

<!-- EN:AW-10-061 -->
“Well, I never heard it before,” said the Mock Turtle; “but it sounds uncommon nonsense.”
<!-- /EN:AW-10-061 -->

> 「いや、私は今まで聞いたことがない」とウミガメもどきは言った。「だが、並外れてばかげたものに聞こえるな」

<a id="AW-10-062"></a>

**AW-10-062**

<!-- EN:AW-10-062 -->
Alice said nothing; she had sat down with her face in her hands, wondering if anything would *ever* happen in a natural way again.
<!-- /EN:AW-10-062 -->

> アリスは何も言わなかった。座って両手で顔を覆い、これから先、何かがまた普通どおりに起こることなんて、*本当に*あるのかしらと思っていた。

<a id="AW-10-063"></a>

**AW-10-063**

<!-- EN:AW-10-063 -->
“I should like to have it explained,” said the Mock Turtle.
<!-- /EN:AW-10-063 -->

> 「説明してもらいたいものだ」とウミガメもどきは言った。

<a id="AW-10-064"></a>

**AW-10-064**

<!-- EN:AW-10-064 -->
“She can’t explain it,” said the Gryphon hastily. “Go on with the next verse.”
<!-- /EN:AW-10-064 -->

> 「説明はできないんだよ」とグリフォンは急いで言った。「次の節を続けな」

<a id="AW-10-065"></a>

**AW-10-065**

<!-- EN:AW-10-065 -->
“But about his toes?” the Mock Turtle persisted. “How *could* he turn them out with his nose, you know?”
<!-- /EN:AW-10-065 -->

> 「だが、あのつま先は？」とウミガメもどきは食い下がった。「どうすれば鼻で外へ向けられるというんだい？」

<a id="AW-10-066"></a>

**AW-10-066**

<!-- EN:AW-10-066 -->
“It’s the first position in dancing.” Alice said; but was dreadfully puzzled by the whole thing, and longed to change the subject.
<!-- /EN:AW-10-066 -->

> 「踊りの第一の足の位置なの」とアリスは言った。けれど、何もかもがひどくわからなくて、話題を変えたいと切に思っていた。

<a id="AW-10-067"></a>

**AW-10-067**

<!-- EN:AW-10-067 -->
“Go on with the next verse,” the Gryphon repeated impatiently: “it begins ‘*I passed by his garden*.’”
<!-- /EN:AW-10-067 -->

> 「次の節を続けな」とグリフォンは、じれったそうに繰り返した。「『*私は彼の庭のそばを通った*』で始まるんだ」

<a id="AW-10-068"></a>

**AW-10-068**

<!-- EN:AW-10-068 -->
Alice did not dare to disobey, though she felt sure it would all come wrong, and she went on in a trembling voice:—
<!-- /EN:AW-10-068 -->

> アリスは、きっとまたすっかり間違ってしまうと思ったが、逆らう勇気もなく、震える声で続けた。

<a id="AW-10-069"></a>

**AW-10-069**

<!-- EN:AW-10-069 -->
“I passed by his garden, and marked, with one eye,  
How the Owl and the Panther were sharing a pie—”  
<!-- /EN:AW-10-069 -->

> 「私は彼の庭のそばを通り、片目で見届けた、  
> フクロウとヒョウが、どうパイを分け合っていたかを――」

<a id="AW-10-070"></a>

**AW-10-070**

<!-- EN:AW-10-070 -->
\[later editions continued as follows  
The Panther took pie-crust, and gravy, and meat,  
While the Owl had the dish as its share of the treat.  
When the pie was all finished, the Owl, as a boon,  
Was kindly permitted to pocket the spoon:  
While the Panther received knife and fork with a growl,  
And concluded the banquet—\]
<!-- /EN:AW-10-070 -->

> ［後の版では、次のように続く。  
> ヒョウはパイの皮と肉汁と肉を取り、  
> フクロウには、ごちそうの取り分として皿が渡った。  
> パイがすっかりなくなると、フクロウは特別な恵みとして、  
> ありがたくも、スプーンを懐に入れることを許された。  
> 一方、ヒョウはうなりながらナイフとフォークを受け取り、  
> 宴を締めくくった――］

> **訳注：** 添付原文の角括弧内も、このダッシュで途切れている。先の詩句を別版から補ってはいない。

<a id="AW-10-071"></a>

**AW-10-071**

<!-- EN:AW-10-071 -->
“What *is* the use of repeating all that stuff,” the Mock Turtle interrupted, “if you don’t explain it as you go on? It’s by far the most confusing thing *I* ever heard!”
<!-- /EN:AW-10-071 -->

> 「話しながら説明してくれないなら、そんなものを暗唱して、*いったい*何になるんだ」とウミガメもどきが遮った。「*私が*今まで聞いた中でも、ずばぬけてわけのわからないものだ！」

<a id="AW-10-072"></a>

**AW-10-072**

<!-- EN:AW-10-072 -->
“Yes, I think you’d better leave off,” said the Gryphon: and Alice was only too glad to do so.
<!-- /EN:AW-10-072 -->

> 「そうだな、もうやめたほうがいい」とグリフォンは言った。アリスは、大喜びでそうした。

<a id="AW-10-073"></a>

**AW-10-073**

<!-- EN:AW-10-073 -->
“Shall we try another figure of the Lobster Quadrille?” the Gryphon went on. “Or would you like the Mock Turtle to sing you a song?”
<!-- /EN:AW-10-073 -->

> 「ロブスターのカドリールの、別の型をやってみようか？」とグリフォンは続けた。「それとも、ウミガメもどきに歌を歌ってもらいたいかい？」

<a id="AW-10-074"></a>

**AW-10-074**

<!-- EN:AW-10-074 -->
“Oh, a song, please, if the Mock Turtle would be so kind,” Alice replied, so eagerly that the Gryphon said, in a rather offended tone, “Hm! No accounting for tastes! Sing her ‘*Turtle Soup*,’ will you, old fellow?”
<!-- /EN:AW-10-074 -->

> 「ああ、歌をお願い。ウミガメもどきさんが歌ってくださるなら」とアリスは答えた。そのあまりの熱心さに、グリフォンは少し気を悪くした口調で言った。「ふん！　好みというのは、わからないものだ！　『*ウミガメのスープ*』を歌ってやってくれないか、相棒？」

<a id="AW-10-075"></a>

**AW-10-075**

<!-- EN:AW-10-075 -->
The Mock Turtle sighed deeply, and began, in a voice sometimes choked with sobs, to sing this:—
<!-- /EN:AW-10-075 -->

> ウミガメもどきは深いため息をつき、時々すすり泣きに詰まる声で、こう歌い始めた。

<a id="AW-10-076"></a>

**AW-10-076**

<!-- EN:AW-10-076 -->
“Beautiful Soup, so rich and green,  
Waiting in a hot tureen!  
Who for such dainties would not stoop?  
Soup of the evening, beautiful Soup!  
Soup of the evening, beautiful Soup!  
    Beau—ootiful Soo—oop!  
    Beau—ootiful Soo—oop!  
Soo—oop of the e—e—evening,  
    Beautiful, beautiful Soup!  
<!-- /EN:AW-10-076 -->

> 「美しいスープ、濃厚で緑色、  
> 熱いスープ鉢の中で待っている！  
> このごちそうに、誰が身をかがめずにいられよう？  
> 夕べのスープ、美しいスープ！  
> 夕べのスープ、美しいスープ！  
> 　　美しーーい　スーープ！  
> 　　美しーーい　スーープ！  
> 夕ーーべの　スーープ、  
> 　　美しい、美しいスープ！

<a id="AW-10-077"></a>

**AW-10-077**

<!-- EN:AW-10-077 -->
“Beautiful Soup! Who cares for fish,  
Game, or any other dish?  
Who would not give all else for two p  
ennyworth only of beautiful Soup?  
Pennyworth only of beautiful Soup?  
    Beau—ootiful Soo—oop!  
    Beau—ootiful Soo—oop!  
Soo—oop of the e—e—evening,  
    Beautiful, beauti—FUL SOUP!”
<!-- /EN:AW-10-077 -->

> 「美しいスープ！　魚なんて誰が欲しがる、  
> 狩りの獲物や、ほかの料理なんて？  
> ほかのすべてを差し出さずにいられようか、たった二ペ  
> ンス分の、美しいスープのために？  
> たった一ペンス分の、美しいスープのために？  
> 　　美しーーい　スーープ！  
> 　　美しーーい　スーープ！  
> 夕ーーべの　スーープ、  
> 　　美しい、美しーーいスープ！」

> **訳注：** 原文は two p／ennyworth のように単語の途中で改行している。訳文も「二ペ／ンス分」と行をまたがせた。次の反復行では、原文どおり pennyworth のみとなる。

<a id="AW-10-078"></a>

**AW-10-078**

<!-- EN:AW-10-078 -->
“Chorus again!” cried the Gryphon, and the Mock Turtle had just begun to repeat it, when a cry of “The trial’s beginning!” was heard in the distance.
<!-- /EN:AW-10-078 -->

> 「もう一度、繰り返しのところを！」とグリフォンは叫んだ。ウミガメもどきが繰り返し始めたちょうどそのとき、遠くから「裁判が始まるぞ！」という叫び声が聞こえた。

<a id="AW-10-079"></a>

**AW-10-079**

<!-- EN:AW-10-079 -->
“Come on!” cried the Gryphon, and, taking Alice by the hand, it hurried off, without waiting for the end of the song.
<!-- /EN:AW-10-079 -->

> 「さあ、来な！」とグリフォンは叫び、アリスの手を取ると、歌の終わりも待たずに急いで走り去った。

<a id="AW-10-080"></a>

**AW-10-080**

<!-- EN:AW-10-080 -->
“What trial is it?” Alice panted as she ran; but the Gryphon only answered “Come on!” and ran the faster, while more and more faintly came, carried on the breeze that followed them, the melancholy words:—
<!-- /EN:AW-10-080 -->

> 「何の裁判なの？」とアリスは走りながら、息を切らして尋ねた。けれどグリフォンは「さあ、来な！」と答えるだけで、ますます速く走った。二人を追うそよ風に乗って、悲しげな歌詞が、だんだんかすかになりながら届いてきた。

<a id="AW-10-081"></a>

**AW-10-081**

<!-- EN:AW-10-081 -->
“Soo—oop of the e—e—evening,  
    Beautiful, beautiful Soup!”
<!-- /EN:AW-10-081 -->

> 「夕ーーべの　スーープ、  
> 　　美しい、美しいスープ！」

[章目次へ戻る](#book-top)

---

<a id="aw-chapter-11"></a>

## 第11章　タルトを盗んだのはだれ？

### CHAPTER XI. Who Stole the Tarts?

<a id="AW-11-001"></a>

**AW-11-001**

<!-- EN:AW-11-001 -->
The King and Queen of Hearts were seated on their throne when they arrived, with a great crowd assembled about them—all sorts of little birds and beasts, as well as the whole pack of cards: the Knave was standing before them, in chains, with a soldier on each side to guard him; and near the King was the White Rabbit, with a trumpet in one hand, and a scroll of parchment in the other. In the very middle of the court was a table, with a large dish of tarts upon it: they looked so good, that it made Alice quite hungry to look at them—“I wish they’d get the trial done,” she thought, “and hand round the refreshments!” But there seemed to be no chance of this, so she began looking at everything about her, to pass away the time.
<!-- /EN:AW-11-001 -->

> 二人が着くと、ハートの王と女王は玉座に座り、そのまわりには大勢が集まっていた。いろいろな小鳥や獣に加え、トランプも一組そっくりそろっていた。ジャックは鎖につながれて王と女王の前に立ち、両側で兵士が一人ずつ見張っていた。王のそばには白ウサギがいて、片手にラッパ、もう片方に羊皮紙の巻物を持っていた。法廷の真ん中にはテーブルがあり、その上にタルトを盛った大きな皿がのっていた。とてもおいしそうで、アリスは見ただけですっかりおなかがすいてしまった。「裁判を終わらせて、おやつを配ってくれればいいのに！」と思った。けれど、その見込みはなさそうだったので、時間をつぶそうと、まわりのものをあれこれ眺め始めた。

<a id="AW-11-002"></a>

**AW-11-002**

<!-- EN:AW-11-002 -->
Alice had never been in a court of justice before, but she had read about them in books, and she was quite pleased to find that she knew the name of nearly everything there. “That’s the judge,” she said to herself, “because of his great wig.”
<!-- /EN:AW-11-002 -->

> アリスは裁判所に入ったことはなかったが、本で読んだことはあった。そこにあるものの名前がほとんどわかると知って、たいそううれしかった。「あれが裁判官ね」とひとりごとを言った。「大きなかつらをかぶっているもの」

<a id="AW-11-003"></a>

**AW-11-003**

<!-- EN:AW-11-003 -->
The judge, by the way, was the King; and as he wore his crown over the wig, (look at the frontispiece if you want to see how he did it,) he did not look at all comfortable, and it was certainly not becoming.
<!-- /EN:AW-11-003 -->

> ちなみに、裁判官は王だった。かつらの上に王冠をかぶっていたので――どうやってかぶったか見たかったら、口絵を見てほしい――少しも楽そうではなかったし、似合っていないことだけは確かだった。

<a id="AW-11-004"></a>

**AW-11-004**

<!-- EN:AW-11-004 -->
“And that’s the jury-box,” thought Alice, “and those twelve creatures,” (she was obliged to say “creatures,” you see, because some of them were animals, and some were birds,) “I suppose they are the jurors.” She said this last word two or three times over to herself, being rather proud of it: for she thought, and rightly too, that very few little girls of her age knew the meaning of it at all. However, “jury-men” would have done just as well.
<!-- /EN:AW-11-004 -->

> 「それから、あれが陪審席」とアリスは思った。「そして、あの十二の生き物が――」（「生き物」と言うしかなかったのだ。獣もいれば、鳥もいたのだから。）「たぶん、陪審員なのね」この最後の言葉は少し自慢だったので、二、三度ひとりで繰り返した。自分くらいの年の女の子で、その意味を知っている子はほとんどいない、と考えたからで、実際そのとおりだった。もっとも、「陪審をする人たち」と言っても、同じように十分だったのだけれど。

> **訳注：** 原文では jurors という語を得意がり、語り手が jury-men でもよかったと付け加える。どちらも陪審員を指す。

<a id="AW-11-005"></a>

**AW-11-005**

<!-- EN:AW-11-005 -->
The twelve jurors were all writing very busily on slates. “What are they doing?” Alice whispered to the Gryphon. “They can’t have anything to put down yet, before the trial’s begun.”
<!-- /EN:AW-11-005 -->

> 十二人の陪審員はみんな、石板にせっせと何か書いていた。「何をしているの？」とアリスはグリフォンにささやいた。「まだ裁判が始まっていないのに、書くことなんてあるはずがないわ」

<a id="AW-11-006"></a>

**AW-11-006**

<!-- EN:AW-11-006 -->
“They’re putting down their names,” the Gryphon whispered in reply, “for fear they should forget them before the end of the trial.”
<!-- /EN:AW-11-006 -->

> 「自分の名前を書いているんだ」とグリフォンはささやき返した。「裁判が終わるまでに忘れてしまわないようにな」

<a id="AW-11-007"></a>

**AW-11-007**

<!-- EN:AW-11-007 -->
“Stupid things!” Alice began in a loud, indignant voice, but she stopped hastily, for the White Rabbit cried out, “Silence in the court!” and the King put on his spectacles and looked anxiously round, to make out who was talking.
<!-- /EN:AW-11-007 -->

> 「ばかな連中！」とアリスは大きな、憤慨した声で言いかけたが、慌ててやめた。白ウサギが「法廷では静粛に！」と叫び、王が眼鏡をかけて、不安そうにあたりを見回し、誰がしゃべっているのか確かめようとしたからだ。

<a id="AW-11-008"></a>

**AW-11-008**

<!-- EN:AW-11-008 -->
Alice could see, as well as if she were looking over their shoulders, that all the jurors were writing down “stupid things!” on their slates, and she could even make out that one of them didn’t know how to spell “stupid,” and that he had to ask his neighbour to tell him. “A nice muddle their slates’ll be in before the trial’s over!” thought Alice.
<!-- /EN:AW-11-008 -->

> アリスには、陪審員たちの肩越しにのぞいているのと同じくらいはっきり、みんなが石板に「ばかな連中！」と書いているのが見えた。一人は「ばか」を意味する stupid のつづりを知らず、隣に教えてもらわなくてはならなかったことまで、わかった。「裁判が終わるころには、石板はさぞごちゃごちゃになっているでしょうね！」とアリスは思った。

<a id="AW-11-009"></a>

**AW-11-009**

<!-- EN:AW-11-009 -->
One of the jurors had a pencil that squeaked. This of course, Alice could *not* stand, and she went round the court and got behind him, and very soon found an opportunity of taking it away. She did it so quickly that the poor little juror (it was Bill, the Lizard) could not make out at all what had become of it; so, after hunting all about for it, he was obliged to write with one finger for the rest of the day; and this was of very little use, as it left no mark on the slate.
<!-- /EN:AW-11-009 -->

> 陪審員の一人は、きいきい音を立てる石筆を使っていた。これには、もちろんアリスは我慢*できなかった*。法廷をぐるりと回ってその後ろへ行き、まもなく隙を見つけて取り上げた。あまり素早かったので、気の毒な小さな陪審員――トカゲのビルだった――には、石筆がどうなったのか、まったくわからなかった。そこで、あちこち探したあと、その日の残りは指で書くしかなくなった。けれど石板に跡がつかないので、ほとんど何の役にも立たなかった。

<a id="AW-11-010"></a>

**AW-11-010**

<!-- EN:AW-11-010 -->
“Herald, read the accusation!” said the King.
<!-- /EN:AW-11-010 -->

> 「触れ役、告発状を読め！」と王は言った。

<a id="AW-11-011"></a>

**AW-11-011**

<!-- EN:AW-11-011 -->
On this the White Rabbit blew three blasts on the trumpet, and then unrolled the parchment scroll, and read as follows:—
<!-- /EN:AW-11-011 -->

> すると白ウサギはラッパを三度吹き、羊皮紙の巻物を広げて、次のように読んだ。

<a id="AW-11-012"></a>

**AW-11-012**

<!-- EN:AW-11-012 -->
“The Queen of Hearts, she made some tarts,  
    All on a summer day:  
The Knave of Hearts, he stole those tarts,  
    And took them quite away!”
<!-- /EN:AW-11-012 -->

> 「ハートの女王が、タルトを作った、  
> 　　ある夏の日のこと。  
> ハートのジャックが、そのタルトを盗み、  
> 　　すっかり持ち去った！」

<a id="AW-11-013"></a>

**AW-11-013**

<!-- EN:AW-11-013 -->
“Consider your verdict,” the King said to the jury.
<!-- /EN:AW-11-013 -->

> 「評決を考えるがよい」と王は陪審員に言った。

<a id="AW-11-014"></a>

**AW-11-014**

<!-- EN:AW-11-014 -->
“Not yet, not yet!” the Rabbit hastily interrupted. “There’s a great deal to come before that!”
<!-- /EN:AW-11-014 -->

> 「まだです、まだです！」と白ウサギは慌てて遮った。「その前に、まだずいぶんすることがございます！」

<a id="AW-11-015"></a>

**AW-11-015**

<!-- EN:AW-11-015 -->
“Call the first witness,” said the King; and the White Rabbit blew three blasts on the trumpet, and called out, “First witness!”
<!-- /EN:AW-11-015 -->

> 「最初の証人を呼べ」と王は言った。白ウサギはラッパを三度吹き、「第一の証人！」と呼ばわった。

<a id="AW-11-016"></a>

**AW-11-016**

<!-- EN:AW-11-016 -->
The first witness was the Hatter. He came in with a teacup in one hand and a piece of bread-and-butter in the other. “I beg pardon, your Majesty,” he began, “for bringing these in: but I hadn’t quite finished my tea when I was sent for.”
<!-- /EN:AW-11-016 -->

> 最初の証人は帽子屋だった。片手にティーカップ、もう片方にバターを塗ったパンを持って入ってきた。「お許しください、陛下」と話し始めた。「こんなものを持ち込んでしまいまして。ですが、呼びに来られたとき、まだお茶がすっかり済んでおりませんでしたので」

<a id="AW-11-017"></a>

**AW-11-017**

<!-- EN:AW-11-017 -->
“You ought to have finished,” said the King. “When did you begin?”
<!-- /EN:AW-11-017 -->

> 「済ませておくべきだった」と王は言った。「いつ始めたのだ？」

<a id="AW-11-018"></a>

**AW-11-018**

<!-- EN:AW-11-018 -->
The Hatter looked at the March Hare, who had followed him into the court, arm-in-arm with the Dormouse. “Fourteenth of March, I *think* it was,” he said.
<!-- /EN:AW-11-018 -->

> 帽子屋は三月ウサギを見た。三月ウサギは、ヤマネと腕を組んで、後から法廷へ入ってきていた。「三月十四日だったと*思います*」と帽子屋は言った。

<a id="AW-11-019"></a>

**AW-11-019**

<!-- EN:AW-11-019 -->
“Fifteenth,” said the March Hare.
<!-- /EN:AW-11-019 -->

> 「十五日」と三月ウサギは言った。

<a id="AW-11-020"></a>

**AW-11-020**

<!-- EN:AW-11-020 -->
“Sixteenth,” added the Dormouse.
<!-- /EN:AW-11-020 -->

> 「十六日」とヤマネが付け加えた。

<a id="AW-11-021"></a>

**AW-11-021**

<!-- EN:AW-11-021 -->
“Write that down,” the King said to the jury, and the jury eagerly wrote down all three dates on their slates, and then added them up, and reduced the answer to shillings and pence.
<!-- /EN:AW-11-021 -->

> 「書き留めよ」と王は陪審員に言った。陪審員たちは、三つの日付を全部、熱心に石板へ書き留め、それから足し合わせて、答えをシリングとペンスに換算した。

<a id="AW-11-022"></a>

**AW-11-022**

<!-- EN:AW-11-022 -->
“Take off your hat,” the King said to the Hatter.
<!-- /EN:AW-11-022 -->

> 「帽子を取れ」と王は帽子屋に言った。

<a id="AW-11-023"></a>

**AW-11-023**

<!-- EN:AW-11-023 -->
“It isn’t mine,” said the Hatter.
<!-- /EN:AW-11-023 -->

> 「私のものではございません」と帽子屋は言った。

<a id="AW-11-024"></a>

**AW-11-024**

<!-- EN:AW-11-024 -->
“*Stolen!*” the King exclaimed, turning to the jury, who instantly made a memorandum of the fact.
<!-- /EN:AW-11-024 -->

> 「*盗品だ！*」と王は、陪審員に向き直って叫んだ。陪審員はたちまち、その事実を記録した。

<a id="AW-11-025"></a>

**AW-11-025**

<!-- EN:AW-11-025 -->
“I keep them to sell,” the Hatter added as an explanation; “I’ve none of my own. I’m a hatter.”
<!-- /EN:AW-11-025 -->

> 「売り物として持っているのでございます」と帽子屋は説明を付け加えた。「自分のものは一つもありません。私は帽子屋です」

<a id="AW-11-026"></a>

**AW-11-026**

<!-- EN:AW-11-026 -->
Here the Queen put on her spectacles, and began staring at the Hatter, who turned pale and fidgeted.
<!-- /EN:AW-11-026 -->

> ここで女王が眼鏡をかけ、帽子屋をじっと見つめ始めた。帽子屋は青くなり、そわそわした。

<a id="AW-11-027"></a>

**AW-11-027**

<!-- EN:AW-11-027 -->
“Give your evidence,” said the King; “and don’t be nervous, or I’ll have you executed on the spot.”
<!-- /EN:AW-11-027 -->

> 「証言せよ」と王は言った。「それから、おどおどするな。さもないと、その場で処刑させるぞ」

<a id="AW-11-028"></a>

**AW-11-028**

<!-- EN:AW-11-028 -->
This did not seem to encourage the witness at all: he kept shifting from one foot to the other, looking uneasily at the Queen, and in his confusion he bit a large piece out of his teacup instead of the bread-and-butter.
<!-- /EN:AW-11-028 -->

> この言葉は、証人を少しも元気づけなかったようだ。帽子屋は不安そうに女王を見ながら、片足からもう片足へと体重を移し続けた。混乱のあまり、バターつきのパンの代わりに、ティーカップを大きくかじり取ってしまった。

<a id="AW-11-029"></a>

**AW-11-029**

<!-- EN:AW-11-029 -->
Just at this moment Alice felt a very curious sensation, which puzzled her a good deal until she made out what it was: she was beginning to grow larger again, and she thought at first she would get up and leave the court; but on second thoughts she decided to remain where she was as long as there was room for her.
<!-- /EN:AW-11-029 -->

> ちょうどそのとき、アリスはたいそう不思議な感覚に襲われ、それが何かわかるまでは、ずいぶん戸惑った。また体が大きくなり始めていたのだ。最初は立ち上がって法廷を出ようかと思ったが、考え直して、いる場所があるかぎり、そこにとどまることにした。

<a id="AW-11-030"></a>

**AW-11-030**

<!-- EN:AW-11-030 -->
“I wish you wouldn’t squeeze so,” said the Dormouse, who was sitting next to her. “I can hardly breathe.”
<!-- /EN:AW-11-030 -->

> 「そんなに押しつぶさないでほしいな」と、隣に座っていたヤマネは言った。「息もろくにできないよ」

<a id="AW-11-031"></a>

**AW-11-031**

<!-- EN:AW-11-031 -->
“I can’t help it,” said Alice very meekly: “I’m growing.”
<!-- /EN:AW-11-031 -->

> 「仕方がないの」とアリスは、とてもおとなしく言った。「大きくなっているんですもの」

<a id="AW-11-032"></a>

**AW-11-032**

<!-- EN:AW-11-032 -->
“You’ve no right to grow *here*,” said the Dormouse.
<!-- /EN:AW-11-032 -->

> 「*ここで*大きくなる権利はないよ」とヤマネは言った。

<a id="AW-11-033"></a>

**AW-11-033**

<!-- EN:AW-11-033 -->
“Don’t talk nonsense,” said Alice more boldly: “you know you’re growing too.”
<!-- /EN:AW-11-033 -->

> 「ばかなことを言わないで」とアリスは、前より大胆に言った。「あなたも大きくなっているでしょう」

<a id="AW-11-034"></a>

**AW-11-034**

<!-- EN:AW-11-034 -->
“Yes, but *I* grow at a reasonable pace,” said the Dormouse: “not in that ridiculous fashion.” And he got up very sulkily and crossed over to the other side of the court.
<!-- /EN:AW-11-034 -->

> 「そうさ、でも*ぼくは*まともな速さで大きくなるんだ」とヤマネは言った。「そんなばかげたやり方ではなくね」そして、ひどく不機嫌そうに立ち上がり、法廷の反対側へ渡っていった。

<a id="AW-11-035"></a>

**AW-11-035**

<!-- EN:AW-11-035 -->
All this time the Queen had never left off staring at the Hatter, and, just as the Dormouse crossed the court, she said to one of the officers of the court, “Bring me the list of the singers in the last concert!” on which the wretched Hatter trembled so, that he shook both his shoes off.
<!-- /EN:AW-11-035 -->

> このあいだじゅう、女王は帽子屋を見つめるのをやめていなかった。ヤマネが法廷を横切ったちょうどそのとき、法廷の係官の一人に、「前の音楽会で歌った者の名簿を持ってこい！」と言った。哀れな帽子屋は、それを聞くとひどく震え、両方の靴を振り落としてしまった。

<a id="AW-11-036"></a>

**AW-11-036**

<!-- EN:AW-11-036 -->
“Give your evidence,” the King repeated angrily, “or I’ll have you executed, whether you’re nervous or not.”
<!-- /EN:AW-11-036 -->

> 「証言せよ」と王は怒って繰り返した。「さもないと、おどおどしていようがいまいが、処刑させるぞ」

<a id="AW-11-037"></a>

**AW-11-037**

<!-- EN:AW-11-037 -->
“I’m a poor man, your Majesty,” the Hatter began, in a trembling voice, “—and I hadn’t begun my tea—not above a week or so—and what with the bread-and-butter getting so thin—and the twinkling of the tea—”
<!-- /EN:AW-11-037 -->

> 「私は貧しい男でございます、陛下」と帽子屋は震える声で話し始めた。「――それで、お茶を始めてまだ――一週間かそこらもたっておりませんで――バターつきのパンは、ひどく薄くなってまいりますし――お茶はきらきらいたしますし――」

<a id="AW-11-038"></a>

**AW-11-038**

<!-- EN:AW-11-038 -->
“The twinkling of the *what?*” said the King.
<!-- /EN:AW-11-038 -->

> 「*何が*きらきらするというのだ？」と王は言った。

<a id="AW-11-039"></a>

**AW-11-039**

<!-- EN:AW-11-039 -->
“It *began* with the tea,” the Hatter replied.
<!-- /EN:AW-11-039 -->

> 「お茶から*始まった*のでございます」と帽子屋は答えた。

<a id="AW-11-040"></a>

**AW-11-040**

<!-- EN:AW-11-040 -->
“Of course twinkling begins with a T!” said the King sharply. “Do you take me for a dunce? Go on!”
<!-- /EN:AW-11-040 -->

> 「twinkling が T で始まるのは当たり前だ！」と王はぴしゃりと言った。「わしをまぬけだと思っているのか？　続けろ！」

> **訳注：** tea（お茶）と文字 T は同じ発音。帽子屋の「きらきらはお茶から始まった」を、王は twinkling という語の頭文字の話だと受け取る。

<a id="AW-11-041"></a>

**AW-11-041**

<!-- EN:AW-11-041 -->
“I’m a poor man,” the Hatter went on, “and most things twinkled after that—only the March Hare said—”
<!-- /EN:AW-11-041 -->

> 「私は貧しい男でございます」と帽子屋は続けた。「それからは、たいていのものがきらきらしまして――ただ、三月ウサギがこう言って――」

<a id="AW-11-042"></a>

**AW-11-042**

<!-- EN:AW-11-042 -->
“I didn’t!” the March Hare interrupted in a great hurry.
<!-- /EN:AW-11-042 -->

> 「言っていない！」と三月ウサギは大慌てで遮った。

<a id="AW-11-043"></a>

**AW-11-043**

<!-- EN:AW-11-043 -->
“You did!” said the Hatter.
<!-- /EN:AW-11-043 -->

> 「言ったじゃないか！」と帽子屋は言った。

<a id="AW-11-044"></a>

**AW-11-044**

<!-- EN:AW-11-044 -->
“I deny it!” said the March Hare.
<!-- /EN:AW-11-044 -->

> 「否認する！」と三月ウサギは言った。

<a id="AW-11-045"></a>

**AW-11-045**

<!-- EN:AW-11-045 -->
“He denies it,” said the King: “leave out that part.”
<!-- /EN:AW-11-045 -->

> 「否認しておる」と王は言った。「その部分は省け」

<a id="AW-11-046"></a>

**AW-11-046**

<!-- EN:AW-11-046 -->
“Well, at any rate, the Dormouse said—” the Hatter went on, looking anxiously round to see if he would deny it too: but the Dormouse denied nothing, being fast asleep.
<!-- /EN:AW-11-046 -->

> 「ええ、とにかく、ヤマネがこう言いまして――」と帽子屋は続けた。ヤマネも否認するのではないかと、不安そうにあたりを見回した。けれどヤマネはぐっすり眠っていたので、何も否認しなかった。

<a id="AW-11-047"></a>

**AW-11-047**

<!-- EN:AW-11-047 -->
“After that,” continued the Hatter, “I cut some more bread-and-butter—”
<!-- /EN:AW-11-047 -->

> 「それから」と帽子屋は続けた。「私はバターつきのパンを、もう少し切りまして――」

<a id="AW-11-048"></a>

**AW-11-048**

<!-- EN:AW-11-048 -->
“But what did the Dormouse say?” one of the jury asked.
<!-- /EN:AW-11-048 -->

> 「しかし、ヤマネは何と言ったのだ？」と陪審員の一人が尋ねた。

<a id="AW-11-049"></a>

**AW-11-049**

<!-- EN:AW-11-049 -->
“That I can’t remember,” said the Hatter.
<!-- /EN:AW-11-049 -->

> 「それは思い出せません」と帽子屋は言った。

<a id="AW-11-050"></a>

**AW-11-050**

<!-- EN:AW-11-050 -->
“You *must* remember,” remarked the King, “or I’ll have you executed.”
<!-- /EN:AW-11-050 -->

> 「*必ず*思い出すのだ」と王は言った。「さもなくば処刑させるぞ」

<a id="AW-11-051"></a>

**AW-11-051**

<!-- EN:AW-11-051 -->
The miserable Hatter dropped his teacup and bread-and-butter, and went down on one knee. “I’m a poor man, your Majesty,” he began.
<!-- /EN:AW-11-051 -->

> 哀れな帽子屋は、ティーカップとバターつきのパンを取り落とし、片膝をついた。「私は貧しい男でございます、陛下」と話し始めた。

<a id="AW-11-052"></a>

**AW-11-052**

<!-- EN:AW-11-052 -->
“You’re a *very* poor *speaker*,” said the King.
<!-- /EN:AW-11-052 -->

> 「おまえは、*話し手としては**たいそう*お粗末だ」と王は言った。

> **訳注：** 帽子屋の poor man（貧しい男）を、王は poor speaker（話の下手な者）という別の意味の poor に取り替えて返している。

<a id="AW-11-053"></a>

**AW-11-053**

<!-- EN:AW-11-053 -->
Here one of the guinea-pigs cheered, and was immediately suppressed by the officers of the court. (As that is rather a hard word, I will just explain to you how it was done. They had a large canvas bag, which tied up at the mouth with strings: into this they slipped the guinea-pig, head first, and then sat upon it.)
<!-- /EN:AW-11-053 -->

> ここでモルモットの一匹が歓声を上げ、すぐに法廷の係官たちに抑え込まれた。（少し難しい言葉なので、どうやったのか説明しておこう。係官たちは、口をひもで縛れる大きな帆布の袋を持っていた。その中へモルモットを頭から滑り込ませ、それから上に座ったのだ。）

> **訳注：** suppressed は歓声などを「制止した」という意味だが、語り手は文字どおり上から押さえ込む動作として説明している。

<a id="AW-11-054"></a>

**AW-11-054**

<!-- EN:AW-11-054 -->
“I’m glad I’ve seen that done,” thought Alice. “I’ve so often read in the newspapers, at the end of trials, “There was some attempt at applause, which was immediately suppressed by the officers of the court,” and I never understood what it meant till now.”
<!-- /EN:AW-11-054 -->

> 「やり方を見ることができて、よかった」とアリスは思った。「新聞の裁判の記事の最後に、『拍手をしようとする者もいたが、ただちに法廷の係官によって抑え込まれた』と、何度も読んだことがあるけれど、今まで何のことかわからなかったんですもの」

<a id="AW-11-055"></a>

**AW-11-055**

<!-- EN:AW-11-055 -->
“If that’s all you know about it, you may stand down,” continued the King.
<!-- /EN:AW-11-055 -->

> 「知っていることがそれだけなら、証人席から下がってよろしい」と王は続けた。

<a id="AW-11-056"></a>

**AW-11-056**

<!-- EN:AW-11-056 -->
“I can’t go no lower,” said the Hatter: “I’m on the floor, as it is.”
<!-- /EN:AW-11-056 -->

> 「これ以上は下がれません」と帽子屋は言った。「もう床の上におりますから」

<a id="AW-11-057"></a>

**AW-11-057**

<!-- EN:AW-11-057 -->
“Then you may *sit* down,” the King replied.
<!-- /EN:AW-11-057 -->

> 「では、*座って*よろしい」と王は答えた。

> **訳注：** stand down は証人が「証言を終えて席を離れる」こと。帽子屋は down を低い位置へ行くことと受け取り、王は stand に対して sit を持ち出す。

<a id="AW-11-058"></a>

**AW-11-058**

<!-- EN:AW-11-058 -->
Here the other guinea-pig cheered, and was suppressed.
<!-- /EN:AW-11-058 -->

> ここで、もう一匹のモルモットが歓声を上げ、抑え込まれた。

<a id="AW-11-059"></a>

**AW-11-059**

<!-- EN:AW-11-059 -->
“Come, that finished the guinea-pigs!” thought Alice. “Now we shall get on better.”
<!-- /EN:AW-11-059 -->

> 「さあ、これでモルモットは片づいたわ！」とアリスは思った。「これからは、もっとはかどるでしょう」

<a id="AW-11-060"></a>

**AW-11-060**

<!-- EN:AW-11-060 -->
“I’d rather finish my tea,” said the Hatter, with an anxious look at the Queen, who was reading the list of singers.
<!-- /EN:AW-11-060 -->

> 「それより、お茶を済ませたいのでございます」と帽子屋は言った。歌い手の名簿を読んでいる女王を、不安そうに見ていた。

<a id="AW-11-061"></a>

**AW-11-061**

<!-- EN:AW-11-061 -->
“You may go,” said the King, and the Hatter hurriedly left the court, without even waiting to put his shoes on.
<!-- /EN:AW-11-061 -->

> 「行ってよろしい」と王は言った。帽子屋は、靴を履く暇も惜しんで、慌ただしく法廷を出ていった。

<a id="AW-11-062"></a>

**AW-11-062**

<!-- EN:AW-11-062 -->
“—and just take his head off outside,” the Queen added to one of the officers: but the Hatter was out of sight before the officer could get to the door.
<!-- /EN:AW-11-062 -->

> 「――それで、外で首をはねておけ」と女王は係官の一人に付け加えた。けれど、係官が扉までたどり着く前に、帽子屋は姿を消していた。

<a id="AW-11-063"></a>

**AW-11-063**

<!-- EN:AW-11-063 -->
“Call the next witness!” said the King.
<!-- /EN:AW-11-063 -->

> 「次の証人を呼べ！」と王は言った。

<a id="AW-11-064"></a>

**AW-11-064**

<!-- EN:AW-11-064 -->
The next witness was the Duchess’s cook. She carried the pepper-box in her hand, and Alice guessed who it was, even before she got into the court, by the way the people near the door began sneezing all at once.
<!-- /EN:AW-11-064 -->

> 次の証人は、公爵夫人の料理人だった。手にコショウ入れを持っていた。扉のそばの人たちが一斉にくしゃみをし始めたので、アリスは料理人が法廷に入る前から、それが誰かわかった。

<a id="AW-11-065"></a>

**AW-11-065**

<!-- EN:AW-11-065 -->
“Give your evidence,” said the King.
<!-- /EN:AW-11-065 -->

> 「証言せよ」と王は言った。

<a id="AW-11-066"></a>

**AW-11-066**

<!-- EN:AW-11-066 -->
“Shan’t,” said the cook.
<!-- /EN:AW-11-066 -->

> 「お断りだね」と料理人は言った。

<a id="AW-11-067"></a>

**AW-11-067**

<!-- EN:AW-11-067 -->
The King looked anxiously at the White Rabbit, who said in a low voice, “Your Majesty must cross-examine *this* witness.”
<!-- /EN:AW-11-067 -->

> 王は不安そうに白ウサギを見た。白ウサギは低い声で言った。「*この*証人には、陛下が反対尋問をなさらねばなりません」

<a id="AW-11-068"></a>

**AW-11-068**

<!-- EN:AW-11-068 -->
“Well, if I must, I must,” the King said, with a melancholy air, and, after folding his arms and frowning at the cook till his eyes were nearly out of sight, he said in a deep voice, “What are tarts made of?”
<!-- /EN:AW-11-068 -->

> 「まあ、せねばならんのなら、仕方がない」と王は憂うつそうに言った。それから腕を組み、目がほとんど見えなくなるほど眉をひそめて料理人をにらんだあと、低い声で言った。「タルトは何でできておる？」

<a id="AW-11-069"></a>

**AW-11-069**

<!-- EN:AW-11-069 -->
“Pepper, mostly,” said the cook.
<!-- /EN:AW-11-069 -->

> 「たいてい、コショウさ」と料理人は言った。

<a id="AW-11-070"></a>

**AW-11-070**

<!-- EN:AW-11-070 -->
“Treacle,” said a sleepy voice behind her.
<!-- /EN:AW-11-070 -->

> 「糖蜜だよ」と、その後ろから眠そうな声がした。

<a id="AW-11-071"></a>

**AW-11-071**

<!-- EN:AW-11-071 -->
“Collar that Dormouse,” the Queen shrieked out. “Behead that Dormouse! Turn that Dormouse out of court! Suppress him! Pinch him! Off with his whiskers!”
<!-- /EN:AW-11-071 -->

> 「あのヤマネをひっ捕らえろ！」と女王は金切り声を上げた。「あのヤマネの首をはねよ！　あのヤマネを法廷から追い出せ！　抑え込め！　つねれ！　ひげを切り落とせ！」

<a id="AW-11-072"></a>

**AW-11-072**

<!-- EN:AW-11-072 -->
For some minutes the whole court was in confusion, getting the Dormouse turned out, and, by the time they had settled down again, the cook had disappeared.
<!-- /EN:AW-11-072 -->

> しばらく法廷全体は、ヤマネを追い出すので大混乱になった。ようやくまた静まったころには、料理人は姿を消していた。

<a id="AW-11-073"></a>

**AW-11-073**

<!-- EN:AW-11-073 -->
“Never mind!” said the King, with an air of great relief. “Call the next witness.” And he added in an undertone to the Queen, “Really, my dear, *you* must cross-examine the next witness. It quite makes my forehead ache!”
<!-- /EN:AW-11-073 -->

> 「かまわん！」と王は、ひどくほっとした様子で言った。「次の証人を呼べ」それから女王に、小声で付け加えた。「本当に、おまえ、次の証人の反対尋問は*おまえが*やっておくれ。おかげで額がすっかり痛くなってしまった！」

<a id="AW-11-074"></a>

**AW-11-074**

<!-- EN:AW-11-074 -->
Alice watched the White Rabbit as he fumbled over the list, feeling very curious to see what the next witness would be like, “—for they haven’t got much evidence *yet*,” she said to herself. Imagine her surprise, when the White Rabbit read out, at the top of his shrill little voice, the name “Alice!”
<!-- /EN:AW-11-074 -->

> アリスは、白ウサギが名簿でもたもたと名前を探すのを眺めながら、次の証人はどんな者だろうと、とても知りたく思った。「――だって、*まだ*大した証拠は出ていないもの」とひとりごとを言った。白ウサギが、か細い甲高い声を精いっぱい張り上げて「アリス！」という名前を読み上げたとき、アリスがどれほど驚いたか、想像してみてほしい。

[章目次へ戻る](#book-top)

---

<a id="aw-chapter-12"></a>

## 第12章　アリスの証言

### CHAPTER XII. Alice’s Evidence

<a id="AW-12-001"></a>

**AW-12-001**

<!-- EN:AW-12-001 -->
“Here!” cried Alice, quite forgetting in the flurry of the moment how large she had grown in the last few minutes, and she jumped up in such a hurry that she tipped over the jury-box with the edge of her skirt, upsetting all the jurymen on to the heads of the crowd below, and there they lay sprawling about, reminding her very much of a globe of goldfish she had accidentally upset the week before.
<!-- /EN:AW-12-001 -->

> 「はい！」とアリスは叫んだ。その場の慌ただしさに、この数分で自分がどれほど大きくなったか、すっかり忘れていた。あまりに勢いよく立ち上がったので、スカートの端で陪審席をひっくり返し、陪審員を全員、下にいた群衆の頭の上へ放り出してしまった。みんな手足を広げて転がっていた。その様子は、先週うっかりひっくり返した、丸い金魚鉢の中の金魚を強く思い出させた。

<a id="AW-12-002"></a>

**AW-12-002**

<!-- EN:AW-12-002 -->
“Oh, I *beg* your pardon!” she exclaimed in a tone of great dismay, and began picking them up again as quickly as she could, for the accident of the goldfish kept running in her head, and she had a vague sort of idea that they must be collected at once and put back into the jury-box, or they would die.
<!-- /EN:AW-12-002 -->

> 「ああ、*本当に*ごめんなさい！」とアリスは、ひどくうろたえた声で叫び、できるかぎり急いで拾い上げ始めた。あの金魚の一件が頭から離れず、すぐに集めて陪審席へ戻さないと死んでしまう、と何となく思ったのだ。

<a id="AW-12-003"></a>

**AW-12-003**

<!-- EN:AW-12-003 -->
“The trial cannot proceed,” said the King in a very grave voice, “until all the jurymen are back in their proper places—*all*,” he repeated with great emphasis, looking hard at Alice as he said so.
<!-- /EN:AW-12-003 -->

> 「陪審員が全員、正しい場所へ戻るまでは、裁判は進められぬ」と王は、たいそう重々しい声で言った。「*全員が*」と、アリスをじっと見ながら、強く念を押した。

<a id="AW-12-004"></a>

**AW-12-004**

<!-- EN:AW-12-004 -->
Alice looked at the jury-box, and saw that, in her haste, she had put the Lizard in head downwards, and the poor little thing was waving its tail about in a melancholy way, being quite unable to move. She soon got it out again, and put it right; “not that it signifies much,” she said to herself; “I should think it would be *quite* as much use in the trial one way up as the other.”
<!-- /EN:AW-12-004 -->

> アリスが陪審席を見ると、慌てていたため、トカゲを頭から逆さに入れてしまっていた。かわいそうな小さなトカゲは、まるで動けず、悲しげに尻尾を振り回していた。アリスはすぐにまた取り出し、正しい向きに直した。「だからといって、大して違いがあるわけではないけれど」とひとりごとを言った。「どちらを上にしても、裁判の役に立つ度合いは*まったく*同じだと思うわ」

<a id="AW-12-005"></a>

**AW-12-005**

<!-- EN:AW-12-005 -->
As soon as the jury had a little recovered from the shock of being upset, and their slates and pencils had been found and handed back to them, they set to work very diligently to write out a history of the accident, all except the Lizard, who seemed too much overcome to do anything but sit with its mouth open, gazing up into the roof of the court.
<!-- /EN:AW-12-005 -->

> 陪審員たちは、ひっくり返された衝撃から少し立ち直り、石板と石筆を見つけて返してもらうと、たいそう熱心に事故のいきさつを書き始めた。ただしトカゲだけは別だった。すっかり打ちのめされてしまったらしく、口を開けて座り、法廷の天井を見上げることしかできなかった。

<a id="AW-12-006"></a>

**AW-12-006**

<!-- EN:AW-12-006 -->
“What do you know about this business?” the King said to Alice.
<!-- /EN:AW-12-006 -->

> 「この事件について何を知っておる？」と王はアリスに言った。

<a id="AW-12-007"></a>

**AW-12-007**

<!-- EN:AW-12-007 -->
“Nothing,” said Alice.
<!-- /EN:AW-12-007 -->

> 「何も」とアリスは言った。

<a id="AW-12-008"></a>

**AW-12-008**

<!-- EN:AW-12-008 -->
“Nothing *whatever?*” persisted the King.
<!-- /EN:AW-12-008 -->

> 「*まったく*何もか？」と王は重ねて尋ねた。

<a id="AW-12-009"></a>

**AW-12-009**

<!-- EN:AW-12-009 -->
“Nothing whatever,” said Alice.
<!-- /EN:AW-12-009 -->

> 「まったく何も」とアリスは言った。

<a id="AW-12-010"></a>

**AW-12-010**

<!-- EN:AW-12-010 -->
“That’s very important,” the King said, turning to the jury. They were just beginning to write this down on their slates, when the White Rabbit interrupted: “*Un*important, your Majesty means, of course,” he said in a very respectful tone, but frowning and making faces at him as he spoke.
<!-- /EN:AW-12-010 -->

> 「それはたいへん重要だ」と王は、陪審員に向き直って言った。みんなが石板へ書き留め始めたとき、白ウサギが口を挟んだ。「もちろん、陛下は重要では*ない*とおっしゃりたいのでございますね」と、たいそううやうやしい口調で言った。けれど、そう言いながら眉をひそめ、王へ向けて顔であれこれ合図をしていた。

<a id="AW-12-011"></a>

**AW-12-011**

<!-- EN:AW-12-011 -->
“*Un*important, of course, I meant,” the King hastily said, and went on to himself in an undertone,
<!-- /EN:AW-12-011 -->

> 「もちろん、重要では*ない*と言いたかったのだ」と王は慌てて言った。それから小声で、ひとりごとを続けた。

<a id="AW-12-012"></a>

**AW-12-012**

<!-- EN:AW-12-012 -->
“important—unimportant—unimportant—important—” as if he were trying which word sounded best.
<!-- /EN:AW-12-012 -->

> 「重要――重要ではない――重要ではない――重要――」まるで、どちらの言葉の響きがいちばんよいか、試しているようだった。

<a id="AW-12-013"></a>

**AW-12-013**

<!-- EN:AW-12-013 -->
Some of the jury wrote it down “important,” and some “unimportant.” Alice could see this, as she was near enough to look over their slates; “but it doesn’t matter a bit,” she thought to herself.
<!-- /EN:AW-12-013 -->

> 陪審員の中には「重要」と書く者もいれば、「重要ではない」と書く者もいた。アリスは石板をのぞき込めるほど近くにいたので、それが見えた。「でも、そんなことは少しもかまわないわ」と思った。

<a id="AW-12-014"></a>

**AW-12-014**

<!-- EN:AW-12-014 -->
At this moment the King, who had been for some time busily writing in his note-book, cackled out “Silence!” and read out from his book, “Rule Forty-two. *All persons more than a mile high to leave the court*.”
<!-- /EN:AW-12-014 -->

> そのとき、しばらく前から手帳にせっせと何かを書いていた王が、甲高い声で「静粛に！」と叫び、手帳から読み上げた。「規則第四十二条。*身長が一マイルを超える者は、全員、法廷から退去すること*」

<a id="AW-12-015"></a>

**AW-12-015**

<!-- EN:AW-12-015 -->
Everybody looked at Alice.
<!-- /EN:AW-12-015 -->

> みんながアリスを見た。

<a id="AW-12-016"></a>

**AW-12-016**

<!-- EN:AW-12-016 -->
“*I’m* not a mile high,” said Alice.
<!-- /EN:AW-12-016 -->

> 「*わたしは*、一マイルもありません」とアリスは言った。

<a id="AW-12-017"></a>

**AW-12-017**

<!-- EN:AW-12-017 -->
“You are,” said the King.
<!-- /EN:AW-12-017 -->

> 「ある」と王は言った。

<a id="AW-12-018"></a>

**AW-12-018**

<!-- EN:AW-12-018 -->
“Nearly two miles high,” added the Queen.
<!-- /EN:AW-12-018 -->

> 「二マイル近くある」と女王が付け加えた。

<a id="AW-12-019"></a>

**AW-12-019**

<!-- EN:AW-12-019 -->
“Well, I shan’t go, at any rate,” said Alice: “besides, that’s not a regular rule: you invented it just now.”
<!-- /EN:AW-12-019 -->

> 「とにかく、わたしは出ていきません」とアリスは言った。「それに、それは正式な規則ではないわ。たった今、お作りになったんでしょう」

<a id="AW-12-020"></a>

**AW-12-020**

<!-- EN:AW-12-020 -->
“It’s the oldest rule in the book,” said the King.
<!-- /EN:AW-12-020 -->

> 「この本で、いちばん古い規則だ」と王は言った。

<a id="AW-12-021"></a>

**AW-12-021**

<!-- EN:AW-12-021 -->
“Then it ought to be Number One,” said Alice.
<!-- /EN:AW-12-021 -->

> 「それなら、第一条のはずでしょう」とアリスは言った。

<a id="AW-12-022"></a>

**AW-12-022**

<!-- EN:AW-12-022 -->
The King turned pale, and shut his note-book hastily. “Consider your verdict,” he said to the jury, in a low, trembling voice.
<!-- /EN:AW-12-022 -->

> 王は青くなり、慌てて手帳を閉じた。「評決を考えるがよい」と、低い震える声で陪審員に言った。

<a id="AW-12-023"></a>

**AW-12-023**

<!-- EN:AW-12-023 -->
“There’s more evidence to come yet, please your Majesty,” said the White Rabbit, jumping up in a great hurry; “this paper has just been picked up.”
<!-- /EN:AW-12-023 -->

> 「恐れながら陛下、まだ証拠がございます」と白ウサギは、大慌てで立ち上がって言った。「たった今、この紙が拾われました」

<a id="AW-12-024"></a>

**AW-12-024**

<!-- EN:AW-12-024 -->
“What’s in it?” said the Queen.
<!-- /EN:AW-12-024 -->

> 「何が書いてある？」と女王は言った。

<a id="AW-12-025"></a>

**AW-12-025**

<!-- EN:AW-12-025 -->
“I haven’t opened it yet,” said the White Rabbit, “but it seems to be a letter, written by the prisoner to—to somebody.”
<!-- /EN:AW-12-025 -->

> 「まだ開いておりません」と白ウサギは言った。「ですが、被告が――誰かに宛てて書いた、手紙のようでございます」

<a id="AW-12-026"></a>

**AW-12-026**

<!-- EN:AW-12-026 -->
“It must have been that,” said the King, “unless it was written to nobody, which isn’t usual, you know.”
<!-- /EN:AW-12-026 -->

> 「そうに違いない」と王は言った。「誰にも宛てずに書いたのでないかぎりはな。そんなことは、普通ではないからな」

<a id="AW-12-027"></a>

**AW-12-027**

<!-- EN:AW-12-027 -->
“Who is it directed to?” said one of the jurymen.
<!-- /EN:AW-12-027 -->

> 「誰宛てなのだ？」と陪審員の一人が言った。

<a id="AW-12-028"></a>

**AW-12-028**

<!-- EN:AW-12-028 -->
“It isn’t directed at all,” said the White Rabbit; “in fact, there’s nothing written on the *outside*.” He unfolded the paper as he spoke, and added “It isn’t a letter, after all: it’s a set of verses.”
<!-- /EN:AW-12-028 -->

> 「宛先は、まったく書かれていません」と白ウサギは言った。「実際、*外側*には何も書かれていないのです」そう言いながら紙を開き、付け加えた。「やはり、手紙ではありませんでした。何節かの詩です」

<a id="AW-12-029"></a>

**AW-12-029**

<!-- EN:AW-12-029 -->
“Are they in the prisoner’s handwriting?” asked another of the jurymen.
<!-- /EN:AW-12-029 -->

> 「被告の筆跡なのか？」と、別の陪審員が尋ねた。

<a id="AW-12-030"></a>

**AW-12-030**

<!-- EN:AW-12-030 -->
“No, they’re not,” said the White Rabbit, “and that’s the queerest thing about it.” (The jury all looked puzzled.)
<!-- /EN:AW-12-030 -->

> 「いいえ、違います」と白ウサギは言った。「そこが、いちばん奇妙なのです」（陪審員たちは、みんな困惑した顔になった。）

<a id="AW-12-031"></a>

**AW-12-031**

<!-- EN:AW-12-031 -->
“He must have imitated somebody else’s hand,” said the King. (The jury all brightened up again.)
<!-- /EN:AW-12-031 -->

> 「ほかの誰かの筆跡をまねたに違いない」と王は言った。（陪審員たちは、みんなまた明るい顔になった。）

<a id="AW-12-032"></a>

**AW-12-032**

<!-- EN:AW-12-032 -->
“Please your Majesty,” said the Knave, “I didn’t write it, and they can’t prove I did: there’s no name signed at the end.”
<!-- /EN:AW-12-032 -->

> 「恐れながら、陛下」とジャックは言った。「私は書いておりませんし、私が書いたとは証明できません。最後に名前の署名がないのですから」

<a id="AW-12-033"></a>

**AW-12-033**

<!-- EN:AW-12-033 -->
“If you didn’t sign it,” said the King, “that only makes the matter worse. You *must* have meant some mischief, or else you’d have signed your name like an honest man.”
<!-- /EN:AW-12-033 -->

> 「署名しなかったのなら」と王は言った。「なおさら悪い。何か悪だくみをしていたに*決まっている*。そうでなければ、正直な者らしく名を署名したはずだ」

<a id="AW-12-034"></a>

**AW-12-034**

<!-- EN:AW-12-034 -->
There was a general clapping of hands at this: it was the first really clever thing the King had said that day.
<!-- /EN:AW-12-034 -->

> これには、あちこちから拍手が起こった。その日、王が口にした中で、初めて本当に気の利いた言葉だった。

<a id="AW-12-035"></a>

**AW-12-035**

<!-- EN:AW-12-035 -->
“That *proves* his guilt,” said the Queen.
<!-- /EN:AW-12-035 -->

> 「これで、こいつの有罪は*証明された*」と女王は言った。

<a id="AW-12-036"></a>

**AW-12-036**

<!-- EN:AW-12-036 -->
“It proves nothing of the sort!” said Alice. “Why, you don’t even know what they’re about!”
<!-- /EN:AW-12-036 -->

> 「そんなことは、何も証明されていません！」とアリスは言った。「だって、何についての詩かも、まだわかっていないでしょう！」

<a id="AW-12-037"></a>

**AW-12-037**

<!-- EN:AW-12-037 -->
“Read them,” said the King.
<!-- /EN:AW-12-037 -->

> 「読め」と王は言った。

<a id="AW-12-038"></a>

**AW-12-038**

<!-- EN:AW-12-038 -->
The White Rabbit put on his spectacles. “Where shall I begin, please your Majesty?” he asked.
<!-- /EN:AW-12-038 -->

> 白ウサギは眼鏡をかけた。「恐れながら、陛下、どこから始めましょうか？」と尋ねた。

<a id="AW-12-039"></a>

**AW-12-039**

<!-- EN:AW-12-039 -->
“Begin at the beginning,” the King said gravely, “and go on till you come to the end: then stop.”
<!-- /EN:AW-12-039 -->

> 「初めから始めよ」と王は重々しく言った。「終わりに来るまで続け、それからやめよ」

<a id="AW-12-040"></a>

**AW-12-040**

<!-- EN:AW-12-040 -->
These were the verses the White Rabbit read:—
<!-- /EN:AW-12-040 -->

> 白ウサギが読んだのは、次のような詩だった。

<a id="AW-12-041"></a>

**AW-12-041**

<!-- EN:AW-12-041 -->
“They told me you had been to her,  
    And mentioned me to him:  
She gave me a good character,  
    But said I could not swim.  
<!-- /EN:AW-12-041 -->

> 「彼らは私に、あなたが彼女のところへ行き、  
> 　　彼に私のことを話したと言った。  
> 彼女は私のことをよく言ってくれたが、  
> 　　私は泳げないと言った。

<a id="AW-12-042"></a>

**AW-12-042**

<!-- EN:AW-12-042 -->
He sent them word I had not gone  
    (We know it to be true):  
If she should push the matter on,  
    What would become of you?  
<!-- /EN:AW-12-042 -->

> 彼は彼らに、私は行かなかったと知らせた  
> 　　（私たちは、それが本当だと知っている）。  
> もし彼女がこの話を押し進めたら、  
> 　　あなたはどうなるだろう？

<a id="AW-12-043"></a>

**AW-12-043**

<!-- EN:AW-12-043 -->
I gave her one, they gave him two,  
    You gave us three or more;  
They all returned from him to you,  
    Though they were mine before.  
<!-- /EN:AW-12-043 -->

> 私は彼女に一つ、彼らは彼に二つを渡し、  
> 　　あなたは私たちに三つか、それ以上をくれた。  
> みな彼のもとから、あなたのもとへ戻った、  
> 　　前には、私のものだったけれど。

<a id="AW-12-044"></a>

**AW-12-044**

<!-- EN:AW-12-044 -->
If I or she should chance to be  
    Involved in this affair,  
He trusts to you to set them free,  
    Exactly as we were.  
<!-- /EN:AW-12-044 -->

> もし私か彼女が、たまたま  
> 　　この一件に巻き込まれることになったら、  
> 彼はあなたが彼らを自由にしてくれると頼みにしている、  
> 　　ちょうど私たちがそうだったように。

<a id="AW-12-045"></a>

**AW-12-045**

<!-- EN:AW-12-045 -->
My notion was that you had been  
    (Before she had this fit)  
An obstacle that came between  
    Him, and ourselves, and it.  
<!-- /EN:AW-12-045 -->

> 私の考えでは、あなたは  
> 　　（彼女がこの発作を起こす前には）  
> 彼と、私たちと、それとのあいだに  
> 　　立ちはだかる障害だった。

<a id="AW-12-046"></a>

**AW-12-046**

<!-- EN:AW-12-046 -->
Don’t let him know she liked them best,  
    For this must ever be  
A secret, kept from all the rest,  
    Between yourself and me.”
<!-- /EN:AW-12-046 -->

> 彼女がそれらをいちばん好きだったと、彼には知らせないで、  
> 　　これはいつまでも  
> ほかの者すべてに隠した秘密でなくてはならないのだから、  
> 　　あなたと私のあいだだけの」

> **訳注：** この詩では、he、she、they、you、it などの指示対象が明示されない。訳でも、具体的な人物やタルトを補って意味を確定してはいない。

<a id="AW-12-047"></a>

**AW-12-047**

<!-- EN:AW-12-047 -->
“That’s the most important piece of evidence we’ve heard yet,” said the King, rubbing his hands; “so now let the jury—”
<!-- /EN:AW-12-047 -->

> 「これこそ、これまで聞いた中でいちばん重要な証拠だ」と王は手をこすり合わせて言った。「では今こそ、陪審に――」

<a id="AW-12-048"></a>

**AW-12-048**

<!-- EN:AW-12-048 -->
“If any one of them can explain it,” said Alice, (she had grown so large in the last few minutes that she wasn’t a bit afraid of interrupting him), “I’ll give him sixpence. *I* don’t believe there’s an atom of meaning in it.”
<!-- /EN:AW-12-048 -->

> 「そのうちの誰か一人でも説明できたら」とアリスは言った。この数分でとても大きくなっていたので、王の言葉を遮るのも、少しも怖くなかった。「六ペンスあげるわ。*わたしは*、そこにかけらほどの意味もないと思うもの」

<a id="AW-12-049"></a>

**AW-12-049**

<!-- EN:AW-12-049 -->
The jury all wrote down on their slates, “*She* doesn’t believe there’s an atom of meaning in it,” but none of them attempted to explain the paper.
<!-- /EN:AW-12-049 -->

> 陪審員はみんな、石板に「*彼女は*、そこにかけらほどの意味もないと思っている」と書き留めた。けれど、その紙を説明しようとする者は一人もいなかった。

<a id="AW-12-050"></a>

**AW-12-050**

<!-- EN:AW-12-050 -->
“If there’s no meaning in it,” said the King, “that saves a world of trouble, you know, as we needn’t try to find any. And yet I don’t know,” he went on, spreading out the verses on his knee, and looking at them with one eye; “I seem to see some meaning in them, after all. “—*said I could not swim*—” you can’t swim, can you?” he added, turning to the Knave.
<!-- /EN:AW-12-050 -->

> 「意味がないのなら」と王は言った。「大変な手間が省ける。意味を見つけようとしなくて済むのだからな。いや、それでも、どうだろう」と続け、膝の上に詩を広げて、片目で眺めた。「やはり、何か意味が見えるような気がする。『――*私は泳げないと言った*――』おまえは泳げないのだろう？」と、ジャックに向き直って付け加えた。

<a id="AW-12-051"></a>

**AW-12-051**

<!-- EN:AW-12-051 -->
The Knave shook his head sadly. “Do I look like it?” he said. (Which he certainly did *not*, being made entirely of cardboard.)
<!-- /EN:AW-12-051 -->

> ジャックは悲しそうに首を振った。「泳げそうに見えますか？」と言った。（体がすべて厚紙でできていたので、確かに*そうは見えなかった*。）

<a id="AW-12-052"></a>

**AW-12-052**

<!-- EN:AW-12-052 -->
“All right, so far,” said the King, and he went on muttering over the verses to himself: “‘*We know it to be true*—’ that’s the jury, of course—‘*I gave her one, they gave him two*—’ why, that must be what he did with the tarts, you know—”
<!-- /EN:AW-12-052 -->

> 「ここまでは、よし」と王は言い、詩をぶつぶつ読みながら続けた。「『*私たちは、それが本当だと知っている*――』これは、もちろん陪審だ――『*私は彼女に一つ、彼らは彼に二つを渡し*――』なるほど、こやつがタルトをどうしたかに違いない――」

<a id="AW-12-053"></a>

**AW-12-053**

<!-- EN:AW-12-053 -->
“But, it goes on ‘*they all returned from him to you*,’” said Alice.
<!-- /EN:AW-12-053 -->

> 「でも、その先には『*みな彼のもとから、あなたのもとへ戻った*』とあります」とアリスは言った。

<a id="AW-12-054"></a>

**AW-12-054**

<!-- EN:AW-12-054 -->
“Why, there they are!” said the King triumphantly, pointing to the tarts on the table. “Nothing can be clearer than *that*. Then again—‘*before she had this fit*—’ you never had fits, my dear, I think?” he said to the Queen.
<!-- /EN:AW-12-054 -->

> 「ほら、そこにあるではないか！」と王はテーブルの上のタルトを指し、得意げに言った。「*これほど*はっきりしたことはない。それから、また――『*彼女がこの発作を起こす前には*――』おまえは発作など起こしたことはなかったと思うが？」と女王に言った。

<a id="AW-12-055"></a>

**AW-12-055**

<!-- EN:AW-12-055 -->
“Never!” said the Queen furiously, throwing an inkstand at the Lizard as she spoke. (The unfortunate little Bill had left off writing on his slate with one finger, as he found it made no mark; but he now hastily began again, using the ink, that was trickling down his face, as long as it lasted.)
<!-- /EN:AW-12-055 -->

> 「一度もない！」と女王は怒り狂って言いながら、トカゲにインク台を投げつけた。（気の毒な小さなビルは、指で書いても跡がつかないとわかって、石板に書くのをやめていた。だが今度は、顔を伝って流れるインクを使い、それがあるかぎり、大急ぎでまた書き始めた。）

<a id="AW-12-056"></a>

**AW-12-056**

<!-- EN:AW-12-056 -->
“Then the words don’t *fit* you,” said the King, looking round the court with a smile. There was a dead silence.
<!-- /EN:AW-12-056 -->

> 「では、その言葉は、おまえには*当てはまらん*な」と王は笑顔で法廷を見回しながら言った。水を打ったような静けさだった。

> **訳注：** fit は名詞で「発作」、動詞で「合う・当てはまる」。王は直前の fits を、ここでは fit you に掛けている。

<a id="AW-12-057"></a>

**AW-12-057**

<!-- EN:AW-12-057 -->
“It’s a pun!” the King added in an offended tone, and everybody laughed, “Let the jury consider their verdict.” the King said, for about the twentieth time that day.
<!-- /EN:AW-12-057 -->

> 「しゃれだぞ！」と王は気を悪くして付け加えた。するとみんな笑った。「陪審員は評決を考えるがよい」と王は言った。その日、およそ二十度目だった。

<a id="AW-12-058"></a>

**AW-12-058**

<!-- EN:AW-12-058 -->
“No, no!” said the Queen. “Sentence first—verdict afterwards.”
<!-- /EN:AW-12-058 -->

> 「いや、いや！」と女王は言った。「刑の言い渡しが先――評決は後だ」

<a id="AW-12-059"></a>

**AW-12-059**

<!-- EN:AW-12-059 -->
“Stuff and nonsense!” said Alice loudly. “The idea of having the sentence first!”
<!-- /EN:AW-12-059 -->

> 「ばかばかしい、でたらめだわ！」とアリスは大声で言った。「先に刑を言い渡すなんて！」

<a id="AW-12-060"></a>

**AW-12-060**

<!-- EN:AW-12-060 -->
“Hold your tongue!” said the Queen, turning purple.
<!-- /EN:AW-12-060 -->

> 「黙れ！」と女王は、顔を紫色にして言った。

<a id="AW-12-061"></a>

**AW-12-061**

<!-- EN:AW-12-061 -->
“I won’t!” said Alice.
<!-- /EN:AW-12-061 -->

> 「いやよ！」とアリスは言った。

<a id="AW-12-062"></a>

**AW-12-062**

<!-- EN:AW-12-062 -->
“Off with her head!” the Queen shouted at the top of her voice. Nobody moved.
<!-- /EN:AW-12-062 -->

> 「この子の首をはねよ！」と女王は声のかぎりに叫んだ。誰も動かなかった。

<a id="AW-12-063"></a>

**AW-12-063**

<!-- EN:AW-12-063 -->
“Who cares for you?” said Alice, (she had grown to her full size by this time). “You’re nothing but a pack of cards!”
<!-- /EN:AW-12-063 -->

> 「あなたたちなんか、誰が気にするものですか？」とアリスは言った。そのころには、もう本来の大きさに戻っていた。「ただのトランプ一組じゃない！」

<a id="AW-12-064"></a>

**AW-12-064**

<!-- EN:AW-12-064 -->
At this the whole pack rose up into the air, and came flying down upon her: she gave a little scream, half of fright and half of anger, and tried to beat them off, and found herself lying on the bank, with her head in the lap of her sister, who was gently brushing away some dead leaves that had fluttered down from the trees upon her face.
<!-- /EN:AW-12-064 -->

> すると、トランプは一組そっくり空中へ舞い上がり、アリスめがけて飛びかかってきた。アリスは、半分は怖さ、半分は怒りで小さく悲鳴を上げ、払いのけようとした。そして気がつくと、土手に横たわり、姉の膝に頭をのせていた。姉は、木からひらひら落ちてアリスの顔にかかった枯れ葉を、そっと払い落としているところだった。

<a id="AW-12-065"></a>

**AW-12-065**

<!-- EN:AW-12-065 -->
“Wake up, Alice dear!” said her sister; “Why, what a long sleep you’ve had!”
<!-- /EN:AW-12-065 -->

> 「起きて、アリス！」と姉は言った。「まあ、ずいぶん長く眠っていたのね！」

<a id="AW-12-066"></a>

**AW-12-066**

<!-- EN:AW-12-066 -->
“Oh, I’ve had such a curious dream!” said Alice, and she told her sister, as well as she could remember them, all these strange Adventures of hers that you have just been reading about; and when she had finished, her sister kissed her, and said, “It *was* a curious dream, dear, certainly: but now run in to your tea; it’s getting late.” So Alice got up and ran off, thinking while she ran, as well she might, what a wonderful dream it had been.
<!-- /EN:AW-12-066 -->

> 「ああ、とっても不思議な夢を見たの！」とアリスは言い、今みなさんが読んできたばかりの、あの奇妙な冒険の数々を、思い出せるかぎり姉にすっかり話して聞かせた。話し終えると、姉はアリスに口づけして言った。「確かに、*本当に*不思議な夢だったわね。でも、もうおうちへ走って、お茶にしなさい。遅くなってきたわ」そこでアリスは立ち上がり、走っていった。走りながら、あれはなんてすばらしい夢だったのだろうと考えていた。そう思うのも、もっともなことだった。

<a id="AW-12-067"></a>

<!-- EN:AW-12-067 -->
---
<!-- /EN:AW-12-067 -->

<a id="AW-12-068"></a>

**AW-12-068**

<!-- EN:AW-12-068 -->
But her sister sat still just as she left her, leaning her head on her hand, watching the setting sun, and thinking of little Alice and all her wonderful Adventures, till she too began dreaming after a fashion, and this was her dream:—
<!-- /EN:AW-12-068 -->

> けれど姉は、アリスが去ったときのまま、じっと座っていた。手に頭をもたせ、沈む太陽を眺めながら、小さなアリスと、そのすばらしい冒険の数々を思っていた。やがて姉もまた、いわば夢を見始めた。それは、こんな夢だった。

<a id="AW-12-069"></a>

**AW-12-069**

<!-- EN:AW-12-069 -->
First, she dreamed of little Alice herself, and once again the tiny hands were clasped upon her knee, and the bright eager eyes were looking up into hers—she could hear the very tones of her voice, and see that queer little toss of her head to keep back the wandering hair that *would* always get into her eyes—and still as she listened, or seemed to listen, the whole place around her became alive with the strange creatures of her little sister’s dream.
<!-- /EN:AW-12-069 -->

> まず、小さなアリスそのものを夢に見た。小さな両手が、また姉の膝の上で組まれ、きらきらと熱心な目が、姉の目を見上げていた。あの声の調子までも聞こえ、いつも*決まって*目にかかってくる髪を払いのけようとする、あの独特の、ちょっと頭を振る仕草が見えた。そして、なお耳を傾けているうちに――あるいは、耳を傾けているような気がしているうちに――あたり一面が、妹の夢に出てきた奇妙な生き物たちで、生き生きと満ちていった。

<a id="AW-12-070"></a>

**AW-12-070**

<!-- EN:AW-12-070 -->
The long grass rustled at her feet as the White Rabbit hurried by—the frightened Mouse splashed his way through the neighbouring pool—she could hear the rattle of the teacups as the March Hare and his friends shared their never-ending meal, and the shrill voice of the Queen ordering off her unfortunate guests to execution—once more the pig-baby was sneezing on the Duchess’s knee, while plates and dishes crashed around it—once more the shriek of the Gryphon, the squeaking of the Lizard’s slate-pencil, and the choking of the suppressed guinea-pigs, filled the air, mixed up with the distant sobs of the miserable Mock Turtle.
<!-- /EN:AW-12-070 -->

> 白ウサギが急いで通り過ぎると、足元の長い草がさらさらと鳴った。おびえたネズミが、近くの池をしぶきを上げて進んだ。三月ウサギと仲間たちが終わりのない食事を共にする、ティーカップのがちゃがちゃいう音が聞こえた。気の毒な招待客を処刑へ連れていけと命じる、女王の甲高い声も。ブタの赤ん坊は再び公爵夫人の膝でくしゃみをし、そのまわりでは皿という皿ががちゃんと砕けた。グリフォンの金切り声、トカゲの石筆のきいきいいう音、抑え込まれたモルモットたちの息の詰まる音が、またあたりに満ち、遠くから聞こえる哀れなウミガメもどきの深いすすり泣きと混じり合った。

<a id="AW-12-071"></a>

**AW-12-071**

<!-- EN:AW-12-071 -->
So she sat on, with closed eyes, and half believed herself in Wonderland, though she knew she had but to open them again, and all would change to dull reality—the grass would be only rustling in the wind, and the pool rippling to the waving of the reeds—the rattling teacups would change to tinkling sheep-bells, and the Queen’s shrill cries to the voice of the shepherd boy—and the sneeze of the baby, the shriek of the Gryphon, and all the other queer noises, would change (she knew) to the confused clamour of the busy farm-yard—while the lowing of the cattle in the distance would take the place of the Mock Turtle’s heavy sobs.
<!-- /EN:AW-12-071 -->

> こうして姉は、目を閉じたまま座り続け、自分も不思議の国にいると、半ば信じていた。けれど、また目を開けさえすれば、何もかもが退屈な現実へ変わってしまうことも、わかっていた。草はただ風にそよいでいるだけになり、池には葦の揺れにつれてさざ波が立つだけになる。ティーカップのがちゃがちゃいう音は羊の鈴のちりんちりんという音に、女王の甲高い叫び声は羊飼いの少年の声に変わる。そして、赤ん坊のくしゃみも、グリフォンの金切り声も、そのほかの奇妙な音もすべて、忙しい農場の庭先の入り混じった騒ぎ声に変わるのだ、と姉は知っていた。遠くの牛の鳴き声が、ウミガメもどきの深いすすり泣きに取って代わることも。

<a id="AW-12-072"></a>

**AW-12-072**

<!-- EN:AW-12-072 -->
Lastly, she pictured to herself how this same little sister of hers would, in the after-time, be herself a grown woman; and how she would keep, through all her riper years, the simple and loving heart of her childhood: and how she would gather about her other little children, and make *their* eyes bright and eager with many a strange tale, perhaps even with the dream of Wonderland of long ago: and how she would feel with all their simple sorrows, and find a pleasure in all their simple joys, remembering her own child-life, and the happy summer days.
<!-- /EN:AW-12-072 -->

> 最後に姉は思い描いた。この同じ幼い妹が、やがて時がたち、一人の大人の女性になる姿を。そして、年を重ねても、子どものころの素直で愛情深い心を保ち続ける姿を。そのまわりには別の小さな子どもたちが集まり、妹は不思議な話をいくつも聞かせて、*その子たちの*目を、きらきらと熱心に輝かせるだろう。もしかすると、遠い昔の不思議の国の夢さえ、話して聞かせるかもしれない。そして、自分の子ども時代と幸せな夏の日々を思い出しながら、その子たちの素朴な悲しみの一つ一つを共に感じ、素朴な喜びの一つ一つに楽しみを見いだすだろう、と。

[章目次へ戻る](#book-top)

---
