# 赤い点のついた傘

副詞と、時・場所・数・条件を伝えることばを読む　｜　英日対訳 49編

黒い傘が六本ある。係の人がそのうちの一本を机に置く。まだ誰のものかは分からない。それでも、二人はもう *the umbrella* と呼べる。

先に場面を読んでから、小さな語が何を決めていたかを確かめる。英文のすぐ下に、一段下げて日本語訳を置いた。太字は巻末索引に載せた用例。索引の右肩の数字は、元のリストで同じ綴りの見出しを区別する印。

**練習するなら**　まず一話の英文だけを追う。話末の問いに自分の言葉で答え、対訳と部末の「読みの確認」に戻る。部末の短い対訳では、一か所を変えて、どこまで同じ話でいられるかを試せる。

## 目次

- [第1部　誰のもの、どの一つ](#part1)　01–07
- [第2部　地図にある道、歩いた道](#part2)　08–14
- [第3部　時計が鳴るまで](#part3)　15–21
- [第4部　食卓から店先まで](#part4)　22–28
- [第5部　声が届く場所](#part5)　29–35
- [第6部　何を数えたのか](#part6)　36–42
- [第7部　読む人がいる部屋](#part7)　43–49
- [用例索引](#wordindex)　副詞391項目・その他297項目

---

<a id="part1"></a>

## 第1部　誰のもの、どの一つ

同じ絵を前にして、弟は「君の」、語り手は「彼女の」と言う。話し手が交代しても、誰を指しているかを追ってみよう。

<a id="r01"></a>

### 01　傘の持ち主

<a id="p01-1"></a>

**1**　‘**Hello**. I think I left **an** umbrella here.’ The woman behind the desk put **a** black umbrella on the table. ‘**Whose** umbrella is **this** one, then?’ I reached for it. ‘**Do** you recognize it?’ she asked. ‘There are six just like it.’

> 「こんにちは。ここに傘を置き忘れたと思うのですが」係の女性は黒い傘を一本、机に置いた。「では、こちらはどなたの傘でしょう？」私が手を伸ばすと、「見覚えがありますか。同じようなのが六本あるんですよ」と彼女は言った。

<a id="p01-2"></a>

**2**　‘**My** sister writes **her** name inside everything. My brother puts **his** name on the outside. I put a little red dot under the handle.’ She turned **the** umbrella over. No dot. ‘Perhaps **that** umbrella by **your** chair?’ I said.

> 「妹はどの持ち物にも、内側に名前を書きます。兄は外側に。私は持ち手の下に小さな赤い点を付けます」彼女が机の傘をひっくり返すと、点はなかった。「そちらの椅子のそばにある傘かもしれません」と私は言った。

<a id="p01-3"></a>

**3**　This time there was a dot. ‘**Sorry**, I nearly took the wrong one. **Thanks** for asking.’ Outside it had begun to rain. I opened the umbrella. A little red drop ran down my hand.

> 今度は点があった。「すみません、もう少しで違う傘を持っていくところでした。確かめてくれてありがとう」外では雨が降り始めていた。傘を開くと、小さな赤いしずくが手を伝った。

**読みの問い**　最初に an umbrella と言い、女性が傘を机に置いた後で the umbrella と言えるのはなぜか。それで持ち主まで分かるだろうか。

<a id="r02"></a>

### 02　誰の描いた冬か

<a id="p02-1"></a>

**1**　Three families had painted the same street **for** a winter exhibition. We hung the pictures together. **Besides** a picture from each family, there were two little drawings by children. Then the labels fell off.

> 三つの家族が冬の展覧会のために同じ通りを描き、私たちは絵を並べて飾った。各家族の作品のほかに、子どもの小さな絵も2枚あった。ところが、作品につけた札が落ちてしまった。

<a id="p02-2"></a>

**2**　‘**Whose** is the one with the red sky?’ I asked the children. ‘It is **mine**,’ said the girl. Her younger brother shook his head. ‘**Yours** has a moon.’ We turned both drawings over to read the names on the back. The one with the moon was indeed **hers**. The red sky was **his**.

> 「空が赤いのは誰の絵？」と子どもたちに聞いた。「私の」と女の子が言った。弟は首を振った。「君のには月があるよ」子どもたちの絵を二枚とも裏返して、裏の名前を読んだ。月のあるほうが確かに女の子のもので、赤い空のほうは弟のだった。

<a id="p02-3"></a>

**3**　The parents had not signed their pictures. ‘**Unlike** the children, we all chose the same grey sky. How can we tell **ours** from **theirs**?’ I held one picture up. A white mark looked **like** a little bird above a roof.

> 親たちは絵に署名していなかった。「子どもたちと違って、私たちはみんな同じ灰色の空にしたんです。うちの絵とよその絵をどう見分けたらいいでしょう」私が一枚を掲げると、屋根の上に、小鳥に似た白い跡があった。

<a id="p02-4"></a>

**4**　‘That was my finger,’ said a man at the back. Soon every family had found its **own**. The labels went back up. But people spent longer looking at that little bird than reading any of the names.

> 「それは私の指の跡です」と後ろの男性が言った。ほどなく、どの家族も自分たちの作品を見つけた。札は元に戻された。それでも人々は作者の名前を読むより、あの小鳥を見るのに長い時間をかけていた。

**読みの問い**　同じ絵を指しながら、子どもの発言では yours、語り手の説明では hers になるのはなぜか。

<a id="r03"></a>

### 03　鏡に写らない指輪

<a id="p03-1"></a>

**1**　A ring slipped **off** my finger while I was washing a cup. It struck the edge **of** the sink and fell **into** my open bag. At least, that was what I thought I saw in the mirror **above** the sink.

> カップを洗っていると、指輪が私の指からするりと抜けた。流しの縁に当たり、口の開いた私のかばんに落ちた。少なくとも、流しの上の鏡には、そう映ったように見えた。

<a id="p03-2"></a>

**2**　The bag stood **on** a chair **next to** the sink. I emptied it **onto** the table. There was no ring **among** the coins. I felt **inside** each pocket. All I found was a hole.

> かばんは流しのすぐ隣の椅子に載っていた。私は中身をテーブルの上にあけた。硬貨の中に指輪はなかった。ポケットを一つずつ中まで手で探った。見つけたのは穴だけだった。

<a id="p03-3"></a>

**3**　My son was **beside** me by now. He bent down and ran a finger **around** each wooden leg. There was my ring, resting **against** the fourth one. It had slipped through the hole and fallen **under** the chair.

> そのころには息子が私のそばに来ていた。息子はかがんで、椅子の木の脚を一本ずつ指でぐるりとなぞった。指輪は4本目の脚に寄りかかるようにして止まっていた。穴を通り抜けて、椅子の下に落ちていたのだ。

<a id="p03-4"></a>

**4**　‘You were right,’ he said. ‘It was **in** the bag. The difficulty is how long it was there.’

> 「合ってたよ」と息子は言った。「指輪はかばんの中にあった。問題は、そこにどれくらいの間あったかだね」

**読みの問い**　かばんを指す二つの表現のうち、落下の行き先を示すものと、その直後の状態を示すものはどれか。

<a id="r04"></a>

### 04　貸せない一冊

<a id="p04-1"></a>

**1**　You could borrow **anything** on the library shelves. Yet one book stood in a glass case. ‘Has **anybody** ever read that **one**?’ a child asked. ‘Almost **everyone** in the village,’ said the man at the desk. ‘**No one** has ever taken it home.’

> 図書館の棚にあるものは何でも借りられた。ところが一冊だけ、ガラスケースに入った本があった。「あれ、読んだことがある人いる？」と子どもが聞いた。「村のほとんどみんなが読んだよ」と受付の男性が言った。「家に持ち帰った人は一人もいないけどね」

<a id="p04-2"></a>

**2**　He opened the case. Inside the book were two envelopes. One had **nothing** in it. The **other** held a letter. ‘**Somebody** wrote a story this morning. Put it in the book, and the empty envelope is for you to fill.’

> 男性がケースを開けた。本の中には封筒が2枚あった。一方には何も入っていなかった。もう一方には手紙が1枚入っていた。「今朝、誰かが物語を書いたんだ。その物語を本に挟んで。空いている封筒は、君が何か入れるためにある」

<a id="p04-3"></a>

**3**　‘But I want to read **everything** first.’ ‘Of course. When **someone** adds a story, we make a copy. If you take a copy, we make **another**.’ He opened a box. It was full of stories that people could take home.

> 「でも、まず全部読みたいな」「もちろん。誰かが物語を書き足すたび、写しを作るんだ。君がその写しを持っていったら、また一部作るよ」男性が箱を開けると、持ち帰って読める物語でいっぱいだった。

<a id="p04-4"></a>

**4**　‘Who wrote the first story?’ asked the child. ‘**Nobody** remembers. The first page went missing years ago. **Everybody** remembers **something** about it, though.’ The child took a fresh sheet of paper. ‘Then my first story will be about the different first stories.’

> 「最初の物語を書いたのは誰？」と子どもが尋ねた。「覚えている人はいないよ。最初のページは何年も前になくなったんだ。でも、そのお話についてなら、誰しも何かしら覚えている」子どもは新しい紙を一枚取った。「じゃあ私が最初に書くのは、みんなの中にある、少しずつ違う最初の物語だ」

**読みの問い**　最初の話について nobody と everybody が続いても矛盾しないのはなぜか。

<a id="r05"></a>

### 05　十年後の私へ

<a id="p05-1"></a>

**1**　When **I** was ten, our teacher gave **me** an envelope. ‘Write a letter to the person you will be in ten years.’ My friend said **he** had nothing to tell that person. The teacher handed **him** a second sheet anyway. He filled it **himself**, in tiny letters.

> 私が10歳のとき、先生が封筒をくれた。「10年後の自分に手紙を書いてごらん」友達は、その相手に伝えることなどないと言った。先生はそれでも彼に2枚目の紙を渡した。彼は自分で、小さな字でびっしり書いた。

<a id="p05-2"></a>

**2**　My little sister wanted a turn. I gave **her** my spare envelope. ‘Can you write my name?’ **she** asked. I did. She drew the rest **herself**. There was a tall girl, a small girl and a long blue line between them.

> 妹もやりたがった。私は予備の封筒を渡した。「私の名前を書いてくれる？」と妹が聞いた。名前は私が書いた。残りは妹が自分で絵にした。背の高い女の子と小さな女の子がいて、二人の間には長い青い線があった。

<a id="p05-3"></a>

**3**　Ten years later my sister opened her letter. The picture **itself** had hardly changed, but **it** now seemed to ask a question. ‘Is **this** how tall I thought I would be?’ She pointed to the taller girl.

> 10年後、妹は手紙を開けた。絵そのものはほとんど変わっていなかったのに、今は何かを問いかけてくるようだった。「私、このくらいの背になると思ってたのかな」妹は背の高いほうの女の子を指した。

<a id="p05-4"></a>

**4**　‘That is me,’ I said. ‘You drew us on opposite sides of a river.’ ‘**That** explains the blue line.’ I found **myself** looking at the picture again. When had I decided the girl was me?

> 「それは私だよ」と私は言った。「川の向こうとこちらに私たちを描いたんだよ」「それなら青い線の説明がつくね」私は気がつくと、また絵を見ていた。あの女の子が私だと決めたのは、いつのことだろう。

**読みの問い**　herself と myself のそれぞれを取って読むと、どんな違いが生じるか。

<a id="r06"></a>

### 06　持ち主がいない声

<a id="p06-1"></a>

**1**　Have you **ever** heard your own voice as a child? When a woman from the museum rang, I thought I finally had. I was **deeply** moved to hear a little voice saying, ‘Leave some cake for me.’ I had not known the woman **long**, but she seemed to know me very well **indeed**.

> 子どものころの自分の声を聴いたことはあるだろうか。博物館の女性から電話が来たとき、私はとうとう自分の声を聴けたと思った。「私の分のケーキも残しておいて」と小さな声が言うのを聴いて、胸にこみ上げるものがあった。その女性と知り合ってから長くはなかったが、彼女は私のことをほんとうによく知っているようだった。

<a id="p06-2"></a>

**2**　She had **initially** hoped to put a name to every voice. Her collection was **largely** made up of recordings given by local families. People remembered the same afternoon **differently**. My father had changed **little** over the years and would most **likely** remember the cake. I promised to ask him **later**.

> 女性は当初、どの声の主も突き止めようと思っていた。コレクションの大部分は地元の家族が寄せた録音だった。同じ日の午後でも、人によって記憶は違った。父は昔からほとんど変わらない人で、きっとケーキのことを覚えている。後で聞いてみると私は約束した。

<a id="p06-3"></a>

**3**　The room we used **least** was the one my father remembered best. ‘I made that recording in there. I used to play it to your brother. I have been playing it to his children **lately**.’ My brother, **likewise**, remembered the room. But he asked about the plate **instead**. ‘Was it blue? If it was, that was me.’

> 私たちがいちばん使わなかった部屋を、父はいちばんよく覚えていた。「そこで録音したんだ。お前の兄さんによく聴かせたよ。最近では、あいつの子どもたちに聴かせている」兄も同じようにその部屋を覚えていた。ところが兄が尋ねたのは、お皿のほうだった。「青かった？　青なら、その声は僕だよ」

<a id="p06-4"></a>

**4**　I could have gone on believing it was my voice **forever**. In a museum, someone will **inevitably** ask whose voice it is, and a voice alone cannot **fully** answer. **Hence** the note beside ours reads, ‘Two brothers, one cake. One of them is still waiting for his share.’

> 私は、いつまでも自分の声だと信じ続けていたかもしれない。博物館では、いずれ必ず誰かが「これは誰の声ですか」と尋ねる。声だけでは十分には答えられない。だから、私たちの録音の横にはこう書いてある。「兄弟二人にケーキ一つ。どちらか一人は、まだ自分の分を待っている」

**読みの問い**　父がケーキを覚えている見込みと、いつか誰かが声の主を尋ねるという見通しには、確かさの違いがある。どの語がそれを示すか。

<a id="r07"></a>

### 07　地図の上の持ち主

<a id="p07-1"></a>

**1**　The town sent **us** a map to correct. ‘**We** know this street,’ I told my sister. ‘We can draw it **ourselves**.’ There were children playing by the river. We showed **them** our map, and **they** laughed. ‘**What** is that white space?’

> 町から、直してほしいと地図が送られてきた。「この通りならよく知っているから、自分たちで描けるよ」と妹に言った。川辺で遊ぶ子どもたちに地図を見せると、みんな笑った。「その白いところ、何？」

<a id="p07-2"></a>

**2**　It was a garden. ‘Write **whatever** you call it,’ I said. The children passed the pencil among **themselves**. Three names appeared. ‘**Which** should we keep?’ I asked the woman **who** grew the flowers there.

> 庭だった。「君たちが呼んでいる名なら何でもいいから書いて」と私は言った。子どもたちは自分たちの間で鉛筆を回した。名前が三つ出そろった。「どれを残せばいいでしょう」と、そこで花を育てている女性に聞いた。

<a id="p07-3"></a>

**3**　‘**Whoever** uses the garden has a name for it,’ she said. ‘The boy with **whom** I share my tools calls it home. He lives on a boat. What would **you** call it if you slept on the river **yourself**?’

> 「この庭を使う人なら誰でも、庭を自分なりの名で呼んでいるのよ」と女性が答えた。「私と一緒に道具を使っている男の子は、ここを自分の家と呼ぶの。舟で暮らしている子よ。あなた自身が川の上で寝ていたら、ここを何と呼ぶかしら？」

<a id="p07-4"></a>

**4**　We kept all three names. **Such** was the space they took up that our garden now looked bigger than the station. This time we drew a number on the map and wrote the names below it.

> 三つとも残した。ところが、その名前がずいぶん場所を取ったので、地図では庭が駅よりも大きく見えるようになった。今度は地図の庭に番号を書き、名前は下にまとめて書いた。

**読みの問い**　who と with whom は、庭で起きたことの中に、それぞれどんな立場の人を置いているか。

### 同じ場面で言い換える　1　自分で描く、自分を描く

太字に注目して、場面をどう読み替えるか考えよう。

She drew the picture **herself**.

> 彼女はその絵を自分の手で描いた。

She drew a picture **of herself**.

> 彼女は自分を描いた。

二文目は自画像だと分かる。一文目だけなら、描かれたのは別の人でもよい。

### 第1部　読みの確認

**[01　傘の持ち主](#r01)**　最初は聞き手がどの一本か特定できない。後では机の上の一本を二人とも指せる。どれを指しているかが共有できても、その持ち主が誰かは別の問題。

**[02　誰の描いた冬か](#r02)**　弟は姉を相手に「君の絵」と言っている。語り手はその場面を読者に「彼女の絵」と伝えている。持ち主は一人で、話す人とその相手が変わる。

**[03　鏡に写らない指輪](#r03)**　into my open bag は指輪が外から中へ移った出来事。in the bag はある時点で中にあった状態で、その時間の長さまでは言っていない。

**[04　貸せない一冊](#r04)**　誰も覚えていないのは作者が誰だったか。一方、誰の記憶にも何か残っているのは物語の中身。二つの文で思い出そうとしている対象が違う。

**[05　十年後の私へ](#r05)**　She drew the rest だけでも絵を描いたという文は成り立つ。herself は、名前を人に書いてもらった妹が、絵は自分の手で描いたという強調。I found myself looking では、見ているのが自分だと気づいたという意味に myself が必要になる。

**[06　持ち主がいない声](#r06)**　most likely は、覚えている可能性がとても高いという予想。inevitably は、博物館に所蔵されれば誰かがそう尋ねるのは避けられない、という見通し。

**[07　地図の上の持ち主](#r07)**　who は花を育てた人を指し、その人が育てる動作をする。with whom は道具を一緒に使う相手を指す。道具を共用しているという発言で、主語に置かれているのは女性のほう。

---

<a id="part2"></a>

## 第2部　地図にある道、歩いた道

橋の方へ歩いた人が、その橋を渡ったとは限らない。本文の道筋を、頭の中の地図に一本ずつ引いてみよう。

<a id="r08"></a>

### 08　橋を渡ったのは誰か

<a id="p08-1"></a>

**1**　My father and I stood **about** ten steps **apart** on the bridge. The river ran **below**. A train went **by** on the line **above**. Between the two noises I heard a child call, ‘Are you coming **along**?’

> 父と私は橋の上で十歩ほど離れて立っていた。下には川が流れ、上の線路を列車が通り過ぎた。二つの音の切れ目に、「一緒に来る？」という子どもの声が聞こえた。

<a id="p08-2"></a>

**2**　I looked **ahead**. On the far bank stood two houses with a narrow path in **between**. I could see the fields **beyond**. Nobody came **across**. I turned **left**, then looked **down**. A small boat was moving under the bridge.

> 私は前を見た。向こう岸には家が二軒あり、その間に細い道があった。さらに向こうには畑が見えた。誰もこちらへ渡ってこない。私は左を向き、それから下をのぞいた。小舟が橋の下を進んでいた。

<a id="p08-3"></a>

**3**　A girl sat at the front, with a dog **behind**. One little hand reached **downwards**, **deep** into the water. A red ball came **close**, then slipped past her hand. ‘Come **back**!’ called the girl in the boat. It was the ball she wanted to take along. She had never been talking to us.

> 女の子が舳先に座り、その後ろには犬がいた。小さな手が下へ伸び、水の奥まで入った。赤いボールがすぐそばまで来て、その手をすり抜けた。「戻っておいで！」と、舟の女の子が呼んだ。一緒に連れていきたかったのは赤いボールだった。はじめから私たちに話しかけてなどいなかったのだ。

**読みの問い**　岸にある小道と畑は、二軒の家から見てそれぞれどこか。そう読める語を探そう。

<a id="r09"></a>

### 09　橋を渡らない手紙

<a id="p09-1"></a>

**1**　A nurse on the south bank had a letter for a patient on the north bank. **From** her window she could see his room. In summer she sometimes swam **across** the river. Today the water was far too cold, and the road **to** the hospital was four miles long.

> 南岸にいる看護師は、北岸にいる患者に渡す手紙を持っていた。窓から、その人の部屋が見えた。夏ならときどき川を泳いで渡ったが、今日は水があまりに冷たく、病院までは道をたどると4マイルもあった。

<a id="p09-2"></a>

**2**　She set off **along** the bank. The path ran **alongside** the railway, then disappeared **behind** a row of houses. A boy fishing **below** the road called up to her. ‘Are you going **towards** the bridge?’

> 彼女は岸に沿って歩き出した。小道は線路と並んで続き、やがて家並みの裏に隠れた。道より低いところで釣りをしていた少年が、下から声をかけた。「橋のほうへ行くの？」

<a id="p09-3"></a>

**3**　The nurse nodded. ‘I have to go **over** it, then back **via** the market.’ The boy pointed. Just **beyond** the houses, steps led **through** a little garden to the water. A boat was waiting **beneath** the bridge.

> 看護師はうなずいた。「橋を渡って、それから市場を通ってこっちのほうへ戻らなきゃいけないの」少年が指さした。家並みのすぐ先に階段があり、小さな庭を抜けて水辺まで下りていた。橋の真下には舟が待っていた。

<a id="p09-4"></a>

**4**　‘My father takes the hospital staff across. He can take a letter too.’ She watched him put it in his pocket. That evening the patient wrote back on the envelope. There was just room for two words of thanks.

> 「父さんが病院で働く人たちを向こう岸に渡してる。手紙だって届けられるよ」彼が手紙をポケットにしまうのを彼女は見届けた。その晩、患者は封筒に返事を書いた。二語のお礼なら、ちょうど書く余白があった。

**読みの問い**　少年は橋の方角を尋ねただけなのに、看護師の返事からは橋を渡ることまで分かる。違いはどの二語に表れているか。

<a id="r10"></a>

### 10　地図の星はどこにある

<a id="p10-1"></a>

**1**　‘**Where** is the old bridge?’ I asked. The woman selling maps pointed to a red star. ‘You are **there**.’ I bought the map. I liked the sound of that. I had hardly set **out**, and I had already arrived.

> 「古い橋はどこですか」と私が尋ねると、地図を売っている女性は赤い星を指さした。「あなたはそこにいます」私はその地図を買った。うれしい話だ。出かけたばかりだというのに、もう着いたことになる。

<a id="p10-2"></a>

**2**　A bird flew **low** over the river. A boat drew **near**. There was a bridge **nearby**, but it was made of bright new steel. The old stone bridge was **nowhere** in sight.

> 一羽の鳥が川の上を低く飛んだ。舟が一そう近づいてきた。確かに近くに橋はあったが、ぴかぴかの新しい鋼鉄製だった。古い石橋はどこにも見当たらなかった。

<a id="p10-3"></a>

**3**　A boy went **past** with a fishing rod. ‘Go **north** along the bank,’ he said. ‘Turn **right** at the wall. There is a gap you can just get **through**. Then go **straight** on until you see the stone.’

> 釣りざおを持った少年が通り過ぎた。「岸に沿って北へ。塀のところで右に曲がって。どうにか通り抜けられる隙間があるよ。そこを抜けたら、石が見えるまでまっすぐだよ」

<a id="p10-4"></a>

**4**　I turned **round** to thank him. He was already walking **south**. On the old bridge I found another woman selling maps. She had just left the new bridge to work **somewhere** quiet. She was facing **west**, watching the sun go down. The star on her map was still at the new bridge. I gave her my map and took hers back to the woman at the new bridge.

> お礼を言おうと振り返ると、少年はもう南へ歩いていた。古い橋にも地図を売っている女性がいた。静かなところで働きたいと、新しい橋から移ってきたばかりだという。彼女は西を向いて夕日を眺めていた。彼女の地図の星はまだ新しい橋の位置にあった。私は自分の地図を彼女に渡し、彼女の地図を新しい橋にいる女性のところへ持っていった。

**読みの問い**　舟と橋のうち、こちらとの距離が縮まっていると書かれているのはどちらか。どの表現で分かるか。

<a id="r11"></a>

### 11　向かいの席にいる友達

<a id="p11-1"></a>

**1**　‘**Anywhere** near the station will do,’ my friend said. I chose a small hotel just beyond the station, **near** the bridge, and asked her to meet me in the front room. When I arrived, she sent a message. ‘I can see the bridge. Where are you?’

> 「駅の近くならどこでもいいよ」と友達が言った。私は駅を少し過ぎた、橋の近くの小さなホテルを選び、表の部屋で落ち合おうと伝えた。着くと友達からメッセージが来た。「橋が見えるよ。どこにいるの？」

<a id="p11-2"></a>

**2**　I went **up** the stairs to look for her. Nobody. I looked **out** the window. There she sat in a hotel **opposite** mine, waving at somebody on the street **outside** my window.

> 私は階段を上って捜した。誰もいない。窓の外を見ると、友達は私のホテルの向かいのホテルに座って、こちらの窓の外の通りにいた誰かに手を振っていた。

<a id="p11-3"></a>

**3**　I went **down** the stairs and hurried **past** the reception desk. There was a fence **between** the hotels. By the time I had gone **round** the fence, she was coming round the other end.

> 私は階段を下り、急いで受付の前を通り過ぎた。二軒のホテルの間には柵があった。私が柵を回り込んだとき、友達はもう反対の端を回ってこちらへ来るところだった。

<a id="p11-4"></a>

**4**　This time I stopped walking. ‘**Somewhere** with only one door would suit us better,’ I said. We found a bench. It had no doors at all.

> 今度は私が歩くのをやめた。「出入口が一つしかないところのほうが、私たちにはよさそうだね」と言った。見つけたベンチには、出入口が一つもなかった。

**読みの問い**　near という場所の指定で行き違いが起きたのはなぜか。そのあと opposite で初めて何が決まったか。

<a id="r12"></a>

### 12　二通りの雨の地図

<a id="p12-1"></a>

**1**　I was asked **to** draw a map of the village for people on foot. **One** morning I followed two children to school. **Whenever** it rained, they took a longer route **because** the short path flooded. My map showed the short path, **but** it did not show the rain.

> 村を歩く人のために地図を描くよう頼まれた。ある朝、学校へ向かう子ども二人の後をついていった。雨が降ると決まって二人は遠回りをした。近道が水につかるからだ。私の地図には近道が載っていても、雨までは載っていなかった。

<a id="p12-2"></a>

**2**　‘Put a blue line **where** the water comes over the path,’ said one. ‘**Whether** we use the path depends on how deep the water is.’ ‘**Wherever** you put your line, somebody will think it is a river,’ said the other.

> 「道に水があふれるところに青い線を引いて」と一人が言った。「そこを通るかどうかは、水の深さによるんだ」「どこに線を引いたって、川だと思う人がいるよ」ともう一人が言った。

<a id="p12-3"></a>

**3**　We settled on using two maps **until** we could find a better answer. On a dry day you opened the map on the left, **whereas** on a wet day you opened the one on the right. Everything was the same **except** that one thin line changed from a path into a question.

> もっといい方法が見つかるまで、地図は二枚にした。雨のない日は左の地図を、雨の日は右の地図を開く。どちらも同じだったが、ただ一本の細い線だけが、道を表していたのに、通れるかどうかという問いに変わっていた。

**読みの問い**　where を使う子と wherever を使う子は、青い線を引く場所について何が違うことを言っているか。

<a id="r13"></a>

### 13　切符の安い買い方

<a id="p13-1"></a>

**1**　We were **abroad** when my sister went **downtown** to buy two tickets for a train going **east**. ‘Buy **direct** from us and save money,’ said the notice. She bought the tickets **cheap**. The station was not **far** from our room.

> 私たちが外国にいたとき、妹が街の中心部へ、東行きの列車の切符を二枚買いに行った。「直接お求めならお安くなります」と掲示にあった。妹は安く切符を手に入れた。駅は私たちの部屋から遠くなかった。

<a id="p13-2"></a>

**2**　We left **early** and walked **fast**. At the station a man shook his head. ‘Your train leaves from the station at the airport, six miles **away**. You can pay **extra** to change your tickets and leave from here. **Alternatively**, you can take the bus there.’

> 私たちは早く出て、足早に歩いた。駅で係員が首を横に振った。「お二人の列車は六マイル離れた空港駅から出ます。追加料金を払えば、この駅から乗れる切符に変更できます。もう一つの方法は、バスで向こうの駅まで行くことです」

<a id="p13-3"></a>

**3**　We could **barely** afford the change. **Besides**, the bus was outside. We rode it to the airport and waited. Our train was running **late**. My sister looked no **further** than the price on her ticket. ‘A good deal,’ she said. On the way **home** I bought our tickets **elsewhere**. This time I read the name of the station.

> 私たちにとって変更料はどうにか払える額だった。おまけに外にはもうバスがいた。私たちは空港まで乗って列車を待った。列車は遅れていた。妹は切符の値段しか見ていなかった。「お買い得だね」と妹は言った。帰りには私が別の所で切符を買った。今度は駅名も読んだ。

**読みの問い**　alternatively と besides は、どちらも次の可能性や理由を導入する。この場面で、どちらが選べる二案を作っているか。

<a id="r14"></a>

### 14　安い切符ほど早く着く？

<a id="p14-1"></a>

**1**　At the station I asked for a cheap ticket to the coast. The woman at the desk wrote down four numbers. ‘**Thirteen**, **fourteen**, **fifteen** and **sixteen** pounds. Which bus do you want?’ I pointed to the lowest price. ‘The slow bus, I suppose?’

> 駅で海岸までの安い切符を頼んだ。窓口の女性は数字を四つ書いた。「十三、十四、十五、十六ポンド。どのバスにします？」私はいちばん安い値段を指した。「きっと時間がかかる便ですね？」

<a id="p14-2"></a>

**2**　She wrote a time beside each price. ‘The first takes **thirty** minutes. The other three take **forty**, **fifty** and **sixty** minutes. The first goes straight there. The last stops at every village along the coast.’

> 彼女は値段の隣に、それぞれの所要時間を書いた。「最初の便は三十分です。ほかは順に四十分、五十分、六十分。最初の便は直行で、最後の便は海沿いの村に一つずつ止まります」

<a id="p14-3"></a>

**3**　‘Why would anyone pay more to arrive later?’ I asked. A man behind me put his money on the desk. ‘Because I live in one of the villages on the way.’

> 「なぜ、よけいにお金を払って遅く着く便を選ぶ人がいるんでしょう」と聞くと、後ろの男性が窓口にお金を置いた。「私はその途中の村に住んでいるからですよ」

**読みの問い**　値段を見た場面の thirteen と、所要時間を書き足した場面の thirty は、それぞれどの単位の数か。どちらも同じ便を指すだろうか。

### 同じ場面で言い換える　2　橋の方へ、橋を渡って

太字に注目して、場面をどう読み替えるか考えよう。

I walked **towards** the bridge.

> 私は橋の方に歩いた。

I walked **across** the bridge.

> 私は橋を歩いて渡った。

橋の手前で引き返した人でも、一文目なら言える。二文目では橋を通って反対側に出ている。

### 第2部　読みの確認

**[08　橋を渡ったのは誰か](#r08)**　between は二軒の間を指し、beyond はその先まで視線を伸ばす。橋の上の語り手からは、まず家と小道、その奥に畑が見える。

**[09　橋を渡らない手紙](#r09)**　towards は橋を向いて進む方向を示す。over はここでは、橋を通って向こう岸へ移る経路を示す。

**[10　地図の星はどこにある](#r10)**　舟。drew near は「近づいてきた」と距離の変化を描く。橋についての nearby は、その場所からすでに近いことを示す。

**[11　向かいの席にいる友達](#r11)**　near the bridge は橋との距離が近いことしか示さず、両方のホテルが条件に合う。opposite mine で、どちらのホテルを基準に、どちら側を探せばよいかが決まる。

**[12　二通りの雨の地図](#r12)**　最初の子は水が道にあふれる特定の場所を指定している。もう一人は場所をどこに決めても、線を川と読み違える人が出てくると言っている。

**[13　切符の安い買い方](#r13)**　alternatively が「変更料を払うか、バスで行くか」をつなぐ。besides は、変更料の負担に加えてバスが目の前にあるという、同じ選択を支える理由を足す。

**[14　安い切符ほど早く着く？](#r14)**　十三ポンドと三十分で、同じ直行便。片方は値段、もう片方は所要時間で、単位が変わる。

---

<a id="part3"></a>

## 第3部　時計が鳴るまで

真夜中をまたぐと「明日」は「今日」になる。時刻、呼び方、約束のうち、何が動いたのだろう。

<a id="r15"></a>

### 15　まだ宛先のない手紙

<a id="p15-1"></a>

**1**　‘**Hi**, is this the office that sends letters to the future?’ ‘**Yes**. **What** year do you want?’ ‘I am not sure. **Which** year would you choose?’ ‘I work here,’ said the woman. ‘I only get to choose the stamp.’

> 「やあ、ここが未来に手紙を送る窓口？」「はい。何年をご希望ですか？」「まだ決めていません。あなたならどの年を選びます？」「私はここの職員ですからね」と女性は言った。「私が選べるのは切手だけです」

<a id="p15-2"></a>

**2**　‘Writing to myself **used to** be easy,’ the visitor said. ‘I **would** just leave a note on my bed. By morning I had usually forgotten it.’ ‘You **can** still do that,’ said the woman. ‘You **can** even use our paper. But you **cannot** send a letter from here without a date.’

> 「昔は自分に手紙を書くのなんて簡単だったんです」と客は言った。「ベッドにメモを置いておくだけだったんです。たいてい朝には、そのメモのことを忘れていましたよ」「今でもそれはできますよ。ここの紙を使ってくださっても結構です。ただ、日付がなければここからは送れません」

<a id="p15-3"></a>

**3**　‘**All right**. I **will** take the paper.’ At the door he turned back. ‘**Bye**. See you tomorrow.’ ‘**Goodbye**,’ said the woman. ‘There. You **have** chosen a date after all.’

> 「分かりました。紙をいただきます」出口で彼は振り返った。「じゃあ、また明日」「さようなら」と女性は言った。「ほら、結局、日を一つお決めになりましたね」

**読みの問い**　職員が続けて使う二つの can のうち、本人の自由でできることと、職員の許可でできることはそれぞれ何か。

<a id="r16"></a>

### 16　日付をまたぐ切符

<a id="p16-1"></a>

**1**　‘**When** does the last train leave?’ I asked. ‘At five past twelve,’ the man at the window said. It was nearly twelve **o'clock** at night. ‘So I shall travel **tomorrow**?’ He looked at the clock. ‘Yes, if you buy your ticket **now**.’

> 「終電はいつ出ますか」「十二時五分です」と窓口の男性が言った。夜の十二時になろうとしていた。「では、私が乗るのは明日ですね？」彼は時計を見た。「ええ、今お買いになるなら」

<a id="p16-2"></a>

**2**　He left the little lamp **on** over the window. ‘First choose the station. **Next**, choose the date. I shall count the money **meanwhile**.’ I had just touched the screen **once** when the station clock began to strike.

> 男性は窓口の上の小さな明かりをつけたままにした。「まず駅を選んでください。次に日付です。その間にお金を数えますから」私が画面に一度触れたところで、駅の時計が鳴り始めた。

<a id="p16-3"></a>

**3**　‘Your train will be here **presently**,’ he said. ‘It leaves **shortly** after midnight. It will **soon** be too late to buy a ticket.’ I took my glove **off**. My finger was quicker without it.

> 「もうじき列車が来ますよ。真夜中を少し過ぎたら発車です。切符が買えるのもあと少しですよ」私は手袋を脱いだ。素手のほうが指を速く動かせた。

<a id="p16-4"></a>

**4**　The clock fell silent. ‘Let us get this **over** with,’ I said. ‘What about the date?’ I asked. ‘Is the train still running **tonight**?’ ‘Yes. But the train you meant to catch tomorrow leaves **today**. You came in **yesterday**.’ I chose the date and **then** paid. The train had not arrived **yet**.

> 鐘の音がやんだ。「これを済ませてしまいましょう」と私は言った。「日付はどうなります？　列車はまだ今夜走るんですよね？」「ええ。ただ、明日乗るつもりだった列車は、今日出るんです。あなたがここに来たのは昨日です」私は日付を選び、それから代金を払った。列車はまだ来ていなかった。

**読みの問い**　夜の十二時を過ぎても同じ晩の列車に乗る。客が選ぶ日を指す言葉はどう変わったか。その間、列車の出発予定はどうなったか。

<a id="r17"></a>

### 17　どちらの時計の正午か

<a id="p17-1"></a>

**1**　Our station has had two clocks **since** the flood. One hangs **at** the entrance and one above the ticket office. **Throughout** the winter they agreed. Then a passenger came in just **before** noon and found the ticket office closed.

> 洪水以来、駅には時計が二つある。一つは出入口に、もう一つは切符売り場の上に掛かっている。冬のあいだずっと、二つは同じ時刻を示していた。ところがある日、正午の少し前に来た客には、もう窓口が閉まっていた。

<a id="p17-2"></a>

**2**　‘**According to** the notice, you sell tickets **till** noon. And you are closed **until** two. It is only ten to twelve.’ The clerk looked up. ‘By my clock it is two minutes **after** twelve.’

> 「掲示には、切符を売るのは正午まで、次に開くのは2時とあります。まだ12時10分前ですよ」係員は見上げた。「こちらの時計では12時2分です」

<a id="p17-3"></a>

**3**　**During** the lunch break the clerk checked both clocks against the radio. **Upon** hearing the signal, she saw that her clock was fast. **Following** a call to the manager, she put a note on the door. ‘We shall open again **within** ten minutes.’

> 昼休みに係員は、ラジオで二つの時計を確かめた。時報を聞いた瞬間、自分の時計が進んでいると分かった。駅長に電話したあと、扉に張り紙を出した。「10分以内に窓口を再開します」

<a id="p17-4"></a>

**4**　‘Since **when** have you sold tickets during lunch?’ the passenger asked. ‘Since today. We closed twelve minutes early this morning. You can still have your ticket.’

> 「いつから昼休みにも切符を売るようになったんです？」と客が聞いた。「今日からです。今朝は十二分早く閉めてしまいましたから。切符は、今からでもお買いいただけますよ」

**読みの問い**　「10分以内に開く」と「2時まで閉まっている」は、それぞれ何を時間で区切っているか。

<a id="r18"></a>

### 18　明かりが消える条件

<a id="p18-1"></a>

**1**　‘We **have to** finish **before** the sun goes down,’ said the guide. ‘You **must** keep this lamp with you. You **need** not keep it on.’ ‘**Could** you show me how it works?’ I asked. ‘I **may** need it in the tunnel.’

> 「日が沈む前に終えなくては」と案内役が言った。「このランプは必ず携帯してください。つけっぱなしにする必要はありません」「使い方を見せていただけますか。トンネルで必要になるかもしれません」

<a id="p18-2"></a>

**2**　‘**Shall** we try it here? Cover the glass **while** I turn the handle. **Once** I stop, take your hand away.’ A pale circle appeared on the wall. ‘**Wow**,’ I said. ‘How long will it last?’ ‘**Till** your arm gets tired, if you keep turning.’

> 「ここで試しましょうか。私がハンドルを回す間、ガラスを手で覆ってください。私が回すのをやめたら、手を離して」壁に淡い光の輪が現れた。「わあ、どれくらいもちますか？」「回し続けるなら、腕が疲れるまでですよ」

<a id="p18-3"></a>

**3**　‘You **should** try it yourself. The handle **might** stick. We **ought** to find out here.’ I turned it. The light died. The guide looked down at his hand on the glass. ‘**OK**, try it again. This time I will take my hand away too.’

> 「ご自分でもやってみてください。ハンドルが途中で引っかかるかもしれません。ここで確かめておきましょう」私が回すと光が消えた。案内役は、ガラスを覆っている自分の手に目を落とした。「よし、もう一度。今度は私の手もどけますね」

**読みの問い**　need not keep it on と must keep this lamp with you を両方守ってトンネルに入る方法を一つ挙げる。

<a id="r19"></a>

### 19　閉じた店は開いているか

<a id="p19-1"></a>

**1**　**As** I passed the little shop, the owner was painting the word ‘Closed’ on **both** doors. ‘**Since** you are still here, may I buy some paint?’ I asked. ‘You may, **albeit** in a rather unusual way. Come in through the garden.’

> 小さな店の前を通りかかると、店主が両方のドアに「閉店」と書いていた。「まだいらっしゃるのなら、ペンキを売っていただけますか」「いいですよ。もっとも、ちょっと妙な買い方になりますがね。庭から入ってください」

<a id="p19-2"></a>

**2**　‘**Either** door will open **if** you push it,’ he explained. ‘**Neither** door will close **unless** I lift it. I cannot lift it **and** paint it at the same time, **so** both doors are open.’ ‘May I come in this way, then?’ ‘You would be in my way, **plus** the paint is wet.’

> 「どちらのドアも押せば開きます。でも、私が持ち上げないかぎり、どちらも閉まりません。持ち上げながらペンキは塗れないので、二枚とも開けてあるんです」「じゃあ、ここから入っても？」「仕事の邪魔になりますし、そのうえペンキがまだ乾いていません」

<a id="p19-3"></a>

**3**　**After** I paid, he showed me the way out through the garden. ‘**Now** that you have your paint, what will you do with it?’ ‘Write “Open” on my garden gate,’ I said. ‘I would like people to know **that** they can come in.’

> 代金を払うと、店主は庭を通って外まで案内してくれた。「さて、ペンキも手に入ったし、何に使うんです？」「うちの庭の門に『開いています』って書きます。入っていいって分かってもらいたいので」

**読みの問い**　Either door will open と Neither door will close は矛盾するか。押す場合と持ち上げない場合を分けて考える。

<a id="r20"></a>

### 20　同じだけ進む二つの時計

<a id="p20-1"></a>

**1**　Our laboratory had two clocks. At noon both clocks were **consistently** fast by **approximately** a minute. The director said they were **broadly** in agreement. ‘They are, but what do they agree with?’ asked a student. ‘Can we test that **empirically**?’

> 研究室には時計が二つあった。正午に見ると、どちらの時計も決まって一分ほど進んでいた。所長は、二つの時計はおおむね一致していると言った。「ええ。でも、いったい何と一致しているんですか。それを測って確かめられますか」と学生が尋ねた。

<a id="p20-2"></a>

**2**　She tested the clocks **individually**, comparing each with the time on the radio. They showed **exactly** the same error. They worked **independently**, or so we thought. **Additionally**, both had enough power to run all week. A weak battery could not **adequately** explain the error.

> 学生は時計を一つずつ、ラジオの時報と照らし合わせた。誤差はぴたりと同じだった。二つは独立して動いている、と私たちは思っていた。加えて、どちらも一週間動くだけの電力があった。電池の消耗では誤差を十分に説明できなかった。

<a id="p20-3"></a>

**3**　We looked more **critically** at our test. The student **continually** had to ask visitors not to touch the clocks. One man made us pause. He was **constantly** worried about missing his train. Each morning he set both clocks a little fast. **Consequently**, our result was **essentially** a measure of his fear. The clocks were **entirely** innocent, and he caught his train **considerably** more often than I caught mine.

> 私たちは試験方法をもう少し批判的に見直した。学生は訪問者に、時計に触れないでほしいと繰り返し頼まなければならなかった。そのうちの一人を見て、私たちは考え込んだ。その男性はいつも電車に乗り遅れるのを心配していて、毎朝二つの時計を少し進めていた。つまり結果が実質的に測っていたのは彼の不安だった。時計にはまったく罪がなく、彼が電車に間に合う割合は私よりずっと高かった。

**読みの問い**　二つを一台ずつ検査したことと、二つの誤差が独立に生じたことのうち、観察で確認できたのはどちらか。

<a id="r21"></a>

### 21　二人の庭師と一本の影

<a id="p21-1"></a>

**1**　Two years **ago** my brother and I bought six small plants for a pound **each**. We divided them **equally**. Mine grew **best** near the wall. His grew **better** out in the garden than beside the house. We did not treat them **alike**.

> 二年前、兄と私は小さな苗を六株、一株一ポンドで買い、半分ずつ分けた。私の株は塀の近くでいちばんよく育った。兄の株は家の脇より庭の中のほうがよく育った。二人の育て方は同じではなかった。

<a id="p21-2"></a>

**2**　I **always** watered mine before breakfast. He went to his plants soon **after**. I wrote down their height **daily**. He stood in the same place and took one picture **annually**, each spring. **Afterwards** he put the camera away for another year.

> 私は必ず朝食前に水をやった。兄が自分の株を見に行くのはその少し後だった。私は高さを毎日記録した。兄は毎年春に同じ場所に立ってカメラを構えたので、写真は年に一枚ずつあった。撮り終えると、また一年間カメラをしまい込んだ。

<a id="p21-3"></a>

**3**　‘People **commonly** say plants need light,’ I said. ‘But mine like the wall.’ He set his pictures beside my figures. We could **easily** see what I had missed. A branch above the wall was **gradually** losing its leaves. I had been **actively** looking for a difference below my knees. He had caught it above my head.

> 「植物には光が必要だとよく言うだろう。でも私の株は塀際が好きなんだ」と私は言った。兄は私の数値の横に写真を並べた。私が見逃したものは、一目で分かった。塀の上にかかる枝の葉が、少しずつ減っていた。私は膝より下を熱心に見て、違いを探していた。兄が捉えていたのは私の頭上の変化だった。

**読みの問い**　兄の撮影と私の測定ではどちらが細かな変化を追えるか。それでも兄の記録にしか残らなかったものは何か。

### 同じ場面で言い換える　3　義務を外す、禁止を加える

太字に注目して、場面をどう読み替えるか考えよう。

You **must** keep the lamp on.

> ランプはつけておかなくてはいけない。

You **need not** keep the lamp on.

> ランプをつけておく必要はない。

You **must not** keep the lamp on.

> ランプをつけたままにしてはいけない。

つけたままでも消してもよいのは二文目だけ。

### 第3部　読みの確認

**[15　まだ宛先のない手紙](#r15)**　ベッドにメモを置くのは本人が今でもできること。窓口の紙を使うのは職員がここで認めたこと。後者を聞いた客は、実際に紙を受け取る。

**[16　日付をまたぐ切符](#r16)**　窓口に来たときの tomorrow が、鐘が鳴った後には today になった。変わったのは客が日付を呼ぶ言葉で、列車は一貫して午前零時五分発の予定だった。

**[17　どちらの時計の正午か](#r17)**　within は開けるという一回の行為に期限を設ける。until は閉まった状態が続く、その終点を示す。

**[18　明かりが消える条件](#r18)**　ランプを消したまま持って入ればよい。前者で自由になるのは点灯し続けるかどうかで、携帯する義務は後者に残る。

**[19　閉じた店は開いているか](#r19)**　矛盾しない。どちらを選んでも押せば開く。一方、持ち上げなければ二枚とも閉まらない。対象は同じ二枚でも、条件と動きが違う。

**[20　同じだけ進む二つの時計](#r20)**　individually は学生が一台ずつ検査した手順を示す。independently は二台について当初そう思われていたという話で、同じ人物が時刻を動かしていた以上、誤差には共通の原因がある。

**[21　二人の庭師と一本の影](#r21)**　時間の間隔なら daily の測定のほうが細かい。annually の写真には測定対象の外の枝も写る。gradually は記録の頻度ではなく、葉が減っていく変化の仕方を示す。

---

<a id="part4"></a>

## 第4部　食卓から店先まで

おわんをもう一つ、と頼まれた料理人はスープを出そうとする。一つ増えるのは器か、中身か。

<a id="r22"></a>

### 22　もう一杯か、もう一個か

<a id="p22-1"></a>

**1**　In **our** kitchen, **each** pot has **its** own job. We make soup in the small pot on quiet days. The large pot holds **double** the amount of soup in the small one. **Half** the soup in the large pot goes to the evening class. Is there **any** soup left for lunch? Yes, just as much as in the small pot.

> 私たちの台所では、どの鍋にもそれぞれ役目がある。人が少ない日は小鍋でスープを作る。大鍋に入っているスープは、小鍋の倍の量だ。大鍋のスープの半分は夜の教室に届ける。昼食に回すスープは残るか。残る。ちょうど小鍋に入っているのと同じ量だ。

<a id="p22-2"></a>

**2**　Today there are a **dozen** bowls on the table. We have **enough** soup for everyone, but not **much** bread. ‘Could we have **another** bowl?’ asks a child. ‘There is **some** soup left,’ says the cook. ‘I meant an empty bowl. It is for the bread.’

> 今日はテーブルにおわんが十二個ある。スープは全員に行き渡るけれど、パンはあまりない。「もう一椀、もらえますか」と子どもが聞く。「スープなら少し残ってるよ」と料理人。「欲しいのは空のおわん。パンを入れたいの」

<a id="p22-3"></a>

**3**　Before the meal, **every** bowl held a spoon. Now **all** the spoons are in a single bowl and the bread has a bowl of its own.

> 食事の前はどのおわんにもスプーンが一本入っていた。いまはスプーンが全部一つのおわんに集まり、パンにはパン専用のおわんがある。

**読みの問い**　another bowl を聞いた料理人と、頼んだ子どもは、それぞれ何がもう一つ欲しいと思っていたか。

<a id="r23"></a>

### 23　いちばん少ない一杯

<a id="p23-1"></a>

**1**　My father usually makes a pot of soup. Today he made **double**, because he expected six people. Only **half** came. ‘There is **plenty**,’ he said. ‘Tell me when you have **enough**.’

> 父はふだん鍋一つ分のスープを作る。今日は6人来る予定だったので、倍の量を作った。来たのは半数だけだった。「たっぷりあるよ。自分に十分な量になったら言ってくれ」

<a id="p23-2"></a>

**2**　My aunt asked for a **little**. My uncle asked for the **same**. I was saving room for cake, so I took the **least**. Yet when my father turned back to the pot, the level was still falling.

> おばは少しだけ頼んだ。おじも同じ量を頼んだ。私はケーキの分を空けておきたくて、3人の中でいちばん少なく取った。それなのに、父が鍋のほうを振り向くと、スープのかさはまだ減り続けていた。

<a id="p23-3"></a>

**3**　‘Who had a **lot**?’ he asked. We all showed him our bowls. ‘I did not take **much**,’ said my uncle. ‘I took even **less**,’ I said. Then my aunt put down the bread. Beneath the pot a dark circle was slowly growing.

> 「たくさん取ったのは誰だい？」と父が聞いた。私たちはそろって器を見せた。「私はあまり取らなかったよ」とおじ。「私はそれよりさらに少ないよ」と私が言った。そこでおばがパンを置いた。鍋の下で、黒っぽい染みがゆっくり広がっていた。

<a id="p23-4"></a>

**4**　We lifted the pot over a bowl and caught **some** before it reached the floor. ‘Would anyone like **more**?’ asked my father. For once, he had a good reason to be in a hurry.

> 鍋を持ち上げて下に器をあてがい、床に落ちる前にいくらか受けた。「おかわりする人は？」と父が聞いた。今回ばかりは、急ぐのにももっともな理由があった。

**読みの問い**　the least と even less は、誰を基準に私の一杯を説明しているか。

<a id="r24"></a>

### 24　最後のビスケット

<a id="p24-1"></a>

**1**　I picked up the **last** biscuit **whilst** my family were still discussing how to share it. ‘Would you like half, **or** would you like me to put it back?’ I asked. ‘**Although** it is small, it could feed two,’ my brother said. He had neither a plate **nor** a knife.

> 家族がまだ分け方を相談している間に、私は最後のビスケットを手に取った。「半分いる？　それとも戻そうか？」「小さくても二人分にはなるよ」と兄が言った。兄は皿もナイフも持っていなかった。

<a id="p24-2"></a>

**2**　I broke it. ‘Yours is bigger **than** mine is,’ I said. ‘It looks bigger, **though** it may weigh less,’ he replied. The smaller piece was thick. The larger one had a hole in it. I put both pieces back on the plate. We went to find the kitchen scales. **When** we got back, the plate was empty.

> 割ってみると、「そっちの方が私のより大きいね」と私は言った。「大きく見えるけど、軽いかもしれないよ」と兄。小さい方には厚みがあり、大きい方には穴があった。私は二つとも皿に戻した。二人で台所のはかりを探しに行って、戻ると皿は空だった。

<a id="p24-3"></a>

**3**　The dog **was** sitting under the table. ‘He has eaten it all,’ my brother said. ‘**Yet** I still think you got the smaller half.’

> 犬が机の下に座っていた。「全部食べられたね」と兄は言った。「それでもやっぱり、そっちの方が小さかったと思うよ」

**読みの問い**　兄は though の前で見た目について認めたうえで、何をまだ判断できないと言っているか。

<a id="r25"></a>

### 25　入場無料の市場

<a id="p25-1"></a>

**1**　Our town **formerly** had two markets. **Historically**, the river had divided the town. People on the two banks remained **culturally** distinct. At one market people sold **exclusively** to restaurants. At the other you could buy one apple and discuss it **freely** for an hour.

> 私たちの町には以前、市場が二つあった。昔から町は川で二つに分かれ、両岸の人々はそれぞれ異なる文化を保っていた。一方は料理店だけを相手に売っていた。もう一方ではリンゴを一つ買い、一時間かけて好きなようにそのリンゴについて話し合うこともできた。

<a id="p25-2"></a>

**2**　I work **full-time** at a farm. We sell our fruit **locally**. Keeping two places open was no longer **economically** possible. The cost was **especially** high in winter. We could work more **efficiently** under one roof. Could we serve both groups **effectively** there?

> 私は農場で常勤で働いている。私たちの果物は地元で売っている。二か所を開けておくのは費用の面でもう無理だった。とりわけ冬はお金がかかった。一つの屋根の下なら手間は減る。けれど、そこで両方のお客さんの要望にきちんと応えられるだろうか。

<a id="p25-3"></a>

**3**　‘It is **basically** a question of time,’ said my sister. ‘Let the restaurants come early. Open to everyone at nine.’ We would **happily** pay for an extra hour if it would save the market **long-term**. Children could come in **free**. My sister now visits **frequently**, though I have yet to see her buy an apple.

> 「要は時間の問題だよ」と妹が言った。「料理店には早めに来てもらって、九時に誰でも入れるようにすればいい」それで先々まで市場を残せるなら、私たちは喜んで一時間分の追加費用を負担するつもりだった。子どもは無料で入れることにした。妹は今ではしょっちゅう顔を出す。もっとも、リンゴを買うところはまだ見たことがない。

**読みの問い**　一つの市場にまとめた場合、効率と効果はそれぞれ何で判断できるか。子どもの入場とリンゴについて話す自由の違いも確かめよう。

<a id="r26"></a>

### 26　無料の試合の値段

<a id="p26-1"></a>

**1**　A notice painted **by** a pupil hung on the school gate. ‘Football on Friday. Teachers **versus** students. One pound **per** seat, **plus** a pound for tea. Entry free.’ Everyone **but** my brother seemed quite happy about it.

> 生徒がペンキで書いた掲示が校門に掛かっていた。「金曜日、サッカーの試合。先生対生徒。席は一席につき1ポンド。お茶は別に1ポンド。入場無料」私の兄を除くと、みんなこれで納得しているようだった。

<a id="p26-2"></a>

**2**　He went in **with** me **without** any money. **Despite** the rain, a crowd had come, **including** a woman who had never seen a match. Every seat was taken **except** one with a pool of water on it.

> 兄はお金を一銭も持たずに私と入った。雨にもかかわらず、人が大勢来ていた。サッカーの試合を一度も見たことのない女性もいた。水がたまっている一席を除いて、席はすべて埋まっていた。

<a id="p26-3"></a>

**3**　**Amid** all the shouting he found the pupil who had written the notice. ‘I want to ask **about** the price. What do I get for nothing?’ The pupil spread his coat on the grass and used it **as** a seat.

> 兄は大歓声の中で、掲示を書いた生徒を見つけた。「値段のことを聞きたいんだけど、ただだと何がもらえるの？」生徒は上着を芝生に広げて、座る場所にした。

<a id="p26-4"></a>

**4**　‘A place to stand, **regardless of** how much money you have. A place to sit if you bring a coat. And at the moment, more water than you could possibly drink.’

> 「持っているお金の額に関係なく、立って見る場所はあるよ。上着を持ってくれば、座る場所も。それに今なら、どうやっても飲みきれないほどの水もね」

**読みの問い**　with me と without any money は同じ入場について、何が一緒で、何を持っていなかったと伝えているか。

<a id="r27"></a>

### 27　海外へ出たのは椅子か

<a id="p27-1"></a>

**1**　My aunt works **part-time** in a furniture shop. She can repair a chair with one hand while the other holds a cup. Her work is **reportedly** known **worldwide**. Yet she has never carried a single chair **overseas**.

> おばは家具店でパートの仕事をしている。片手にカップを持ったまま、もう片方の手で椅子を直せる人だ。聞くところによると、その仕事は世界じゅうで知られているらしい。それでも椅子を一脚として海外に運んだことはない。

<a id="p27-2"></a>

**2**　I found a film of her **online**. It showed one particular repair, **namely** how to join the leg to the seat without fresh holes. ‘That old chair is **potentially** worth quite a lot,’ I said. She shook her head **sadly**. ‘It belongs to the shop.’

> ネットでおばの動画を見つけた。紹介している修理はただ一つ、つまり、新しい穴を開けずに脚を座面につなぎ直す方法だ。「その古椅子、もしかしたらけっこう値打ちがあるよ」と言うと、おばは悲しそうに首を振った。「お店のものよ」

<a id="p27-3"></a>

**3**　Nobody had paid her for the film. She had made it **regardless**. A teacher had then sent a film showing how to repair a table. Other people had responded **similarly**. The films were now **widely** used in evening classes.

> 誰も動画の代金を払ってくれたわけではなかった。それでもおばは作った。すると、ある先生が机の直し方を撮って送ってきた。ほかの人たちからも同じように返事があった。今では、そうした動画が夜間講座で広く使われている。

<a id="p27-4"></a>

**4**　‘We have made a system **whereby** one good repair can teach a hundred people,’ she said. ‘**Ultimately**, I care more about knowing someone can sit down than about knowing what a chair is worth.’ She pulled a second chair towards me. ‘Try it.’

> 「誰かが一度うまく修理すれば、それで百人が学べる仕組みができたのよ」とおばは言った。「結局のところ、椅子の値段が分かることより、誰かがちゃんと座れると分かることのほうが大事なの」二脚目の椅子を私のほうへ引き寄せた。「座ってみて」

**読みの問い**　worldwide と overseas は似た広がりを連想させる。本文では、何が世界に広まり、何が海外へ運ばれずにいたか。

<a id="r28"></a>

### 28　大きな数にはどのくらいの紙がいるか

<a id="p28-1"></a>

**1**　‘I need a sheet of paper big enough for a **trillion**,’ said a girl who had just come into the shop. ‘What about this one?’ The man held up a sheet the size of a newspaper. ‘Can we try something smaller first?’ She put a card on the desk and wrote a one followed by a **zero**.

> 「一兆が収まるくらい大きな紙をください」と店に入ってきた女の子が言った。「これはどう？」店員は新聞ほどの大きさの紙を持ち上げた。「先にもっと小さいので試していい？」女の子は机にカードを置き、1を書いて、その後に0を一つ書いた。

<a id="p28-2"></a>

**2**　‘Ten. One more zero makes a **hundred**. Another makes a **thousand**.’ She added three more to make a **million**, then three for a **billion** and three for a trillion. Her number occupied less than half the card.

> 「十。ゼロをもう一つ付けると百。もう一つで千」さらに三つ足して百万、次の三つで十億、もう三つで一兆になった。書いた数字は、カードの半分も場所を取らなかった。

<a id="p28-3"></a>

**3**　‘So you only need a card,’ said the man. ‘That depends. I can write the number here. But my teacher said to draw that many stars.’

> 「じゃあカード一枚で足りるね」と店員が言った。「それはどうかな。数を書くならここに収まるけど、先生が言ったのは、その数だけ星を描きなさいってことなの」

**読みの問い**　write the number と draw that many stars では、一兆が何の量を決めているか。

### 同じ場面で言い換える　4　少なさを見る、人がいたことを見る

太字に注目して、場面をどう読み替えるか考えよう。

**Few** guests asked for more soup.

> スープのおかわりを頼んだ客はほとんどいなかった。

**A few** guests asked for more soup.

> スープのおかわりを頼んだ客が何人かいた。

実際の人数が同じでも、少なさに目を向けるか、頼んだ人がいることを伝えるかで言い方を変えられる。

### 第4部　読みの確認

**[22　もう一杯か、もう一個か](#r22)**　料理人は中身まで含めてスープのおかわりと受け取り、子どもはパンを入れる空の器をもう一つ求めていた。another が加える一つは、場面しだいでどちらにも取れる。

**[23　いちばん少ない一杯](#r23)**　the least は食卓の3人全員の中でいちばん少ないという意味。even less のときは、おじが直前に話した量と比べて、それよりさらに少ないと言っている。

**[24　最後のビスケット](#r24)**　見た目の大きさは認めている。重さの比較は別で、大きく見える方が軽い可能性を残している。

**[25　入場無料の市場](#r25)**　efficiently は場所や手間を節約して運営できること、effectively は両方の客の必要を満たせること。come in free は入場料がかからず、discuss it freely は話し方に制限がない。

**[26　無料の試合の値段](#r26)**　一緒に入った相手は語り手。兄の手元になかったのはお金。無料だったのは入場で、掲示された一席ごとの料金は別にかかる。

**[27　海外へ出たのは椅子か](#r27)**　世界に知られたと伝えられているのはおばの仕事。その様子を写した動画は各地で使われた。一方、おば自身が海外へ運んだことがないのは実物の椅子。評判や映像が届く範囲と、物の移動を分けて読める。

**[28　大きな数にはどのくらいの紙がいるか](#r28)**　前者は一兆という値を数字で表記するので、1と十二個の0で足りる。後者では一兆が描く星の個数を決める。

---

<a id="part5"></a>

## 第5部　声が届く場所

先生が声を張るとかえって言葉が聞き取れない。話す人がしたことと、聞き手に起きたことを読み分けよう。

<a id="r29"></a>

### 29　火事の役は誰か

<a id="p29-1"></a>

**1**　‘**Welcome** to the theatre. The children are going to show you how to leave the building in a fire.’ A boy in a red coat took a deep breath. ‘**Attention**!’ he shouted. Everyone stood up except the girl beside him.

> 「劇場へようこそ。これから子どもたちが、火事のときにどうやって建物から出るかをお見せします」赤い上着の男の子が大きく息を吸った。「気をつけ！」その声に、隣の女の子以外は全員立ち上がった。

<a id="p29-2"></a>

**2**　‘**Hey**, are you coming?’ ‘**No**. I am the fire.’ ‘**Oh**. Do you stay here, then?’ ‘**Yeah**, unless the wind changes.’ ‘**Dear** me,’ said the boy. He looked at the open window. ‘**Please**, could somebody close that?’

> 「ねえ、君も来る？」「ううん。私、火事の役」「ああ。じゃあ、ここにいるの？」「うん、風向きが変わらないかぎりね」「これは困った」と男の子は言った。開いた窓に目をやって、「お願い、誰かあれを閉めてくれる？」

<a id="p29-3"></a>

**3**　The girl followed him anyway. ‘**Ah**, I see,’ said the boy. ‘The wind changed.’ ‘**Well**, no,’ she said. ‘The play is over. My coat is out there.’

> それでも女の子は彼の後についてきた。「ああ、分かった。風向きが変わったんだね」「ええと、違うの。お芝居は終わったでしょ。私の上着、外にあるの」

**読みの問い**　最後の Well を「上手に」と訳すと、女の子が何をしているかをどう取り違えるか。

<a id="r30"></a>

### 30　声がよく通る場所

<a id="p30-1"></a>

**1**　In a hall with a stone floor, a teacher asked three of us to listen to a short address. ‘I need to know how **well** you can hear the words. Tell me **openly** if I lose you.’ I sat in the middle. A girl sat **opposite**.

> 石の床の広間で、先生が私たち三人に短い挨拶を聞いてほしいと言った。「言葉がどのくらいよく聞き取れるか確かめたいんだ。聞き取れなくなったら遠慮なく言ってね」私は真ん中に座り、向かいには女の子が座った。

<a id="p30-2"></a>

**2**　He began **quietly**. I could hear him **perfectly**. Then he spoke **loudly** and my seat became the worst place in the room. ‘Please do not speak so **loud**,’ I said. ‘I hear you **worse** when you raise your voice.’

> 先生は静かに話し始めた。一語残らず聞き取れた。ところが先生が大きな声を出すと、私の席はいちばん聞きにくい場所になった。「そんなに大きな声を出さないでください。声を張るとかえって聞こえにくくなります」

<a id="p30-3"></a>

**3**　The little speaker beside him had worked **OK** in class. Here it **suddenly** gave every word back to us. When the two voices said different words **simultaneously**, the sense of the sentence was **utterly** lost. We took notes **separately** so we could compare them later.

> 先生の横にある小さなスピーカーは、教室では普通に使えていた。ここでは突然、一語一語がスピーカーからも返ってきた。二つの声が同時に違う単語を発すると、文の意味がまったく分からなくなった。後で比べられるように、それぞれ別々にメモを取った。

<a id="p30-4"></a>

**4**　He spoke **slowly**, then **quickly**. I copied the date down **wrong** both times. ‘Who did **worst**?’ he asked. Three hands went up. ‘I had no idea the sound was **this** bad.’ He turned the speaker off, and nobody missed the next date.

> 先生はゆっくり話し、次は速く話した。私は二度とも日付を書き間違えた。「いちばん成績が悪かったのは誰？」手が三本上がった。「音がこれほどひどいとは思わなかったな」先生がスピーカーを切ると、次の日付は全員が聞き取れた。

**読みの問い**　聞こえ方について、worse は何と何を比べるか。先生が worst と言ったとき、比較する対象はどう変わったか。

<a id="r31"></a>

### 31　舞台の上の二脚

<a id="p31-1"></a>

**1**　We needed a chair for a play. The queen had to look **very** small when she sat on it. Our first chair was **reasonably** comfortable and **relatively** cheap. It was also **nearly** the same size as the one she had at home.

> 芝居に使う椅子が必要だった。女王が座ったときに、その体がとても小さく見えなければならない。最初の椅子はまずまずの座り心地で、値段も比較的安かった。大きさも、女王役の人が家で使うものとほとんど同じだった。

<a id="p31-2"></a>

**2**　From my seat the queen looked **quite** happy and **somewhat** bored. She certainly did not look **that** small. ‘Are you being **overly** careful with the money?’ she asked. ‘It is **pretty** hard to look lost in a chair that fits.’

> 私の席から見ると、女王はなかなか幸せそうで、少し退屈そうでもあった。確かにそれほど小さくは見えない。「お金のことを気にしすぎじゃない？」と彼女は言った。「体にぴったりの椅子で、埋もれた感じを出すのってけっこう難しいのよ」

<a id="p31-3"></a>

**3**　Our second chair cost only **slightly** more, but its back was **way** above her head. The queen looked a **lot** smaller. She smiled **more** freely on it. ‘Is it **terribly** heavy?’ I asked. It was **remarkably** light for its size.

> 二脚目の椅子は少し高いだけだったが、背もたれは彼女の頭よりずっと高かった。女王はぐんと小さく見え、笑顔もさっきよりのびのびしていた。「ものすごく重いの？」と私が尋ねた。その大きさからすると、驚くほど軽かった。

<a id="p31-4"></a>

**4**　There was one **rather** serious difficulty. The chair was **so** wide that it would not fit through the door. ‘Do we **really** need the door?’ the queen asked. We took the chair through the window. Going in was **much** easier that way. Coming out was easier **too**.

> 一つ、かなり重大な問題があった。椅子の幅があまりに広く、戸口を通らなかった。「本当にその戸口を使う必要がある？」と女王は聞いた。私たちは窓から椅子を運び入れた。そのほうが入れるのはずっと楽だった。出すのもやはり楽だった。

**読みの問い**　The queen looked a lot smaller. で小さくなったのは何か。本当に女王の身長が変わったのか。

<a id="r32"></a>

### 32　舞台の見えない特等席

<a id="p32-1"></a>

**1**　Two small theatres offered to host our school play. ‘**Anyone** who wants to help can visit the theatres,’ said the teacher. Twenty pupils came. **All** agreed that the first theatre had better chairs. Only a **few** asked what you could see from them.

> 二つの小さな劇場が、学校の劇を上演する場所を提供すると言ってくれた。「手伝いたい人なら誰でも、劇場を見に行けますよ」と先生は言った。20人の生徒が来た。最初の劇場のほうが椅子がいいという点では全員一致した。そこから何が見えるかを尋ねたのは、ほんの数人だった。

<a id="p32-2"></a>

**2**　‘Choose **any** you like,’ said the manager, so we tried the seats. **Several** faced a wall. **Many** had a good view of the audience opposite. But **none** gave a small child a clear view of the floor where the actors would sit.

> 「好きな席をどれでもどうぞ」と支配人に言われ、みんなで座ってみた。壁に向いた席がいくつかあった。向かいの観客がよく見える席も多かった。けれども、小さな子どもに、役者たちが座る床をしっかり見せてくれる席は一つもなかった。

<a id="p32-3"></a>

**3**　The second theatre had just two benches, with room for four on each. We tried **both**. **Each** gave a clear view, and a child could sit on **either**. ‘But **neither** can seat twenty,’ said the teacher.

> 二番目の劇場には四人掛けのベンチが二つしかなかった。両方を試した。どちらのベンチからも舞台がよく見え、子どもは好きなほうに座れた。「でも、どちらも一つで20人は座れないわね」と先生が言った。

<a id="p32-4"></a>

**4**　By now **most** of us preferred the second theatre. One girl did the counting. ‘We do not need twenty places. Twelve of us are in the play.’

> このころには私たちの大半が二番目の劇場を気に入っていた。一人の女子生徒が人数を数えた。「20人分もいりませんよ。うち12人は出演するんですから」

**読みの問い**　二番目の劇場で both、either、neither が示す選択肢は同じ。試した数、子どもが選べる範囲、20人座れるベンチの数はそれぞれどうなるか。

<a id="r33"></a>

### 33　いちばん高い音

<a id="p33-1"></a>

**1**　I had worked **hard** for my first concert. I could **hardly** sleep the night before. It meant a great deal to me **emotionally**. My teacher spoke **highly** of our group. Could we sing **any** better with an audience in the room?

> 初めての演奏会に向け、私は懸命に練習してきた。前の晩はほとんど眠れなかった。気持ちの上で、それほど大きな意味のある演奏会だった。先生は私たちのグループを高く評価してくれていた。人前に出たら、今より少しでもうまく歌えるだろうか。

<a id="p33-2"></a>

**2**　There were eight singers **altogether**. I went on **last**. From my place I saw a girl in the front row holding a red balloon **high** above her head. The expression on her face **alone** made me forget the man who had come to judge us.

> 歌い手は全部で八人だった。私は最後に舞台に出た。自分の立ち位置から、最前列の女の子が頭上高く赤い風船を掲げているのが見えた。その子の顔つきだけで、私たちの審査に来た男性のことは頭から消えた。

<a id="p33-3"></a>

**3**　Then the balloon burst. I was **absolutely** certain we had lost our place. Our teacher stepped **forward** and said **firmly**, ‘Start with the second verse.’ We sang it **anyway**. We had already sung the second verse once. The girl was **genuinely** pleased. ‘It was my favourite part,’ she said. ‘**Actually**, I liked it better twice.’

> そのとき風船が割れた。私たちはどこまで歌ったか分からなくなってしまった、と私は確信した。先生は一歩前に出て、きっぱり「二番から」と言った。それでも私たちは歌った。二番はすでに一度歌っていた。女の子は心から喜んでいた。「そこがいちばん好きだったの。ほんとは二回聴けたほうがよかった」と言った。

**読みの問い**　練習の度合いと、眠れた程度をそれぞれ示す語はどれか。先生の評価と風船の位置にも似た形のペアがある。

<a id="r34"></a>

### 34　生放送の鳥

<a id="p34-1"></a>

**1**　A rare bird was **allegedly** living on the roof of our radio station. The story had been reported **extensively**. A visitor told me the path led **directly** to its nest. ‘You cannot use that path **any more**,’ I said. ‘We are **currently** repairing the roof.’

> 珍しい鳥が、うちのラジオ局の屋根にすんでいるという話だった。その話は広く報じられていた。ある見学者は、例の通路は巣へまっすぐ通じていると私に言った。「もうあの通路は使えませんよ。今ちょうど屋根を直しているんです」と私は答えた。

<a id="p34-2"></a>

**2**　We decided to listen from a window and changed the afternoon programme **accordingly**. We told our audience **explicitly** that nobody at the station had seen the bird. The street became **extremely** quiet. Nobody in the next room moved **either**. What **else** could make a whole town hold its breath?

> 私たちは窓から耳を澄ますことにして、それに合わせて午後の番組を変更した。局では誰もその鳥を見ていないことを、聴いている人にもはっきり伝えた。通りはひどく静かになった。隣室でも誰一人動かなかった。町じゅうに息をひそめさせられるものが、ほかにあるだろうか。

<a id="p34-3"></a>

**3**　We **finally** heard a call. It was **incredibly** loud. We broadcast it **live**. **Ironically**, the one person who could explain the call had missed the programme. The man repairing our roof came down for tea, still singing the same three notes. He had **arguably** given the finest performance of his life.

> ついに鳴き声がした。信じられないほど大きな声だった。私たちはそれを生放送で流した。皮肉にも、あの声を説明できる当の本人が、番組を聴き逃していた。屋根を直していた職人が、お茶を飲みに下りてきた。まだ、あの三つの音を同じように歌っていた。あれは彼の生涯でいちばんの名演だったとも言える。

**読みの問い**　鳥がいるという話と、生涯いちばんの名演だったという評を、語り手はそれぞれどの立場から述べているか。

<a id="r35"></a>

### 35　静かな部屋で歓声を上げてよいか

<a id="p35-1"></a>

**1**　The notice outside our reading room said, ‘Please behave **appropriately**.’ A young man **desperately** wanted to cheer. His mother had **just** read a whole page without help for the first time. Was it **legally** possible to forbid a man to cheer for his mother?

> 閲覧室の外の掲示には「場にふさわしい振る舞いをお願いします」とあった。ある若い男性は歓声を上げたくてたまらなかった。母親がたった今、初めて誰の助けも借りずに丸々一ページ読み終えたのだ。母に声援を送ることを法的に禁じることなどできるのだろうか。

<a id="p35-2"></a>

**2**　‘**Firstly**, this is a reading room,’ said the manager. ‘**Furthermore**, you accepted our rule by coming in.’ ‘I may have accepted it **implicitly**,’ said the son. ‘But what does it mean? **Even** turning a page makes a sound.’

> 「第一に、ここは閲覧室です」と責任者は言った。「そのうえ、入ってきた時点でここの決まりを受け入れたはずです」「暗黙のうちに受け入れたのかもしれません」と息子は言った。「でもどんな意味の決まりです？　ページをめくるだけでも音はします」

<a id="p35-3"></a>

**3**　‘**Ideally**, a rule helps people read,’ said his mother. ‘**However**, nobody has read a word since you started this argument. More **importantly**, I still have another page to read.’ She had **indirectly** asked for silence. We took her last words **literally** and turned the page for her. ‘**Frankly**,’ she added, ‘I can do that too.’ It **fundamentally** changed my idea of help.

> 「理想をいえば、決まりは読む人の役に立つものですね」と母親が言った。「けれど、あなたたちが議論を始めてから、誰も一語も読んでいない。それより大事なことに、私にはまだ次のページがあるんです」彼女は遠回しに静かにしてほしいと伝えていた。私たちは最後の言葉を文字どおりに受け取り、彼女のためにページをめくった。「率直に言うとね」と彼女は付け加えた。「それも自分でできるのよ」それで私は、助けるということへの考えを根本から改めた。

**読みの問い**　息子の同意と母親の要求は、どちらも言葉にそのまま表れてはいない。本文はそれぞれをどう表現したか。

### 同じ場面で言い換える　5　聞き手を絞る、聞こえた音を絞る

太字に注目して、場面をどう読み替えるか考えよう。

**Only the girl** heard the bell.

> そのベルが聞こえたのは女の子だけだった。

The girl heard **only the bell**.

> 女の子に聞こえたのはベルの音だけだった。

同じ部屋にいた先生にもベルが聞こえたとする。一文目とは両立しないが、二文目とは両立する。

### 第5部　読みの確認

**[29　火事の役は誰か](#r29)**　女の子は動作の出来を評していない。相手が納得したばかりの説明をそっと訂正するため、否定の前に一拍置いている。

**[30　声がよく通る場所](#r30)**　worse は同じ席の私が、静かな声と張った声を聞いたときの違いを表す。先生の worst は三人の聞き手の成績を比べ、その中でいちばん悪い人を尋ねている。

**[31　舞台の上の二脚](#r31)**　二脚の椅子に座った姿を比べたときの、見かけの大きさ。a lot は smaller にかかり、その見え方の差が大きいことを表す。

**[32　舞台の見えない特等席](#r32)**　試したのは二つとも。子どもはどちらか好きなほうを選べる。一つだけで20人座れるベンチはゼロ。

**[33　いちばん高い音](#r33)**　worked hard は懸命に練習した、could hardly sleep はほとんど眠れなかった。spoke highly of は高く評価していた、high above her head は頭上の高い位置だ。

**[34　生放送の鳥](#r34)**　allegedly は他人の主張を未確認のまま伝える。arguably は、名演だったと評価する余地があるという語り手自身の判断を添える。

**[35　静かな部屋で歓声を上げてよいか](#r35)**　implicitly は入室という行動に同意が暗黙に含まれることを表す。息子は may have accepted と、その可能性として述べている。indirectly は「次のページがある」という発言を通じて、遠回しに静かにしてほしいと伝えたこと。

---

<a id="part6"></a>

## 第6部　何を数えたのか

賛成した人数が増えた日に、賛成した人の割合が下がった。どちらの文も成り立つ数え方がある。

<a id="r36"></a>

### 36　壁の日記

<a id="p36-1"></a>

**1**　My grandfather marked my height on the kitchen wall from the time I was **six** until I was **twelve**. At **seven** I could just reach the shelf. At **eight** I could take a cup down. At **nine** I broke one and was asked to leave the cups alone.

> 祖父は私が六歳のときから十二歳になるまで、台所の壁に背の高さを記してくれた。七歳でようやく棚に手が届き、八歳でカップを下ろせた。九歳で一つ割ってしまい、カップには触らないようにと言われた。

<a id="p36-2"></a>

**2**　At **ten** I was taller than the mark for **eleven**. How could I have got shorter? My grandfather put a finger on the line. ‘You asked me to mark the wall when you got home from school. Look at your feet in this picture.’

> 十歳の私の方が十一歳の印より背が高い。どうして縮んだのだろう。祖父はその線に指を置いた。「学校から帰ったとき、測ってって言っただろう。この写真の足元を見てごらん」

<a id="p36-3"></a>

**3**　There I was, ten years old, in my new boots. I had always thought the wall was a record of my height. For one year, at least, it was also a record of my shoes.

> そこにいたのは、新しいブーツを履いた十歳の私だった。壁に残っているのは私の身長の記録だとずっと思っていた。少なくとも一年分は、靴の記録でもあったのだ。

**読みの問い**　At ten I was taller than the mark for eleven. の ten と eleven の後ろには、どんな情報が言われずに残っているか。

<a id="r37"></a>

### 37　五人の走者と二つの順位

<a id="p37-1"></a>

**1**　**Five** runners started **two** minutes apart. I stood at the finish with a piece of paper. The **first** to arrive was in red. The **second** wore blue, the **third** green, the **fourth** yellow and the **fifth** black. I wrote the colours in that order.

> 五人の走者が二分おきにスタートした。私は紙を持ってゴールに立った。最初に着いたのは赤。二番目は青、三番目は緑、四番目は黄、五番目は黒。私はその順に色を書き留めた。

<a id="p37-2"></a>

**2**　‘Who won?’ a child asked. ‘The one in red, I think.’ ‘When did she start?’ I had **one** list of colours, but the child wanted **three** things for each runner. ‘Tell me the colour, the start time and the finish time. Then I can tell you who won.’

> 「誰が優勝？」と子どもが聞いた。「赤の人だと思うよ」「その人、いつ出発したの？」私が持っていたのは色を並べた表一つ。子どもが走者ごとに知りたかったのは三つだ。「色と出発時刻と到着時刻を教えて。そうしたら誰が優勝したか言えるから」

<a id="p37-3"></a>

**3**　The runner in black had started **four** places behind the runner in red and had finished just a minute after her. I looked at my list again. It was a perfectly good answer to a different question.

> 黒の走者は赤の走者より四つ後の順番で出発したのに、到着はわずか一分遅れだった。私は表を見直した。それは確かに正しい答えだった。別の問いへの答えだったのだ。

**読みの問い**　the fifth to arrive の fifth で決まる順位と、子どもが求める順位を区別する。赤と黒だけなら、どちらが短時間で走ったか。

<a id="r38"></a>

### 38　二人の二位

<a id="p38-1"></a>

**1**　The twins dressed the **same** and trained **together**, but had never entered the same race. The older sister finished **second** in the morning race. In the afternoon the younger sister came **second**. Both crossed the line in exactly twelve seconds.

> 双子の姉妹は同じ格好をして一緒に練習していたが、同じレースに出たことはなかった。姉は午前のレースで二位になり、午後は妹が二位に入った。ゴールタイムは二人ともちょうど十二秒だった。

<a id="p38-2"></a>

**2**　‘Then you have measured one runner **twice**,’ a reporter said. The judge took the complaint **seriously**. ‘First, the races started four hours apart. **Secondly**, I watched both races **throughout**.’ He checked the photographs **thoroughly**. In both, a girl in green was crossing the line.

> 「だったら、同じ選手を二度計ったのでしょう」と記者が言った。審判はその異議を真剣に受け止めた。「まず、二つのレースは四時間離れていました。第二に、私はどちらのレースも初めから終わりまで見ていました」写真も念入りに確かめた。どちらにも、緑の服の少女がゴールする姿が写っていた。

<a id="p38-3"></a>

**3**　‘They **truly** could pass for one runner,’ the judge admitted. ‘But look beyond the line.’ In the first picture, the younger sister was holding a coat for the older one. In the second, the older sister was doing the same for her.

> 「確かに同じ選手だと言われても通りそうですね」と審判は認めた。「でもゴールの先を見てください」一枚目では、妹が姉のためにコートを持って待っていた。二枚目では、姉が妹に同じことをしていた。

<a id="p38-4"></a>

**4**　**Strictly** speaking, the clocks had told us nothing about who ran. The photographs showed both sisters, **thereby** settling the question. **Thereafter**, the reporter always asked what lay outside the part of a picture he had seen.

> 厳密に言えば、時計が教えてくれた情報からは、誰が走ったかは分からなかった。写真には姉妹が二人とも写っていて、それで疑問は解けた。それ以来、記者は写真の自分が見た部分の外に何が写っているか、必ず尋ねるようになった。

**読みの問い**　二回出てくる second と、審判の Secondly は、それぞれ何を順に並べているか。

<a id="r39"></a>

### 39　潮の高さを測る線

<a id="p39-1"></a>

**1**　‘Look **here**,’ my uncle said. ‘See that line on the harbour wall? The sea **generally** reaches it in winter. **How** would you find out whether the water is getting higher?’ I looked along the wall. A second line was **also** visible. It was **fairly** new.

> 「ここを見て」と叔父が言った。「港の壁に線があるだろう。冬にはたいてい、海面があそこに届く。水位が上がってきているかどうか、どうやって調べる？」私は壁に沿って目をやった。もう一本、線が見えた。かなり新しかった。

<a id="p39-2"></a>

**2**　‘Measure the distance between the two lines **first**,’ I suggested. He shook his head. ‘The old line was **badly** damaged in a storm. We drew the new one where we could reach. Our choice **greatly** affects your answer.’ I found it **increasingly** difficult to say which question I was answering.

> 「まず二本の線の間隔を測ればいい」と私は言った。叔父は首を振った。「古い線は嵐でひどく傷んだ。新しいほうは手の届く場所に引いたんだ。私たちがどこを選んだかで、君の答えは大きく変わる」自分が何に答えようとしているのか、私はだんだん自信がなくなった。

<a id="p39-3"></a>

**3**　**Fortunately**, the wall had steps. Each day at high water, we counted the steps the sea had not reached. After a week of heavy rain the number fell **dramatically**. ‘A fall in the number of steps above water **definitely** means higher water today,’ I said. ‘Whether the sea is rising over the years is **less** clear.’ He **immediately** handed me his book of figures. ‘**Hopefully**, you will **eventually** want the other thirty books too.’

> 幸い、その壁には階段があった。私たちは毎日、満潮のときに水につかっていない段を数えた。大雨が一週間続くと、段数は大きく減った。「水面より上に出ている段が減ったのなら、今日の水位が上がったことは確かだ。でも、何年にもわたって海面が上がっているかどうかは、そこまではっきりしない」と私は言った。叔父はすぐに数値の記録帳を渡してくれた。「そのうち、残りの三十冊も読みたくなってくれるといいな」

**読みの問い**　数えた段数から、語り手がその日について断言できたことと、何年にもわたる変化について保留したことを読み分けよう。

<a id="r40"></a>

### 40　賛成者が増えるほど下がる数字

<a id="p40-1"></a>

**1**　We asked visitors whether the library should open at night. On Monday, **seventeen** people out of **seventy** said yes. On Tuesday it was **eighteen** out of **eighty**. On Wednesday, **nineteen** out of **ninety** wanted the change.

> 図書館を夜も開けるべきか、来館者に尋ねた。月曜は七十人中十七人が賛成。火曜は八十人中十八人。水曜は九十人中十九人が夜間開館を望んだ。

<a id="p40-2"></a>

**2**　‘Support grew every day,’ said the manager. ‘Look at how many said yes.’ The student drew three bars of equal length and coloured in the share that said yes each day. The coloured part got shorter. ‘What title shall I give the chart?’ she asked.

> 「支持は毎日増えた。賛成した人数を見て」と管理人は言った。学生は同じ長さの棒を三本描き、それぞれの日に賛成した人の割合だけ色を塗った。色の部分は日ごとに短くなった。「図の表題はどうしましょう？」

<a id="p40-3"></a>

**3**　On a fourth day they would need at least **twenty** people to say yes just to keep the count rising. They put two figures above each bar. The first told readers how many people wanted a longer day at the library. The second told them how many had been asked. Both agreed to leave the word ‘support’ out of the title.

> 仮に四日目も人数の増加を続けたいなら、少なくとも二十人には賛成してもらう必要がある。二人はそれぞれの棒の上に数字を二つ添えた。一つ目は開館時間の延長を望んだ人数、二つ目は質問を受けた人数だ。表題に「支持」という一語を使うのはやめよう、という点で二人の意見が合った。

**読みの問い**　seventeen out of seventy から nineteen out of ninety へと移るとき、人数と割合はそれぞれどう変わるか。

<a id="r41"></a>

### 41　図書館に来たことのない人の票

<a id="p41-1"></a>

**1**　The library moved its evening talk to Saturday. Attendance rose fifty **per cent**, from twenty to thirty. ‘It is the time that people like **most**,’ the manager said. ‘We chose it **partly** because of the survey.’

> 図書館は夜に開いていた講演を土曜日に移した。参加者は二十人から三十人へ、五〇パーセント増えた。「皆さんがいちばん気に入っている時間帯です。アンケートの結果もあって、この時間に決めました」と館長は言った。

<a id="p41-2"></a>

**2**　The survey was designed **primarily** to find a convenient time. The team had **randomly** selected people as they entered the library, **mainly** in the morning from Monday to Friday. People visiting at that hour were **predominantly** retired. People who worked in town **typically** came in after six.

> アンケートの主な目的は、都合のよい時間帯を知ることだった。担当者は来館者を入り口で無作為に選んだが、調査したのは主に平日の午前中だった。その時間の来館者は退職した人が大半で、町で働く人たちが来るのはたいてい六時を過ぎてからだった。

<a id="p41-3"></a>

**3**　Nineteen visitors chose Saturday and eleven chose Monday, **roughly** two thirds and one third **respectively**. The Monday group were **mostly** parents. They **specifically** asked for an event they could attend while the children were at school.

> 十九人が土曜日を、十一人が月曜日を選んだ。およそ三分の二と三分の一に、それぞれ相当する。月曜を選んだグループはほとんどが親で、子どもが学校にいる間に参加できる催しを、と具体的に希望していた。

<a id="p41-4"></a>

**4**　‘Attendance has grown **substantially**,’ I said. ‘But has access improved **overall**? A Saturday talk is **significantly** harder to attend if you work on Saturdays. And **statistically**, what do we know about the people who never come in?’ The manager looked at the thirty answers. ‘We have not asked them.’

> 「参加者が大幅に増えたのは確かです。でも、全体として参加しやすくなったでしょうか。土曜日に働く人にとっては、土曜の講演に出るのはずっと難しい。それに統計の上では、一度も来館しない人のことがどれだけ分かりますか」館長は三十人分の回答を見た。「その人たちには聞いていませんね」

**読みの問い**　無作為に選んだのに、町の全員が答える機会を等しく持っていなかったのはなぜか。randomly は何をする段階にかかるか。

<a id="r42"></a>

### 42　鳴ったベルは何を証明したか

<a id="p42-1"></a>

**1**　The bell on my bicycle was **totally** silent. It had a battery and a little switch. My brother changed both and rang it **successfully**. ‘**Therefore** the old battery was dead,’ he said. He **subsequently** wrote that on the battery.

> 私の自転車のベルはまったく音がしなかった。電池と小さなスイッチがついていた。兄が両方を取り替えると、うまく鳴った。「したがって、古い電池が切れていたんだ」と彼は言い、その後、電池にそう書き込んだ。

<a id="p42-2"></a>

**2**　‘You cannot tell that **solely** from the sound,’ I said. ‘**Moreover**, the old switch might still work **properly**. We need to know **precisely** which change made the difference. **Otherwise** we may throw out a good part.’

> 「鳴ったことだけではそう言えないよ。それに、古いスイッチだってまだ正常に働くかもしれない。どちらを替えたから鳴るようになったのか、正確に確かめる必要がある。そうでないと、使える部品を捨てかねないよ」

<a id="p42-3"></a>

**3**　We tested the parts **systematically**. First, with the new switch in place, we put the old battery back. The bell rang. **Thus** we knew the old battery could supply power. Then we tried the old switch with the new battery. Silence.

> 私たちは順序を決めて部品を調べた。まず、新しいスイッチはそのままにして、古い電池を戻した。ベルが鳴った。これで、古い電池でも電力を供給できると分かった。それから、新しい電池と古いスイッチの組み合わせを試した。音はしなかった。

<a id="p42-4"></a>

**4**　‘**Theoretically**, both old parts could have failed,’ I said. ‘But we have a **purely** practical question. Can we use the old battery?’ My brother rang the bell with it again. ‘My repair was not **wholly** wrong,’ he said. ‘I **simply** repaired more than I needed to.’

> 「理屈の上では、古い部品が両方とも故障している可能性はあった。でも、私たちが知りたいのは純粋に実用上のこと。古い電池は使える？」兄はその電池でもう一度ベルを鳴らした。「私の修理も全部間違っていたわけじゃない。必要以上に直しただけだ」

**読みの問い**　最初の Therefore と、後の Thus はどちらも結論を導く。実験がその結論を直接支えているのはどちらか。

### 同じ場面で言い換える　6　十だけ減る、十まで減る

太字に注目して、場面をどう読み替えるか考えよう。

The number fell **by** ten.

> その数は十減った。

The number fell **to** ten.

> その数は十に減った。

最初に三十人いたなら、最後は一文目で二十人、二文目で十人。

### 第6部　読みの確認

**[36　壁の日記](#r36)**　どちらも年齢で、十歳のときの本人と、十一歳のときに付けた印の高さを比べている。十時・十一時という読みは、子どもの成長を記す冒頭の文と合わない。

**[37　五人の走者と二つの順位](#r37)**　fifth はゴールで観察した到着順の五番目。子どもが知りたいのは各自の所要時間の順位。黒は八分遅く出発して一分遅く着いたので、赤より七分短い時間で走った。

**[38　二人の二位](#r38)**　second は各レースでの着順を示す。姉と妹は別々のレースでそれぞれ二番目にゴールした。Secondly は審判が挙げる根拠の順を示し、二つ目の根拠を導く。

**[39　潮の高さを測る線](#r39)**　definitely はその日の水位の判断を支える。less clear は長年にわたる傾向への確信を弱める。hopefully は将来の語り手に対する叔父の願いで、eventually はその気持ちになるまで時間がかかりうることを示す。

**[40　賛成者が増えるほど下がる数字](#r40)**　賛成人数は十七人から十九人へ増える。一方、全回答者のうちの割合は約24％から約21％へ下がる。何を数えた増減なのかを言えば、二つの観察を両立させられる。

**[41　図書館に来たことのない人の票](#r41)**　randomly が修飾するのは、入り口に来た人の中から回答者を選ぶ過程。調査は主に平日午前の館内で行われたので、別の時間に来る人や、そもそも利用していない人の希望は拾いにくい。

**[42　鳴ったベルは何を証明したか](#r42)**　後の Thus。新しいスイッチと古い電池で実際に鳴ったので、古い電池はその場で電力を供給できた。最初は二つの部品を同時に替えたため、鳴ったという結果だけから古い電池が原因だったとは決められない。

---

<a id="part7"></a>

## 第7部　読む人がいる部屋

空に見える額縁を前に「誰が絵を持っていったの？」と尋ねる。目に入ったものと、問いの中ですでに決めたことを分けてみよう。

<a id="r43"></a>

### 43　雨宿りに来た本

<a id="p43-1"></a>

**1**　It was raining **heavily** when a boy ran **indoors**, his coat **all** wet. The library was **almost** empty. I had been **half** asleep behind the desk. ‘Can I leave this **anywhere**?’ he asked. In one hand was a book I had never seen **before**. In the other was a pair of clean socks.

> 大雨の中、男の子が屋内に駆け込んできた。上着はずぶぬれだった。図書館にはほとんど人がおらず、私は受付でうとうとしていた。「これ、どこかに置いてもいい？」片手には私がそれまで見たことのない本、もう片方にはきれいな靴下が一足あった。

<a id="p43-2"></a>

**2**　Water was finding its way **in** through the flat roof. We went **downstairs** to find a shelf dry **enough** for the book. We looked **everywhere**. The boy stopped **briefly** beside a box, opened it and looked **inside**. It was **completely** dry.

> 平らな屋根から雨が入り込んでいた。私たちは階下に行き、本を置けるくらい乾いた棚を探した。あらゆる場所を見た。男の子は箱のそばでちょっと立ち止まり、ふたを上げて中を見た。そこは完全に乾いていた。

<a id="p43-3"></a>

**3**　He ran his hand back and **forth** over the cover. I asked whether he wanted to borrow the book himself. ‘I have **already** read this one. I made it!’ he said. **Apparently**, he had brought his own book to join ours. He was **certainly** the first writer to arrive with a book and a change of socks.

> 男の子は手を前後に動かして、本の表紙をなでた。その本を自分で借りたいのかと尋ねると、「これはもう読んだよ。僕が作ったんだ！」と言う。どうやら、自分の本を図書館の本の仲間に入れようと持ってきたらしい。自分の本と替えの靴下を持って現れた作家は、たしかに彼が初めてだった。

**読みの問い**　びしょぬれの上着とほとんど人のいない図書館について、それぞれ程度を表す語を拾おう。その語を日本語ではどう訳し分けたか。

<a id="r44"></a>

### 44　席を取っておく手紙

<a id="p44-1"></a>

**1**　Our little reading room was **originally** a shop. **Previously**, you had to buy a paper if you wanted to sit by the fire. **Nowadays** the chairs are free. The fire has **never** been lit **since**.

> 町の小さな読書室は、もとは商店だった。以前は火のそばに座りたければ新聞を買う必要があった。今では無料で座れる。あれ以来、暖炉に火が入ったことは一度もない。

<a id="p44-2"></a>

**2**　Readers **usually** leave a book on a chair to keep their place. They **normally** come back before anyone needs it. One chair, however, was **often** empty for hours. The book on it was **rarely** the same two days running.

> 読者はたいてい、椅子に本を置いて席を取っておく。普通は誰かがそこに座りたくなる前に戻ってくる。ところが一脚だけ、何時間も誰も座らないことがよくあった。そこに置かれる本が二日続けて同じことはめったになかった。

<a id="p44-3"></a>

**3**　I visit **regularly**, every Friday. Until **recently** I had **seldom** opened any of the books on that chair. Then I picked up a **newly** published one. Inside was a note. ‘Come and sit with me **sometime**.’

> 私は決まって毎週金曜日に通っている。つい最近まで、その席の本を開くことはめったになかった。ところがある日、出たばかりの本を手に取ると、中にメモがあった。「いつか、私と一緒に座りに来てください」

<a id="p44-4"></a>

**4**　‘In this room we have **traditionally** kept that chair for strangers,’ a woman explained. ‘**Sometimes** they just read. **Occasionally** one stays for tea.’ She pulled out the chair for me. The book had been saving my place.

> 「ここでは昔から、まだ知り合っていない人のためにその席を空けているの」と女性が教えてくれた。「本だけ読んでいくこともあるし、たまにはお茶を飲んでいく人もいるわ」彼女は私のために椅子を引いた。あの本が取っていてくれたのは、私の席だったのだ。

**読みの問い**　メモの sometime を sometimes に変えると、誘いはどう変わるか。

<a id="r45"></a>

### 45　静かな読書室

<a id="p45-1"></a>

**1**　**Many** people came to see the new reading room. **Most** visitors stayed by the door. **Few** visitors sat down, and **no** visitor stayed for long. ‘Perhaps people have **little** time for books,’ said the manager. ‘Or perhaps,’ I said, ‘they have nowhere to put **their** coats.’

> 新しい読書室を見に大勢が来た。大半の人は入口あたりにとどまった。腰を下ろす人はほとんどおらず、長居した人は一人もいなかった。「みんな本に割く時間がほとんどないのかも」と管理人。「それとも」と私は言った。「上着の置き場がないからかもしれませんよ」

<a id="p45-2"></a>

**2**　We tried **several** changes. Our **first** change was a shelf by the door. Our **second** change was a seat below it. Visitors now spent **less** time standing and **more** time reading. The seat that got the **least** light turned out to be the most popular.

> 私たちはいくつか変更を試した。まず入口のそばに棚を付け、次にその下に席を設けた。すると立っている時間が減り、読書の時間が増えた。いちばん光の当たらない席が、いちばん人気だった。

<a id="p45-3"></a>

**3**　A **lot** of people wanted to know why. ‘**Whatever** reason they give, write it down,’ the manager said. The first reply was short. ‘You can read anywhere. In **such** a comfortable seat, you can also fall asleep.’ The room had **become** a success for a reason we had never counted on.

> 理由を知りたがる人がたくさんいた。「どんな理由を挙げても書き留めて」と管理人は言った。最初の答えは短かった。「読むだけならどこででも読めます。これほど座り心地のいい席なら、居眠りもできます」読書室は、私たちが思いもしなかった理由で人気を集めていた。

**読みの問い**　Few visitors sat down と no visitor stayed for long では、「一人でもいたか」という問いにどんな違いが出るか。

<a id="r46"></a>

### 46　庭を開けることに賛成ですか

<a id="p46-1"></a>

**1**　At our meeting we had **only** one question to answer. Should the little garden behind the hall stay open after dark? I was **particularly** interested in the answer because my shift ended at nine. I had seen the gate, but never the garden.

> 集会で答えるべき問いは一つだけだった。会館の裏の小さな庭を、日が暮れても開けておくべきか。私の勤務は九時までなので、その答えにはとりわけ関心があった。門は見たことがあるが、庭は一度も見たことがなかった。

<a id="p46-2"></a>

**2**　‘**Personally**, I would **readily** pay for another key,’ I said. Several people spoke **strongly** in favour of the idea, **notably** a woman who worked nights. Keeping the garden open would let her meet her neighbours **socially** before work.

> 「私としては、鍵をもう一本作る費用なら喜んで出します」と言った。何人もが強い賛意を表した。なかでも夜勤の女性がそうだった。庭が開いていれば、出勤前に近所の人たちと交流できるという。

<a id="p46-3"></a>

**3**　The people living beside the gate reacted **negatively**. ‘I am **not** against the garden,’ one man said. ‘**Neither** am I,’ said his wife. ‘We cannot sleep when the gate closes, **nor** can the children. Come and listen.’

> 門のそばの住民からは否定的な反応が返った。「庭に反対しているんじゃないんです」と男性が言った。「私も庭には反対していません」と妻が続けた。「門が閉まると、私たちは眠れないし、子どもたちも眠れません。聞きに来てください」

<a id="p46-4"></a>

**4**　I expected **merely** a click. **Nevertheless**, I went. The great iron gate struck stone. A soft strip on the gate was cheap. It was **nonetheless** effective. The family responded **positively** to the next test. ‘One thing, **though**,’ the man said. ‘Do let us have a key as well.’

> 私はカチッと鳴る程度だろうと思っていた。それでも行ってみた。大きな鉄の門が石にぶつかった。門に取りつけた柔らかい帯は安価だったが、それでも効果があった。次に試したとき、家族の反応は好意的だった。「ただ、一つだけ」と男性は言った。「うちにも鍵を一本くださいね」

**読みの問い**　妻の Neither am I と、その後の nor can the children では、誰にどの否定が引き継がれるか。

<a id="r47"></a>

### 47　川のそばの小さな博物館

<a id="p47-1"></a>

**1**　At the river museum we kept some of the boats **outdoors**. I was standing **outside** when I noticed that the river had been rising **steadily** for an hour. A stick on the bank pointed **upwards** at an angle. Only its tip was showing.

> 川の博物館では、何艘かの舟を屋外に置いていた。私が外に立っていると、この一時間、川の水位が着実に上がり続けていたことに気づいた。岸には棒が斜め上向きに突き立っていた。もう先端しか見えなかった。

<a id="p47-2"></a>

**2**　Most of the boats floated **up** with the water. **Unfortunately**, the smallest one was already **partially** full. It filled **rapidly** and went **under**. **Thankfully**, it was tied to the bank, so we knew where to find it.

> たいていの舟は水と一緒に浮き上がった。残念ながら、いちばん小さい舟にはすでにいくらか水が入っていた。みるみる水がたまり、舟は沈んだ。ありがたいことに岸につないであったので、後でどこを探せばよいかは分かった。

<a id="p47-3"></a>

**3**　Inside, we carried the old photographs **upstairs**. The drains ran **underground**, out of sight. Water would **naturally** flow towards the lowest room if a drain was blocked. One wet afternoon could damage the collection **severely**.

> 館内では古い写真を上の階へ運んだ。排水路は地下を通っていて見えなかった。どこかで詰まれば、水は自然といちばん低い部屋に向かって流れる。午後のひと雨だけでも、収蔵品は大きな被害を受けかねなかった。

<a id="p47-4"></a>

**4**　We closed the ground floor **temporarily**. By morning the water had fallen **sufficiently** for us to go back. The floor was **still** wet after drying **overnight**. We moved the photographs **permanently**. They had survived one flood without getting wet. Nobody wanted to test them twice.

> 一階を一時閉鎖した。朝までには水位が十分に下がり、中に戻れた。一晩乾かしたのに、床はまだ濡れていた。写真は今後ずっと上の階で保管することにした。一度の洪水は濡れずに済んだ。二度目も大丈夫か試したい人はいなかった。

**読みの問い**　temporarily と permanently は、それぞれ何を元に戻すかどうかに関わるか。

<a id="r48"></a>

### 48　鏡で読める手紙

<a id="p48-1"></a>

**1**　The old printer at the museum worked **all right** until I asked it to copy a letter. The writing was **as** dark as the original, but I could not read a word. ‘Look **around**,’ said the woman at the desk.

> 博物館の古い印刷機は、私が手紙を一枚複写するまでは問題なく動いていた。文字は原本と変わらない濃さなのに、一語も読めない。「周りを見てごらん」と受付の女性が言った。

<a id="p48-2"></a>

**2**　She put her book **aside** and held a mirror **halfway** between us. In the glass I could **clearly** read the date. Had I **accidentally** put the paper in **backwards**? I fed it in **carefully** and tried **again**. The same thing happened.

> 女性は本を脇へ置き、二人のちょうど中間に鏡をかざした。鏡の中では日付がはっきり読めた。うっかり紙の向きを逆にして入れたのだろうか。気をつけて紙を入れ、もう一度試した。結果は同じだった。

<a id="p48-3"></a>

**3**　‘Look **closely** at the original.’ I **instantly** saw my mistake. The writer had **deliberately** written every word backwards. The machine had copied it **accurately**. My eyes had **automatically** gone to the copy. For a moment I thought I was seeing **double**. Then I saw that I was looking at both letters and reading both **correctly** in the glass.

> 「原本をよく見て」私はすぐに自分の勘違いに気づいた。書き手はわざと、どの単語も逆向きに書いていた。機械は正確に複写していたのだ。私は無意識に写しのほうへ目をやっていた。一瞬、物が二重に見えているのかと思った。よく見ると、鏡に原本と写しの両方が映っていて、私はどちらもちゃんと読めていた。

**読みの問い**　故意だった行為、失敗かもしれないと思った行為、意識せずにした行為を一つずつ拾おう。

<a id="r49"></a>

### 49　空の額から分かること

<a id="p49-1"></a>

**1**　In the museum there was a **seemingly** empty frame on the wall. ‘**Why** has somebody taken the picture?’ my sister asked. ‘**Maybe** there never was a picture,’ I said. ‘An empty frame does not **necessarily** mean a picture is missing.’

> 博物館の壁に、一見すると空っぽの額が掛かっていた。「どうして誰かが絵を持っていったの？」と妹が聞いた。「もともと絵はなかったのかも。空の額があるからといって、絵がなくなったとは限らないよ」と私は言った。

<a id="p49-2"></a>

**2**　‘**Perhaps** the artist took it home,’ she said. ‘It could **possibly** be on the other side of the wall.’ We had no evidence **whatsoever** for either idea. **Presumably** the guard would know.

> 「ひょっとすると画家が家に持って帰ったのかも」と妹は言った。「もしかしたら、この壁の反対側にあるのかもしれない」どちらの考えにも証拠はまったくなかった。あそこの係員なら知っているだろう。

<a id="p49-3"></a>

**3**　The **supposedly** empty frame was attracting a crowd. ‘**Surely** they cannot all be looking at nothing,’ my sister said. ‘There is **probably** something we have missed.’ **Sure** enough, a thin black line ran across the middle. We had **somehow** failed to see it.

> 空だというその額の前に人が集まってきた。「まさか全員が何もないところを眺めているわけじゃないでしょ。たぶん何か見落としているよ」と妹。果たして、真ん中に細い黒い線が一本走っていた。私たちはどういうわけか見過ごしていたのだ。

<a id="p49-4"></a>

**4**　‘There is **undoubtedly** a line,’ I said. ‘It is **obviously** black. Is that the picture?’ The guard took one step to the left. The line moved with him. ‘It is the shadow of my pen,’ he said.

> 「線があるのは間違いない。見てのとおり黒いね。あれが絵かな？」係員が一歩左へ動くと、線も一緒に動いた。「私のペンの影ですよ」と彼は言った。

**読みの問い**　空の額を見た妹の最初の問いには、どんな前提があるか。語り手は、どの言葉でその前提に留保をつけたか。

### 同じ場面で言い換える　7　今も、もう、まだ

太字に注目して、場面をどう読み替えるか考えよう。

She is **still** reading.

> 彼女は今も読んでいる。

She is **already** reading.

> 彼女はもう読んでいる。

She has **not** started reading **yet**.

> 彼女はまだ読み始めていない。

一文目は続いていること、二文目はすでに始まっていること、三文目は始まる時点がまだ来ていないことを伝える。

### 第7部　読みの確認

**[43　雨宿りに来た本](#r43)**　all はぬれ具合を強め、all wet で「ずぶぬれ」。almost empty は完全に無人になる少し手前で、受付には語り手がいた。

**[44　席を取っておく手紙](#r44)**　sometime は「いつか都合のよいときに」と、一度の訪問でもかなう誘い。sometimes にすると「ときどき座りに来て」と、折々の訪問を誘う言い方になる。

**[45　静かな読書室](#r45)**　前者は座った人が少なかったという捉え方で、人数をゼロと断定しない。後者は長居した人を明確にゼロとしている。

**[46　庭を開けることに賛成ですか](#r46)**　前者では夫の「庭に反対していない」が妻にも当てはまる。後者では両親の「眠れない」が子どもたちにも当てはまる。二つの否定の中身は違う。

**[47　川のそばの小さな博物館](#r47)**　一時的だったのは一階の閉鎖で、水が引くと再び入れた。一方、写真の移動は恒久的で、一階が使えるようになっても写真は上の階に置いておく。

**[48　鏡で読める手紙](#r48)**　deliberately は書き手が文字を逆にしたこと、accidentally は語り手が疑った紙の入れ間違い、automatically は写しに目が向いたことにかかる。実際に起きたのは一つ目と三つ目だ。

**[49　空の額から分かること](#r49)**　誰かが絵を持ち去ったことを前提に、理由を聞いている。does not necessarily mean は、額が空でも「絵がなくなった」とまでは言えない、と推論の範囲を狭めている。

---

<a id="wordindex"></a>

## 用例索引

数字は「話．段落」。たとえば 01.2 は第01話の第2段落。見出しを押すと該当段落へ移動する。品詞と同形語の区別は元のリストに従った。ひとつの綴りが複数の欄にあるときは、英語のどの部分と結びつくかを読み比べてほしい。

### 同じ綴りを読み比べる

- **since**　[今も店にいるのだから、と理由を示す 19.1](#p19-1) ／ [洪水を起点にする 17.1](#p17-1) ／ [以前の話を受けて、それ以来と伝える 44.1](#p44-1)。
- **any**　[スープが少しでも残っているか 22.1](#p22-1) ／ [いすをどれでも選んでよい 32.2](#p32-2) ／ [今より少しでもうまく歌えるか 33.1](#p33-1)。
- **as**　[通りかかったときのこと 19.1](#p19-1) ／ [上着を座る場所として使う 26.3](#p26-3) ／ [文字が原本と同じくらい濃い 48.1](#p48-1)。
- **both**　[後ろに名詞が続く「両方のドア」19.1](#p19-1) ／ [直前のベンチ二つを受けて「両方を試した」32.3](#p32-3)。

### 自分が英国英語で言うなら

第11話の *looked out the window* は北米でよく使われる形。*looked out of the window* とも言える。第13話の *went downtown* も北米寄りで、英国英語では *went into the city centre* と言える。元のリストにある形を太字の本文で読めるようにした。 [辞書の用例・窓](https://www.oxfordlearnersdictionaries.com/definition/english/out_1) ／ [辞書の用例・街の中心](https://www.oxfordlearnersdictionaries.co.uk/definition/english/downtown_1)

### 副詞　391項目

**A**　[about 08.1](#p08-1)　·　[above 08.1](#p08-1)　·　[abroad 13.1](#p13-1)　·　[absolutely 33.3](#p33-3)　·　[accidentally 48.2](#p48-2)　·　[accordingly 34.2](#p34-2)　·　[accurately 48.3](#p48-3)　·　[across 08.2](#p08-2)　·　[actively 21.3](#p21-3)

[actually 33.3](#p33-3)　·　[additionally 20.2](#p20-2)　·　[adequately 20.2](#p20-2)　·　[after 21.2](#p21-2)　·　[afterwards 21.2](#p21-2)　·　[again 48.2](#p48-2)　·　[ago 21.1](#p21-1)　·　[ahead 08.2](#p08-2)　·　[alike 21.1](#p21-1)

[all 43.1](#p43-1)　·　[all right 48.1](#p48-1)　·　[allegedly 34.1](#p34-1)　·　[almost 43.1](#p43-1)　·　[alone 33.2](#p33-2)　·　[along 08.1](#p08-1)　·　[already 43.3](#p43-3)　·　[also 39.1](#p39-1)　·　[alternatively 13.2](#p13-2)

[altogether 33.2](#p33-2)　·　[always 21.2](#p21-2)　·　[annually 21.2](#p21-2)　·　[any 33.1](#p33-1)　·　[any more 34.1](#p34-1)　·　[anyway 33.3](#p33-3)　·　[anywhere 43.1](#p43-1)　·　[apart 08.1](#p08-1)　·　[apparently 43.3](#p43-3)

[appropriately 35.1](#p35-1)　·　[approximately 20.1](#p20-1)　·　[arguably 34.3](#p34-3)　·　[around 48.1](#p48-1)　·　[as 48.1](#p48-1)　·　[aside 48.2](#p48-2)　·　[automatically 48.3](#p48-3)　·　[away 13.2](#p13-2)

**B**　[back 08.3](#p08-3)　·　[backwards 48.2](#p48-2)　·　[badly 39.2](#p39-2)　·　[barely 13.3](#p13-3)　·　[basically 25.3](#p25-3)　·　[before 43.1](#p43-1)　·　[behind 08.3](#p08-3)　·　[below 08.1](#p08-1)　·　[besides 13.3](#p13-3)

[best 21.1](#p21-1)　·　[better 21.1](#p21-1)　·　[between 08.2](#p08-2)　·　[beyond 08.2](#p08-2)　·　[briefly 43.2](#p43-2)　·　[broadly 20.1](#p20-1)　·　[by 08.1](#p08-1)

**C**　[carefully 48.2](#p48-2)　·　[certainly 43.3](#p43-3)　·　[cheap 13.1](#p13-1)　·　[clearly 48.2](#p48-2)　·　[close² 08.3](#p08-3)　·　[closely 48.3](#p48-3)　·　[commonly 21.3](#p21-3)　·　[completely 43.2](#p43-2)　·　[consequently 20.3](#p20-3)

[considerably 20.3](#p20-3)　·　[consistently 20.1](#p20-1)　·　[constantly 20.3](#p20-3)　·　[continually 20.3](#p20-3)　·　[correctly 48.3](#p48-3)　·　[critically 20.3](#p20-3)　·　[culturally 25.1](#p25-1)　·　[currently 34.1](#p34-1)

**D**　[daily 21.2](#p21-2)　·　[deep 08.3](#p08-3)　·　[deeply 06.1](#p06-1)　·　[definitely 39.3](#p39-3)　·　[deliberately 48.3](#p48-3)　·　[desperately 35.1](#p35-1)　·　[differently 06.2](#p06-2)　·　[direct 13.1](#p13-1)　·　[directly 34.1](#p34-1)

[double 48.3](#p48-3)　·　[down 08.2](#p08-2)　·　[downstairs 43.2](#p43-2)　·　[downtown 13.1](#p13-1)　·　[downwards 08.3](#p08-3)　·　[dramatically 39.3](#p39-3)

**E**　[each 21.1](#p21-1)　·　[early 13.2](#p13-2)　·　[easily 21.3](#p21-3)　·　[east 13.1](#p13-1)　·　[economically 25.2](#p25-2)　·　[effectively 25.2](#p25-2)　·　[efficiently 25.2](#p25-2)　·　[either 34.2](#p34-2)　·　[else 34.2](#p34-2)

[elsewhere 13.3](#p13-3)　·　[emotionally 33.1](#p33-1)　·　[empirically 20.1](#p20-1)　·　[enough 43.2](#p43-2)　·　[entirely 20.3](#p20-3)　·　[equally 21.1](#p21-1)　·　[especially 25.2](#p25-2)　·　[essentially 20.3](#p20-3)　·　[even 35.2](#p35-2)

[eventually 39.3](#p39-3)　·　[ever 06.1](#p06-1)　·　[everywhere 43.2](#p43-2)　·　[exactly 20.2](#p20-2)　·　[exclusively 25.1](#p25-1)　·　[explicitly 34.2](#p34-2)　·　[extensively 34.1](#p34-1)　·　[extra 13.2](#p13-2)　·　[extremely 34.2](#p34-2)

**F**　[fairly 39.1](#p39-1)　·　[far 13.1](#p13-1)　·　[fast 13.2](#p13-2)　·　[finally 34.3](#p34-3)　·　[firmly 33.3](#p33-3)　·　[first 39.2](#p39-2)　·　[firstly 35.2](#p35-2)　·　[forever 06.4](#p06-4)　·　[formerly 25.1](#p25-1)

[forth 43.3](#p43-3)　·　[fortunately 39.3](#p39-3)　·　[forward 33.3](#p33-3)　·　[frankly 35.3](#p35-3)　·　[free 25.3](#p25-3)　·　[freely 25.1](#p25-1)　·　[frequently 25.3](#p25-3)　·　[full-time 25.2](#p25-2)　·　[fully 06.4](#p06-4)

[fundamentally 35.3](#p35-3)　·　[further 13.3](#p13-3)　·　[furthermore 35.2](#p35-2)

**G**　[generally 39.1](#p39-1)　·　[genuinely 33.3](#p33-3)　·　[gradually 21.3](#p21-3)　·　[greatly 39.2](#p39-2)

**H**　[half 43.1](#p43-1)　·　[halfway 48.2](#p48-2)　·　[happily 25.3](#p25-3)　·　[hard 33.1](#p33-1)　·　[hardly 33.1](#p33-1)　·　[heavily 43.1](#p43-1)　·　[hence 06.4](#p06-4)　·　[here 39.1](#p39-1)　·　[high 33.2](#p33-2)

[highly 33.1](#p33-1)　·　[historically 25.1](#p25-1)　·　[home 13.3](#p13-3)　·　[hopefully 39.3](#p39-3)　·　[how 39.1](#p39-1)　·　[however 35.3](#p35-3)

**I**　[ideally 35.3](#p35-3)　·　[immediately 39.3](#p39-3)　·　[implicitly 35.2](#p35-2)　·　[importantly 35.3](#p35-3)　·　[in 43.2](#p43-2)　·　[increasingly 39.2](#p39-2)　·　[incredibly 34.3](#p34-3)　·　[indeed 06.1](#p06-1)　·　[independently 20.2](#p20-2)

[indirectly 35.3](#p35-3)　·　[individually 20.2](#p20-2)　·　[indoors 43.1](#p43-1)　·　[inevitably 06.4](#p06-4)　·　[initially 06.2](#p06-2)　·　[inside 43.2](#p43-2)　·　[instantly 48.3](#p48-3)　·　[instead 06.3](#p06-3)　·　[ironically 34.3](#p34-3)

**J**　[just 35.1](#p35-1)

**L**　[largely 06.2](#p06-2)　·　[last¹ 33.2](#p33-2)　·　[late 13.3](#p13-3)　·　[lately 06.3](#p06-3)　·　[later 06.2](#p06-2)　·　[least 06.3](#p06-3)　·　[left 08.2](#p08-2)　·　[legally 35.1](#p35-1)　·　[less 39.3](#p39-3)

[likely 06.2](#p06-2)　·　[likewise 06.3](#p06-3)　·　[literally 35.3](#p35-3)　·　[little 06.2](#p06-2)　·　[live² 34.3](#p34-3)　·　[locally 25.2](#p25-2)　·　[long-term 25.3](#p25-3)　·　[long¹ 06.1](#p06-1)　·　[lot 31.3](#p31-3)

[loud 30.2](#p30-2)　·　[loudly 30.2](#p30-2)　·　[low 10.2](#p10-2)

**M**　[mainly 41.2](#p41-2)　·　[maybe 49.1](#p49-1)　·　[meanwhile 16.2](#p16-2)　·　[merely 46.4](#p46-4)　·　[more 31.3](#p31-3)　·　[moreover 42.2](#p42-2)　·　[most 41.1](#p41-1)　·　[mostly 41.3](#p41-3)　·　[much 31.4](#p31-4)

**N**　[namely 27.2](#p27-2)　·　[naturally 47.3](#p47-3)　·　[near 10.2](#p10-2)　·　[nearby 10.2](#p10-2)　·　[nearly 31.1](#p31-1)　·　[necessarily 49.1](#p49-1)　·　[negatively 46.3](#p46-3)　·　[neither 46.3](#p46-3)　·　[never 44.1](#p44-1)

[nevertheless 46.4](#p46-4)　·　[newly 44.3](#p44-3)　·　[next 16.2](#p16-2)　·　[nonetheless 46.4](#p46-4)　·　[nor 46.3](#p46-3)　·　[normally 44.2](#p44-2)　·　[north 10.3](#p10-3)　·　[not 46.3](#p46-3)　·　[notably 46.2](#p46-2)

[now 16.1](#p16-1)　·　[nowadays 44.1](#p44-1)　·　[nowhere 10.2](#p10-2)

**O**　[o'clock 16.1](#p16-1)　·　[obviously 49.4](#p49-4)　·　[occasionally 44.4](#p44-4)　·　[off 16.3](#p16-3)　·　[often 44.2](#p44-2)　·　[OK 30.3](#p30-3)　·　[on 16.2](#p16-2)　·　[once 16.2](#p16-2)　·　[online 27.2](#p27-2)

[only 46.1](#p46-1)　·　[openly 30.1](#p30-1)　·　[opposite 30.1](#p30-1)　·　[originally 44.1](#p44-1)　·　[otherwise 42.2](#p42-2)　·　[out 10.1](#p10-1)　·　[outdoors 47.1](#p47-1)　·　[outside 47.1](#p47-1)　·　[over 16.4](#p16-4)

[overall 41.4](#p41-4)　·　[overly 31.2](#p31-2)　·　[overnight 47.4](#p47-4)　·　[overseas 27.1](#p27-1)

**P**　[part-time 27.1](#p27-1)　·　[partially 47.2](#p47-2)　·　[particularly 46.1](#p46-1)　·　[partly 41.1](#p41-1)　·　[past 10.3](#p10-3)　·　[per cent 41.1](#p41-1)　·　[perfectly 30.2](#p30-2)　·　[perhaps 49.2](#p49-2)　·　[permanently 47.4](#p47-4)

[personally 46.2](#p46-2)　·　[positively 46.4](#p46-4)　·　[possibly 49.2](#p49-2)　·　[potentially 27.2](#p27-2)　·　[precisely 42.2](#p42-2)　·　[predominantly 41.2](#p41-2)　·　[presently 16.3](#p16-3)　·　[presumably 49.2](#p49-2)　·　[pretty 31.2](#p31-2)

[previously 44.1](#p44-1)　·　[primarily 41.2](#p41-2)　·　[probably 49.3](#p49-3)　·　[properly 42.2](#p42-2)　·　[purely 42.4](#p42-4)

**Q**　[quickly 30.4](#p30-4)　·　[quietly 30.2](#p30-2)　·　[quite 31.2](#p31-2)

**R**　[randomly 41.2](#p41-2)　·　[rapidly 47.2](#p47-2)　·　[rarely 44.2](#p44-2)　·　[rather 31.4](#p31-4)　·　[readily 46.2](#p46-2)　·　[really 31.4](#p31-4)　·　[reasonably 31.1](#p31-1)　·　[recently 44.3](#p44-3)　·　[regardless 27.3](#p27-3)

[regularly 44.3](#p44-3)　·　[relatively 31.1](#p31-1)　·　[remarkably 31.3](#p31-3)　·　[reportedly 27.1](#p27-1)　·　[respectively 41.3](#p41-3)　·　[right 10.3](#p10-3)　·　[roughly 41.3](#p41-3)　·　[round 10.4](#p10-4)

**S**　[sadly 27.2](#p27-2)　·　[same 38.1](#p38-1)　·　[second 38.1](#p38-1)　·　[second¹ 38.1](#p38-1)　·　[secondly 38.2](#p38-2)　·　[seemingly 49.1](#p49-1)　·　[seldom 44.3](#p44-3)　·　[separately 30.3](#p30-3)　·　[seriously 38.2](#p38-2)

[severely 47.3](#p47-3)　·　[shortly 16.3](#p16-3)　·　[significantly 41.4](#p41-4)　·　[similarly 27.3](#p27-3)　·　[simply 42.4](#p42-4)　·　[simultaneously 30.3](#p30-3)　·　[since 44.1](#p44-1)　·　[slightly 31.3](#p31-3)　·　[slowly 30.4](#p30-4)

[so 31.4](#p31-4)　·　[socially 46.2](#p46-2)　·　[solely 42.2](#p42-2)　·　[somehow 49.3](#p49-3)　·　[sometime 44.3](#p44-3)　·　[sometimes 44.4](#p44-4)　·　[somewhat 31.2](#p31-2)　·　[somewhere 10.4](#p10-4)　·　[soon 16.3](#p16-3)

[south 10.4](#p10-4)　·　[specifically 41.3](#p41-3)　·　[statistically 41.4](#p41-4)　·　[steadily 47.1](#p47-1)　·　[still 47.4](#p47-4)　·　[straight 10.3](#p10-3)　·　[strictly 38.4](#p38-4)　·　[strongly 46.2](#p46-2)　·　[subsequently 42.1](#p42-1)

[substantially 41.4](#p41-4)　·　[successfully 42.1](#p42-1)　·　[suddenly 30.3](#p30-3)　·　[sufficiently 47.4](#p47-4)　·　[supposedly 49.3](#p49-3)　·　[sure 49.3](#p49-3)　·　[surely 49.3](#p49-3)　·　[systematically 42.3](#p42-3)

**T**　[temporarily 47.4](#p47-4)　·　[terribly 31.3](#p31-3)　·　[thankfully 47.2](#p47-2)　·　[that 31.2](#p31-2)　·　[then 16.4](#p16-4)　·　[theoretically 42.4](#p42-4)　·　[there 10.1](#p10-1)　·　[thereafter 38.4](#p38-4)　·　[thereby 38.4](#p38-4)

[therefore 42.1](#p42-1)　·　[this 30.4](#p30-4)　·　[thoroughly 38.2](#p38-2)　·　[though 46.4](#p46-4)　·　[through 10.3](#p10-3)　·　[throughout 38.2](#p38-2)　·　[thus 42.3](#p42-3)　·　[today 16.4](#p16-4)　·　[together 38.1](#p38-1)

[tomorrow 16.1](#p16-1)　·　[tonight 16.4](#p16-4)　·　[too 31.4](#p31-4)　·　[totally 42.1](#p42-1)　·　[traditionally 44.4](#p44-4)　·　[truly 38.3](#p38-3)　·　[twice 38.2](#p38-2)　·　[typically 41.2](#p41-2)

**U**　[ultimately 27.4](#p27-4)　·　[under 47.2](#p47-2)　·　[underground 47.3](#p47-3)　·　[undoubtedly 49.4](#p49-4)　·　[unfortunately 47.2](#p47-2)　·　[up 47.2](#p47-2)　·　[upstairs 47.3](#p47-3)　·　[upwards 47.1](#p47-1)　·　[usually 44.2](#p44-2)

[utterly 30.3](#p30-3)

**V**　[very 31.1](#p31-1)

**W**　[way 31.3](#p31-3)　·　[well 30.1](#p30-1)　·　[west 10.4](#p10-4)　·　[whatsoever 49.2](#p49-2)　·　[when 16.1](#p16-1)　·　[where 10.1](#p10-1)　·　[whereby 27.4](#p27-4)　·　[wholly 42.4](#p42-4)　·　[why 49.1](#p49-1)

[widely 27.3](#p27-3)　·　[worldwide 27.1](#p27-1)　·　[worse 30.2](#p30-2)　·　[worst 30.4](#p30-4)　·　[wrong 30.4](#p30-4)

**Y**　[yesterday 16.4](#p16-4)　·　[yet 16.4](#p16-4)

### 助動詞　3項目

[be 24.3](#p24-3)　·　[do¹ 01.1](#p01-1)　·　[have 15.3](#p15-3)

### 接続詞　32項目

[after 19.3](#p19-3)　·　[albeit 19.1](#p19-1)　·　[although 24.1](#p24-1)　·　[and 19.2](#p19-2)　·　[as 19.1](#p19-1)　·　[because 12.1](#p12-1)　·　[before 18.1](#p18-1)　·　[but 12.1](#p12-1)　·　[except 12.3](#p12-3)

[if 19.2](#p19-2)　·　[nor 24.1](#p24-1)　·　[now 19.3](#p19-3)　·　[once 18.2](#p18-2)　·　[or 24.1](#p24-1)　·　[plus¹ 19.2](#p19-2)　·　[since 19.1](#p19-1)　·　[so 19.2](#p19-2)　·　[than 24.2](#p24-2)

[that 19.3](#p19-3)　·　[though 24.2](#p24-2)　·　[till 18.2](#p18-2)　·　[unless 19.2](#p19-2)　·　[until 12.3](#p12-3)　·　[when 24.2](#p24-2)　·　[whenever 12.1](#p12-1)　·　[where 12.2](#p12-2)　·　[whereas 12.3](#p12-3)

[wherever 12.2](#p12-2)　·　[whether 12.2](#p12-2)　·　[while 18.2](#p18-2)　·　[whilst 24.1](#p24-1)　·　[yet 24.3](#p24-3)

### 定冠詞　1項目

[the 01.2](#p01-2)

### 限定詞　42項目

**A**　[all 22.3](#p22-3)　·　[another 22.2](#p22-2)　·　[any 22.1](#p22-1)

**B**　[both 19.1](#p19-1)

**D**　[double 22.1](#p22-1)　·　[dozen 22.2](#p22-2)

**E**　[each 22.1](#p22-1)　·　[either 19.2](#p19-2)　·　[enough 22.2](#p22-2)　·　[every 22.3](#p22-3)

**F**　[few 45.1](#p45-1)　·　[first 45.2](#p45-2)

**H**　[half 22.1](#p22-1)　·　[her 01.2](#p01-2)　·　[his 01.2](#p01-2)

**I**　[its 22.1](#p22-1)

**L**　[last¹ 24.1](#p24-1)　·　[least 45.2](#p45-2)　·　[less 45.2](#p45-2)　·　[little 45.1](#p45-1)　·　[lot 45.3](#p45-3)

**M**　[many 45.1](#p45-1)　·　[more 45.2](#p45-2)　·　[most 45.1](#p45-1)　·　[much 22.2](#p22-2)　·　[my 01.2](#p01-2)

**N**　[neither 19.2](#p19-2)　·　[no 45.1](#p45-1)

**O**　[one 12.1](#p12-1)　·　[our 22.1](#p22-1)

**S**　[second¹ 45.2](#p45-2)　·　[several 45.2](#p45-2)　·　[some 22.2](#p22-2)　·　[such 45.3](#p45-3)

**T**　[that 01.2](#p01-2)　·　[their 45.1](#p45-1)　·　[this 01.1](#p01-1)

**W**　[what 15.1](#p15-1)　·　[whatever 45.3](#p45-3)　·　[which 15.1](#p15-1)　·　[whose 01.1](#p01-1)

**Y**　[your 01.2](#p01-2)

### 感嘆詞　20項目

[ah 29.3](#p29-3)　·　[all right 15.3](#p15-3)　·　[attention 29.1](#p29-1)　·　[bye 15.3](#p15-3)　·　[dear 29.2](#p29-2)　·　[goodbye 15.3](#p15-3)　·　[hello 01.1](#p01-1)　·　[hey 29.2](#p29-2)　·　[hi 15.1](#p15-1)

[no 29.2](#p29-2)　·　[oh 29.2](#p29-2)　·　[OK 18.3](#p18-3)　·　[please 29.2](#p29-2)　·　[sorry 01.3](#p01-3)　·　[thanks 01.3](#p01-3)　·　[welcome 29.1](#p29-1)　·　[well 29.3](#p29-3)　·　[wow 18.2](#p18-2)

[yeah 29.2](#p29-2)　·　[yes 15.1](#p15-1)

### 不定冠詞　1項目

[a, an 01.1](#p01-1)

### 不定詞の標識　1項目

[to 12.1](#p12-1)

### 連結動詞　1項目

[become 45.3](#p45-3)

### 法助動詞など　15項目

[can（能力） 15.2](#p15-2)　·　[can¹（許可） 15.2](#p15-2)　·　[cannot 15.2](#p15-2)　·　[could 18.1](#p18-1)　·　[have to 18.1](#p18-1)　·　[may 18.1](#p18-1)　·　[might 18.3](#p18-3)　·　[must 18.1](#p18-1)　·　[need 18.1](#p18-1)

[ought 18.3](#p18-3)　·　[shall 18.2](#p18-2)　·　[should 18.3](#p18-3)　·　[used to 15.2](#p15-2)　·　[will 15.3](#p15-3)　·　[would 15.2](#p15-2)

### 数詞　38項目

**B**　[billion 28.2](#p28-2)

**E**　[eight 36.1](#p36-1)　·　[eighteen 40.1](#p40-1)　·　[eighty 40.1](#p40-1)　·　[eleven 36.2](#p36-2)

**F**　[fifteen 14.1](#p14-1)　·　[fifth 37.1](#p37-1)　·　[fifty 14.2](#p14-2)　·　[first 37.1](#p37-1)　·　[five 37.1](#p37-1)　·　[forty 14.2](#p14-2)　·　[four 37.3](#p37-3)　·　[fourteen 14.1](#p14-1)　·　[fourth 37.1](#p37-1)

**H**　[hundred 28.2](#p28-2)

**M**　[million 28.2](#p28-2)

**N**　[nine 36.1](#p36-1)　·　[nineteen 40.1](#p40-1)　·　[ninety 40.1](#p40-1)

**O**　[one 37.2](#p37-2)

**S**　[second¹ 37.1](#p37-1)　·　[seven 36.1](#p36-1)　·　[seventeen 40.1](#p40-1)　·　[seventy 40.1](#p40-1)　·　[six 36.1](#p36-1)　·　[sixteen 14.1](#p14-1)　·　[sixty 14.2](#p14-2)

**T**　[ten 36.2](#p36-2)　·　[third 37.1](#p37-1)　·　[thirteen 14.1](#p14-1)　·　[thirty 14.2](#p14-2)　·　[thousand 28.2](#p28-2)　·　[three 37.2](#p37-2)　·　[trillion 28.1](#p28-1)　·　[twelve 36.1](#p36-1)　·　[twenty 40.3](#p40-3)

[two 37.1](#p37-1)

**Z**　[zero 28.1](#p28-1)

### 前置詞　66項目

**A**　[about 26.3](#p26-3)　·　[above 03.1](#p03-1)　·　[according to 17.2](#p17-2)　·　[across 09.1](#p09-1)　·　[after 17.2](#p17-2)　·　[against 03.3](#p03-3)　·　[along 09.2](#p09-2)　·　[alongside 09.2](#p09-2)　·　[amid 26.3](#p26-3)

[among 03.2](#p03-2)　·　[around 03.3](#p03-3)　·　[as 26.3](#p26-3)　·　[at 17.1](#p17-1)

**B**　[before 17.1](#p17-1)　·　[behind 09.2](#p09-2)　·　[below 09.2](#p09-2)　·　[beneath 09.3](#p09-3)　·　[beside 03.3](#p03-3)　·　[besides 02.1](#p02-1)　·　[between 11.3](#p11-3)　·　[beyond 09.3](#p09-3)　·　[but 26.1](#p26-1)

[by 26.1](#p26-1)

**D**　[despite 26.2](#p26-2)　·　[down 11.3](#p11-3)　·　[during 17.3](#p17-3)

**E**　[except 26.2](#p26-2)

**F**　[following 17.3](#p17-3)　·　[for 02.1](#p02-1)　·　[from 09.1](#p09-1)

**I**　[in 03.4](#p03-4)　·　[including 26.2](#p26-2)　·　[inside 03.2](#p03-2)　·　[into 03.1](#p03-1)

**L**　[like（類似） 02.3](#p02-3)

**N**　[near 11.1](#p11-1)　·　[next to 03.2](#p03-2)

**O**　[of 03.1](#p03-1)　·　[off 03.1](#p03-1)　·　[on 03.2](#p03-2)　·　[onto 03.2](#p03-2)　·　[opposite 11.2](#p11-2)　·　[out 11.2](#p11-2)　·　[outside 11.2](#p11-2)　·　[over 09.3](#p09-3)

**P**　[past 11.3](#p11-3)　·　[per 26.1](#p26-1)　·　[plus¹ 26.1](#p26-1)

**R**　[regardless of 26.4](#p26-4)　·　[round 11.3](#p11-3)

**S**　[since 17.1](#p17-1)

**T**　[through 09.3](#p09-3)　·　[throughout 17.1](#p17-1)　·　[till 17.2](#p17-2)　·　[to 09.1](#p09-1)　·　[towards 09.2](#p09-2)

**U**　[under 03.3](#p03-3)　·　[unlike 02.3](#p02-3)　·　[until 17.2](#p17-2)　·　[up 11.2](#p11-2)　·　[upon 17.3](#p17-3)

**V**　[versus 26.1](#p26-1)　·　[via 09.3](#p09-3)

**W**　[with 26.2](#p26-2)　·　[within 17.3](#p17-3)　·　[without 26.2](#p26-2)

### 代名詞　77項目

**A**　[all 32.1](#p32-1)　·　[another 04.3](#p04-3)　·　[any 32.2](#p32-2)　·　[anybody 04.1](#p04-1)　·　[anyone 32.1](#p32-1)　·　[anything 04.1](#p04-1)　·　[anywhere 11.1](#p11-1)

**B**　[both 32.3](#p32-3)

**D**　[double 23.1](#p23-1)

**E**　[each 32.3](#p32-3)　·　[either 32.3](#p32-3)　·　[enough 23.1](#p23-1)　·　[everybody 04.4](#p04-4)　·　[everyone 04.1](#p04-1)　·　[everything 04.3](#p04-3)

**F**　[few 32.1](#p32-1)

**H**　[half 23.1](#p23-1)　·　[he 05.1](#p05-1)　·　[her 05.2](#p05-2)　·　[hers 02.2](#p02-2)　·　[herself 05.2](#p05-2)　·　[him 05.1](#p05-1)　·　[himself 05.1](#p05-1)　·　[his 02.2](#p02-2)

**I**　[I 05.1](#p05-1)　·　[it 05.3](#p05-3)　·　[itself 05.3](#p05-3)

**L**　[least 23.2](#p23-2)　·　[less 23.3](#p23-3)　·　[little 23.2](#p23-2)　·　[lot 23.3](#p23-3)

**M**　[many 32.2](#p32-2)　·　[me 05.1](#p05-1)　·　[mine（所有） 02.2](#p02-2)　·　[more 23.4](#p23-4)　·　[most 32.4](#p32-4)　·　[much 23.3](#p23-3)　·　[myself 05.4](#p05-4)

**N**　[neither 32.3](#p32-3)　·　[no one 04.1](#p04-1)　·　[nobody 04.4](#p04-4)　·　[none 32.2](#p32-2)　·　[nothing 04.2](#p04-2)

**O**　[one 04.1](#p04-1)　·　[other 04.2](#p04-2)　·　[ours 02.3](#p02-3)　·　[ourselves 07.1](#p07-1)　·　[own 02.4](#p02-4)

**P**　[plenty 23.1](#p23-1)

**S**　[same 23.2](#p23-2)　·　[several 32.2](#p32-2)　·　[she 05.2](#p05-2)　·　[some 23.4](#p23-4)　·　[somebody 04.2](#p04-2)　·　[someone 04.3](#p04-3)　·　[something 04.4](#p04-4)　·　[somewhere 11.4](#p11-4)　·　[such 07.4](#p07-4)

**T**　[that 05.4](#p05-4)　·　[theirs 02.3](#p02-3)　·　[them 07.1](#p07-1)　·　[themselves 07.2](#p07-2)　·　[they 07.1](#p07-1)　·　[this 05.3](#p05-3)

**U**　[us 07.1](#p07-1)

**W**　[we 07.1](#p07-1)　·　[what 07.1](#p07-1)　·　[whatever 07.2](#p07-2)　·　[when 17.4](#p17-4)　·　[which 07.2](#p07-2)　·　[who 07.2](#p07-2)　·　[whoever 07.3](#p07-3)　·　[whom 07.3](#p07-3)　·　[whose 02.2](#p02-2)

**Y**　[you 07.3](#p07-3)　·　[yours 02.2](#p02-2)　·　[yourself 07.3](#p07-3)

### 資料と照合範囲

本文の太字と索引を照合した対象は、副詞391行とその他の品詞297行の計688行。同じ綴りの別項目も個別に扱った。第01話には不定冠詞の二つの形がそろう。小話の英文は7,184語、部末の言い換え英文は90語。英語は許可リストの見出し語とその文法上の語形を使用した。たとえば *took* は *take*、*children* は *child* に照合した。

会話で前提が少しずつずれる仕掛けは『アリス』の二作品を、日常の問い・数値の読み取り・理由の言い分けは既存の回答集を参考にした。短い英文を一部だけ変えて意味を動かす練習は、添付の学習ノートにある方法を用いた。物語と例文は本書のための創作。

文法書で引き直す場合の手掛かりは、ポケット文法の第50–56項（義務・許可・可能性など）、第120–130項（副詞的に働く表現）、実用語法の第195–201項（位置・焦点・頻度・場所など）。項番号は添付の目次で確認した。

<!-- 組版引継ぎ：指定仕様書 v1.0 の共通設定を適用する。A4縦・両面長辺とじ・原寸、白地・濃紺見出し・青の中見出し、本文8.6 pt、欧文 Noto Sans SemiCondensed・和文 Noto Sans CJK JP。表紙の次の偶数ページから見開きを始める。英文と直後の対訳は一組として保持。本文・索引・しおりは検索可能な文字を使い、索引の話・段落番号を固定する。原仕様の5見開きおよび12ページは既存目次専用。本書の総ページ数、表紙目次のページ参照、下端の物理ページ番号としおりは組版後に確定する。末尾は裏表紙。 -->
