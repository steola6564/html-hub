# 赤い点のついた傘　明日の部屋

*The Room for Tomorrow*

英日対訳の連作12話　｜　第245〜256話

川の博物館に、夜の部屋を一晩だけ開く計画が持ち上がる。静かに読みたい料理係、声を合わせたい歌い手、八時に帰る警備員。町の掲示物を印刷する私と記録係は、一枚の約束を実際の夜へ変えていく。

英語本文 6,741語。英文の直下に日本語訳を置いた。番号は「話．対訳単位」。各話の後に、主な用例から本文へ戻れる索引を付けている。

OLPGは Oxford Learner’s Pocket Grammar、PEUは Practical English Usage。参照番号は添付Contents Indexの項目番号で、用例の説明は本作の英文と場面についての分析。Conversation Modelの下位分類には、添付された暫定分類の名称を用いた。

## 目次

- [245　日付のない掲示](#story-245)
- [246　誰でも座れる椅子](#story-246)
- [247　時計が聞いたこと](#story-247)
- [248　二人分の署名](#story-248)
- [249　無料の部屋の費用](#story-249)
- [250　まだ渡さない声](#story-250)
- [251　動いた椅子](#story-251)
- [252　雨に備えて](#story-252)
- [253　小さくて大きな音](#story-253)
- [254　刷り直せない一枚](#story-254)
- [255　役に立つ空欄](#story-255)
- [256　返ってきた部屋](#story-256)

---

<a id="story-245"></a>

## 245　日付のない掲示

*A Notice Without a Day*

<a id="c245-01"></a>

**245.01**　I print the notices that tell our town what it is going to do.

> 私は、町がこれから何をするのかを知らせる掲示を印刷している。

<a id="c245-02"></a>

**245.02**　On Wednesday morning, I carried a notice to the museum by the river, although the town had not quite decided.

> 水曜の朝、町の考えはまだ十分にはまとまっていなかったが、私は掲示を一枚、川辺の博物館へ運んだ。

<a id="c245-03"></a>

**245.03**　The new clerk was standing below a copy of a photograph of two boats.

> 新しく来た記録係の女性が、二艘の舟を写した写真の複製の下に立っていた。

<a id="c245-04"></a>

**245.04**　She kept the museum records, and at present she was recording an empty space.

> 彼女は博物館の記録を管理していて、今は空いた場所を記録していた。

<a id="c245-05"></a>

**245.05**　The old photograph was safe upstairs, but the copy’s label had been taken down because its words had left one of the boats out.

> 古い写真は上階に安全に保管されていたが、複製の札は、その言葉では片方の舟が抜け落ちてしまうため外されていた。

<a id="c245-06"></a>

**245.06**　The clerk measured the space, then shut her book.

> 記録係は空間の広さを測り、それから帳面を閉じた。

<a id="c245-07"></a>

**245.07**　‘A useful size,’ she said. ‘Something may fit there eventually.’

> 「使いやすそうな大きさね。そのうち何か収まるかもしれない」と彼女は言った。

<a id="c245-08"></a>

**245.08**　I held up my paper.

> 私は紙を掲げた。

<a id="c245-09"></a>

**245.09**　‘The room will open tomorrow,’ she read.

> 「部屋は明日開きます」と彼女は読んだ。

<a id="c245-10"></a>

**245.10**　‘It is open now.’

> 「今も開いているわね」

<a id="c245-11"></a>

**245.11**　‘Tomorrow it will be open in the evening as well.’

> 「明日は夜も開いているんです」

<a id="c245-12"></a>

**245.12**　‘Which room?’

> 「どの部屋のこと？」

<a id="c245-13"></a>

**245.13**　I pointed at the room around us, as though it had just arrived and needed an introduction.

> 私は、部屋が今やって来て紹介を待っているかのように、周囲を指さした。

<a id="c245-14"></a>

**245.14**　‘This one.’

> 「この部屋です」

<a id="c245-15"></a>

**245.15**　‘That will be clear to someone standing here,’ she said, looking towards the window.

> 「ここに立っている人には、それで分かるわね」と彼女は窓のほうを見ながら言った。

<a id="c245-16"></a>

**245.16**　Across the road, a woman was trying to lift a basket while keeping a book under her arm.

> 道の向こうでは、女性が本を脇に挟んだまま、籠を持ち上げようとしていた。

<a id="c245-17"></a>

**245.17**　I went out and carried the basket as far as the museum door.

> 私は外に出て、籠を博物館の戸口まで運んだ。

<a id="c245-18"></a>

**245.18**　She followed me in, with the book still firmly under her arm.

> 女性は、本をまだしっかりと脇に挟んだまま、私について中へ入った。

<a id="c245-19"></a>

**245.19**　The corner of my notice had folded under the handle of the basket.

> 掲示の角が、籠の持ち手の下で折れ曲がっていた。

<a id="c245-20"></a>

**245.20**　I pressed it flat on a table while the cook studied the photograph, turning her head slightly to see the second boat.

> 料理係が写真に見入り、二艘目の舟を見ようと少し首を傾けている間、私はテーブルの上で紙を平らにした。

<a id="c245-21"></a>

**245.21**　‘Is that the notice for the room you can see from the bridge?’ she asked.

> 「それは、橋から見える部屋の掲示？」と彼女は尋ねた。

<a id="c245-22"></a>

**245.22**　The clerk looked at me, and I wrote the name of the museum above my sentence.

> 記録係が私を見ると、私は自分の文の上に博物館の名前を書いた。

<a id="c245-23"></a>

**245.23**　The woman was a cook in the cafe across the road.

> その女性は、道の向こうのカフェで働く料理係だった。

<a id="c245-24"></a>

**245.24**　She could see our windows from her kitchen, but she was usually at work while the museum was open.

> 台所からこちらの窓は見えたが、博物館が開いている時間は、たいてい仕事をしていた。

<a id="c245-25"></a>

**245.25**　‘What are you going to show us?’ she asked.

> 「何を見せてくれる予定なの？」と彼女は尋ねた。

<a id="c245-26"></a>

**245.26**　I had imagined a talk, with somebody explaining the photographs and everybody else being interested.

> 私は、誰かが写真を解説し、ほかの人が皆、興味を持って聞く説明会を思い描いていた。

<a id="c245-27"></a>

**245.27**　The cook put down her basket and tried to free the book.

> 料理係は籠を置き、本を取り出そうとした。

<a id="c245-28"></a>

**245.28**　‘I spend all day listening to people,’ she said.

> 「一日じゅう、人の話を聞いているの」と彼女は言った。

<a id="c245-29"></a>

**245.29**　‘I was hoping for somewhere to sit.’

> 「どこかに座れたらと思っていたんだけど」

<a id="c245-30"></a>

**245.30**　The clerk reached for her book again, then stopped with her hand on the cover.

> 記録係は再び帳面へ手を伸ばしたが、表紙に手を置いたところで動きを止めた。

<a id="c245-31"></a>

**245.31**　‘Would you like to read, or would you rather leave the book closed for a while?’

> 「本を読みたい？　それとも、しばらく閉じたままにしておきたい？」

<a id="c245-32"></a>

**245.32**　‘I should like the choice.’

> 「選べるといいわね」

<a id="c245-33"></a>

**245.33**　The cook pulled a loose sheet from between the pages and used it to wipe a mark from her basket.

> 料理係はページの間から一枚の紙を抜き取り、それで籠の汚れを拭いた。

<a id="c245-34"></a>

**245.34**　‘That was my list,’ she said when she saw me watching. ‘The story is safe.’

> 私が見ているのに気づくと、「今のは私のリストよ。物語は無事」と彼女は言った。

<a id="c245-35"></a>

**245.35**　‘And what time would help?’ the clerk asked.

> 「何時なら都合がいい？」と記録係が尋ねた。

<a id="c245-36"></a>

**245.36**　‘After six, when I have finished work.’

> 「六時過ぎ、仕事を終えてからね」

<a id="c245-37"></a>

**245.37**　The clerk brought a chair from the store and offered it to her.

> 記録係は保管室から椅子を一脚運び、料理係に勧めた。

<a id="c245-38"></a>

**245.38**　‘We could try one evening,’ she said. ‘This Thursday.’

> 「一晩、試してみてもいいわね。今度の木曜に」と彼女は言った。

<a id="c245-39"></a>

**245.39**　‘For a talk?’ I asked.

> 「説明会を開くためですか？」と私は尋ねた。

<a id="c245-40"></a>

**245.40**　‘For people who cannot usually come.’

> 「普段は来られない人たちのために」

<a id="c245-41"></a>

**245.41**　The cook sat down, but kept the basket between her feet.

> 料理係は腰を下ろしたが、籠は両足の間に置いておいた。

<a id="c245-42"></a>

**245.42**　‘Will there be a charge?’

> 「料金はかかる？」

<a id="c245-43"></a>

**245.43**　‘We can make the visit free,’ the clerk said.

> 「来てもらうのは無料にできるわ」と記録係は言った。

<a id="c245-44"></a>

**245.44**　‘I shall find out how long we can keep the room open.’

> 「部屋を何時まで開けておけるか、確かめるわね」

<a id="c245-45"></a>

**245.45**　I turned the paper over and began another notice, this time leaving a space for the hours.

> 私は紙を裏返して新しい掲示を書き始め、今度は時間を書き込む場所を空けた。

<a id="c245-46"></a>

**245.46**　Behind me, the cook opened her book, read half a page, and shut it when a voice called from across the road.

> 私の後ろで料理係は本を開き、半ページを読むと、道の向こうから呼ぶ声がしたので閉じた。

<a id="c245-47"></a>

**245.47**　The clerk took the basket to the door for her.

> 記録係は彼女の籠を戸口まで運んだ。

<a id="c245-48"></a>

**245.48**　I left the empty space beneath the boats exactly as I had found it.

> 私は舟の写真の下の空間を、来たときと同じように空けておいた。

### この話の用例索引

#### Grammar・Usage

| OLPG・PEUの該当項目 | 本文の用例 | 場面での働き |
|---|---|---|
| OLPG 96 The main uses of a/an and the ／ PEU 134 articles: basic information (A) | [245.03](#c245-03) “a copy of a photograph” ／ [245.05](#c245-05) “the copy’s label” | a copy で展示物を初めて導入し、続く the copy で同じ複製を指す。上階の原物との位置関係も示される。 |
| OLPG 103 Demonstratives ／ PEU 144 this and that | [245.14](#c245-14) “This one.” ／ [245.15](#c245-15) “someone standing here” | This one はその場の部屋を指せるが、掲示を別の場所で読む人にも通じるかが問題になる。窓外の人を見た後、博物館名が書き加えられる。 |
| OLPG 172 Relative clauses without commas ／ PEU 234 identifying and non-identifying clauses: the tall man who . . .; Mr Rogers, who . . . | [245.21](#c245-21) “the room you can see from the bridge” ／ [245.40](#c245-40) “people who cannot usually come” | 関係節が、橋から見えるどの部屋か、普段来られないどの人たちかを絞る。場所の特定から、夜間利用を設ける相手の具体化へ進む。 |
| OLPG 38 Will and shall ／ OLPG 41 Will, be going to, or the present tense? ／ PEU 38 will ／ PEU 39 will, going to and present progressive: advanced points | [245.09](#c245-09) “The room will open tomorrow” ／ [245.25](#c245-25) “What are you going to show us?” | will による告知に対し、料理係は be going to で催しの意図・計画を尋ねる。開くという告知が先行し、そこで何をするかは相談の中で変わる。 |

#### Conversation Modelの意味操作

| 操作と暫定下位分類 | 人物・本文位置 | 発言を受けて起きたこと |
|---|---|---|
| 補足 — 明確化・言い換え | 記録係　[245.12](#c245-12)・[245.15](#c245-15) | 掲示の the room が何を指すか問い直し、その場の指さしが通じる相手を示す。印刷物に場所の名前を加える必要が見えてくる。 |
| 反論 — 代替・選好 | 料理係　[245.29](#c245-29)・[245.32](#c245-32) | 語り手の想定する説明会とは異なる希望として、座れる場所と過ごし方を選べることを求める。その希望が、記録係の用途の尋ね直しにつながる。 |
| 補足 — 理由・説明 | 料理係　[245.36](#c245-36) | 何時が都合よいかという問いに、六時を過ぎ、仕事を終えてからという時間を答える。 |
| 発展 — 結果・帰結 | 記録係　[245.38](#c245-38)・[245.40](#c245-40) | 普段は仕事中で来られないという事情と、座って過ごしたい希望を受け、一晩の試行を提案する。まだ閉める時刻を調べる段階だと残している。 |

---

<a id="story-246"></a>

## 246　誰でも座れる椅子

*A Chair for Anyone*

<a id="c246-01"></a>

**246.01**　By noon, we had brought eight chairs from the museum store into the room.

> 正午までに、私たちは博物館の保管室から、椅子を八脚運び込んでいた。

<a id="c246-02"></a>

**246.02**　I placed them in two rows, with four chairs in each row and a clear path to the door.

> 私は一列に四脚ずつ、二列に並べ、戸口へ続く通路を空けた。

<a id="c246-03"></a>

**246.03**　The clerk counted them while I carried in a small table.

> 私が小さなテーブルを運び入れる間、記録係は椅子を数えた。

<a id="c246-04"></a>

**246.04**　‘A chair for everyone,’ I suggested, putting a large card on the nearest seat.

> 私は手近な座面に大きな札を置き、「みんなのための椅子、というのは？」と提案した。

<a id="c246-05"></a>

**246.05**　‘Everyone in town?’ asked the cook, who had come back during her break.

> 休憩中に戻ってきた料理係が、「町のみんなの？」と尋ねた。

<a id="c246-06"></a>

**246.06**　She looked from the eight chairs to the houses beyond the river.

> 彼女は八脚の椅子から、川の向こうの家々へと視線を移した。

<a id="c246-07"></a>

**246.07**　‘The people will have to be rather small.’

> 「それなら、ずいぶん小さな人たちでないとね」

<a id="c246-08"></a>

**246.08**　‘Anyone can come,’ the clerk said. ‘That is what we mean.’

> 「誰でも来ていい、という意味よ」と記録係は言った。

<a id="c246-09"></a>

**246.09**　‘And each person will have somewhere to sit?’

> 「それで、一人ひとりに座る場所があるの？」

<a id="c246-10"></a>

**246.10**　I lifted the card and looked for a better place to put everyone.

> 私は札を持ち上げ、「みんな」をもっと上手に収められる場所を探した。

<a id="c246-11"></a>

**246.11**　The clerk took a pencil and wrote a different line beneath mine.

> 記録係は鉛筆を取り、私の文の下に別の一行を書いた。

<a id="c246-12"></a>

**246.12**　‘For people who work all day,’ the cook read.

> 「一日じゅう働く人たちのために」と料理係は読んだ。

<a id="c246-13"></a>

**246.13**　‘And if I have a day off?’

> 「私が休みの日だったら？」

<a id="c246-14"></a>

**246.14**　‘Then you can come during the ordinary opening hours.’

> 「それなら、普段の開館時間にも来られるわね」

<a id="c246-15"></a>

**246.15**　The cook pulled out the chair that was nearest the window, but did not sit down.

> 料理係は窓にいちばん近い椅子を引いたが、腰を下ろさなかった。

<a id="c246-16"></a>

**246.16**　‘I might spend that day with my mother.’

> 「その日は母と過ごすかもしれないわ」

<a id="c246-17"></a>

**246.17**　‘Or I might be tired and stay at home.’

> 「疲れて、家にいるかもしれない」

<a id="c246-18"></a>

**246.18**　The clerk rubbed the end of the pencil between her fingers.

> 記録係は、鉛筆の端を指の間でこすった。

<a id="c246-19"></a>

**246.19**　She had already begun a second card, with spaces for the visitor’s name and the hours they worked.

> 彼女はすでに二枚目の札を書き始め、来場者の名前と働いている時間の記入欄を設けていた。

<a id="c246-20"></a>

**246.20**　‘If I fill that in, will you ask me to prove it?’

> 「そこに書いたら、それを証明するように言うの？」

<a id="c246-21"></a>

**246.21**　The cook’s voice was still light, but she held the back of the chair with a firm grip.

> 料理係の声はまだ軽い調子だったが、椅子の背をしっかりと握っていた。

<a id="c246-22"></a>

**246.22**　‘I wanted to keep the chairs for the people who needed this evening.’

> 「この夜の時間が必要な人のために、椅子を確保したかったの」

<a id="c246-23"></a>

**246.23**　‘So did I,’ said the cook, ‘but I would rather leave my working hours at work.’

> 「私もよ。でも、仕事の時間の話は仕事場に置いてきたいわ」と料理係は言った。

<a id="c246-24"></a>

**246.24**　She put her book on the table and turned the chair towards the river.

> 彼女は本をテーブルに置き、椅子を川のほうへ向けた。

<a id="c246-25"></a>

**246.25**　The clerk sat beside her on the next chair.

> 記録係はその隣の椅子に座った。

<a id="c246-26"></a>

**246.26**　‘What would make this easy to use?’

> 「どうしたら、ここを気軽に使える？」

<a id="c246-27"></a>

**246.27**　‘A free chair, and no need to explain why I want it.’

> 「空いている椅子があって、それを使いたい理由を説明しなくていいことね」

<a id="c246-28"></a>

**246.28**　I crossed out both lines and wrote that anyone was welcome to use a chair when one was free.

> 私は二行とも消し、椅子が空いていれば誰でも気軽に使える、と書いた。

<a id="c246-29"></a>

**246.29**　The cook read it and asked me to move the table a little closer.

> 料理係はそれを読むと、テーブルをもう少し近くへ動かしてほしいと頼んだ。

<a id="c246-30"></a>

**246.30**　She could now put down her book without having to get up.

> これで、立ち上がらなくても本を置けるようになった。

<a id="c246-31"></a>

**246.31**　The door opened, and a man came in carrying a thin black case.

> 戸が開き、薄い黒いケースを持った男性が入ってきた。

<a id="c246-32"></a>

**246.32**　He was a singer who practised with two friends after work.

> 彼は仕事の後、二人の友人と練習する歌い手だった。

<a id="c246-33"></a>

**246.33**　‘I heard that everyone was welcome,’ he said.

> 「誰でも歓迎だと聞きました」と彼は言った。

<a id="c246-34"></a>

**246.34**　He opened the case, which contained music on loose sheets, and laid it on the table.

> 彼はケースを開いてテーブルに置いた。中には、ばらばらの紙に書かれた楽譜が入っていた。

<a id="c246-35"></a>

**246.35**　‘We need somewhere for our voices.’

> 「私たちの声のための場所が欲しいんです」

<a id="c246-36"></a>

**246.36**　The cook closed her book with one finger inside it.

> 料理係は指を一本ページの間に挟んで、本を閉じた。

<a id="c246-37"></a>

**246.37**　‘How much room do they take?’

> 「声は、どれくらい場所を取るの？」

<a id="c246-38"></a>

**246.38**　He laughed, then looked at the book.

> 彼は笑い、それから本を見た。

<a id="c246-39"></a>

**246.39**　‘More than three chairs, perhaps.’

> 「椅子三脚分よりは、広いかもしれません」

<a id="c246-40"></a>

**246.40**　‘I mean somewhere to practise together, rather than three places to sit.’

> 「座る場所が三つというより、一緒に練習できる場所という意味です」

<a id="c246-41"></a>

**246.41**　Through the window we could see the wall on the river side of the building.

> 窓越しに、建物の川側の壁が見えた。

<a id="c246-42"></a>

**246.42**　He went outside and tried a few notes there while we stayed by the table.

> 私たちがテーブルのそばにいる間、彼は外へ出て、そこで少し声を出してみた。

<a id="c246-43"></a>

**246.43**　His voice reached us through the open window, but it was easy to hear one another over it.

> 開いた窓から彼の声が届いたが、その声がしていても、私たちは互いの話を楽に聞き取れた。

<a id="c246-44"></a>

**246.44**　‘We could try that tomorrow,’ he said when he returned.

> 戻ってくると彼は、「明日、あそこで試してみるのはどうでしょう」と言った。

<a id="c246-45"></a>

**246.45**　‘Provided we agree about the hours,’ the clerk said.

> 「使う時間について合意できればね」と記録係は言った。

<a id="c246-46"></a>

**246.46**　The singer put away his music, and the cook returned to her page.

> 歌い手は楽譜をしまい、料理係は読んでいたページに戻った。

<a id="c246-47"></a>

**246.47**　I hung the card on the door, above the handle where everyone could see it.

> 私は、誰からも見えるように、取っ手の上に札を掛けた。

### この話の用例索引

#### Grammar・Usage

| OLPG・PEUの該当項目 | 本文の用例 | 場面での働き |
|---|---|---|
| OLPG 114 Everyone, something, etc ／ PEU 149 all, everybody/everyone and everything ／ PEU 180 somebody, someone, anybody, anyone, etc | [246.04](#c246-04) “A chair for everyone” ／ [246.08](#c246-08) “Anyone can come” | everyone の呼びかけを料理係は町全体の人数へ広げ、anyone can come は個々人の来場資格を開く。歓迎の範囲と八脚の容量が会話の中で別々に検討される。 |
| OLPG 107 Both, either, neither, every, and each ／ PEU 153 each | [246.02](#c246-02) “four chairs in each row” ／ [246.09](#c246-09) “each person will have somewhere to sit” | each は列を一つずつ数える配置説明と、人を一人ずつ見る問いの両方に使われる。後者によって、全体への歓迎から一人ごとの座席へ焦点が移る。 |
| OLPG 172 Relative clauses without commas ／ OLPG 173 Relative clauses with commas ／ PEU 234 identifying and non-identifying clauses: the tall man who . . .; Mr Rogers, who . . . | [246.05](#c246-05) “the cook, who had come back during her break” ／ [246.32](#c246-32) “a singer who practised with two friends” | the cook, who ... は既知の料理係に休憩中という事情を添える。一方、a singer who ... は新しい男性を練習仲間との関係で導入し、三人分の利用希望へつながる。 |
| OLPG 113 One and ones ／ PEU 182 one (substitute word): a big one | [246.28](#c246-28) “use a chair when one was free” | one は先に出た a chair を受ける。書き直された札は、空いている一脚を使える条件として、利用希望と席数を結び付ける。 |

#### Conversation Modelの意味操作

| 操作と暫定下位分類 | 人物・本文位置 | 発言を受けて起きたこと |
|---|---|---|
| 反論 — 限定・留保 | 記録係　[246.08](#c246-08)・[246.09](#c246-09) | 「みんなの椅子」が人数分の席を連想させたため、意図した歓迎の範囲を、誰でも来られるという形に絞って言い直す。料理係はそこから一人ごとの座席を問い返す。 |
| 反論 — 条件・例外 | 料理係　[246.13](#c246-13)・[246.16](#c246-16) | 一日働く人に対象を絞る札に対し、仕事が休みの日を提示する。さらに、休みの日にも家族との時間や疲労があるため、通常時間に来られるとは限らないと具体化する。 |
| 反論 — 代替・選好 | 料理係　[246.23](#c246-23)・[246.27](#c246-27) | 必要な人に席を残したい意図を受け止めながら、勤務時間を説明して席を得る負担を嫌う自分の希望を示す。勤務時間の説明を、席を使うための条件にしてほしくないという希望を伝える。 |
| 反論 — 修正 | 私　[246.28](#c246-28)・[246.28](#c246-28) | 二つの札の条件が生んだ問題を受け、両方の文を消す。勤務状況による資格確認を外し、空席があるときの利用へ文面を修正する。 |
| 補足 — 明確化・言い換え | 歌い手　[246.40](#c246-40) | 声のための場所がどれほどの広さを取るかという料理係の問いに、三人が一緒に練習できる場所という意味を明確にする。座席だけでは測れない希望が現れる。 |

---

<a id="story-247"></a>

## 247　時計が聞いたこと

*What the Clock Had Heard*

<a id="c247-01"></a>

**247.01**　In the afternoon, the clerk sent for me because the museum seemed to have two closing times.

> 午後、博物館には閉館時刻が二つあるようだと、記録係が私を呼んだ。

<a id="c247-02"></a>

**247.02**　One was written in the book on her desk, and the other had arrived with the cook.

> 一つは机の上の帳面に書いてあり、もう一つは料理係とともにやって来ていた。

<a id="c247-03"></a>

**247.03**　The book said five, but the cook had seen people in the room after six the previous Thursday.

> 帳面では五時だったが、料理係は前の木曜、六時を過ぎてから室内に人がいるのを見ていた。

<a id="c247-04"></a>

**247.04**　‘I have been trying to find out how late we already stay open,’ the clerk said.

> 「普段から何時まで開けているのか、調べ続けているところなの」と記録係は言った。

<a id="c247-05"></a>

**247.05**　She moved a little clock so that all three of us could see its face.

> 彼女は小さな時計を動かし、私たち三人全員に文字盤が見えるようにした。

<a id="c247-06"></a>

**247.06**　‘Was it this clock you heard?’

> 「聞こえたのは、この時計？」

<a id="c247-07"></a>

**247.07**　The cook nodded and put a clean cloth beside her book.

> 料理係はうなずき、本の横に清潔な布を置いた。

<a id="c247-08"></a>

**247.08**　‘It struck six while I was waiting outside.’

> 「外で待っている間に、六時を打ったの」

<a id="c247-09"></a>

**247.09**　‘Then the room was open until six,’ I said, and reached for my pencil.

> 「それなら、六時まで開いていたんですね」と私は言い、鉛筆に手を伸ばした。

<a id="c247-10"></a>

**247.10**　‘I did not get in,’ she said.

> 「私は入れなかったわ」

<a id="c247-11"></a>

**247.11**　My pencil stayed above the paper.

> 私の鉛筆は、紙の上で止まった。

<a id="c247-12"></a>

**247.12**　‘You said that people were inside.’

> 「中に人がいたと言いましたよね」

<a id="c247-13"></a>

**247.13**　‘They were, and I was outside.’

> 「いたわ。それで、私は外にいたの」

<a id="c247-14"></a>

**247.14**　‘When the clock rang, I had been standing there for nearly ten minutes,’ the cook added.

> 「時計が鳴ったときには、もう十分近くそこに立っていたの」と料理係は付け加えた。

<a id="c247-15"></a>

**247.15**　The clerk drew a short line between the two times in her book.

> 記録係は帳面の二つの時刻の間に、短い線を引いた。

<a id="c247-16"></a>

**247.16**　‘Were you waiting to come in, or had you arranged to meet someone?’

> 「中へ入るのを待っていたの？　それとも、誰かに会う約束をしていた？」

<a id="c247-17"></a>

**247.17**　‘I wanted to look at the boats.’

> 「舟の写真を見たかったの」

<a id="c247-18"></a>

**247.18**　‘I had finished work early, and I could see the lights.’

> 「早めに仕事を終えて、明かりが見えたから」

<a id="c247-19"></a>

**247.19**　She folded the cloth twice and put it in her pocket.

> 彼女は布を二度折り、ポケットへ入れた。

<a id="c247-20"></a>

**247.20**　‘I tried the door, but it was locked.’

> 「戸を開けようとしたけれど、鍵がかかっていたの」

<a id="c247-21"></a>

**247.21**　The guard came in with a book under his arm and a key in his hand.

> 警備員が、脇に帳面を抱え、手に鍵を持って入ってきた。

<a id="c247-22"></a>

**247.22**　‘I have brought the record of our hours,’ he said.

> 「勤務時間の記録を持ってきました」と彼は言った。

<a id="c247-23"></a>

**247.23**　He was the man who had been inside the room that Thursday.

> 彼は、その木曜に室内にいた男性だった。

<a id="c247-24"></a>

**247.24**　The cook recognized him and smiled without quite looking pleased.

> 料理係は彼に見覚えがあり、笑顔を見せたが、喜んでいるというほどの表情ではなかった。

<a id="c247-25"></a>

**247.25**　‘I had closed the doors before you came,’ he told her.

> 「あなたが来る前に、入口の戸を閉めていたんです」と彼は料理係に話した。

<a id="c247-26"></a>

**247.26**　‘We were moving a heavy table, and then I was checking the windows.’

> 「重いテーブルを動かしていて、それから私は窓を点検していました」

<a id="c247-27"></a>

**247.27**　‘I saw you from the other end of the room, through a window above the table.’

> 「部屋の反対側から、テーブルの上の窓越しにあなたが見えたんです」

<a id="c247-28"></a>

**247.28**　‘By the time I reached the door, you had gone round the corner.’

> 「私が戸口へたどり着いたときには、あなたはもう角を曲がっていました」

<a id="c247-29"></a>

**247.29**　The cook looked down at her book.

> 料理係は自分の本に目を落とした。

<a id="c247-30"></a>

**247.30**　‘I thought someone might open the door if I waited.’

> 「待っていれば、誰かが戸を開けてくれるかもしれないと思ったの」

<a id="c247-31"></a>

**247.31**　‘I wish I had seen you earlier,’ the guard said.

> 「もっと早く気づいていればよかった」と警備員は言った。

<a id="c247-32"></a>

**247.32**　He put his key on the desk and opened the record.

> 彼は机に鍵を置き、記録を開いた。

<a id="c247-33"></a>

**247.33**　Under five he had written that the doors were locked, and beneath that was a list of jobs for the next three hours.

> 五時の欄に、戸を施錠したと書いてあり、その下には、その後の三時間に行う仕事の一覧があった。

<a id="c247-34"></a>

**247.34**　At the bottom he had written his leaving time, which I had not asked about.

> いちばん下には、私がまだ尋ねていなかった退勤時刻が書かれていた。

<a id="c247-35"></a>

**247.35**　The clerk read it, then asked whether he could talk to us after his next round.

> 記録係はそれを読むと、次の見回りの後で話す時間があるかと尋ねた。

<a id="c247-36"></a>

**247.36**　There was more to arrange than the time on a clock.

> 決めておくことは、時計の示す時間のほかにもあった。

<a id="c247-37"></a>

**247.37**　Before the cook left, she picked up my trial notice.

> 立ち去る前に、料理係は試しに作った私の掲示を取り上げた。

<a id="c247-38"></a>

**247.38**　‘When you read this on Friday, where will Thursday have gone?’

> 「金曜にこれを読むときには、木曜はどこへ行ってしまっているの？」

<a id="c247-39"></a>

**247.39**　The word tomorrow was still sitting in the middle of the page.

> 「明日」という言葉は、まだ紙の中央に居座っていた。

<a id="c247-40"></a>

**247.40**　‘I shall take it down afterwards,’ I said.

> 「終わったら外しますよ」と私は言った。

<a id="c247-41"></a>

**247.41**　‘And the person who takes a copy home?’

> 「写しを家へ持って帰った人は？」

<a id="c247-42"></a>

**247.42**　The clerk checked Thursday’s date on her phone and showed the screen to me.

> 記録係は携帯電話で木曜の日付を確かめ、画面を私に見せた。

<a id="c247-43"></a>

**247.43**　I wrote Thursday in large letters.

> 私は大きな字で「木曜」と書いた。

<a id="c247-44"></a>

**247.44**　I copied the day and month below it and held the paper out for her to check.

> その下に月日を書き写し、確認してもらうために彼女へ紙を差し出した。

<a id="c247-45"></a>

**247.45**　The cook took one last look and left for her kitchen.

> 料理係は最後にもう一度見てから、台所へ戻った。

<a id="c247-46"></a>

**247.46**　I carried the corrected sheet to my shop, with the space for the hours still empty.

> 私は、時間の欄をまだ空けたまま、訂正した紙を自分の店へ運んだ。

<a id="c247-47"></a>

**247.47**　Behind me, the clock began to strike, and the guard counted its notes while putting his key back in his pocket.

> 私の後ろで時計が鳴り始め、警備員はその音の数を数えながら、鍵をポケットへ戻していた。

### この話の用例索引

#### Grammar・Usage

| OLPG・PEUの該当項目 | 本文の用例 | 場面での働き |
|---|---|---|
| OLPG 34 The present perfect continuous ／ PEU 50 present perfect progressive | [247.04](#c247-04) “I have been trying to find out” | have been trying は、閉館時刻を確かめる作業をこれまで続け、今も決着していない状況を示す。記録係が証言を集めている段階として読める。 |
| OLPG 33 The past continuous ／ PEU 45 past progressive | [247.08](#c247-08) “It struck six while I was waiting outside.” ／ [247.26](#c247-26) “We were moving a heavy table” | was waiting は時計が六時を打つときの継続中の行動を示す。警備員の were moving / was checking は、施錠後に室内に人がいた時間の仕事を具体化する。 |
| OLPG 35 Past perfect tenses ／ PEU 53 past perfect: basic information | [247.25](#c247-25) “I had closed the doors before you came” ／ [247.28](#c247-28) “By the time I reached the door, you had gone round the corner.” | had closed と had gone により、料理係の到着前の施錠、警備員が戸口へ着く前の立ち去りを順序づける。二人の行動が行き違った経緯が分かる。 |
| OLPG 35 Past perfect tenses ／ PEU 55 past perfect: progressive | [247.14](#c247-14) “I had been standing there for nearly ten minutes” | had been standing ... for nearly ten minutes は、過去の時報までに続いていた待ち時間を示す。通りがかりに一瞬見たという読み方を避け、入ろうとして待っていた事情を伝える。 |
| OLPG 169 Reporting questions ／ PEU 260 indirect speech: questions and answers | [247.35](#c247-35) “asked whether he could talk to us after his next round” | asked whether ... で、次の見回りの後に話せるかを尋ねたことを報告する。勤務を進めている警備員に、相談のための時間を調整してもらう場面になる。 |
| OLPG 43 The future continuous and perfect ／ PEU 40 future perfect | [247.38](#c247-38) “where will Thursday have gone?” | will ... have gone は金曜の読み手を基準に、その時点では木曜が過ぎていることを、曜日がどこかへ行く冗談にする。掲示の tomorrow を月日へ直すきっかけになる。 |

#### Conversation Modelの意味操作

| 操作と暫定下位分類 | 人物・本文位置 | 発言を受けて起きたこと |
|---|---|---|
| 発展 — 推論・評価 | 私　[247.09](#c247-09) | 六時の時報と室内にいた人を結び付け、六時まで来館できたと推論する。この推論は直後の料理係の経験によって見直される。 |
| 反論 — 限定・留保 | 料理係　[247.10](#c247-10)・[247.13](#c247-13) | 室内に人がいたという証言を保ちつつ、自分は外にいて入れなかったという範囲を加える。語り手が加えた開館中という判断の根拠が不足していると分かる。 |
| 補足 — 明確化・言い換え | 記録係　[247.16](#c247-16) | 外で待っていた理由として、入館希望と待ち合わせを分けて尋ねる。料理係が舟の写真を見たかったこと、戸を開けようとしたことを話せるようになる。 |
| 補足 — 例示・証拠 | 警備員　[247.25](#c247-25)・[247.33](#c247-33) | 自分の行動の説明に、施錠とその後の仕事を記した記録を添える。六時過ぎに人がいた事情と、来館者の利用時間を具体的な記録から確認できる。 |
| 反論 — 条件・例外 | 料理係　[247.41](#c247-41) | 催しの後に掲示を外すという語り手の対処へ、写しを持ち帰る読み手を加える。読む日のずれが残るため、木曜の月日を印刷する対処へ進む。 |

---

<a id="story-248"></a>

## 248　二人分の署名

*Two Signatures*

<a id="c248-01"></a>

**248.01**　Later that Wednesday, the guard closed the door behind the last visitor and joined us at the table.

> その水曜の遅い時間、警備員は最後の来館者が出ると戸を閉め、テーブルの私たちに加わった。

<a id="c248-02"></a>

**248.02**　I laid out the notice with Thursday’s date and the empty space beneath it.

> 私は木曜の日付が入り、その下に空欄のある掲示を広げた。

<a id="c248-03"></a>

**248.03**　The clerk placed the record of working hours beside it.

> 記録係はその横に勤務時間の記録を置いた。

<a id="c248-04"></a>

**248.04**　‘We have permission to use the room,’ she began.

> 「部屋を使う許可は得ています」と彼女は切り出した。

<a id="c248-05"></a>

**248.05**　‘Could you keep the doors open until everyone has finished?’

> 「皆が使い終わるまで、入口を開けておいていただけますか？」

<a id="c248-06"></a>

**248.06**　The guard looked at the eight chairs, then at the path between them.

> 警備員は八脚の椅子を見て、それから椅子の間の通路を見た。

<a id="c248-07"></a>

**248.07**　‘What time will that be?’

> 「それは何時になりますか？」

<a id="c248-08"></a>

**248.08**　‘I thought you could tell us.’

> 「それを教えていただけるかと思っていました」

<a id="c248-09"></a>

**248.09**　He pulled out a chair and sat down.

> 彼は椅子を引いて座った。

<a id="c248-10"></a>

**248.10**　‘I finish at eight.’

> 「私の勤務は八時までです」

<a id="c248-11"></a>

**248.11**　‘Yes, I saw that in the book.’

> 「はい、帳面で確認しました」

<a id="c248-12"></a>

**248.12**　‘I have to check the windows and doors before I leave, and somebody has to put the room back in order.’

> 「帰る前に窓と戸を点検しなければなりませんし、誰かが部屋を元どおりに片付ける必要があります」

<a id="c248-13"></a>

**248.13**　The clerk looked at the line where the visitors’ hours were going to go.

> 記録係は、来場者の利用時間を書く予定の行を見た。

<a id="c248-14"></a>

**248.14**　‘I have already said that the cook can come after six.’

> 「料理係には、六時より後に来られると、もう伝えてあります」

<a id="c248-15"></a>

**248.15**　‘She can,’ he said. ‘I am asking when she has to leave.’

> 「来られますよ。私が聞いているのは、何時に帰ってもらうかです」と彼は言った。

<a id="c248-16"></a>

**248.16**　I moved the pencil towards the clerk, but she did not take it.

> 私は記録係のほうへ鉛筆を差し出したが、彼女は取らなかった。

<a id="c248-17"></a>

**248.17**　‘You needn’t stay after eight,’ she said.

> 「八時より後まで残っていただく必要はありません」と彼女は言った。

<a id="c248-18"></a>

**248.18**　‘I won’t,’ the guard said.

> 「私は残りません」と警備員は言った。

<a id="c248-19"></a>

**248.19**　‘My father waits for me to cook his dinner.’

> 「父が、私が夕食を作るのを待っています」

<a id="c248-20"></a>

**248.20**　‘He says he doesn’t mind when I am late, but I do.’

> 「私が遅くなっても気にしないと言いますが、私は気になります」

<a id="c248-21"></a>

**248.21**　The long hand of the little clock moved towards the next minute.

> 小さな時計の長針が、次の一分へと進んでいった。

<a id="c248-22"></a>

**248.22**　The clerk picked up the pencil at last.

> 記録係はようやく鉛筆を取った。

<a id="c248-23"></a>

**248.23**　‘I gave you an ending that depended on everybody else,’ she said.

> 「ほかの人全員に左右される終わり方を、あなたに引き受けてもらおうとしていましたね」と彼女は言った。

<a id="c248-24"></a>

**248.24**　‘Let us give the evening a time of its own.’

> 「この夜の催しに、きちんと時間を決めましょう」

<a id="c248-25"></a>

**248.25**　She wrote six, left a space, and waited.

> 彼女は六時と書き、間を空けて待った。

<a id="c248-26"></a>

**248.26**　‘Half past seven for the visitors,’ the guard suggested.

> 「来場者には七時半まで、というのはどうですか」と警備員が提案した。

<a id="c248-27"></a>

**248.27**　‘You can use the room until then if it is ready for me to check before eight.’

> 「八時前に私が点検できる状態にしてもらえれば、それまでは部屋を使えます」

<a id="c248-28"></a>

**248.28**　‘How long does the check take?’ I asked.

> 「点検にはどのくらいかかりますか？」と私は尋ねた。

<a id="c248-29"></a>

**248.29**　‘Ten minutes, if the path is clear and everything is in its place.’

> 「通路が空いていて、物が全て所定の場所にあれば、十分間です」と彼は言った。

<a id="c248-30"></a>

**248.30**　I counted the chairs and looked at the distance to the store.

> 私は椅子を数え、保管室までの距離を確かめた。

<a id="c248-31"></a>

**248.31**　I picked up one chair and carried it to the store.

> 私は一脚を持ち上げ、保管室へ運んだ。

<a id="c248-32"></a>

**248.32**　The door opened towards me, so I had to put the chair down before I could reach the handle.

> 戸はこちらへ開くので、取っ手に手を伸ばすには、まず椅子を下ろさなければならなかった。

<a id="c248-33"></a>

**248.33**　‘Leave that door open while you carry them,’ the guard said. ‘I can lock it afterwards.’

> 「運ぶ間は、その戸を開けておいてください。私が後で鍵をかけられます」と警備員は言った。

<a id="c248-34"></a>

**248.34**　I brought the chair back and put it beside the other seven.

> 私は椅子を持って戻り、ほかの七脚の横へ置いた。

<a id="c248-35"></a>

**248.35**　‘You don’t have to do the carrying yourselves,’ he added, ‘but I need to know who will.’

> 「運ぶ仕事を、あなたたち自身がする必要はありません。でも、誰がするのかは確認しておく必要があります」と彼は付け加えた。

<a id="c248-36"></a>

**248.36**　The clerk drew two small boxes on a separate sheet.

> 記録係は別の紙に小さな四角を二つ描いた。

<a id="c248-37"></a>

**248.37**　‘I will help carry the chairs back,’ she said, writing beside the first box.

> 「私が椅子を運んで戻すのを手伝います」と彼女は言い、一つ目の四角の横に書いた。

<a id="c248-38"></a>

**248.38**　‘I will do the same, and wipe the table,’ I said.

> 「私も運びます。それからテーブルを拭きます」と私は言った。

<a id="c248-39"></a>

**248.39**　‘I shall bring the cloths.’

> 「布も私が持ってきます」

<a id="c248-40"></a>

**248.40**　‘And I will make sure that people leave at half past seven,’ the clerk added.

> 「それから、七時半に皆に退出してもらえるよう、私が責任を持ちます」と記録係が付け加えた。

<a id="c248-41"></a>

**248.41**　We wrote our names beneath the jobs, and each of us signed beside a box.

> 私たちは仕事の下に名前を書き、それぞれ四角の横に署名した。

<a id="c248-42"></a>

**248.42**　The guard read the sheet before agreeing.

> 警備員は紙を読んでから同意した。

<a id="c248-43"></a>

**248.43**　He would check the other rooms first, leaving ours until we had finished the chairs and table.

> 彼は先にほかの部屋を点検し、私たちの部屋は椅子とテーブルを片付け終えるまで待つことになった。

<a id="c248-44"></a>

**248.44**　His usual paid hours would cover the evening, but we would have to clear the room in time.

> その晩は、彼が給与を受け取る通常の勤務時間内で対応できるが、私たちは時間内に部屋を片付けなければならない。

<a id="c248-45"></a>

**248.45**　‘This Thursday,’ he said, touching the date.

> 「この木曜ですね」と彼は日付に触れながら言った。

<a id="c248-46"></a>

**248.46**　‘We can see how it goes before promising another.’

> 「もう一晩を約束する前に、今回の様子を見られますね」

<a id="c248-47"></a>

**248.47**　At my shop, I printed one copy with the agreed hours beneath the date.

> 店に戻り、私は日付の下に合意した時間を入れた掲示を一枚刷った。

<a id="c248-48"></a>

**248.48**　The clerk checked the numbers, then carried it back to the guard with the sheet bearing our two signatures.

> 記録係は数字を確認すると、二人分の署名がある紙とともに、その掲示を警備員のところへ持ち帰った。

### この話の用例索引

#### Grammar・Usage

| OLPG・PEUの該当項目 | 本文の用例 | 場面での働き |
|---|---|---|
| OLPG 8 Getting people to do things ／ PEU 80 instructions and requests: will, would, can, could, might, shall ／ PEU 311 politeness: distancing verb forms | [248.05](#c248-05) “Could you keep the doors open until everyone has finished?” | Could you ... は丁寧な依頼を作るが、until everyone has finished では警備員が何時まで拘束されるか未定のままになる。応じられる条件を聞き返す必要が生じる。 |
| OLPG 50 Must and have to ／ PEU 74 strong obligation: have (got) to | [248.12](#c248-12) “I have to check the windows and doors” ／ [248.12](#c248-12) “somebody has to put the room back in order” | have to は退勤前の点検と片付けの必要を示す。前者の担当は I、後者は somebody なので、誰が片付けるかは後で具体化される。 |
| OLPG 51 Don't have to, needn't, and mustn't ／ PEU 74 strong obligation: have (got) to | [248.17](#c248-17) “You needn’t stay after eight” ／ [248.35](#c248-35) “You don’t have to do the carrying yourselves” | needn’t は八時以降に残る義務を外し、don’t have to は二人自身が運ぶ義務を外す。運搬担当を決める必要は残り、二人が自分の意思で引き受ける流れになる。 |
| OLPG 53 Can, could, may, and be allowed to ／ PEU 81 permission: can, could, may, might, be allowed to | [248.27](#c248-27) “You can use the room until then if it is ready for me to check before eight.” | can は部屋を使う許可を、until then と if の条件付きで示す。来場者の利用は七時半まで、片付けと点検は八時退勤に間に合うように行うという範囲が合意される。 |
| OLPG 38 Will and shall ／ PEU 79 willingness: will, can | [248.37](#c248-37) “I will help carry the chairs back” ／ [248.38](#c248-38) “I will do the same, and wipe the table” ／ [248.40](#c248-40) “I will make sure that people leave at half past seven” | I will により、椅子を戻すこと、机を拭くこと、退出を確認することを話し手が引き受ける。担当未定だった仕事が署名できる約束へ変わる。 |

#### Conversation Modelの意味操作

| 操作と暫定下位分類 | 人物・本文位置 | 発言を受けて起きたこと |
|---|---|---|
| 補足 — 明確化・言い換え | 警備員　[248.07](#c248-07)・[248.15](#c248-15) | 「皆が使い終わるまで」という依頼を受け、何時に終わるのか尋ねる。記録係が開始時刻の約束を挙げると、必要なのは退出時刻だと焦点を明確にする。 |
| 補足 — 理由・説明 | 警備員　[248.19](#c248-19)・[248.20](#c248-20) | 八時に帰るという自分の意思に、父の夕食を作る事情と自分が大事にしたいことを添える。父が遅れを許すかどうかだけでは決まらない理由が示される。 |
| 反論 — 修正 | 記録係　[248.23](#c248-23)・[248.24](#c248-24) | 自分の依頼では終わる時刻を来場者全員に委ねていたと認め、催しに時刻を設定する方向へ修正する。理解したという発言の後、鉛筆で実際の時間を書き始める。 |
| 反論 — 条件・例外 | 警備員　[248.27](#c248-27)・[248.29](#c248-29) | 七時半までの利用を認める条件として、八時前に点検できる状態を求める。必要な十分の点検時間と通路の状態が、片付けの分担を決める根拠になる。 |
| 補足 — 追加・詳述 | 記録係・私　[248.37](#c248-37)・[248.39](#c248-39)・[248.40](#c248-40) | 時間の合意に対し、自分たちが行う運搬、清掃、布の用意、退出確認を加える。警備員が具体的な分担を読んで同意できる形にする。 |

---

<a id="story-249"></a>

## 249　無料の部屋の費用

*The Cost of a Free Room*

<a id="c249-01"></a>

**249.01**　On Thursday morning, I carried four fresh notices to the museum, with the ink still wet on one corner.

> 木曜の朝、私は刷りたての掲示を四枚、博物館へ運んだ。一枚の隅では、インクがまだ乾いていなかった。

<a id="c249-02"></a>

**249.02**　The clerk had ruled a page into two columns and was smiling at a large zero in the second.

> 記録係は紙に線を引いて二つの欄を作り、二つ目の欄の大きなゼロを見てほほ笑んでいた。

<a id="c249-03"></a>

**249.03**　‘There's nothing to pay,’ she said.

> 「払うものは何もありません」と彼女は言った。

<a id="c249-04"></a>

**249.04**　‘Nothing for whom?’ asked the cook, stopping on her way to the cafe.

> 「誰にとって、何もないの」と、カフェへ向かう途中に立ち寄った料理係が尋ねた。

<a id="c249-05"></a>

**249.05**　‘For the visitors, at the door.’

> 「来る人が、入口で払うものです」

<a id="c249-06"></a>

**249.06**　The clerk added these words above the figure, which immediately looked less impressive.

> 記録係が数字の上にそう書き加えると、その数字はたちまち、さほど立派なものには見えなくなった。

<a id="c249-07"></a>

**249.07**　‘The museum has agreed to pay for paper, ink, and light from its own funds.’

> 「紙とインクと灯りの費用は、博物館が自分の予算から出すことで了承しています」

<a id="c249-08"></a>

**249.08**　She showed us the approval, then turned her page over.

> 彼女はその了承を記した紙を私たちに見せ、それから自分の紙を裏返した。

<a id="c249-09"></a>

**249.09**　On the back, there was considerably less nothing.

> 裏では、「何もない」がずいぶん減っていた。

<a id="c249-10"></a>

**249.10**　There were four sheets of paper, some ink, and the electricity we would use that evening.

> 紙四枚と、いくらかのインクと、その晩に使う電気が書かれていた。

<a id="c249-11"></a>

**249.11**　‘Eight chairs cost us nothing,’ I said, trying to improve the picture.

> 「椅子は八脚とも、費用がかからない」と私は言い、少しでも明るい話にしようとした。

<a id="c249-12"></a>

**249.12**　‘We own them already,’ the clerk said, ‘but they still have to be moved.’

> 「もう持っている椅子ですからね」と記録係は言った。「でも、運ぶ仕事は残っています」

<a id="c249-13"></a>

**249.13**　She wrote our names beside that job and beside the clearing up after half past seven.

> 彼女は椅子を運ぶ仕事と、七時半を過ぎてからの片付けの横に、私たち二人の名前を書いた。

<a id="c249-14"></a>

**249.14**　The guard's time until eight was already included in his paid working hours.

> 警備員の八時までの時間は、すでに賃金が支払われる勤務時間に含まれていた。

<a id="c249-15"></a>

**249.15**　No one had added another hour to it overnight.

> 一晩のうちに、誰かがそこへもう一時間足したということもなかった。

<a id="c249-16"></a>

**249.16**　‘Not all the work is paid for,’ the cook said, looking at our names.

> 「仕事の全部に、お金が出るわけじゃないのね」と料理係は私たちの名前を見ながら言った。

<a id="c249-17"></a>

**249.17**　‘Some of it is ours to give,’ said the clerk, ‘and we have agreed to give it tonight.’

> 「私たちが自分で差し出せる時間もあります」と記録係は言った。「今夜は、その時間を使うと二人で決めました」

<a id="c249-18"></a>

**249.18**　She entered the hours as carefully as she had entered the cost of paper.

> 彼女は紙の費用を書き入れたときと同じくらい丁寧に、その時間も記入した。

<a id="c249-19"></a>

**249.19**　I thought of a further improvement.

> 私はさらにいい案を思いついた。

<a id="c249-20"></a>

**249.20**　‘Could you bring a few cakes?’ I asked the cook.

> 「ケーキをいくつか持ってきてもらえるかな」と私は料理係に頼んだ。

<a id="c249-21"></a>

**249.21**　‘There wouldn't be many people to feed.’

> 「食べる人は、そんなに多くはならないだろうし」

<a id="c249-22"></a>

**249.22**　She put her bag down very slowly.

> 彼女は、ずいぶんゆっくりとかばんを下ろした。

<a id="c249-23"></a>

**249.23**　‘How many cakes can I make without buying anything or spending any time?’

> 「何も買わず、時間もまったく使わずに作れるケーキって、何個までかしら」

<a id="c249-24"></a>

**249.24**　I began to count before I noticed her expression.

> 私は数え始めてから、彼女の顔つきに気づいた。

<a id="c249-25"></a>

**249.25**　‘I have a little time after work,’ she continued, ‘and I'd like to keep it.’

> 「仕事が終わったあと、少しだけ時間があるの」と彼女は続けた。「それを自分のために取っておきたい」

<a id="c249-26"></a>

**249.26**　The clerk's pencil stopped above a space where a third name might have fitted.

> 記録係の鉛筆が、三人目の名前も入りそうな空欄の上で止まった。

<a id="c249-27"></a>

**249.27**　‘You came to read,’ I said.

> 「本を読みに来たんだったね」と私は言った。

<a id="c249-28"></a>

**249.28**　‘Yes, and I shall be hungry, so I'll bring something for myself.’

> 「そう。それに、おなかはすくでしょうから、自分が食べるものは持ってくるわ」

<a id="c249-29"></a>

**249.29**　‘Of course,’ said the clerk, moving her pencil away.

> 「もちろんです」と記録係は言い、鉛筆をその空欄から離した。

<a id="c249-30"></a>

**249.30**　‘You don't need to give us your evening as well as your reason.’

> 「理由を話してもらったうえに、夜の時間まで差し出してもらう必要はありませんね」

<a id="c249-31"></a>

**249.31**　The cook picked up her bag, but she did not leave at once.

> 料理係はかばんを持ち上げたが、すぐには出ていかなかった。

<a id="c249-32"></a>

**249.32**　‘Will there be water?’

> 「水はあるの」

<a id="c249-33"></a>

**249.33**　‘I'll bring a bottle of water and some glasses,’ I said.

> 「私が水を入れた瓶とグラスをいくつか用意するよ」と私は答えた。

<a id="c249-34"></a>

**249.34**　‘How many glasses have we got?’ the clerk asked.

> 「グラスはいくつあるんでしょう」と記録係が尋ねた。

<a id="c249-35"></a>

**249.35**　I opened the cupboard and counted eight, although one had a crack.

> 私は戸棚を開けて八つ数えたが、一つにはひびが入っていた。

<a id="c249-36"></a>

**249.36**　The cook held that one up to the light.

> 料理係は、その一つを光にかざした。

<a id="c249-37"></a>

**249.37**　‘Seven, then,’ she said, and put it aside.

> 「じゃあ、七つね」と言って、彼女はそれを脇へよけた。

<a id="c249-38"></a>

**249.38**　‘I'll bring another from my shop,’ I said.

> 「私の店から、もう一つ持ってくるよ」と私は言った。

<a id="c249-39"></a>

**249.39**　She set the sound glasses in a row, without offering to wash them.

> 彼女は無傷のグラスを一列に並べたが、洗おうとは申し出なかった。

<a id="c249-40"></a>

**249.40**　‘Then that's enough for me.’

> 「それなら、私は十分」

<a id="c249-41"></a>

**249.41**　We agreed to keep drinks on a small table away from the photographs.

> 私たちは、飲み物を写真から離れた小さなテーブルに置くことにした。

<a id="c249-42"></a>

**249.42**　The clerk crossed out the empty space for food and left the space for another person's name empty.

> 記録係は食べ物用の空欄に線を引き、もう一人の名前を入れる欄は空けたままにした。

<a id="c249-43"></a>

**249.43**　‘If someone wants to help, we can discuss a particular job with them,’ she said.

> 「手伝いたい人がいれば、具体的な仕事をその人と相談できます」と彼女は言った。

<a id="c249-44"></a>

**249.44**　‘We haven't bought anybody with a free chair.’

> 「無料の椅子を出したからといって、誰かを買い取ったわけではありませんから」

<a id="c249-45"></a>

**249.45**　The cook laughed, and I felt able to look at her again.

> 料理係が笑い、私はようやくまた彼女の顔を見ることができた。

<a id="c249-46"></a>

**249.46**　She drew a small book from her bag and showed us how far she had got.

> 彼女はかばんから小さな本を出し、どこまで読んだかを見せてくれた。

<a id="c249-47"></a>

**249.47**　A piece of blue thread lay between two pages.

> 二枚のページの間に、青い糸が一本挟まっていた。

<a id="c249-48"></a>

**249.48**　‘I should like to move this tonight,’ she said.

> 「今夜は、これを先へ進めたいの」と彼女は言った。

<a id="c249-49"></a>

**249.49**　Then she went across the road to work, and I took the glasses to the sink.

> それから彼女は道を渡って仕事に向かい、私はグラスを流しへ運んだ。

### この話の用例索引

#### Grammar・Usage

| OLPG・PEUの該当項目 | 本文の用例 | 場面での働き |
|---|---|---|
| OLPG 88 Countable and uncountable nouns ／ PEU 119 countable and uncountable nouns: basic information ／ PEU 121 piece- and group-words: a blade of grass; a bunch of flowers | [249.10](#c249-10) “four sheets of paper” ／ [249.10](#c249-10) “some ink” | paperとinkを材料として扱い、紙にはsheetsという単位を添えて必要量を記録する。無料の入場を実際に支える材料が、帳面に現れる。 |
| OLPG 5 Negative statements ／ OLPG 106 All, most, etc ／ PEU 147 all (of) with noun phrases and pronouns ／ PEU 221 ambiguous negatives | [249.16](#c249-16) “Not all the work is paid for” | notがallにかかり、作業の一部には賃金が出ていないと示す。警備員の有給勤務と、二人が今夜引き受けた時間の違いを確認する。 |
| OLPG 105 A lot of, many, much, etc ／ PEU 165 much and many | [249.23](#c249-23) “How many cakes can I make” ／ [249.34](#c249-34) “How many glasses have we got” | how manyで数えられる量を問う。ケーキの問いは材料も時間も使わず作れるという前提を揺さぶり、グラスの問いは使える実数の確認へ進む。 |
| OLPG 105 A lot of, many, much, etc ／ PEU 168 (a) little and (a) few | [249.20](#c249-20) “a few cakes” ／ [249.25](#c249-25) “a little time after work” | a fewはケーキの個数、a littleは仕事後の時間の少量を表す。依頼する側にとっての少数と、引き受ける側に残る時間の少なさが会話の判断を変える。 |
| OLPG 108 Some and any ／ PEU 161 some and any: the main differences ／ PEU 222 non-affirmative words: anybody, ever, yet, etc | [249.23](#c249-23) “without buying anything or spending any time” ／ [249.33](#c249-33) “some glasses” | withoutの後のanything・any timeが、材料購入も時間消費もないという条件を示す。some glassesでは、その時点で個数を決めずに必要な品を用意すると申し出ている。 |

#### Conversation Modelの意味操作

| 操作と暫定下位分類 | 人物・本文位置 | 発言を受けて起きたこと |
|---|---|---|
| 補足 — 明確化・言い換え | 記録係　[249.05](#c249-05) | 料理係の「誰にとって」という問いを受け、nothing to payの対象を入口で払う来場者へ絞り、欄にも書き足す。 |
| 反論 — 修正 | 料理係　[249.23](#c249-23) | 来客が少なければケーキを簡単に頼めるという私の見込みに、必要な材料と時間を入れ直す。私は数えようとしてから、その前提に気づく。 |
| 反論 — 限定・留保 | 料理係　[249.25](#c249-25)・[249.25](#c249-25) | 勤務後の時間が多少あることを、手伝いを引き受ける同意と結びつけない。自分の休息と読書に使う範囲を明言する。 |
| 発展 — 比較・分類 | 料理係　[249.35](#c249-35)・[249.37](#c249-37) | 戸棚にある八個という数え方へ、客が使える状態という基準を加える。ひびのある一個を取り分け、使用可能数を七個とする。 |
| 発展 — 結果・帰結 | 私　[249.38](#c249-38) | 使えるグラスが一個足りないという確認を受け、自分の店から補う具体的な作業を引き受ける。 |

---

<a id="story-250"></a>

## 250　まだ渡さない声

*A Voice Kept Back*

<a id="c250-01"></a>

**250.01**　The retired railway worker came into my shop after lunch and laid one of my notices on the table.

> 昼食のあと、引退した鉄道員が私の店へ来て、私の刷った掲示を一枚テーブルに置いた。

<a id="c250-02"></a>

**250.02**　He had taken it from the station, and its top corner was torn.

> 駅から外してきたもので、上の隅が破れていた。

<a id="c250-03"></a>

**250.03**　‘It seems I've got a new job,’ he said.

> 「どうやら、新しい仕事ができたらしい」と彼は言った。

<a id="c250-04"></a>

**250.04**　The line below the opening time read, ‘The railway worker will speak at six.’

> 開場時刻の下には、「鉄道員が六時からお話しします」と書かれていた。

<a id="c250-05"></a>

**250.05**　The clerk, who was checking the remaining paper with me, put her list down.

> 私と一緒に残りの紙を確認していた記録係が、一覧を下ろした。

<a id="c250-06"></a>

**250.06**　‘I thought you said you might say a few words,’ she began.

> 「少し話をするかもしれないと、おっしゃったと思ったのですが」と彼女は切り出した。

<a id="c250-07"></a>

**250.07**　‘I said I might say a few words if I came.’

> 「行ったら、少し話すかもしれない、と言ったんだ」

<a id="c250-08"></a>

**250.08**　He touched the announcement with one finger.

> 彼は予告の一行を指で触った。

<a id="c250-09"></a>

**250.09**　‘That gives me rather less choice.’

> 「これだと、私に残る選択肢はだいぶ少ないね」

<a id="c250-10"></a>

**250.10**　That morning, the clerk had brought me his possible offer, with the condition missing.

> その朝、記録係は彼が話すかもしれないという話を、条件が抜けたまま私へ伝えていた。

<a id="c250-11"></a>

**250.11**　I had removed the remaining uncertainty and given the words a neat line of their own.

> 私は残っていた不確かさも取り去り、その言葉を、見栄えのよい独立した一行にしていた。

<a id="c250-12"></a>

**250.12**　Then she had checked the date and times and said the notices could go out.

> それから彼女が日付と時刻を確認し、掲示を出してよいと言ったのだった。

<a id="c250-13"></a>

**250.13**　There were four copies, at the station, the market, the museum entrance, and my shop.

> 掲示は四枚あり、駅、市場、博物館の入口、そして私の店に出ていた。

<a id="c250-14"></a>

**250.14**　I took the one from my window before trying to explain.

> 私は説明をしようとする前に、窓の掲示を外した。

<a id="c250-15"></a>

**250.15**　‘You haven't agreed to do this,’ I said.

> 「この予定を引き受けたわけではないんですね」と私は言った。

<a id="c250-16"></a>

**250.16**　‘No.’

> 「そうだ」

<a id="c250-17"></a>

**250.17**　‘We'll remove the announcement from all four copies.’

> 「四枚とも、この予告を取り除きます」

<a id="c250-18"></a>

**250.18**　The clerk pulled a chair towards him, but he remained standing.

> 記録係が彼のほうへ椅子を引き寄せたが、彼は立ったままだった。

<a id="c250-19"></a>

**250.19**　‘Would you mind telling us what makes the idea difficult?’ she asked.

> 「その案のどんなところが難しいのか、教えていただいてもよろしいでしょうか」と彼女は尋ねた。

<a id="c250-20"></a>

**250.20**　He looked at her open notebook and put his hand inside his coat.

> 彼は開いたままの彼女のノートを見て、上着の内側に手を入れた。

<a id="c250-21"></a>

**250.21**　Then he took it out again, empty.

> それから、何も持たずに手を出した。

<a id="c250-22"></a>

**250.22**　‘How much do I have to tell you before you'll take it down?’

> 「どこまで話せば、それを外してもらえるんだい」

<a id="c250-23"></a>

**250.23**　‘Nothing,’ she said, and closed the book.

> 「何も話していただく必要はありません」と彼女は言い、ノートを閉じた。

<a id="c250-24"></a>

**250.24**　‘I was asking for something you hadn't offered.’

> 「申し出ていないことまで、話してもらおうとしていました」

<a id="c250-25"></a>

**250.25**　I brought a clean sheet, but waited before putting any words on it.

> 私はきれいな紙を一枚取ってきたが、何か書き始める前に手を止めた。

<a id="c250-26"></a>

**250.26**　‘Would you like us to say that no talk has been arranged?’

> 「話をする催しは予定されていない、と書く形でよいでしょうか」

<a id="c250-27"></a>

**250.27**　‘Yes, please.’

> 「そうしてもらいたい」

<a id="c250-28"></a>

**250.28**　‘And say the earlier notice was wrong, or people may think I broke a promise.’

> 「それから、前の掲示が間違っていたと書いてほしい。そうしないと、私が約束を破ったと思う人がいるかもしれない」

<a id="c250-29"></a>

**250.29**　The clerk repeated his request to me, keeping both parts this time.

> 記録係は今度は二つの要望を両方とも残して、彼の依頼を私に伝え直した。

<a id="c250-30"></a>

**250.30**　I used paper from my own box for the four corrections.

> 私は四枚の訂正には、自分の箱にある紙を使った。

<a id="c250-31"></a>

**250.31**　I printed a correction large enough to be read without leaning towards the paper.

> 私は、紙へ顔を近づけなくても読める大きさで、訂正を刷った。

<a id="c250-32"></a>

**250.32**　The room, the date, and the times remained, with no name offered as an attraction.

> 部屋、日付、時刻は残し、呼び物として誰かを掲げることはやめた。

<a id="c250-33"></a>

**250.33**　‘Have we made it harder for you to come?’ I asked.

> 「私たちのせいで、来づらくなってしまいましたか」と私は尋ねた。

<a id="c250-34"></a>

**250.34**　‘A little,’ he said, and I let the answer stand.

> 「少しね」と彼は言い、私はその答えをそのまま受け止めた。

<a id="c250-35"></a>

**250.35**　‘A man at the station asked whether he could bring his children,’ he added.

> 「駅で、子どもを連れてきてもいいかと聞かれたよ」と彼は付け加えた。

<a id="c250-36"></a>

**250.36**　‘I like talking to children, but I don't want to wait at the front of a room while they wait for something wonderful.’

> 「子どもと話すのは好きだ。でも、子どもたちが何かすばらしいことを期待して待つ中で、部屋の前方に立って待ちたくはない」

<a id="c250-37"></a>

**250.37**　He rubbed the torn corner of the old notice flat.

> 彼は古い掲示の破れた隅を、指で平らに伸ばした。

<a id="c250-38"></a>

**250.38**　‘If I come, I'd like to be allowed to listen.’

> 「行ったら、聞いていることも認めてもらいたい」

<a id="c250-39"></a>

**250.39**　‘You can,’ I said.

> 「もちろんです」と私は言った。

<a id="c250-40"></a>

**250.40**　He sat down at last, though only long enough to read the new notice.

> 彼はようやく腰を下ろしたが、新しい掲示を読む間だけだった。

<a id="c250-41"></a>

**250.41**　‘May I have a plain piece of paper?’

> 「何も書いていない紙を一枚もらえるかな」

<a id="c250-42"></a>

**250.42**　I slid one across to him.

> 私は彼のほうへ一枚滑らせた。

<a id="c250-43"></a>

**250.43**　‘I may write a few lines for myself before I come,’ he said.

> 「行く前に、自分のために何行か書いてみるかもしれない」と彼は言った。

<a id="c250-44"></a>

**250.44**　‘There are things I forget when too many people are waiting for me to remember.’

> 「大勢の人に思い出すのを待たれていると、忘れてしまうこともあるから」

<a id="c250-45"></a>

**250.45**　He folded the blank sheet and put it in his pocket.

> 彼は白紙を折りたたみ、ポケットに入れた。

<a id="c250-46"></a>

**250.46**　Before he left, I put one corrected copy in the shop window, where he stopped to read it again.

> 彼が帰る前に、私は訂正版を一枚、店の窓に出した。彼はそこで足を止め、もう一度読んだ。

<a id="c250-47"></a>

**250.47**　The clerk took the new notices to the market and the museum, while I went to the station.

> 記録係が新しい掲示を市場と博物館へ運び、その間に私は駅へ向かった。

<a id="c250-48"></a>

**250.48**　At each place we explained the error as well as replacing the paper.

> 私たちは、それぞれの場所で紙を取り替えるとともに、間違いを説明した。

<a id="c250-49"></a>

**250.49**　At the station, I put the new sheet under the glass and closed the little door.

> 駅で私は新しい紙をガラスの内側に入れ、小さな扉を閉めた。

### この話の用例索引

#### Grammar・Usage

| OLPG・PEUの該当項目 | 本文の用例 | 場面での働き |
|---|---|---|
| OLPG 38 Will and shall ／ OLPG 55 May, might, can, and could ／ PEU 38 will ／ PEU 71 chances: may, might and could | [250.04](#c250-04) “will speak at six” ／ [250.07](#c250-07) “might say a few words if I came” | mightとifのついた本人の話が、掲示ではwillによる確定した予定に強められた。その差によって、本人の選択が公の約束として扱われてしまう。 |
| OLPG 165 Basics of indirect speech ／ PEU 258 indirect speech: introduction | [250.06](#c250-06) “I thought you said you might say a few words” ／ [250.07](#c250-07) “I said I might say a few words if I came” | 相手が何を言ったかをsaid以下で報告し合う中で、記録係が落とした条件が本人の再報告に戻る。伝聞の内容を照合することが訂正の出発点になる。 |
| OLPG 8 Getting people to do things ／ OLPG 74 Some patterns with the gerund ／ PEU 100 -ing forms after verbs: I enjoy travelling. ／ PEU 310 politeness: using questions | [250.19](#c250-19) “Would you mind telling us what makes the idea difficult” | would you mindに-ing形を続けた丁寧な質問が、ここでは理由を話す負担として受け取られる。記録係はノートを閉じ、説明を求める手を止める。 |
| OLPG 169 Reporting questions ／ PEU 260 indirect speech: questions and answers ／ PEU 261 whether and if | [250.35](#c250-35) “asked whether he could bring his children” | whether以下に疑問文の内容を通常の語順で埋め込み、駅で受けた問い合わせを報告する。掲示がすでに聴衆の期待を生んでいたことが具体化する。 |
| OLPG 53 Can, could, may, and be allowed to ／ PEU 81 permission: can, could, may, might, be allowed to | [250.38](#c250-38) “I'd like to be allowed to listen” | be allowed toによって、聞く側として参加できることを本人が求める。参加する可能性を残しながら、その場で担う役割を選び直す。 |

#### Conversation Modelの意味操作

| 操作と暫定下位分類 | 人物・本文位置 | 発言を受けて起きたこと |
|---|---|---|
| 反論 — 修正 | 鉄道員　[250.07](#c250-07) | 記録係による再現へ、発話の不確かさと来場する場合という条件を戻し、掲示された出演確約を訂正する。 |
| 反論 — 限定・留保 | 鉄道員　[250.22](#c250-22) | 誤掲示の撤回に私的な事情の説明まで必要なのかを問い、依頼されている開示の範囲を狭める。 |
| 反論 — 修正 | 記録係　[250.24](#c250-24) | 事情を聞くことが当然の次段階だという自分の進め方を修正し、ノートを閉じる。本人の説明を待たずに掲示の訂正へ進む。 |
| 補足 — 追加・詳述 | 鉄道員　[250.28](#c250-28) | 出演予告を消すだけでは本人が約束を破ったと読まれ得るため、以前の掲示の誤りを明示する要望を追加する。 |
| 反論 — 代替・選好 | 鉄道員　[250.38](#c250-38) | 話し手として期待される状況に対し、来るなら聞く側でもいたいという希望を示す。のちに自分用の紙を求める判断も本人に残る。 |

---

<a id="story-251"></a>

## 251　動いた椅子

*The Chairs That Moved*

<a id="c251-01"></a>

**251.01**　Late that afternoon, I returned to the museum with the glass I had promised to bring.

> その日の夕方近く、私は持ってくると約束したグラスを手に、博物館へ戻った。

<a id="c251-02"></a>

**251.02**　Two chairs stood in the corridor, and the guard could open the door only halfway.

> 廊下には椅子が二脚あり、警備員は扉を半分までしか開けられなかった。

<a id="c251-03"></a>

**251.03**　‘These have been left in the way,’ he said.

> 「通り道に置かれたままで、邪魔になっています」と彼は言った。

<a id="c251-04"></a>

**251.04**　I put the glass on the small table and helped him carry the chairs inside.

> 私は小さなテーブルにグラスを置き、彼と一緒に椅子を室内へ運んだ。

<a id="c251-05"></a>

**251.05**　The door opened fully again before he asked who had moved them.

> 椅子を動かしたのは誰かと彼が尋ねたときには、扉はまた、いっぱいまで開くようになっていた。

<a id="c251-06"></a>

**251.06**　The singer, who was sorting his papers by the window, raised his head.

> 窓際で紙を整理していた歌い手が、顔を上げた。

<a id="c251-07"></a>

**251.07**　‘They were put there while we made some room.’

> 「場所を空けるときに、そこへ置かれたんです」

<a id="c251-08"></a>

**251.08**　‘By whom?’ asked the guard.

> 「誰が置いたんですか」と警備員は尋ねた。

<a id="c251-09"></a>

**251.09**　‘I had them moved,’ said the singer, getting up.

> 「私が動かしてもらいました」と歌い手は言い、立ち上がった。

<a id="c251-10"></a>

**251.10**　‘I got my friends to carry them out because I thought they were in the way here.’

> 「ここでは邪魔になると思って、友人たちに外へ運んでもらったんです」

<a id="c251-11"></a>

**251.11**　One of the friends came in from the river side of the building.

> 友人の一人が、建物の川側から入ってきた。

<a id="c251-12"></a>

**251.12**　‘We asked where to put them,’ she said.

> 「どこへ置くのかは聞いたんですよ」と彼女は言った。

<a id="c251-13"></a>

**251.13**　‘You did,’ the singer agreed, ‘and I pointed at the corridor.’

> 「聞いてくれたね」と歌い手は認めた。「それで私が廊下を指したんだ」

<a id="c251-14"></a>

**251.14**　The guard looked at the singer, who had picked up a chair in each hand.

> 警備員は、今では両手に一脚ずつ椅子を持っている歌い手を見た。

<a id="c251-15"></a>

**251.15**　‘What did you need the space for?’

> 「何のための場所が必要だったんですか」

<a id="c251-16"></a>

**251.16**　‘The printer said the middle needed to be cleared.’

> 「印刷係が、真ん中を空ける必要があると言ったので」

<a id="c251-17"></a>

**251.17**　I recognized my own voice in the sentence, although it sounded more important coming from him.

> 私はその文に自分の声を聞き取ったが、彼の口から出ると、私が言ったときよりも重大なことに聞こえた。

<a id="c251-18"></a>

**251.18**　I had made the request that morning, on my way out with the notices.

> その朝、掲示を持って出かけるとき、私はそう頼んでいた。

<a id="c251-19"></a>

**251.19**　I had said nothing about where the chairs should go.

> 椅子をどこへ置くかについては、何も言っていなかった。

<a id="c251-20"></a>

**251.20**　‘I wanted people to reach the photograph without walking between other people's knees,’ I explained.

> 「ほかの人の膝の間を通らずに、写真まで行けるようにしたかったんです」と私は説明した。

<a id="c251-21"></a>

**251.21**　‘Then let's make that possible,’ said the guard, taking one of the chairs from the singer.

> 「では、そうできるようにしましょう」と警備員は言い、歌い手から椅子を一脚受け取った。

<a id="c251-22"></a>

**251.22**　He asked me to hold the door open while we tried a different arrangement.

> 彼は私に扉を開けて押さえているよう頼み、私たちは別の配置を試した。

<a id="c251-23"></a>

**251.23**　We placed four chairs near one side of the room and four near the other.

> 部屋の片側に四脚、反対側に四脚を寄せて置いた。

<a id="c251-24"></a>

**251.24**　Within those two loose groups, people could turn their chairs towards a person, a picture, or the river.

> その二組の椅子は間隔を空けて置いてあり、人や写真や川のほうへ向きを変えられた。

<a id="c251-25"></a>

**251.25**　There was a clear space down the middle and a clear way to the door.

> 真ん中には空いた場所ができ、扉までの道も通れるようになった。

<a id="c251-26"></a>

**251.26**　One chair near the window faced straight into the evening light.

> 窓の近くの一脚は、夕方の光がまっすぐ差し込むほうを向いていた。

<a id="c251-27"></a>

**251.27**　I sat in it and covered my eyes.

> 私はそこに座り、手で目を覆った。

<a id="c251-28"></a>

**251.28**　The singer turned it a little, then sat down to see whether that was better.

> 歌い手は椅子を少し回し、それから自分でも座って、そのほうがいいか確かめた。

<a id="c251-29"></a>

**251.29**　From there he could look at the river without looking directly at the sun.

> そこからなら、太陽を直接見ずに川を見ることができた。

<a id="c251-30"></a>

**251.30**　The guard left enough space behind it for someone to pass.

> 警備員は、その後ろに人が通れるだけの空間を残した。

<a id="c251-31"></a>

**251.31**　The singer put his papers on one chair, then took them off again.

> 歌い手は椅子の一つに紙を置き、それからまた持ち上げた。

<a id="c251-32"></a>

**251.32**　‘They don't need a seat,’ he said, and put them in a blue file.

> 「この紙に席はいらないね」と彼は言い、青い書類ばさみに入れた。

<a id="c251-33"></a>

**251.33**　The clerk came back with a cloth and examined the new arrangement.

> 記録係が布を持って戻り、新しい配置を確かめた。

<a id="c251-34"></a>

**251.34**　She began to draw it on a sheet of paper.

> 彼女は紙に、その配置を描き始めた。

<a id="c251-35"></a>

**251.35**　Then she turned the paper over and asked the guard how the chairs should be arranged in the store.

> それから紙を裏返し、保管室では椅子をどのように置くのか、警備員に尋ねた。

<a id="c251-36"></a>

**251.36**　He described two rows, with enough room for the door to open, and showed us where the table belonged.

> 彼は、扉が開くだけの空間を残して二列にする配置を説明し、テーブルを戻す場所も教えてくれた。

<a id="c251-37"></a>

**251.37**　She drew that arrangement too, and wrote ‘Ready by ten to eight’ above it.

> 彼女はそちらの配置も描き、上に「七時五十分までに点検できる状態に」と書いた。

<a id="c251-38"></a>

**251.38**　I put the plan inside the cupboard door, where we could find it when we cleared up.

> 私は片付けのときに見つけられるよう、その図を戸棚の扉の内側に付けた。

<a id="c251-39"></a>

**251.39**　The singer's other friend waited by the entrance with an empty bag.

> 歌い手のもう一人の友人は、空のかばんを持って入口で待っていた。

<a id="c251-40"></a>

**251.40**　‘Can we get outside now?’ he asked.

> 「そろそろ外へ出てもいいかな」と彼は尋ねた。

<a id="c251-41"></a>

**251.41**　‘We came to practise, and I've only used my arms so far.’

> 「練習しに来たのに、今のところ腕しか使っていないよ」

<a id="c251-42"></a>

**251.42**　The singer laughed and joined him, carrying the file himself.

> 歌い手は笑い、書類ばさみを自分で持って、彼のところへ行った。

<a id="c251-43"></a>

**251.43**　Their friend followed them past the fully open door.

> もう一人の友人が、いっぱいに開いた扉を通って、そのあとに続いた。

<a id="c251-44"></a>

**251.44**　The guard checked his watch, then walked the whole way to the photograph without having to turn his shoulders.

> 警備員は腕時計を確認し、それから横向きになることなく、写真までずっと歩いていった。

<a id="c251-45"></a>

**251.45**　From outside came three separate notes, followed by a laugh and another attempt.

> 外から別々の三つの音が聞こえ、笑い声と、もう一度試す声が続いた。

### この話の用例索引

#### Grammar・Usage

| OLPG・PEUの該当項目 | 本文の用例 | 場面での働き |
|---|---|---|
| OLPG 59 Passive verb forms ／ OLPG 60 The use of the passive ／ PEU 57 passive structures and verb forms ／ PEU 67 When do we use passive structures? | [251.03](#c251-03) “These have been left in the way” | 現在完了の受動態で、置かれた椅子が今も通路を塞いでいる状態を先に示す。警備員と私は、置いた人を尋ねる前に椅子を動かす。 |
| OLPG 60 The use of the passive ／ PEU 58 by + agent | [251.07](#c251-07) “They were put there” ／ [251.08](#c251-08) “By whom” | 行為者を示さない受動態へのbyを用いた問いが、誰が指示したかの確認につながる。歌い手は自分の依頼を明かす。 |
| OLPG 62 Patterns with have and get ／ PEU 109 causative and similar structures with have | [251.09](#c251-09) “I had them moved” | have＋目的語＋過去分詞で、歌い手が移動を手配したことを表す。椅子を実際に持った人と、移動を頼んだ人の関係が明らかになる。 |
| OLPG 62 Patterns with have and get ／ OLPG 68 Verb + object + to-infinitive ／ PEU 108 causative and similar structures with get | [251.10](#c251-10) “I got my friends to carry them out” | get＋人＋to不定詞で、友人へ運ぶ作業を頼んだと具体化する。友人の確認に続いて、歌い手自身が移動先も指したと認める。 |
| OLPG 68 Verb + object + to-infinitive ／ OLPG 170 Reporting requests, offers, etc ／ PEU 98 verb + object + infinitive: I want you to listen. ／ PEU 262 indirect speech: infinitives | [251.22](#c251-22) “He asked me to hold the door open” | ask＋人＋to不定詞で警備員の依頼を報告し、配置を直す間の私の役割を具体的にする。責任の確認から協力の動作へ会話が進む。 |

#### Conversation Modelの意味操作

| 操作と暫定下位分類 | 人物・本文位置 | 発言を受けて起きたこと |
|---|---|---|
| 補足 — 明確化・言い換え | 歌い手　[251.09](#c251-09)・[251.13](#c251-13) | 椅子がそこにあったという説明へ、自分が移動を頼み、置き場所も指したという行為者情報を加える。 |
| 補足 — 焦点・関係づけ | 警備員　[251.15](#c251-15) | 誰が動かしたかの確認を終え、空間を必要とした目的へ焦点を移す。人が写真へ近づける配置を作る相談へつながる。 |
| 補足 — 理由・説明 | 私　[251.20](#c251-20) | 真ん中を空けてほしいという自分の曖昧な依頼の理由を明らかにする。その目的をもとに、廊下を塞がず八脚を置く方法を試す。 |
| 発展 — 順序・時間的展開 | 記録係　[251.35](#c251-35)・[251.37](#c251-37) | 今夜使う配置から、点検前に保管室へ戻す段階へ計画を進める。二つの図と期限を残し、片付けの順序を具体的に扱う。 |

---

<a id="story-252"></a>

## 252　雨に備えて

*In Case of Rain*

<a id="c252-01"></a>

**252.01**　Ten minutes before six, a grey cloud covered the light that had troubled our chair.

> 六時の十分前、一つの灰色の雲が、さっき私たちの椅子を困らせた光を覆った。

<a id="c252-02"></a>

**252.02**　Outside, the singer and his two friends were trying to keep their voices together.

> 外では、歌い手と二人の友人が、声をそろえようとしていた。

<a id="c252-03"></a>

**252.03**　The wind seemed to prefer one voice at a time.

> 風は、一度に一人の声を選んで運びたいらしかった。

<a id="c252-04"></a>

**252.04**　Their papers shook against the blue file, and the singer held them down with his hand.

> 青い書類ばさみに重ねた紙が震え、歌い手は手で押さえた。

<a id="c252-05"></a>

**252.05**　‘We'll stay outside unless it rains,’ he called through the window.

> 「雨が降らなければ、外にいます」と彼は窓越しに声をかけた。

<a id="c252-06"></a>

**252.06**　The clerk looked at the cloud and brought a dry cloth to the entrance.

> 記録係は雲を見て、乾いた布を入口へ運んだ。

<a id="c252-07"></a>

**252.07**　‘In case the papers get wet,’ she said, laying it beside the door.

> 「紙がぬれたときのために」と言って、彼女は扉のそばに置いた。

<a id="c252-08"></a>

**252.08**　I reached for the handle to let the singers in, but she stopped me.

> 私は歌い手たちを中に入れようと取っ手へ手を伸ばしたが、彼女が止めた。

<a id="c252-09"></a>

**252.09**　‘They still want to practise outside.’

> 「皆さん、まだ外で練習したいんです」

<a id="c252-10"></a>

**252.10**　I left the door closed and went back to the window.

> 私は扉を閉めたまま、窓のところへ戻った。

<a id="c252-11"></a>

**252.11**　The singer tried singing towards the river, to see whether less of the sound would reach the room.

> 歌い手は、部屋へ届く音が減るかどうか、川のほうを向いて歌ってみた。

<a id="c252-12"></a>

**252.12**　His friends changed their positions to hear him better.

> 友人たちは、彼の声がもっとよく聞こえるように立つ位置を変えた。

<a id="c252-13"></a>

**252.13**　We tried closing the window, and the voices became softer, although they did not disappear.

> 私たちは試しに窓を閉めてみた。声は聞こえなくなりはしなかったが、小さくなった。

<a id="c252-14"></a>

**252.14**　The clerk sat where the cook had chosen to read and opened the museum guide.

> 記録係は、料理係が本を読もうと選んでいた場所に座り、博物館の案内を開いた。

<a id="c252-15"></a>

**252.15**　I waited until she turned a page.

> 私は彼女がページをめくるまで待った。

<a id="c252-16"></a>

**252.16**　‘Could you follow it?’

> 「内容を追えたかな」

<a id="c252-17"></a>

**252.17**　‘Yes,’ she said, ‘but I already know what's on this page.’

> 「ええ」と彼女は言った。「でも、このページに何が書いてあるか、私はもう知っています」

<a id="c252-18"></a>

**252.18**　She closed the guide and put it back.

> 彼女は案内を閉じ、元の場所へ戻した。

<a id="c252-19"></a>

**252.19**　‘The cook will have to judge for herself.’

> 「料理係には、自分で判断してもらう必要がありますね」

<a id="c252-20"></a>

**252.20**　A small wet mark appeared on the outside of the glass.

> ガラスの外側に、小さな水の跡がついた。

<a id="c252-21"></a>

**252.21**　Then another joined it, and the singer looked up.

> それからもう一つ跡がつき、歌い手が空を見上げた。

<a id="c252-22"></a>

**252.22**　His friend tried to turn a page, but the wind folded it back across her fingers.

> 彼の友人がページをめくろうとしたが、風で紙が折れ返り、彼女の指にかぶさった。

<a id="c252-23"></a>

**252.23**　The singer reached for it, and three loose sheets rose out of the file.

> 歌い手がそれに手を伸ばすと、挟まっていた三枚の紙が舞い上がった。

<a id="c252-24"></a>

**252.24**　I opened the window, caught one, and watched the other two land against the wall.

> 私は窓を開けて一枚をつかみ、残る二枚が壁際に落ちるのを見た。

<a id="c252-25"></a>

**252.25**　His friends picked them up before the rain grew heavier.

> 雨が強くなる前に、友人たちがその二枚を拾った。

<a id="c252-26"></a>

**252.26**　‘We'll come in if it gets worse,’ the singer said.

> 「ひどくなったら中へ入ります」と歌い手は言った。

<a id="c252-27"></a>

**252.27**　It got worse while he was saying it.

> 彼がそう言っているうちに、雨はひどくなった。

<a id="c252-28"></a>

**252.28**　Water ran from the edge of the file onto his arm.

> 書類ばさみの端から水が伝わり、彼の腕に流れた。

<a id="c252-29"></a>

**252.29**　The guard looked at his watch and opened the door.

> 警備員は腕時計を見て、扉を開いた。

<a id="c252-30"></a>

**252.30**　It was six, and the cook was coming across the road with her bag held over her head.

> 六時だった。料理係が、かばんを頭の上にかざして道を渡ってきた。

<a id="c252-31"></a>

**252.31**　I took the cloth to the singer and helped him cover the papers.

> 私は布を歌い手のところへ持っていき、紙にかぶせるのを手伝った。

<a id="c252-32"></a>

**252.32**　The three friends came inside, leaving a clear way for the cook behind them.

> 三人は中へ入り、あとから来る料理係が通れるよう、通り道を空けた。

<a id="c252-33"></a>

**252.33**　She lowered her bag and shook the water from her fingers.

> 彼女はかばんを下ろし、指についた水を振り落とした。

<a id="c252-34"></a>

**252.34**　‘Has the outside come in?’ she asked, looking at the wet papers.

> 「外が、中に入ってきたの」と、ぬれた紙を見て彼女は尋ねた。

<a id="c252-35"></a>

**252.35**　‘We're hoping to sing in here,’ said the singer.

> 「ここで歌わせてもらえたらと思っています」と歌い手は言った。

<a id="c252-36"></a>

**252.36**　The cook glanced at the chair by the window.

> 料理係は窓のそばの椅子に目をやった。

<a id="c252-37"></a>

**252.37**　‘I'd still like to read.’

> 「私は、やっぱり本を読みたいわ」

<a id="c252-38"></a>

**252.38**　‘And we'd like to finish one song,’ he said.

> 「こちらも、一曲は最後まで歌いたいんです」と彼は言った。

<a id="c252-39"></a>

**252.39**　The clerk moved the empty bag from a chair and offered the cook a seat.

> 記録係は椅子から空のかばんをどけ、料理係に座るよう勧めた。

<a id="c252-40"></a>

**252.40**　Nobody could tell how long the rain would last.

> 雨がどれくらい続くのかは、誰にもわからなかった。

<a id="c252-41"></a>

**252.41**　‘If it stops, we can go out again,’ the singer said.

> 「やめば、また外へ出られます」と歌い手は言った。

<a id="c252-42"></a>

**252.42**　‘But we can't promise when,’ said his friend, looking at the river through the rain.

> 「でも、それがいつになるかは約束できないね」と彼の友人は、雨越しに川を見ながら言った。

<a id="c252-43"></a>

**252.43**　I returned the page I had caught, and she shook the water off its edge.

> 私がつかまえたページを返すと、彼女は端についた水を振り落とした。

<a id="c252-44"></a>

**252.44**　‘We have until half past seven,’ the guard reminded them.

> 「使えるのは七時半までです」と警備員が念を押した。

<a id="c252-45"></a>

**252.45**　‘There's time to try something,’ said the cook, setting her bag under her chair.

> 「何か試す時間はあるわね」と料理係は言い、かばんを椅子の下に置いた。

<a id="c252-46"></a>

**252.46**　I hung the wet cloth over the back of a chair while the singer spread the sheets on the floor beside him.

> 私はぬれた布を椅子の背にかけ、その間に歌い手が自分の横の床へ紙を広げた。

<a id="c252-47"></a>

**252.47**　The cook opened her book at the blue thread, and he drew a breath.

> 料理係が青い糸の挟まったところで本を開き、彼は息を吸った。

### この話の用例索引

#### Grammar・Usage

| OLPG・PEUの該当項目 | 本文の用例 | 場面での働き |
|---|---|---|
| OLPG 161 Other ways of expressing a condition ／ PEU 247 unless | [252.05](#c252-05) “We'll stay outside unless it rains” | unlessで屋外にいる計画の例外を示す。実際に雨が強まると、歌い手たちが中へ移る条件が成立する。 |
| OLPG 161 Other ways of expressing a condition ／ PEU 248 in case and if | [252.07](#c252-07) “In case the papers get wet” ／ [252.26](#c252-26) “We'll come in if it gets worse” | in caseは紙がぬれる場合への事前の備えを、ifは雨がひどくなった場合に中へ入る行動を表す。布の準備と移動の時点が異なる。 |
| OLPG 67 Verbs taking either form ／ PEU 105 infinitives or -ing forms: both possible with different uses | [252.11](#c252-11) “tried singing towards the river” ／ [252.13](#c252-13) “tried closing the window” ／ [252.22](#c252-22) “tried to turn a page” | try＋-ingは向きや窓を変える方法を試す場面で使われる。try＋to不定詞は、風に妨げられながらページをめくろうとする動作を表す。 |
| OLPG 156 Type 0 and 1 conditionals ／ PEU 238 ordinary structures | [252.41](#c252-41) “If it stops, we can go out again” | 未来に雨がやむという可能性をif節の現在形で置き、その場合の再移動をcanで示す。時刻を確約できないことが友人から加えられる。 |
| OLPG 163 Noun clauses ／ PEU 266 interrogative (question-word) clauses | [252.40](#c252-40) “how long the rain would last” | how long以下の疑問の内容をtellの目的語として埋め込む。雨の継続時間がわからず、屋外練習の再開時刻を決められない状況を表す。 |

#### Conversation Modelの意味操作

| 操作と暫定下位分類 | 人物・本文位置 | 発言を受けて起きたこと |
|---|---|---|
| 反論 — 条件・例外 | 歌い手　[252.05](#c252-05)・[252.32](#c252-32) | 屋外で練習する案に雨という例外を置く。例外が現実になると三人は室内へ移り、別の人の読書との調整が必要になる。 |
| 反論 — 限定・留保 | 記録係　[252.17](#c252-17)・[252.19](#c252-19) | 自分が案内を読めたという結果に、内容を知っているという条件を加える。その結果だけで料理係も読めるとは判断せず、本人の評価を残す。 |
| 発展 — 推論・評価 | 歌い手の友人　[252.42](#c252-42) | 雨がやめば外へ戻れるという見込みを受け、やむ時刻まで確約できる根拠はないと判断する。 |
| 反論 — 代替・選好 | 料理係　[252.37](#c252-37) | 歌い手たちが室内で歌いたいという希望を受け、自分の読書の希望も残して示す。雨のため同じ部屋を使う状況に、双方の目的を残す。 |
| 発展 — 結果・帰結 | 料理係　[252.45](#c252-45) | 七時半までという利用時間の確認を受け、残る時間で調整を試せると応じる。かばんを自分の椅子の下へ置き、場に加わる。 |

---

<a id="story-253"></a>

## 253　小さくて大きな音

*The Smallest Loud Noise*

<a id="c253-01"></a>

**253.01**　Just after six, the first song reached the far wall.

> 六時を少し過ぎて、最初の歌が向こうの壁に届いた。

<a id="c253-02"></a>

**253.02**　By the second line, the wall appeared to have joined in.

> 二行目に入るころには、壁まで歌に加わったようだった。

<a id="c253-03"></a>

**253.03**　The cook stopped reading with one finger still holding her place.

> 料理係は、読んでいた場所に指を置いたまま読むのをやめた。

<a id="c253-04"></a>

**253.04**　The singer lowered the sheet he had taken from the blue file.

> 歌い手は、青い書類ばさみから取り出した歌の紙を下ろした。

<a id="c253-05"></a>

**253.05**　‘It was quieter outside,’ he said.

> 「外では、もっと静かだったんです」と彼は言った。

<a id="c253-06"></a>

**253.06**　‘There are only three of us.’

> 「私たちは三人だけなんですが」

<a id="c253-07"></a>

**253.07**　‘I have only one head,’ the cook replied, ‘and there is already a conversation in it.’

> 「私の頭は一つだけですけど、その中でもう会話が進んでいるんです」と料理係は答えた。

<a id="c253-08"></a>

**253.08**　She showed him a page on which a woman had been trying to enter a house for some time.

> ある女性が家に入ろうとして、しばらく入れずにいるページを、彼女は歌い手に見せた。

<a id="c253-09"></a>

**253.09**　The clerk looked from the three singers to the eight chairs.

> 記録係は三人の歌い手と八脚の椅子を見比べた。

<a id="c253-10"></a>

**253.10**　‘Would it help if we sat further apart?’

> 「もっと離れて座れば、少しよくなるでしょうか」

<a id="c253-11"></a>

**253.11**　‘Perhaps,’ said the cook, ‘but I would like to hear what happens at this door.’

> 「そうかもしれません。でも、私はこの戸口で何が起きるか聞きたいんです」と料理係は言った。

<a id="c253-12"></a>

**253.12**　She put the book on her knees and gave the singer her attention.

> 彼女は本を膝に置き、歌い手に目を向けた。

<a id="c253-13"></a>

**253.13**　‘I don't need silence all evening. I would like twenty quiet minutes at a time.’

> 「夜の間ずっと静かでなくてもいいんです。一度に二十分、静かな時間が欲しい」

<a id="c253-14"></a>

**253.14**　‘Could you sing more quietly?’ the clerk asked.

> 「もう少し小さな声で歌えますか」と記録係は尋ねた。

<a id="c253-15"></a>

**253.15**　The singer tried a line, and his friends joined him near the corner.

> 歌い手が一行歌ってみると、隅の近くで友人たちも声を合わせた。

<a id="c253-16"></a>

**253.16**　Their words came back across the room with considerable force.

> その言葉は、かなりの勢いで部屋を横切って返ってきた。

<a id="c253-17"></a>

**253.17**　The cook offered the clerk her chair for a moment.

> 料理係は、少しの間、自分の椅子に座ってみるよう記録係に勧めた。

<a id="c253-18"></a>

**253.18**　When the singer spoke her name, the clerk looked towards the window, although he was standing by the door.

> 歌い手が名前を呼ぶと、記録係は窓のほうを見た。彼が立っていたのは扉のそばだった。

<a id="c253-19"></a>

**253.19**　‘The room is rather generous with voices,’ she said.

> 「この部屋は、声をずいぶん気前よく配るんですね」と彼女は言った。

<a id="c253-20"></a>

**253.20**　‘Perhaps it could lend us a second pair of ears.’

> 「耳も、もう二つずつ貸してくれるかもしれません」

<a id="c253-21"></a>

**253.21**　‘Then I should have two conversations to follow,’ the cook said.

> 「そうしたら、追いかける会話が二つになってしまいます」と料理係は言った。

<a id="c253-22"></a>

**253.22**　The clerk stood up and returned the chair to her.

> 記録係は立ち上がって、彼女に椅子を返した。

<a id="c253-23"></a>

**253.23**　One of the singer's friends shook her head.

> 歌い手の友人の一人が首を振った。

<a id="c253-24"></a>

**253.24**　‘If we sing any more quietly, we'll hear only the rain.’

> 「これ以上声を小さくしたら、聞こえるのは雨だけになってしまうわ」

<a id="c253-25"></a>

**253.25**　The cook stood up and moved her chair a little to the side.

> 料理係は立ち上がり、自分の椅子を少し横へ動かした。

<a id="c253-26"></a>

**253.26**　‘That corner sends everything straight to my ear. Try facing the coats.’

> 「あの隅からは、何もかも私の耳へまっすぐ届くんです。コートのほうを向いてみてください」

<a id="c253-27"></a>

**253.27**　The coats hung near the entrance, heavy with water.

> コートは入口近くに掛かり、水を含んで重くなっていた。

<a id="c253-28"></a>

**253.28**　The guard pointed to the clear way between them and the door.

> 警備員は、コートと扉の間に空けてある通り道を指した。

<a id="c253-29"></a>

**253.29**　‘You can stand beside it, if you keep this way open.’

> 「ここを空けておいてくれれば、その脇に立ってもいいですよ」

<a id="c253-30"></a>

**253.30**　They moved closer together and turned towards the coats.

> 三人は互いに近づき、コートのほうを向いた。

<a id="c253-31"></a>

**253.31**　This time I could hear the singer without hearing quite so much of the wall.

> 今度は、壁から返ってくる声がいくらか減り、歌い手の声を聞き取れた。

<a id="c253-32"></a>

**253.32**　‘It is quieter,’ the cook said. ‘I still can't read.’

> 「静かにはなりました。でも、まだ読めません」と料理係は言った。

<a id="c253-33"></a>

**253.33**　The singer folded his paper along an old line.

> 歌い手は、以前の折り目に沿って紙を折った。

<a id="c253-34"></a>

**253.34**　‘Five minutes now, then twenty quiet ones?’ he asked.

> 「今、五分。その後は静かに二十分。それでどうでしょう」と彼は尋ねた。

<a id="c253-35"></a>

**253.35**　‘And after that?’

> 「その後は？」

<a id="c253-36"></a>

**253.36**　‘We'll ask again. The rain may have stopped by then.’

> 「また相談しましょう。そのころには雨がやんでいるかもしれません」

<a id="c253-37"></a>

**253.37**　The cook considered this, then laid the blue thread across the page and closed her book.

> 料理係は少し考えてから、青い糸をしおりにして本を閉じた。

<a id="c253-38"></a>

**253.38**　‘Five minutes. I shall be waiting for the other twenty.’

> 「五分ですね。その後の静かな二十分を、待っていますから」

<a id="c253-39"></a>

**253.39**　The railway worker had come in quietly and chosen a chair by the window. I offered to move it nearer the singers.

> 鉄道員は静かに入ってきて、窓のそばの椅子を選んでいた。私は、椅子をもっと歌い手たちに近づけようかと申し出た。

<a id="c253-40"></a>

**253.40**　‘I'd rather sit here,’ he said, beside the window.

> 「私はここに座っていたい」と、窓のそばにいた彼は言った。

<a id="c253-41"></a>

**253.41**　‘I can hear them very well, and I can look away when I want to.’

> 「よく聞こえるし、そうしたくなったら、目をそらすこともできるからね」

<a id="c253-42"></a>

**253.42**　He held a folded page between his hands.

> 彼は折り畳んだ紙を両手の間に挟んでいた。

<a id="c253-43"></a>

**253.43**　I left his chair where it was.

> 私は彼の椅子をそのままにした。

<a id="c253-44"></a>

**253.44**　The singer watched the guard's watch rather more carefully than his own paper.

> 歌い手は、自分の紙よりも警備員の腕時計を、かなり注意深く見ていた。

<a id="c253-45"></a>

**253.45**　At a quarter past six, the guard raised one finger.

> 六時十五分に、警備員が指を一本上げた。

<a id="c253-46"></a>

**253.46**　The three voices stopped together, leaving the last line for later.

> 三人の声は一緒に止まり、最後の一行は後に残った。

<a id="c253-47"></a>

**253.47**　The singer bowed to the coats, which had listened without moving.

> 歌い手はコートにお辞儀をした。コートは身じろぎもせず耳を傾けていた。

<a id="c253-48"></a>

**253.48**　The cook opened her book again.

> 料理係は再び本を開いた。

<a id="c253-49"></a>

**253.49**　Nobody asked the railway worker to turn his chair.

> 鉄道員に椅子の向きを変えるよう頼む人はいなかった。

<a id="c253-50"></a>

**253.50**　After a while, the cook smiled down at the page.

> しばらくして、料理係はページを見下ろしてほほえんだ。

<a id="c253-51"></a>

**253.51**　The woman had finally got into the house.

> 本の中の女性が、ようやく家に入れたのだ。

### この話の用例索引

#### Grammar・Usage

| OLPG・PEUの該当項目 | 本文の用例 | 場面での働き |
|---|---|---|
| OLPG 129 Focus, viewpoint, and truth adverbials ／ PEU 199 focusing adverbials | [253.06](#c253-06) “There are only three of us.” ／ [253.07](#c253-07) “I have only one head” | 歌い手は人数の少なさを only で示す。料理係も同じ語で自分の処理できる範囲を示し、少人数という情報だけでは読書への影響を判断できない場面になる。 |
| OLPG 131 Comparison of adjectives ／ OLPG 133 Comparison of adverbs and quantifiers ／ OLPG 134 Comparison: than, as, etc ／ PEU 204 comparative and superlative adjectives ／ PEU 205 comparative and superlative adverbs ／ PEU 206 using comparatives and superlatives ／ PEU 207 much older, by far the oldest, etc | [253.05](#c253-05) “It was quieter outside” ／ [253.32](#c253-32) “I still can't read.” ／ [253.44](#c253-44) “rather more carefully than his own paper” | 外や先ほどの状態との比較で quieter が使われる。音が小さくなっても料理係が読める水準には達していない。終盤の rather more carefully than は、歌い手が歌の紙以上に終了時刻を気にしている様子を示す。 |
| OLPG 157 Type 2 conditionals ／ PEU 239 special structures with past tenses and would | [253.10](#c253-10) “Would it help if we sat further apart?” | 離れて座る案を would と過去形の if 節で仮に置き、効果を相手に尋ねる。配置を変えれば解決すると先に決めず、料理係の必要を聞く余地ができる。 |
| OLPG 67 Verbs taking either form ／ PEU 105 infinitives or -ing forms: both possible with different uses | [253.26](#c253-26) “Try facing the coats.” | try に続く -ing 形が、向きを変えるという試す方法を示す。声量をさらに下げることに限界を感じた三人が、別の動作を実際に試す。 |
| OLPG 55 May, might, can, and could ／ PEU 71 chances: may, might and could | [253.36](#c253-36) “The rain may have stopped by then.” | may と完了形に by then が付き、次に相談する時点までに雨がやんでいる可能性を残す。その可能性だけで屋外へ戻る約束はせず、五分と二十分の後に相談し直す。 |

#### Conversation Modelの意味操作

| 操作と暫定下位分類 | 人物・本文位置 | 発言を受けて起きたこと |
|---|---|---|
| 発展 — 推論・評価 | 記録係　[253.10](#c253-10) | 歌が読書を妨げている状況から、距離を取れば改善するかという仮の見通しを提示する。効果を質問にして、料理係の反応や実際の聞こえ方で確かめられる形にする。 |
| 反論 — 限定・留保 | 料理係　[253.13](#c253-13) | 歌と読書が衝突している状況を受け、必要な静けさを一回二十分に限定する。全時間を同じ用途にする前提が緩み、交代で使う案が可能になる。 |
| 反論 — 代替・選好 | 料理係　[253.26](#c253-26) | これ以上声を小さくできないという友人の発言を受け、隅から自分の耳へ届く音の方向に注目して、コートへ向く案を出す。三人が実際に向きを変える。 |
| 発展 — 順序・時間的展開 | 歌い手　[253.34](#c253-34)・[253.36](#c253-36) | 向きを変えても料理係が読めないと分かり、歌う五分と静かな二十分を順に置く。その後の使い方は再び相談すると定め、今夜の進み方を組み直す。 |
| 反論 — 代替・選好 | 鉄道員　[253.40](#c253-40)・[253.41](#c253-41) | 近くへ椅子を動かすという私の申し出に、窓辺に残る希望を返す。よく聞こえることに加え、自分から目をそらせることも席を選ぶ理由になる。 |

---

<a id="story-254"></a>

## 254　刷り直せない一枚

*A Page That Could Not Be Printed Again*

<a id="c254-01"></a>

**254.01**　By seven, the railway worker had moved from the window to the table where I kept the spare paper.

> 七時には、鉄道員は窓のそばから、私が予備の紙を置いているテーブルへ移っていた。

<a id="c254-02"></a>

**254.02**　He opened the page he had been holding.

> 彼は持っていた紙を広げた。

<a id="c254-03"></a>

**254.03**　‘I wrote this after lunch,’ he said. ‘Would you listen to the beginning?’

> 「昼食の後に書いたんだ。書き出しを聞いてくれるかね」と彼は言った。

<a id="c254-04"></a>

**254.04**　I said I would, and moved my glass to make room for the page.

> 私は聞きますと答え、紙を置けるように自分のグラスを動かした。

<a id="c254-05"></a>

**254.05**　There were several short lines in blue ink, with a few words crossed out.

> 青いインクの短い行が何本かあり、いくつかの語には取り消す線が引かれていた。

<a id="c254-06"></a>

**254.06**　The first began, ‘At six I used to listen for a key.’

> 最初の行は「六時になると、私はよく鍵の音に耳を澄ませていた」で始まっていた。

<a id="c254-07"></a>

**254.07**　He waited until the singing near the entrance had stopped.

> 彼は入口近くで歌う声がやむのを待った。

<a id="c254-08"></a>

**254.08**　I turned to reach for a clean sheet and knocked the glass with my arm.

> 私がきれいな紙を取ろうと振り向くと、腕がグラスにぶつかった。

<a id="c254-09"></a>

**254.09**　I caught it before it fell, but the water had already spread across his writing.

> グラスが落ちる前に受け止めたが、水はもう彼の書いた文字の上に広がっていた。

<a id="c254-10"></a>

**254.10**　One word ran into another, and the spaces between them turned blue.

> 一つの語のインクが別の語へ流れ込み、語と語の間が青く染まった。

<a id="c254-11"></a>

**254.11**　I tried to lift the page.

> 私は紙を持ち上げようとした。

<a id="c254-12"></a>

**254.12**　It tore where my finger pressed against the wet edge.

> 指がぬれた端を押さえた場所で、紙が破れた。

<a id="c254-13"></a>

**254.13**　‘Leave it,’ he said.

> 「そのままにしてくれ」と彼は言った。

<a id="c254-14"></a>

**254.14**　I took my hand away.

> 私は手を離した。

<a id="c254-15"></a>

**254.15**　The clerk brought a clean cloth and laid it beside the page.

> 記録係がきれいな布を持ってきて、紙のそばに置いた。

<a id="c254-16"></a>

**254.16**　‘We can put it on this, if you like.’

> 「よければ、この上に置けます」

<a id="c254-17"></a>

**254.17**　He nodded, and together they moved it without pulling at the torn part.

> 彼はうなずき、二人は破れた部分を引っ張らないようにして、紙を移した。

<a id="c254-18"></a>

**254.18**　‘I'm sorry,’ I said. ‘I should have moved the glass further away.’

> 「すみません。グラスをもっと遠くへ動かしておくべきでした」と私は言った。

<a id="c254-19"></a>

**254.19**　He looked at the water on the table.

> 彼はテーブルの上の水を見た。

<a id="c254-20"></a>

**254.20**　‘Yes,’ he said.

> 「そうだね」と彼は言った。

<a id="c254-21"></a>

**254.21**　I had expected a longer answer and was ashamed that I had expected a kinder one.

> 私はもっと長い返事を予想していた。そして、もっと優しい返事を期待していた自分を恥じた。

<a id="c254-22"></a>

**254.22**　‘I can print it again,’ I said, reaching for the fresh paper.

> 「もう一度印刷できます」と私は言い、まっさらな紙に手を伸ばした。

<a id="c254-23"></a>

**254.23**　‘Again? You haven't printed it once.’

> 「もう一度？　まだ一度も印刷していないだろう」

<a id="c254-24"></a>

**254.24**　‘I meant a clean copy.’

> 「きれいな写し、という意味でした」

<a id="c254-25"></a>

**254.25**　‘I could make a clean copy myself, if I remembered every word.’

> 「全部の言葉を覚えていれば、きれいな写しは自分でも作れるよ」

<a id="c254-26"></a>

**254.26**　He pointed to the place where the last two lines had met.

> 彼は、最後の二行がにじんで重なった場所を指した。

<a id="c254-27"></a>

**254.27**　‘I had just found the word I wanted there.’

> 「そこに使いたい言葉が、ちょうど見つかったところだったんだ」

<a id="c254-28"></a>

**254.28**　If I had left the water elsewhere, those words would still be clear.

> 水を別の場所に置いていたら、あの言葉は今もはっきり読めるのに。

<a id="c254-29"></a>

**254.29**　That thought gave him nothing to read.

> そう考えても、彼が読めるものは何も増えなかった。

<a id="c254-30"></a>

**254.30**　The clerk asked whether he wanted us to leave him alone for a few minutes.

> 記録係は、数分間一人でいたいかと彼に尋ねた。

<a id="c254-31"></a>

**254.31**　‘You may stay,’ he said to her. ‘I don't want questions yet.’

> 「いてくれてもいいよ。ただ、まだ質問はしないでほしい」と彼は彼女に言った。

<a id="c254-32"></a>

**254.32**　She sat at the other end of the table and left her pencil beside her closed book.

> 彼女はテーブルの反対側に座り、閉じた帳面のそばに鉛筆を置いた。

<a id="c254-33"></a>

**254.33**　I found another cloth, carried the glass away and wiped the table.

> 私は別の布を見つけ、グラスを運び去ってテーブルを拭いた。

<a id="c254-34"></a>

**254.34**　I could manage that without asking him how.

> それなら、やり方を彼に聞かずにできた。

<a id="c254-35"></a>

**254.35**　The page had been folded twice.

> 紙は二度折り畳まれていた。

<a id="c254-36"></a>

**254.36**　Where the folds met, the ink formed a little square.

> 折り目が交わる所では、インクが小さな四角を作っていた。

<a id="c254-37"></a>

**254.37**　I could still see a dot above a letter, although the letter itself had gone.

> 文字そのものは消えていたが、その上にあった点はまだ見えた。

<a id="c254-38"></a>

**254.38**　On a printed page I would have known the size of that gap.

> 印刷したページなら、その空いた部分の大きさは分かっただろう。

<a id="c254-39"></a>

**254.39**　Here I had no way to measure it.

> ここでは、それを測るすべがなかった。

<a id="c254-40"></a>

**254.40**　He touched the dry edge once, as if making sure that the sheet was still there.

> 彼は、紙がまだそこにあることを確かめるように、乾いた端に一度触れた。

<a id="c254-41"></a>

**254.41**　After a while, he began trying words under his breath.

> しばらくして、彼は小声で言葉を試し始めた。

<a id="c254-42"></a>

**254.42**　Some he rejected at once.

> すぐに退ける言葉もあった。

<a id="c254-43"></a>

**254.43**　Sometimes he looked towards the window, as if the answer might arrive from that direction.

> ときには、答えがそちらから届くかもしれないというように、窓のほうを見た。

<a id="c254-44"></a>

**254.44**　‘Could I write down the parts you remember?’ I asked.

> 「覚えている部分を書き取ってもいいでしょうか」と私は尋ねた。

<a id="c254-45"></a>

**254.45**　He shook his head.

> 彼は首を振った。

<a id="c254-46"></a>

**254.46**　‘I want to hear them myself first.’

> 「まずは自分で聞いてみたい」

<a id="c254-47"></a>

**254.47**　I put the paper within his reach and returned to the wet cloth.

> 私は紙を彼の手の届く所に置き、ぬれた布のところへ戻った。

<a id="c254-48"></a>

**254.48**　The singer came to ask whether we wanted another song, then noticed the page and stopped.

> 歌い手が、もう一曲聞きたいかと尋ねに来たが、紙に気づいて立ち止まった。

<a id="c254-49"></a>

**254.49**　‘Later,’ the railway worker said. ‘Ask me later.’

> 「後で。また後で聞いてくれ」と鉄道員は言った。

<a id="c254-50"></a>

**254.50**　The singer went back to his friends.

> 歌い手は友人たちのもとへ戻った。

<a id="c254-51"></a>

**254.51**　‘Please don't tell people I've changed my mind about speaking,’ the railway worker said to me.

> 「話す気が変わったと、ほかの人に言わないでほしい」と鉄道員は私に言った。

<a id="c254-52"></a>

**254.52**　‘I haven't decided.’

> 「まだ決めていないんだ」

<a id="c254-53"></a>

**254.53**　‘I won't,’ I said.

> 「言いません」と私は答えた。

<a id="c254-54"></a>

**254.54**　He chose a pen and drew the clean sheet towards him.

> 彼はペンを一本選び、まっさらな紙を自分のほうへ引き寄せた。

<a id="c254-55"></a>

**254.55**　Then he wrote, ‘At six’.

> それから、「六時になると」と書いた。

### この話の用例索引

#### Grammar・Usage

| OLPG・PEUの該当項目 | 本文の用例 | 場面での働き |
|---|---|---|
| OLPG 58 Used to and dare ／ PEU 87 typical behaviour: used to + infinitive | [254.06](#c254-06) “At six I used to listen for a key.” | used to が、六時に鍵の音を待った過去の繰り返しを示す。今の六時との隔たりが、鉄道員自身の書いた最初の一行に表れる。 |
| OLPG 52 Should, ought to, had better, etc ／ PEU 76 weaker obligation: should and ought to | [254.18](#c254-18) “I should have moved the glass further away.” | should have moved が、グラスをもっと遠くへ動かしておくべきだったと過去を振り返る。私が配慮すべきだった位置を具体的に述べ、自分の行為を引き受ける。 |
| OLPG 30 The present perfect ／ PEU 47 present perfect: basic information | [254.23](#c254-23) “You haven't printed it once.” ／ [254.52](#c254-52) “I haven't decided.” | 現在完了の否定が、発話時点までの未実行を示す。一度も印刷していないことから again の前提が訂正され、最後には発言するかどうかの決定がまだ済んでいないと確認される。 |
| OLPG 35 Past perfect tenses ／ PEU 53 past perfect: basic information | [254.27](#c254-27) “I had just found the word I wanted there.” | 水にぬれた時点より前に、使いたい言葉を見つけていたことを過去完了で示す。just がその発見の新しさを添え、失われた箇所をすぐ書き直せるという私の見込みを、具体的な経緯が変える。 |
| OLPG 157 Type 2 conditionals ／ OLPG 158 Type 3 conditionals ／ OLPG 160 More about if ／ PEU 239 special structures with past tenses and would ／ PEU 241 unreal past situations | [254.25](#c254-25) “I could make a clean copy myself, if I remembered every word.” ／ [254.28](#c254-28) “If I had left the water elsewhere, those words would still be clear.” | 覚えていれば写せるという現在の仮定と、水の置き場所を変えていれば今も読めるという過去の条件が並ぶ。後者は過去完了の条件に現在の結果をつなぎ、失敗の影響が今の修復を難しくしていることを示す。 |
| OLPG 53 Can, could, may, and be allowed to ／ PEU 81 permission: can, could, may, might, be allowed to | [254.31](#c254-31) “You may stay” ／ [254.44](#c254-44) “Could I write down the parts you remember?” | may による同席の許可と could による書き取りの許可願いが、手伝い方を本人が選ぶ場面に使われる。同席は受け入れられ、書き取りはその時点では選ばれない。 |

#### Conversation Modelの意味操作

| 操作と暫定下位分類 | 人物・本文位置 | 発言を受けて起きたこと |
|---|---|---|
| 反論 — 修正 | 鉄道員　[254.23](#c254-23)・[254.27](#c254-27) | 私の「もう一度印刷できる」という申し出を受け、まだ一度も印刷していないという事実を示す。さらに見つけたばかりの言葉だったと伝え、きれいな紙を用意するだけでは修復が進まないことを明らかにする。 |
| 補足 — 明確化・言い換え | 記録係　[254.30](#c254-30) | 言葉を取り戻すことが難しいと分かった後、その場で望む人との距離を尋ねる。話を続けるかどうかを先取りせず、当面の手伝い方を本人が指定できる問いにする。 |
| 反論 — 条件・例外 | 鉄道員　[254.31](#c254-31) | 一人にするかという記録係の問いに、同席は受け入れつつ、まだ質問はしないでほしいと条件を付ける。記録係は帳面を閉じたまま、テーブルの反対側へ座る。 |
| 反論 — 代替・選好 | 鉄道員　[254.44](#c254-44)・[254.46](#c254-46) | 私が、鉄道員の覚えている部分を書き取ろうと申し出たのに対し、本人はまず自分で言葉の響きを聞きたいという方法を選ぶ。私は紙を手の届く所に置き、別の片付けへ戻る。 |
| 反論 — 限定・留保 | 鉄道員　[254.51](#c254-51)・[254.52](#c254-52) | 今すぐ話さず自分で書いている状態を受け、まだ決めていないことを示す。話すことへの意向が変わったという推測を、私が外へ伝えるのを止める。 |

---

<a id="story-255"></a>

## 255　役に立つ空欄

*The Useful Empty Line*

<a id="c255-01"></a>

**255.01**　At a quarter past seven, the guard reminded us that visitors would have to leave in fifteen minutes.

> 七時十五分に、警備員は、来場者には十五分後に退出してもらうことを私たちに念押しした。

<a id="c255-02"></a>

**255.02**　The railway worker looked up from his new page.

> 鉄道員は新しい紙から顔を上げた。

<a id="c255-03"></a>

**255.03**　He had written another line and left a wide space below it.

> 彼はもう一行書き、その下に広い空白を残していた。

<a id="c255-04"></a>

**255.04**　‘What I need is a way to carry the wet one without folding it,’ he said.

> 「必要なのは、ぬれたほうを折らずに持って帰る方法なんだ」と彼は言った。

<a id="c255-05"></a>

**255.05**　I found a shallow box and cut a piece of thick card to fit inside.

> 私は浅い箱を見つけ、中に入る大きさに厚紙を切った。

<a id="c255-06"></a>

**255.06**　He placed the old page on the card himself.

> 彼は自分で、元の紙を厚紙の上に置いた。

<a id="c255-07"></a>

**255.07**　The fresh sheet went into his pocket.

> 新しい紙は彼のポケットに収まった。

<a id="c255-08"></a>

**255.08**　The clerk's form lay beside the box, with a line for words that visitors wanted the museum to keep.

> 箱のそばには記録係の用紙があった。来場者が博物館に残してほしい言葉を書く欄が設けてあった。

<a id="c255-09"></a>

**255.09**　He looked at that line for a moment.

> 彼は少しの間、その欄を見た。

<a id="c255-10"></a>

**255.10**　‘Are you going to write any of this down?’

> 「このことを、何か書き留めるつもりかね」

<a id="c255-11"></a>

**255.11**　‘Only if you ask me to,’ she said.

> 「頼んでくださった場合だけです」と彼女は答えた。

<a id="c255-12"></a>

**255.12**　‘Then leave it empty tonight.’

> 「それなら、今夜は空けておいてくれ」

<a id="c255-13"></a>

**255.13**　‘I will.’

> 「そうします」

<a id="c255-14"></a>

**255.14**　‘The first line can stay in your head,’ he added to me. ‘Please leave it there for the moment.’

> 「最初の一行は、君の頭の中にあって構わない。ただ、今のところはそこに置いておいてくれ」と、彼は私に言い添えた。

<a id="c255-15"></a>

**255.15**　I nodded and held the box while he put on his coat.

> 私はうなずき、彼がコートを着る間、箱を持った。

<a id="c255-16"></a>

**255.16**　‘Thank you for the box,’ he said.

> 「箱はありがとう」と彼は言った。

<a id="c255-17"></a>

**255.17**　He took it with both hands and walked towards the entrance.

> 彼は両手で箱を受け取り、入口へ向かった。

<a id="c255-18"></a>

**255.18**　The singer moved aside for him.

> 歌い手は彼に道を譲った。

<a id="c255-19"></a>

**255.19**　‘We still owe you the end of the song.’

> 「歌の最後を、まだお聞かせしなくちゃいけませんね」

<a id="c255-20"></a>

**255.20**　‘Keep it until I ask,’ the railway worker said. ‘You may need it yourself.’

> 「私が頼むまで取っておいてくれ。君自身が必要になるかもしれないから」と鉄道員は言った。

<a id="c255-21"></a>

**255.21**　His mouth moved into a small smile, but he kept walking.

> 口元に小さな笑みが浮かんだが、彼は歩き続けた。

<a id="c255-22"></a>

**255.22**　At half past seven, the cook closed her book over the blue thread.

> 七時半に、料理係は青い糸を挟んで本を閉じた。

<a id="c255-23"></a>

**255.23**　‘I can wash the glasses, if someone will carry the water,’ she said.

> 「誰かが水を運んでくれるなら、グラスは洗えますよ」と彼女は言った。

<a id="c255-24"></a>

**255.24**　‘I will,’ I said, and picked up the empty bottle.

> 「私が運びます」と答え、私は空の瓶を持ち上げた。

<a id="c255-25"></a>

**255.25**　The clerk was gathering the notices when the singer offered to help with the chairs.

> 記録係が掲示を集めていると、歌い手が椅子の片付けを手伝うと申し出た。

<a id="c255-26"></a>

**255.26**　She turned over the plan inside the cupboard door and showed us where the chairs went in the store.

> 彼女は戸棚の扉の内側にある配置図を裏返し、保管室のどこへ椅子を戻すのか示した。

<a id="c255-27"></a>

**255.27**　‘Can you carry two together?’ I asked him.

> 「一度に二脚運べますか」と私は彼に尋ねた。

<a id="c255-28"></a>

**255.28**　‘I can.’

> 「運べます」

<a id="c255-29"></a>

**255.29**　‘So can I,’ said one of his friends.

> 「私も」と友人の一人が言った。

<a id="c255-30"></a>

**255.30**　The other friend went ahead to check that their way was clear.

> もう一人の友人は先に進み、通り道が空いていることを確かめた。

<a id="c255-31"></a>

**255.31**　Soon the chairs were travelling in pairs, with rather less noise than the people had made earlier.

> ほどなく椅子は二脚ずつ運ばれていった。その音は、先ほど人が立てていた音よりもずっと小さかった。

<a id="c255-32"></a>

**255.32**　The cook called me back before I poured away the last of the water.

> 私が最後の水を捨てる前に、料理係が呼び止めた。

<a id="c255-33"></a>

**255.33**　There was still a mark to wash from one glass.

> 一つのグラスに、まだ洗い落とす汚れが残っていた。

<a id="c255-34"></a>

**255.34**　She held it up, turned it towards the light and gave it back to me.

> 彼女はそれを持ち上げ、光のほうへ向けてから、私に返した。

<a id="c255-35"></a>

**255.35**　I washed it again.

> 私はもう一度洗った。

<a id="c255-36"></a>

**255.36**　The singer's friends put on their coats and waited while he found a missing sheet of music under a chair.

> 歌い手の友人たちはコートを着て待っていた。その間に彼は、見当たらなくなっていた楽譜を椅子の下で見つけた。

<a id="c255-37"></a>

**255.37**　This time he bowed to the chair before putting the paper into his blue file.

> 今度は彼は、椅子にお辞儀をしてから、紙を青い書類ばさみにしまった。

<a id="c255-38"></a>

**255.38**　By twenty to eight, all eight chairs were back in the store.

> 七時四十分までには、八脚の椅子がすべて保管室に戻っていた。

<a id="c255-39"></a>

**255.39**　The cook left with her book under her arm.

> 料理係は本を小脇に抱えて帰った。

<a id="c255-40"></a>

**255.40**　The clerk and I stayed to dry the table and return the glasses to the cupboard.

> 記録係と私は残り、テーブルを乾かしてグラスを戸棚に戻した。

<a id="c255-41"></a>

**255.41**　Twice I counted the eight glasses we had used.

> 使った八個のグラスを、私は二度数えた。

<a id="c255-42"></a>

**255.42**　Then we carried the table back to the store.

> それから、私たちはテーブルを保管室へ戻した。

<a id="c255-43"></a>

**255.43**　At ten to eight, the guard walked round the room with us.

> 七時五十分に、警備員は私たちと部屋を見て回った。

<a id="c255-44"></a>

**255.44**　He tried the door, checked the window and looked where the table had stood.

> 扉の具合を確かめ、窓を確認し、テーブルがあった場所を見た。

<a id="c255-45"></a>

**255.45**　‘Anything else?’ the clerk asked.

> 「ほかには？」と記録係は尋ねた。

<a id="c255-46"></a>

**255.46**　He picked up a small piece of paper and handed it to me.

> 彼は小さな紙切れを拾い、私に渡した。

<a id="c255-47"></a>

**255.47**　It was part of an old notice, containing only the word ‘tomorrow’.

> 古い掲示の切れ端で、「明日」という語だけが残っていた。

<a id="c255-48"></a>

**255.48**　I put it in my pocket.

> 私はそれをポケットに入れた。

<a id="c255-49"></a>

**255.49**　When the clock reached eight, all of us were outside and the guard was on his way home to make his father's dinner.

> 時計が八時を指したとき、私たちは全員外にいて、警備員は父親の夕食を作るため、家に向かっていた。

<a id="c255-50"></a>

**255.50**　The clerk carried her form under her coat.

> 記録係は用紙をコートの内側に入れて持っていた。

<a id="c255-51"></a>

**255.51**　The empty line was still dry.

> 空けたままの欄は、まだぬれていなかった。

### この話の用例索引

#### Grammar・Usage

| OLPG・PEUの該当項目 | 本文の用例 | 場面での働き |
|---|---|---|
| OLPG 25 Emphasis ／ PEU 274 cleft sentences: What I need is a rest. | [255.04](#c255-04) “What I need is a way to carry the wet one without folding it” | What I need is ... が、今ほしい助けを紙の運び方に焦点化する。私の次の行動が、写しを作ることから箱と厚紙を用意することへ進む。 |
| OLPG 75 Preposition + gerund ／ PEU 104 -ing forms after prepositions: without breaking eggs | [255.04](#c255-04) “without folding it” | without に続く -ing 形が、運ぶ際に避けたい動作を明示する。この条件に合う浅い箱と厚紙を選び、鉄道員が自分で紙を載せる。 |
| OLPG 17 Leaving out words after the auxiliary ／ PEU 279 ellipsis after auxiliary verbs ／ PEU 280 ellipsis: infinitives | [255.11](#c255-11) “Only if you ask me to” ／ [255.13](#c255-13) “‘I will.’” | ask me to の後では直前の write any of this down が省かれ、I will では leave it empty が受け継がれる。短い返答で、記録する条件と空欄にしておく約束がやり取りされる。 |
| OLPG 18 Too, either, so, and neither/nor ／ PEU 309 so am I, neither do they, etc | [255.29](#c255-29) “So can I” | 歌い手の I can に続く So can I が、友人も二脚ずつ運べると示す。共通する能力が、その場の片付けに加わる人手になる。 |
| OLPG 160 More about if ／ PEU 243 if . . . will | [255.23](#c255-23) “if someone will carry the water” | if 節の will が、誰かが水を運ぶ役を引き受けることを条件にする。料理係のグラス洗いの申し出に、私が運ぶと応じて作業を分担する。 |

#### Conversation Modelの意味操作

| 操作と暫定下位分類 | 人物・本文位置 | 発言を受けて起きたこと |
|---|---|---|
| 補足 — 焦点・関係づけ | 鉄道員　[255.04](#c255-04) | メモの言葉を取り戻そうとする時間の後で、今その場にいる私が手伝える問題を、ぬれた紙を持ち帰る方法へ絞る。元の紙を自分で持ち帰ることが具体的な用事になる。 |
| 反論 — 条件・例外 | 記録係　[255.11](#c255-11) | このことを書き留めるつもりかという鉄道員の問いに、本人から頼まれた場合という条件を示す。続く空欄にしてほしいという希望を受け入れる。 |
| 反論 — 限定・留保 | 鉄道員　[255.14](#c255-14)・[255.16](#c255-16) | 私が最初の一行をすでに聞いている状態を受け、その記憶を持つことは認めつつ、当面は外へ出さない範囲を指定する。箱への礼も、その時に助けられた事柄へ向ける。 |
| 反論 — 条件・例外 | 料理係　[255.23](#c255-23) | 来場時間が終わると、自分からグラス洗いを申し出て、水を運ぶ人がいることを条件に付ける。私がその役を引き受け、彼女が差し出す作業の範囲が具体化する。 |

---

<a id="story-256"></a>

## 256　返ってきた部屋

*The Room Returned*

<a id="c256-01"></a>

**256.01**　On Friday morning, the room looked ready for an ordinary day.

> 金曜の朝、部屋はいつもの一日を迎える準備ができているように見えた。

<a id="c256-02"></a>

**256.02**　Light from the window lay across the floor where the chairs had stood.

> 椅子を置いていた床には、日が差していた。

<a id="c256-03"></a>

**256.03**　The two boats were still there in the photograph.

> 二艘の舟は、相変わらず写真の中にあった。

<a id="c256-04"></a>

**256.04**　Below them, the space for a question was empty.

> その下の、問いを置くための場所は空いていた。

<a id="c256-05"></a>

**256.05**　The clerk was at the desk, adding up the hours we had given and the things we had used.

> 記録係は机に向かい、私たちが提供した時間と使った物を合計していた。

<a id="c256-06"></a>

**256.06**　Her form was open beside her.

> 彼女のそばには、昨夜の用紙が広げてあった。

<a id="c256-07"></a>

**256.07**　I could see the empty line from the door.

> 空欄は戸口からでも見えた。

<a id="c256-08"></a>

**256.08**　‘The museum has agreed to pay for one more evening,’ she said, showing me a letter.

> 「博物館が、もう一晩分の費用を出すことに同意してくれました」と彼女は言い、手紙を見せた。

<a id="c256-09"></a>

**256.09**　‘I've put down the same hours, subject to the guard's agreement.’

> 「警備員の同意を条件に、同じ時間を書いてあります」

<a id="c256-10"></a>

**256.10**　He came in carrying the book that showed his hours for the following week.

> 警備員が、翌週の勤務時間の載った帳面を持って入ってきた。

<a id="c256-11"></a>

**256.11**　On Thursday, his paid work would again end at eight.

> 木曜には、彼の賃金の出る勤務は再び八時に終わることになっていた。

<a id="c256-12"></a>

**256.12**　‘Can you both do the same jobs?’ he asked.

> 「二人とも、同じ仕事を引き受けられますか」と彼は尋ねた。

<a id="c256-13"></a>

**256.13**　‘I can,’ said the clerk.

> 「引き受けられます」と記録係は答えた。

<a id="c256-14"></a>

**256.14**　‘So can I,’ I said, though I looked at the place where the water had been.

> 「私もです」と私は言った。ただ、水を置いていた場所には目をやった。

<a id="c256-15"></a>

**256.15**　‘The paper will be on a different table next time.’

> 「次は紙を別のテーブルに置きます」

<a id="c256-16"></a>

**256.16**　‘Then there'll be two tables to bring back,’ the guard said.

> 「それなら、戻すテーブルが二つになりますね」と警備員は言った。

<a id="c256-17"></a>

**256.17**　I added the second table to my list of jobs.

> 私は自分の仕事の一覧に、二つ目のテーブルを加えた。

<a id="c256-18"></a>

**256.18**　The guard checked our names, the times, and the clear space marked round the door on the plan.

> 警備員は、私たちの名前と時刻、それから配置図に記された、戸の周りに空けておく場所を確認した。

<a id="c256-19"></a>

**256.19**　Then he signed and went to open the front door for the day's first visitor.

> それから署名し、その日最初の来場者のために玄関を開けに行った。

<a id="c256-20"></a>

**256.20**　The clerk checked the date on her phone.

> 記録係は携帯電話で日付を確かめた。

<a id="c256-21"></a>

**256.21**　I wrote ‘Thursday’ on the new sheet, followed by the day of the month and the month itself.

> 私は新しい紙に「木曜日」と書き、その後に日にちと月を書いた。

<a id="c256-22"></a>

**256.22**　Under that I put six to half past seven, with the room ready for checking at ten to eight.

> その下には、六時から七時半まで、部屋は七時五十分に点検を受けられる状態にする、と記した。

<a id="c256-23"></a>

**256.23**　‘By this afternoon, I'll have printed all four notices,’ I said.

> 「今日の午後までには、四枚の掲示を全部印刷し終えます」と私は言った。

<a id="c256-24"></a>

**256.24**　‘Let me read one before you print the other three.’

> 「残りの三枚を刷る前に、一枚読ませてください」

<a id="c256-25"></a>

**256.25**　I passed her the sheet, and she moved it into the light.

> 私が紙を渡すと、彼女は明るいところへ動かした。

<a id="c256-26"></a>

**256.26**　‘We still need to settle the first part of the evening.’

> 「まだ、最初の時間をどうするか決める必要がありますね」

<a id="c256-27"></a>

**256.27**　She rang the singer, who was at home with his two friends.

> 彼女は歌い手に電話をかけた。彼は二人の友人と家にいた。

<a id="c256-28"></a>

**256.28**　I heard her ask whether they could begin at twenty past six.

> 六時二十分に始められるか、彼女が尋ねるのが聞こえた。

<a id="c256-29"></a>

**256.29**　Then she listened for some time and wrote five minutes on her sheet.

> それからしばらく話を聞き、自分の紙に五分と書いた。

<a id="c256-30"></a>

**256.30**　‘They want to finish the whole song,’ she told me after the call.

> 「一曲を最後まで歌いたいそうです」と、電話の後で彼女は私に言った。

<a id="c256-31"></a>

**256.31**　‘Five minutes, then twenty minutes of quiet, as we tried last night.’

> 「五分歌って、その後は二十分静かにする。昨夜試したように」

<a id="c256-32"></a>

**256.32**　‘And if the cook wants to read from six?’

> 「料理係が六時から読みたいなら？」

<a id="c256-33"></a>

**256.33**　‘Ask her when you take this across.’

> 「これを向こうへ持っていくときに、尋ねてください」

<a id="c256-34"></a>

**256.34**　At the cafe, the cook was putting clean plates on a shelf.

> カフェでは、料理係が清潔な皿を棚に置いていた。

<a id="c256-35"></a>

**256.35**　I waited until she had put down the last one.

> 私は、彼女が最後の一枚を置くまで待った。

<a id="c256-36"></a>

**256.36**　She read the sheet with one hand still on the shelf.

> 彼女は片手を棚に置いたまま、その紙を読んだ。

<a id="c256-37"></a>

**256.37**　‘Quiet from six until twenty past,’ she said.

> 「六時から六時二十分までは静かなんですね」と彼女は言った。

<a id="c256-38"></a>

**256.38**　‘I can get through several pages in that time.’

> 「それだけあれば、何ページか読めます」

<a id="c256-39"></a>

**256.39**　She asked me to put those times on the notice as well.

> その時間も掲示に入れてほしいと、彼女は頼んだ。

<a id="c256-40"></a>

**256.40**　‘I'll check the new copy on my way home,’ she said.

> 「帰りに新しいものを確かめます」と彼女は言った。

<a id="c256-41"></a>

**256.41**　I took the sheet back to the shop and set it beside the print from Wednesday.

> 私は紙を店へ持ち帰り、水曜の印刷物の横に置いた。

<a id="c256-42"></a>

**256.42**　From my pocket I took the little piece that said ‘tomorrow’.

> ポケットから、「明日」と書かれた小さな紙切れを取り出した。

<a id="c256-43"></a>

**256.43**　I folded it twice and pushed it under the short leg of my chair.

> 私はそれを二度折り畳み、椅子の短い脚の下に押し込んだ。

<a id="c256-44"></a>

**256.44**　For the first time that morning, the chair stayed still while I worked.

> その朝初めて、仕事をしている間、椅子がぐらつかずにいてくれた。

### この話の用例索引

#### Grammar・Usage

| OLPG・PEUの該当項目 | 本文の用例 | 場面での働き |
|---|---|---|
| OLPG 30 The present perfect ／ PEU 47 present perfect: basic information | [256.08](#c256-08) “The museum has agreed to pay for one more evening” | 現在完了が、話し合いを経て今ある費用の承認を伝える。one more evening で回数を示し、この先の毎回の開催までは引き受けていない範囲にする。 |
| PEU 43 future in the past | [256.11](#c256-11) “his paid work would again end at eight” | 語りの基準である金曜朝から見た翌週木曜の予定を would で表す。費用の承認に加え、警備員の有給勤務の終了時刻を確認して次回を決める。 |
| OLPG 43 The future continuous and perfect ／ PEU 40 future perfect | [256.23](#c256-23) “By this afternoon, I'll have printed all four notices” | by と未来完了で、金曜の午後までに四枚の印刷を済ませる約束をする。印刷を始める時刻だけでなく、確認できる完成物がそろう期限を示す。 |
| OLPG 152 Clauses of time ／ PEU 231 tense simplification in subordinate clauses | [256.24](#c256-24) “Let me read one before you print the other three.” | これから行う印刷を、before の時間節では現在形 print で表す。先に一枚を読み、残り三枚を刷るという作業順が、前回の誤った予告を繰り返さないための手順になる。 |
| OLPG 169 Reporting questions ／ PEU 260 indirect speech: questions and answers | [256.28](#c256-28) “whether they could begin at twenty past six” | whether 節で歌い手たちへの問いの内容を伝える。開始時刻への同意を尋ねた後、電話の返事を聞いて五分の歌と二十分の静かな時間を紙に記す。 |

#### Conversation Modelの意味操作

| 操作と暫定下位分類 | 人物・本文位置 | 発言を受けて起きたこと |
|---|---|---|
| 反論 — 条件・例外 | 記録係　[256.09](#c256-09) | もう一晩分の費用の承認を受けても、同じ時間で開けるには警備員の同意が必要だと条件を残す。勤務の帳面と担当する仕事をその場で確認してから署名へ進む。 |
| 発展 — 結果・帰結 | 警備員　[256.16](#c256-16) | 私が水と紙を別のテーブルに置くと提案したことから、戻すテーブルも二つになると結果を示す。私は追加の運搬を自分の作業一覧に入れる。 |
| 発展 — 順序・時間的展開 | 記録係・歌い手　[256.28](#c256-28)・[256.31](#c256-31) | 次回の最初の時間を決める必要を受け、六時二十分の歌の開始、五分の歌、その後の二十分の静けさという順序を相談する。前夜に試した長さを、次回の具体的な予定へ置く。 |
| 補足 — 追加・詳述 | 料理係　[256.39](#c256-39) | 六時から六時二十分まで読めると確認した後、その時間も来場者向けの掲示に加えるよう頼む。開場時刻だけだった紙に、読書に使える時間の情報が追加される。 |

---
